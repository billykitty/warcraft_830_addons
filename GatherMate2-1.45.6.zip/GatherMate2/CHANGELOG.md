# GatherMate2

## [1.45.6](https://github.com/Nevcairiel/GatherMate2/tree/1.45.6) (2020-09-01)
[Full Changelog](https://github.com/Nevcairiel/GatherMate2/compare/1.45.5...1.45.6) [Previous Releases](https://github.com/Nevcairiel/GatherMate2/releases)

- Remove classic packaging  
- Use a different spell to get the "Herbalism" string  
    - On retail we can use a different spell to get the skill name directly  
    - On classic this fixes the string for non-ASCII names  
