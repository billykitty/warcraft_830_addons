# HandyNotes

## [v1.5.10](https://github.com/Nevcairiel/HandyNotes/tree/v1.5.10) (2020-04-27)
[Full Changelog](https://github.com/Nevcairiel/HandyNotes/compare/v1.5.9...v1.5.10)

- Update ToC  
- Add fallbacks for plugins that don't provide scale or alpha  
