PhanxFont
============

Simple font replacement and font scaling for the default UI. Type `/font` to
open the options panel, or find it in the standard Interface Options window.

* [Download on CurseForge](https://www.curseforge.com/wow/addons/phanxfont)
* [Download on WoWInterface](https://www.wowinterface.com/downloads/info24565-PhanxFont.html)
* [Report a bug on GitHub](https://github.com/phanx-wow/PhanxFont/issues)

Please note that I consider this addon to be complete, and I do not actively
play WoW anymore, so feature requests will *not* be considered.


Credits
----------

Based on [tekticles](https://github.com/TekNoLogic/tekticles) by Tekkub, which
was in turn based on ClearFont2 by Kirkburn.
