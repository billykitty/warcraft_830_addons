**80000.0**

- Updated for WoW 8.0

**70300.1**

- Fixed config panel errors

**70300.0**

- Initial release
