----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "frFR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateNPCsTable({
    [3037] = {
        name = "Sheza Crin-Sauvage",
    },
    [5164] = {
        name = "Grumnus Sculptacier",
    },
    [14720] = {
        name = "Haut seigneur Saurcroc",
    },
    [16802] = {
        name = "Lor’themar Theron",
    },
    [36648] = {
        name = "Baine Sabot-de-Sang",
    },
    [49748] = {
        name = "Héraut du héros",
    },
    [49750] = {
        name = "Héraut du chef de guerre",
    },
    [108017] = {
        name = "Torv Doublepas",
    },
    [120168] = {
        name = "Chroniqueur To'kini",
    },
    [120170] = {
        name = "Nathanos le Flétrisseur",
    },
    [120551] = {
        name = "Krag'wa le Colossal",
    },
    [120740] = {
        name = "Roi Rastakhan",
    },
    [120788] = {
        name = "Genn Grisetête",
    },
    [120904] = {
        name = "Princesse Talanji",
    },
    [120922] = {
        name = "Dame Jaina Portvaillant",
    },
    [121144] = {
        name = "Katherine Portvaillant",
    },
    [121239] = {
        name = "Flynn Bellebrise",
    },
    [121241] = {
        name = "Princesse Talanji",
    },
    [121288] = {
        name = "Princesse Talanji",
    },
    [121599] = {
        name = "Roi Rastakhan",
    },
    [121706] = {
        name = "Dresseuse de bêtes L'kala",
    },
    [122009] = {
        name = "Maître du kraal B'khor",
    },
    [122129] = {
        name = "Marchand Alexxi Cruzpot",
    },
    [122289] = {
        name = "Gardelame Kaja",
    },
    [122320] = {
        name = "Gardelame Kaja",
    },
    [122370] = {
        name = "Cirrus Lafalaise",
    },
    [122583] = {
        name = "Meera",
    },
    [122661] = {
        name = "Général Jakra'zet",
    },
    [122702] = {
        name = "Enchanteresse Quinni",
    },
    [122703] = {
        name = "Kumali l'Astucieuse",
    },
    [122706] = {
        name = "Théurgiste Salazae",
    },
    [122760] = {
        name = "Druidesse de guerre Loti",
    },
    [122795] = {
        name = "Féticheur Kejabu",
    },
    [122817] = {
        name = "Gardelame Kaja",
    },
    [122939] = {
        name = "Jeune navrecorne",
    },
    [122991] = {
        name = "Chasseuse des ombres Mutumba",
    },
    [123000] = {
        name = "Capitaine Rez'okun",
    },
    [123019] = {
        name = "Maître chasseur Vol'ka",
    },
    [123022] = {
        name = "Pisteur Burke",
    },
    [123026] = {
        name = "Erak le Distant",
    },
    [123063] = {
        name = "Ancien Kuppaka",
    },
    [123118] = {
        name = "Trappeur Custer",
    },
    [123178] = {
        name = "Rustine",
    },
    [123335] = {
        name = "Druidesse de guerre Loti",
    },
    [123526] = {
        name = "Tocant",
    },
    [123544] = {
        name = "Rustine",
    },
    [123545] = {
        name = "Triture",
    },
    [123548] = {
        name = "Tocant",
    },
    [123878] = {
        name = "Rustine",
    },
    [124062] = {
        name = "Roi Rastakhan",
    },
    [124063] = {
        name = "Jol l'Ancien",
    },
    [124289] = {
        name = "Liz « la Téméraire » Seminario",
    },
    [124376] = {
        name = "Féticheur Zentimo",
    },
    [124417] = {
        name = "Cyril Leblanc",
    },
    [124629] = {
        name = "Kaza'jin le Lieur de vagues",
    },
    [124630] = {
        name = "Garde de Kul Tiras\0",
    },
    [124641] = {
        name = "Chasseuse des ombres Mutumba",
    },
    [124655] = {
        name = "Roi Rastakhan",
    },
    [124802] = {
        name = "Seigneur Aldrius Norwington",
    },
    [124915] = {
        name = "Roi Rastakhan",
    },
    [124922] = {
        name = "Héléna Douceur",
    },
    [125039] = {
        name = "Marchand Kro",
    },
    [125041] = {
        name = "Sage aux parchemins Goji",
    },
    [125093] = {
        name = "Villageois de Havrebrune",
    },
    [125312] = {
        name = "Sage aux parchemins Rooka",
    },
    [125317] = {
        name = "Chasseuse des ombres Narez",
    },
    [125342] = {
        name = "Capitaine Keelson",
    },
    [125380] = {
        name = "Lucille Malvoie",
    },
    [125385] = {
        name = "Maréchal Everit Reade",
    },
    [125394] = {
        name = "Connétable Henry Collet",
    },
    [125486] = {
        name = "Chevauche-aile Nivek",
    },
    [125922] = {
        name = "Frère Therold",
    },
    [125962] = {
        name = "Gestionnaire Yerold",
    },
    [126039] = {
        name = "Mag'ash le Venimeux",
    },
    [126079] = {
        name = "Kol'jun Marchemort",
    },
    [126080] = {
        name = "Shinga Marchemort",
    },
    [126148] = {
        name = "Féticheuse Jala",
    },
    [126158] = {
        name = "Flynn Bellebrise",
    },
    [126210] = {
        name = "Fossoyeur Allen",
    },
    [126213] = {
        name = "Princesse Talanji",
    },
    [126225] = {
        name = "Aaron Crêteleux",
    },
    [126240] = {
        name = "Bridget Eaubelle",
    },
    [126298] = {
        name = "Brannon Chantorage",
    },
    [126511] = {
        name = "Dépeceur MacNimp",
    },
    [126560] = {
        name = "Druidesse de guerre Loti",
    },
    [126564] = {
        name = "Seigneur des maléfices Raal",
    },
    [126620] = {
        name = "Flynn Bellebrise",
    },
    [126804] = {
        name = "Saurolisque piégé",
    },
    [127015] = {
        name = "Thaddeus « grand-père » Rivefaille",
    },
    [127080] = {
        name = "Seigneur Valautomne",
    },
    [127112] = {
        name = "Maître-forge Zak'aal",
    },
    [127157] = {
        name = "Marcus Hurleval",
    },
    [127215] = {
        name = "Chasseur des ombres Da'jul",
    },
    [127216] = {
        name = "Zardrax l'Insuffleur",
    },
    [127391] = {
        name = "Cherche-sang Jo'chunga",
    },
    [127396] = {
        name = "Initiée Paeonia",
    },
    [127481] = {
        name = "Seigneur Kennings",
    },
    [127489] = {
        name = "Seigneur des maléfices Raal",
    },
    [127537] = {
        name = "Géraldine",
    },
    [127559] = {
        name = "Seigneur Aldrius Norwington",
    },
    [127570] = {
        name = "Gardelame Kaja",
    },
    [127646] = {
        name = "Seigneur Kennings",
    },
    [127715] = {
        name = "Lucille Malvoie",
    },
    [127743] = {
        name = "Tante Amanda Hale",
    },
    [127837] = {
        name = "Kaza'jin le Lieur de vagues",
    },
    [127961] = {
        name = "Princesse Talanji",
    },
    [127980] = {
        name = "Akunda le Sensé",
    },
    [127992] = {
        name = "Akunda l'Exalté",
    },
    [128228] = {
        name = "Sam l'Affamé",
    },
    [128229] = {
        name = "Jane la Pointe",
    },
    [128261] = {
        name = "Second Jamboya",
    },
    [128349] = {
        name = "Hilde Boutefeu",
    },
    [128353] = {
        name = "Pendi Tournemèche",
    },
    [128377] = {
        name = "Ramasseur d'épaves Bob",
    },
    [128381] = {
        name = "Drogtus Moussetache",
    },
    [128457] = {
        name = "Maude Rivefaille",
    },
    [128494] = {
        name = "Adela Aubepin",
    },
    [128618] = {
        name = "Maître des docks Herrington",
    },
    [128680] = {
        name = "Okri Heurteclef",
    },
    [129164] = {
        name = "Chroniqueur Jabari",
    },
    [129165] = {
        name = "Garde Sa'tao",
    },
    [129291] = {
        name = "Chef Tak",
    },
    [129392] = {
        name = "Henry « le désarmé »",
    },
    [129491] = {
        name = "Roi Rastakhan",
    },
    [129561] = {
        name = "Druidesse de guerre Loti",
    },
    [129642] = {
        name = "Lucille Malvoie",
    },
    [129643] = {
        name = "Maréchal Everit Reade",
    },
    [129670] = {
        name = "Lyssa Gardebois",
    },
    [129703] = {
        name = "Seigneur des maléfices Raal",
    },
    [129757] = {
        name = "Roi Rastakhan",
    },
    [129808] = {
        name = "Fermier Orchamp",
    },
    [129858] = {
        name = "Wulfred Bulléquerre",
    },
    [129907] = {
        name = "Zul le Prophète",
    },
    [129956] = {
        name = "Maître des docks Tyndall",
    },
    [129983] = {
        name = "Inquisitrice Aubeclaire",
    },
    [130101] = {
        name = "Recrue Brutis",
    },
    [130190] = {
        name = "Sergent Calvin",
    },
    [130216] = {
        name = "Magni Barbe-de-Bronze",
    },
    [130341] = {
        name = "Gardelame Kaja",
    },
    [130368] = {
        name = "Samuel D. Colton III\0",
    },
    [130375] = {
        name = "Tallis Coeur-Céleste",
    },
    [130377] = {
        name = "Messager Gérald",
    },
    [130399] = {
        name = "Zoé Encrenage",
    },
    [130424] = {
        name = "Henry « le désarmé »",
    },
    [130450] = {
        name = "Gardelame Sonji",
    },
    [130468] = {
        name = "P'tit Tika",
    },
    [130481] = {
        name = "Shinga Marchemort",
    },
    [130576] = {
        name = "Frère Pike",
    },
    [130603] = {
        name = "Brise-bête Hakid",
    },
    [130660] = {
        name = "Garde de guerre Rakera",
    },
    [130667] = {
        name = "Garde de guerre Rakera",
    },
    [130694] = {
        name = "Maire Roz",
    },
    [130697] = {
        name = "Capitaine des pompiers Jill",
    },
    [130706] = {
        name = "Esprit d'Izita",
    },
    [130714] = {
        name = "Frère Pike",
    },
    [130750] = {
        name = "Capitaine Grez'ko",
    },
    [130785] = {
        name = "Maître chasseur Kil'ja",
    },
    [130821] = {
        name = "Maîtresse des vagues Lanfa",
    },
    [130833] = {
        name = "Capitaine Grez'ko",
    },
    [130844] = {
        name = "Princesse Talanji",
    },
    [130901] = {
        name = "Chroniqueur Grazzul",
    },
    [130929] = {
        name = "Féticheuse Jangalar",
    },
    [131000] = {
        name = "Commandant Kellam",
    },
    [131003] = {
        name = "Spécialiste Wembley",
    },
    [131004] = {
        name = "Ecuyer Augustus III",
    },
    [131253] = {
        name = "Gardien des Titans Hezrel",
    },
    [131290] = {
        name = "Flynn Bellebrise",
    },
    [131354] = {
        name = "Mère des bêtes Jabati",
    },
    [131443] = {
        name = "Télémancien en chef Oculeth\0",
    },
    [131579] = {
        name = "Villageois captif",
    },
    [131580] = {
        name = "Apprenti télémancien Astrandis",
    },
    [131582] = {
        name = "Examinatrice Tae'shara Guette-le-Sang",
    },
    [131636] = {
        name = "Maréchal Everit Reade",
    },
    [131638] = {
        name = "Lucille Malvoie",
    },
    [131639] = {
        name = "Inquisitrice Masse",
    },
    [131640] = {
        name = "Inquisiteur Notley",
    },
    [131641] = {
        name = "Inquisiteur Yorrick",
    },
    [131642] = {
        name = "Inquisiteur Brislame",
    },
    [131654] = {
        name = "Mérédith",
    },
    [131656] = {
        name = "Dresseur de molosses Archibald",
    },
    [131657] = {
        name = "Compendium de l'effusion de sang",
    },
    [131684] = {
        name = "Penny « Mignonne » Hardwick",
    },
    [131763] = {
        name = "Excavateur Morgrum Braise-Silex",
    },
    [131775] = {
        name = "Bernard Joe",
    },
    [131777] = {
        name = "Acadia Cisepierre",
    },
    [131840] = {
        name = "Shuga Splosamorce",
    },
    [131879] = {
        name = "Inquisitrice Aubeclaire",
    },
    [132118] = {
        name = "Fermier Burton",
    },
    [132193] = {
        name = "Angus Ballast",
    },
    [132332] = {
        name = "Princesse Talanji",
    },
    [132333] = {
        name = "Princesse Talanji",
    },
    [132347] = {
        name = "Quentin Whalgrene",
    },
    [132617] = {
        name = "Bently Graissefeu",
    },
    [132720] = {
        name = "Maître des faucons Lloyd",
    },
    [132966] = {
        name = "Lynn Doucette",
    },
    [132988] = {
        name = "Rustine",
    },
    [132994] = {
        name = "Seigneur Arthur Malvoie",
    },
    [133035] = {
        name = "Officier Jovan",
    },
    [133050] = {
        name = "Princesse Talanji",
    },
    [133098] = {
        name = "Inquisitrice Aubeclaire",
    },
    [133101] = {
        name = "Samantha Douceur",
    },
    [133125] = {
        name = "Princesse Talanji",
    },
    [133324] = {
        name = "Seigneur des maléfices Raal",
    },
    [133476] = {
        name = "Princesse Talanji",
    },
    [133489] = {
        name = "Ormhun Martel-de-Pierre",
    },
    [133523] = {
        name = "Ji Patte de Feu",
    },
    [133536] = {
        name = "Grix « Poings de fer » Barlow",
    },
    [133550] = {
        name = "Apprenti mineur Joe",
    },
    [133551] = {
        name = "Mineur en chef Théock",
    },
    [133552] = {
        name = "Chimiste en chef Walters",
    },
    [133576] = {
        name = "Capiston Crochet",
    },
    [133577] = {
        name = "Maître artilleur Ligne",
    },
    [133578] = {
        name = "« Plomb »",
    },
    [133640] = {
        name = "Wayne l'Ancestral",
    },
    [133653] = {
        name = "Seigneur des maléfices Raal",
    },
    [133953] = {
        name = "Sergent Calvin",
    },
    [134009] = {
        name = "Habitante de Corlain",
    },
    [134133] = {
        name = "Tikcha",
    },
    [134166] = {
        name = "Flynn Bellebrise",
    },
    [134345] = {
        name = "Collectionneur Kojo",
    },
    [134408] = {
        name = "Contremaître Jephek",
    },
    [134509] = {
        name = "Chef des guides Tournezip",
    },
    [134628] = {
        name = "Ingénieur civil Alena",
    },
    [134639] = {
        name = "Frère Pike",
    },
    [134702] = {
        name = "Nedly le Grimacier",
    },
    [134720] = {
        name = "Léo Shealds",
    },
    [134752] = {
        name = "Maire Roz",
    },
    [134953] = {
        name = "Alexander Lemarchant",
    },
    [135021] = {
        name = "Inquisitrice Aubeclaire",
    },
    [135067] = {
        name = "Moxie Tourneclé",
    },
    [135085] = {
        name = "Capitaine Lilian Notley",
    },
    [135133] = {
        name = "Garde de guerre Rakera",
    },
    [135179] = {
        name = "Mert Arquemine",
    },
    [135200] = {
        name = "Alexander Lemarchant",
    },
    [135205] = {
        name = "Nathanos le Flétrisseur",
    },
    [135308] = {
        name = "Gardien des ailes Goja",
    },
    [135330] = {
        name = "Nedly le Grimacier",
    },
    [135355] = {
        name = "Meera",
    },
    [135367] = {
        name = "Grettle Tauribo",
    },
    [135517] = {
        name = "Garde-marée Victoria",
    },
    [135534] = {
        name = "Frère Pike",
    },
    [135541] = {
        name = "Incinérateur de Baille-Fonds",
    },
    [135612] = {
        name = "Halford Verroctone",
    },
    [135614] = {
        name = "Maître Mathias Shaw",
    },
    [135618] = {
        name = "Falstad Marteau-Hardi",
    },
    [135620] = {
        name = "Kelsey Etinçacier",
    },
    [135673] = {
        name = "Eclaireur McKellis",
    },
    [135681] = {
        name = "Grand amiral Jes-Tereth",
    },
    [135690] = {
        name = "Amiral de l'effroi Voguenille",
    },
    [135691] = {
        name = "Nathanos le Flétrisseur",
    },
    [135784] = {
        name = "Garde impérial",
    },
    [135793] = {
        name = "Collectionneur Kojo",
    },
    [135794] = {
        name = "Sage aux parchemins Nola",
    },
    [135801] = {
        name = "Seigneur des maléfices Raal",
    },
    [135855] = {
        name = "Tikai Bobinapédale",
    },
    [135861] = {
        name = "Adalyn Garde-Forêt",
    },
    [135874] = {
        name = "Léa Martinel",
    },
    [135890] = {
        name = "Roi Rastakhan",
    },
    [135901] = {
        name = "Fongicien rameau-de-feu",
    },
    [135976] = {
        name = "Morwin Plaine-Coeur",
    },
    [136041] = {
        name = "Emilie Beautemps",
    },
    [136059] = {
        name = "Layla Tirando\0",
    },
    [136140] = {
        name = "Clonk Graissemèche",
    },
    [136195] = {
        name = "Médecin Féoréa",
    },
    [136197] = {
        name = "Général de brigade Thom",
    },
    [136227] = {
        name = "Fixi Fourbesurin",
    },
    [136233] = {
        name = "Klause Bellebrise",
    },
    [136234] = {
        name = "Cési Frantir",
    },
    [136309] = {
        name = "Second Jamboya",
    },
    [136310] = {
        name = "Second Jamboya",
    },
    [136414] = {
        name = "Bergère Ruissemeule",
    },
    [136432] = {
        name = "Brann Barbe-de-Bronze",
    },
    [136458] = {
        name = "Cési Frantir",
    },
    [136497] = {
        name = "Garde-marée Victoria",
    },
    [136562] = {
        name = "Intendant Alfin",
    },
    [136568] = {
        name = "Capitaine Conrad",
    },
    [136574] = {
        name = "Charles Havreport",
    },
    [136576] = {
        name = "Maître des docks Leighton",
    },
    [136641] = {
        name = "Brann Barbe-de-Bronze",
    },
    [136645] = {
        name = "Brann Barbe-de-Bronze",
    },
    [136658] = {
        name = "Marie Havreport",
    },
    [136675] = {
        name = "Brann Barbe-de-Bronze",
    },
    [136683] = {
        name = "Prince marchand Gallywix",
    },
    [136779] = {
        name = "Second Jamboya",
    },
    [136907] = {
        name = "Magni Barbe-de-Bronze",
    },
    [136933] = {
        name = "Frère Pike",
    },
    [137008] = {
        name = "Sergent Ermey",
    },
    [137075] = {
        name = "Lieutenant Dennis Sombreconte",
    },
    [137094] = {
        name = "Fermier Max",
    },
    [137112] = {
        name = "Gardien des Titans Hezrel",
    },
    [137213] = {
        name = "Halford Verroctone",
    },
    [137337] = {
        name = "Sergent Ermey",
    },
    [137401] = {
        name = "Thane-enclume Thurgaden",
    },
    [137506] = {
        name = "Frère Pike",
    },
    [137543] = {
        name = "Sergent Ermey",
    },
    [137613] = {
        name = "Hobart Martelutte",
    },
    [137629] = {
        name = "Mékaru",
    },
    [137631] = {
        name = "Néri",
    },
    [137675] = {
        name = "Chasseur des ombres Ty'jin",
    },
    [137691] = {
        name = "Frère Pike",
    },
    [137694] = {
        name = "Parin Brikmédaille",
    },
    [137727] = {
        name = "Second O'toiles",
    },
    [137742] = {
        name = "Chasseur des ombres Ty'jin",
    },
    [137818] = {
        name = "Myxle « le rat des mers » Canevrille",
    },
    [137837] = {
        name = "Commandant Geya'rah",
    },
    [137867] = {
        name = "Halford Verroctone",
    },
    [137878] = {
        name = "Maître Gadrin",
    },
    [138138] = {
        name = "Princesse Talanji",
    },
    [138285] = {
        name = "Nathanos le Flétrisseur",
    },
    [138352] = {
        name = "Grand seigneur de guerre Cromush",
    },
    [138365] = {
        name = "Grand seigneur de guerre Cromush",
    },
    [138520] = {
        name = "Villageoise de Zeb'ahari",
    },
    [138521] = {
        name = "Technicien de mine",
    },
    [138688] = {
        name = "Centurion Kaga Pierre-Chaude",
    },
    [138708] = {
        name = "Garona Miorque",
    },
    [139061] = {
        name = "Nathanos le Flétrisseur",
    },
    [139069] = {
        name = "Second Redmond",
    },
    [139070] = {
        name = "Capitaine Redmond",
    },
    [139089] = {
        name = "Garde de Passegué",
    },
    [139568] = {
        name = "Magistère Umbric",
    },
    [139705] = {
        name = "Halford Verroctone",
    },
    [139719] = {
        name = "Shandris Pennelune",
    },
    [139722] = {
        name = "Explogénieur Méchazoïd",
    },
    [139912] = {
        name = "Forestier Wons",
    },
    [139926] = {
        name = "Parlépine Boulaie",
    },
    [139928] = {
        name = "Maître Gadrin",
    },
    [140046] = {
        name = "Rozzi",
    },
    [140048] = {
        name = "Arthur Alizé",
    },
    [140105] = {
        name = "Forestier-sombre",
    },
    [140176] = {
        name = "Nathanos le Flétrisseur",
    },
    [140258] = {
        name = "Shandris Pennelune",
    },
    [140484] = {
        name = "Capitaine Amalia Laroche",
    },
    [140485] = {
        name = "Nathanos le Flétrisseur",
    },
    [140495] = {
        name = "Katherine Portvaillant",
    },
    [140590] = {
        name = "Capitaine Grez'ko",
    },
    [140724] = {
        name = "Princesse Talanji",
    },
    [140725] = {
        name = "Esprit de Vol'jin",
    },
    [140752] = {
        name = "Jenny Viverive",
    },
    [141078] = {
        name = "Réfugié de la colline de la Vigie",
    },
    [141555] = {
        name = "Baine Sabot-de-Sang",
    },
    [141602] = {
        name = "Eaugure ressuscité",
    },
    [141603] = {
        name = "Mallory Boisseau",
    },
    [141643] = {
        name = "Traîne-griffe des grand fonds",
    },
    [141644] = {
        name = "Nathanos le Flétrisseur",
    },
    [141672] = {
        name = "Marin noyé",
    },
    [141769] = {
        name = "Marilyn Boisseau",
    },
    [141815] = {
        name = "Marin noyé",
    },
    [141952] = {
        name = "Navrecorne juvénile",
    },
    [142275] = {
        name = "Grommash Hurlenfer",
    },
    [142651] = {
        name = "Lucille Malvoie",
    },
    [142930] = {
        name = "Halford Verroctone",
    },
    [143536] = {
        name = "Grand seigneur de guerre Volrath",
    },
    [143559] = {
        name = "Connétable Tremblelame",
    },
    [143565] = {
        name = "Wayne l'Ancestral",
    },
    [143777] = {
        name = "Hasani le Grand",
    },
    [143845] = {
        name = "Commandant Geya'rah",
    },
    [143846] = {
        name = "Alleria Coursevent",
    },
    [143851] = {
        name = "Kelsey Etinçacier",
    },
    [143871] = {
        name = "Contremaître Mécapiston",
    },
    [143878] = {
        name = "Riiz Salpiège",
    },
    [143908] = {
        name = "Corps mutilé",
    },
    [144095] = {
        name = "Maître Mathias Shaw",
    },
    [145005] = {
        name = "Pérégrin d'élite",
    },
    [145022] = {
        name = "Tisse-temps Delormi",
    },
    [145131] = {
        name = "Crypto-gourou Gryzix",
    },
    [145190] = {
        name = "Princesse Talanji",
    },
    [145225] = {
        name = "Esprit de Vol'jin",
    },
    [145359] = {
        name = "Princesse Talanji",
    },
    [145411] = {
        name = "Dame Sylvanas Coursevent",
    },
    [145424] = {
        name = "Baine Sabot-de-Sang",
    },
    [145462] = {
        name = "Brann Barbe-de-Bronze",
    },
    [145464] = {
        name = "Conseiller Belgrum",
    },
    [145580] = {
        name = "Dame Jaina Portvaillant",
    },
    [145632] = {
        name = "Okri Heurteclef",
    },
    [145751] = {
        name = "Prince marchand Gallywix",
    },
    [145793] = {
        name = "Dame Liadrin",
    },
    [145816] = {
        name = "M.E.G.A.",
    },
    [145965] = {
        name = "Esprit de Vol'jin",
    },
    [145981] = {
        name = "Esprit de Vol'jin",
    },
    [146010] = {
        name = "Forestier-sombre Lyana",
    },
    [146011] = {
        name = "Varok Saurcroc",
    },
    [146013] = {
        name = "Forestier-sombre Alina",
    },
    [146050] = {
        name = "Maiev Chantelombre",
    },
    [146073] = {
        name = "Prince marchand Gallywix",
    },
    [146208] = {
        name = "Krag'wa le Colossal",
    },
    [146264] = {
        name = "Meera",
    },
    [146290] = {
        name = "Esprit de Vol'jin",
    },
    [146323] = {
        name = "Nathanos le Flétrisseur",
    },
    [146325] = {
        name = "Déchiqueteur Blix",
    },
    [146335] = {
        name = "Reine Talanji",
    },
    [146373] = {
        name = "Maiev Chantelombre",
    },
    [146374] = {
        name = "Shandris Pennelune",
    },
    [146375] = {
        name = "Sira Gardelune",
    },
    [146462] = {
        name = "Berserker de la Horde",
    },
    [146536] = {
        name = "Feu follet perdu",
    },
    [146601] = {
        name = "Sira Gardelune",
    },
    [146623] = {
        name = "M.E.G.A.",
    },
    [146630] = {
        name = "Esprit de Vol'jin",
    },
    [146654] = {
        name = "Dame Sylvanas Coursevent",
    },
    [146791] = {
        name = "Forestier-sombre",
    },
    [146806] = {
        name = "Forestier-sombre Lyana",
    },
    [146824] = {
        name = "Princesse Talanji",
    },
    [146877] = {
        name = "Princesse Talanji",
    },
    [146902] = {
        name = "Frère Pike",
    },
    [146921] = {
        name = "Princesse Talanji",
    },
    [146937] = {
        name = "Forestier-sombre",
    },
    [146939] = {
        name = "Ambassadrice Ligelaube",
    },
    [146982] = {
        name = "Dame Jaina Portvaillant",
    },
    [146988] = {
        name = "Terrassier Golad",
    },
    [147075] = {
        name = "Général Rakera",
    },
    [147088] = {
        name = "Arcaniste Valtrois",
    },
    [147135] = {
        name = "Nathanos le Flétrisseur",
    },
    [147145] = {
        name = "Nathanos le Flétrisseur",
    },
    [147149] = {
        name = "Morton Bois-Pignon",
    },
    [147151] = {
        name = "Kelsey Etinçacier",
    },
    [147155] = {
        name = "Rustine",
    },
    [147210] = {
        name = "Forestier-sombre Lyana",
    },
    [147293] = {
        name = "Défenseur da'kani",
    },
    [147311] = {
        name = "Morton Bois-Pignon",
    },
    [147519] = {
        name = "Kelsey Etinçacier",
    },
    [147819] = {
        name = "Maître-lame Telaamon",
    },
    [147842] = {
        name = "Dame Jaina Portvaillant",
    },
    [147843] = {
        name = "Maître Mathias Shaw",
    },
    [147844] = {
        name = "Maître-lame Telaamon",
    },
    [147939] = {
        name = "Pilote d'élite Tonnerouage",
    },
    [147943] = {
        name = "Capitaine Chape Etincetuyère",
    },
    [147950] = {
        name = "Capitaine de l'Engrenage Gueusécrou",
    },
    [147952] = {
        name = "Fizzi Bricolarc",
    },
    [148096] = {
        name = "Grand prélat Rata",
    },
    [148339] = {
        name = "Rustine",
    },
    [148798] = {
        name = "Dame Jaina Portvaillant",
    },
    [148870] = {
        name = "Dorlan Merrien",
    },
    [149084] = {
        name = "Marcheur des esprits Ussoh",
    },
    [149088] = {
        name = "Marcheuse des esprits Isahi",
    },
    [149143] = {
        name = "Nathanos le Flétrisseur",
    },
    [149252] = {
        name = "Ciel lié",
    },
    [149471] = {
        name = "Forestier-sombre Velonara",
    },
    [149503] = {
        name = "Capitaine de l'Engrenage Gueusécrou",
    },
    [149528] = {
        name = "Baine Sabot-de-Sang",
    },
    [149529] = {
        name = "Marcheur des esprits Ussoh",
    },
    [149612] = {
        name = "Shandris Pennelune",
    },
    [149736] = {
        name = "Image de Mimiron",
    },
    [149809] = {
        name = "Gazleu",
    },
    [149815] = {
        name = "Grizzek Moussemolette",
    },
    [149823] = {
        name = "Magni Barbe-de-Bronze",
    },
    [149842] = {
        name = "Baine Sabot-de-Sang",
    },
    [149864] = {
        name = "Maître-bricoleur Suprétincelle",
    },
    [149867] = {
        name = "Magni Barbe-de-Bronze",
    },
    [149870] = {
        name = "Grif Coeur-Sauvage",
    },
    [149877] = {
        name = "Maître-bricoleur Suprétincelle",
    },
    [149904] = {
        name = "Néri Tranchécaille",
    },
    [150086] = {
        name = "Déviss Voltétincelle",
    },
    [150087] = {
        name = "Genn Grisetête",
    },
    [150101] = {
        name = "Dame Jaina Portvaillant",
    },
    [150115] = {
        name = "Princesse Tess Grisetête",
    },
    [150145] = {
        name = "Gila Filkistouch",
    },
    [150187] = {
        name = "Nathanos le Flétrisseur",
    },
    [150196] = {
        name = "Première arcaniste Thalyssra",
    },
    [150200] = {
        name = "Messagère Claridge",
    },
    [150206] = {
        name = "Télémancien en chef Oculeth",
    },
    [150208] = {
        name = "Maître-bricoleur Suprétincelle",
    },
    [150209] = {
        name = "Néri Tranchécaille",
    },
    [150309] = {
        name = "Baine Sabot-de-Sang",
    },
    [150391] = {
        name = "Image de Mimiron",
    },
    [150433] = {
        name = "Gardienne des Hauts Fière-Balafre",
    },
    [150515] = {
        name = "Cirrus Lafalaise",
    },
    [150555] = {
        name = "Waren Biellecœur",
    },
    [150573] = {
        name = "Recycleur Klakrak",
    },
    [150574] = {
        name = "Dame Jaina Portvaillant",
    },
    [150630] = {
        name = "Flip Chargéclair",
    },
    [150631] = {
        name = "Pristie Chargéclair",
    },
    [150633] = {
        name = "Dame Jaina Portvaillant",
    },
    [150637] = {
        name = "Kelsey Etinçacier",
    },
    [150640] = {
        name = "Maître Mathias Shaw",
    },
    [150796] = {
        name = "Kelsey Etinçacier",
    },
    [150885] = {
        name = "Bête maccarbre",
    },
    [150893] = {
        name = "Sanctuaire de la Mer",
    },
    [150894] = {
        name = "Sanctuaire de la Nature",
    },
    [150895] = {
        name = "Sanctuaire des Sables",
    },
    [150896] = {
        name = "Sanctuaire du Brunant",
    },
    [150897] = {
        name = "Sanctuaire de l'Aube",
    },
    [150898] = {
        name = "Sanctuaire des Tempêtes",
    },
    [150956] = {
        name = "Foreuse cassée",
    },
    [151000] = {
        name = "Maître-lame Okani",
    },
    [151100] = {
        name = "Gila Filkistouch",
    },
    [151130] = {
        name = "Grizzek Moussemolette",
    },
    [151132] = {
        name = "Plumes",
    },
    [151134] = {
        name = "Tisse-temps Delormi",
    },
    [151137] = {
        name = "Couturière synchrone",
    },
    [151162] = {
        name = "Atikka « l'As » Chasse-Lune",
    },
    [151173] = {
        name = "Daniss Danse-Fantôme",
    },
    [151283] = {
        name = "Jeune navrecorne",
    },
    [151285] = {
        name = "Mevris Danse-Fantôme",
    },
    [151286] = {
        name = "Petit de Torcali",
    },
    [151462] = {
        name = "Danielle Pêchette",
    },
    [151626] = {
        name = "Chasseur Akana",
    },
    [151641] = {
        name = "Marcheur des esprits Corne-d'Ebène",
    },
    [151682] = {
        name = "Merithra du Rêve",
    },
    [151693] = {
        name = "Merithra du Rêve",
    },
    [151695] = {
        name = "Marcheur des esprits Corne-d'Ebène",
    },
    [151704] = {
        name = "Valithria Marcherêve",
    },
    [151741] = {
        name = "Apprenti Odari",
    },
    [151761] = {
        name = "Vassandra Grifforage",
    },
    [151784] = {
        name = "Mia Grisetête",
    },
    [151825] = {
        name = "Merithra du Rêve",
    },
    [151851] = {
        name = "Télémancien en chef Oculeth",
    },
    [151887] = {
        name = "Merithra du Rêve",
    },
    [151999] = {
        name = "Jo'nok, rempart de Torcali",
    },
    [152002] = {
        name = "Image de Mimiron",
    },
    [152047] = {
        name = "Poën Seldemer",
    },
    [152066] = {
        name = "Première arcaniste Thalyssra",
    },
    [152095] = {
        name = "Magni Barbe-de-Bronze",
    },
    [152108] = {
        name = "Eclaireuse goémline",
    },
    [152194] = {
        name = "D.A.M.E.",
    },
    [152206] = {
        name = "Magni Barbe-de-Bronze",
    },
    [152238] = {
        name = "Riathia Étoilargent",
    },
    [152316] = {
        name = "Image de Thalyssra",
    },
    [152385] = {
        name = "Chaman de Haut-Roc",
    },
    [152484] = {
        name = "Maître-bricoleur Suprétincelle",
    },
    [152489] = {
        name = "Sanctuaire des Tempêtes",
    },
    [152490] = {
        name = "Sanctuaire de l'Aube",
    },
    [152493] = {
        name = "Sanctuaire des Sables",
    },
    [152495] = {
        name = "Sanctuaire de la Mer",
    },
    [152496] = {
        name = "Sanctuaire de la Nature",
    },
    [152497] = {
        name = "Sanctuaire du Brunant",
    },
    [152504] = {
        name = "Gazleu",
    },
    [152522] = {
        name = "Gazleu",
    },
    [152578] = {
        name = "Gazleu",
    },
    [152652] = {
        name = "Gazleu",
    },
    [152747] = {
        name = "Christy Percerouage",
    },
    [152783] = {
        name = "Gazleu",
    },
    [152815] = {
        name = "Magni Barbe-de-Bronze",
    },
    [152845] = {
        name = "Gazleu",
    },
    [152864] = {
        name = "Maître-bricoleur Suprétincelle",
    },
    [153253] = {
        name = "Dame Jaina Portvaillant",
    },
    [153365] = {
        name = "Reine de l'essaim dos-de-miel",
    },
    [153385] = {
        name = "Maître-lame Okani",
    },
    [153422] = {
        name = "Télémancien en chef Oculeth",
    },
    [153512] = {
        name = "Trouveur Pruc",
    },
    [153514] = {
        name = "Trouveuse Palta",
    },
    [153617] = {
        name = "Shandris Pennelune",
    },
    [153670] = {
        name = "Résistant de Mécarouille",
    },
    [153932] = {
        name = "Genn Grisetête",
    },
    [153936] = {
        name = "Surveillant Hajeer",
    },
    [154002] = {
        name = "Atolia Perlemer",
    },
    [154023] = {
        name = "Butineuse naissante",
    },
    [154143] = {
        name = "Collectionneur Kojo",
    },
    [154248] = {
        name = "Maître-lame Inowari",
    },
    [154257] = {
        name = "Instructeur Ulouaka",
    },
    [154418] = {
        name = "Ra Den",
    },
    [154444] = {
        name = "Parlorage Qian",
    },
    [154514] = {
        name = "Kelya Tombelune",
    },
    [154520] = {
        name = "Première arcaniste Thalyssra",
    },
    [154522] = {
        name = "Shandris Pennelune",
    },
    [154532] = {
        name = "Magni Barbe-de-Bronze",
    },
    [154533] = {
        name = "Magni Barbe-de-Bronze",
    },
    [154574] = {
        name = "Kelya Tombelune",
    },
    [154601] = {
        name = "Kelya Tombelune",
    },
    [154607] = {
        name = "Image de Torcali",
    },
    [154640] = {
        name = "Connétable Tremblelame",
    },
    [154660] = {
        name = "Shandris Pennelune",
    },
    [154661] = {
        name = "Première arcaniste Thalyssra",
    },
    [154958] = {
        name = "Travailleur Mitchell",
    },
    [155071] = {
        name = "Shandris Pennelune",
    },
    [155095] = {
        name = "Roi Phaoris",
    },
    [155102] = {
        name = "Grande exploratrice Dellorah",
    },
    [155325] = {
        name = "Première arcaniste Thalyssra",
    },
    [155336] = {
        name = "Guerrier mogu",
    },
    [155482] = {
        name = "Sentinelle",
    },
    [155496] = {
        name = "Irion",
    },
    [155562] = {
        name = "Maître pandashan",
    },
    [155785] = {
        name = "Dame Jaina Portvaillant",
    },
    [155786] = {
        name = "Varok Saurcroc",
    },
    [156003] = {
        name = "Chroniqueur Cho",
    },
    [156297] = {
        name = "Chen Brune d'Orage",
    },
    [156390] = {
        name = "Chen Brune d'Orage",
    },
    [156391] = {
        name = "Li Li Brune d'Orage",
    },
    [156396] = {
        name = "Chipie Serrelavis",
    },
    [156423] = {
        name = "Dame Sylvanas Coursevent",
    },
    [156425] = {
        name = "Forestier-sombre Lenara",
    },
    [156440] = {
        name = "Nathanos le Flétrisseur",
    },
    [156520] = {
        name = "Hobart Martelutte",
    },
    [156542] = {
        name = "Mani Graissemèche",
    },
    [156937] = {
        name = "Chen Brune d'Orage",
    },
    [156938] = {
        name = "Li Li Brune d'Orage",
    },
    [157180] = {
        name = "Tonneaux de Brune d'Orage abandonnés",
    },
    [157491] = {
        name = "Hobart Martelutte",
    },
    [157668] = {
        name = "Meera",
    },
    [157997] = {
        name = "Kelsey Etinçacier",
    },
    [158672] = {
        name = "Vulpérine téméraire",
    },
    [159544] = {
        name = "Arik Dard-de-Scorpide",
    },
    [159560] = {
        name = "Voltigeur Lashan",
    },
    [159587] = {
        name = "Gelbin Mekkanivelle",
    },
    [159682] = {
        name = "Pisteuse Samara",
    },
    [159820] = {
        name = "Soigneur Dyrin",
    },
    [159920] = {
        name = "Zahra Traque-Sable",
    },
    [160101] = {
        name = "Kelsey Etinçacier",
    },
    [160232] = {
        name = "Christy Percerouage",
    },
    [161031] = {
        name = "Capitaine Hadan",
    },
    [161805] = {
        name = "Magni Barbe-de-Bronze",
    },
})
]])()
