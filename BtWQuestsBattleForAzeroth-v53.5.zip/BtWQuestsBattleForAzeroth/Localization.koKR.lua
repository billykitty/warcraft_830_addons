----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "koKR" then
    return
end

local L = BtWQuests.L
L["ALLIED_RACE_MECHAGNOME"] = "Allied Race: 기계노움"
L["ALLIED_RACE_VULPERA"] = "Allied Race: 불페라"
L["BTWQUESTS_COSMETIC_WAIST_OF_TIME"] = "장식: 금쪽같은 시간을 버려낸 허리띠"
L["BTWQUESTS_GIFT_OF_NZOTH"] = "느조스의 선물"
L["BTWQUESTS_HATI_REBORN"] = "다시 태어난 하티"
L["BTWQUESTS_HERITAGE_OF_GILNEAS"] = "길니아스의 유산"
L["BTWQUESTS_HERITAGE_OF_GNOMEREGAN"] = "놈리건의 유산"
L["BTWQUESTS_HERITAGE_OF_KEZAN"] = "케잔의 유산"
L["BTWQUESTS_HERITAGE_OF_THE_BRONZEBEARD"] = "브론즈비어드의 유산"
L["BTWQUESTS_HERITAGE_OF_THE_SHUHALO"] = "슈할로의 유산"
L["BTWQUESTS_HERITAGE_OF_THE_SINDOREI"] = "신도레이의 유산"
L["BTWQUESTS_MAGHAR_ORC"] = "마그하르 오크"
L["BTWQUESTS_NIGHT_WARRIOR_NIGHT_ELF_CUSTOMIZATION"] = "나이트 엘프 '밤 전사' 외형"
L["BTWQUESTS_THE_WAR_CAMPAIGN"] = "전쟁 대장정"
L["BTWQUESTS_THE_WAR_CAMPAIGN_8_1"] = "전쟁 대장정: 다자알로 전투"
L["BTWQUESTS_WARFRONT_THE_BATTLE_FOR_DARKSHORE"] = "격전지: 격전의 어둠해안"
L["DUNGEON_KINGS_REST"] = "던전: 왕들의 안식처"
L["DUNGEON_SIEGE_OF_BORALUS"] = "던전: 보랄러스 공성전"
L["MECHAGNOME"] = "기계노움"
L["VULPERA"] = "불페라"
L["WAIST_OF_TIME"] = "금쪽같은 시간을 버려낸 허리띠"
