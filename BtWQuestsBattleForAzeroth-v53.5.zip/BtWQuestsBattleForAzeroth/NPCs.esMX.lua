----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "esMX" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateNPCsTable({
    [3037] = {
        name = "Sheza Ferocrín",
    },
    [5164] = {
        name = "Grumnus Forjacero",
    },
    [14720] = {
        name = "Alto señor supremo Colmillosauro",
    },
    [15192] = {
        name = "Anacronos",
    },
    [36648] = {
        name = "Baine Pezuña de Sangre",
    },
    [49748] = {
        name = "Heraldo del héroe",
    },
    [49750] = {
        name = "Heraldo del Jefe de Guerra",
    },
    [108017] = {
        name = "Torv Pasodoble",
    },
    [120168] = {
        name = "Cronista To'kini",
    },
    [120170] = {
        name = "Nathanos Clamañublo",
    },
    [120551] = {
        name = "Krag'wa el Enorme",
    },
    [120740] = {
        name = "Rey Rastakhan",
    },
    [120788] = {
        name = "Genn Cringris",
    },
    [120904] = {
        name = "Princesa Talanji",
    },
    [120922] = {
        name = "Lady Jaina Valiente",
    },
    [121144] = {
        name = "Katherine Valiente",
    },
    [121239] = {
        name = "Flynn Vientopropicio",
    },
    [121241] = {
        name = "Princesa Talanji",
    },
    [121288] = {
        name = "Princesa Talanji",
    },
    [121599] = {
        name = "Rey Rastakhan",
    },
    [121706] = {
        name = "Señora de las bestias L'kala",
    },
    [122009] = {
        name = "Maestro del redil B'khor",
    },
    [122129] = {
        name = "Comerciante Alexxi Crisopeya",
    },
    [122289] = {
        name = "Guardafilada Kaja",
    },
    [122320] = {
        name = "Guardafilada Kaja",
    },
    [122370] = {
        name = "Cyrus Catacresta",
    },
    [122672] = {
        name = "Olivia",
    },
    [122702] = {
        name = "Encantadora Quinni",
    },
    [122703] = {
        name = "Kumali la Lista",
    },
    [122706] = {
        name = "Teúrga Salazae",
    },
    [122760] = {
        name = "Druida de guerra Loti",
    },
    [122795] = {
        name = "Médico brujo Kejabu",
    },
    [122817] = {
        name = "Guardafilada Kaja",
    },
    [122939] = {
        name = "Prole de cuernoatroz",
    },
    [122991] = {
        name = "Cazadora de las Sombras Mutumba",
    },
    [123000] = {
        name = "Capitán Rez'okun",
    },
    [123019] = {
        name = "Maestra de caza Vol'ka",
    },
    [123022] = {
        name = "Rastreador Burke",
    },
    [123026] = {
        name = "Erak el Distante",
    },
    [123063] = {
        name = "Anciano Kuppaka",
    },
    [123118] = {
        name = "Trampero Custer",
    },
    [123178] = {
        name = "Parche",
    },
    [123335] = {
        name = "Druida de guerra Loti",
    },
    [123526] = {
        name = "Tictac",
    },
    [123544] = {
        name = "Parche",
    },
    [123545] = {
        name = "Salamandra",
    },
    [123548] = {
        name = "Tictac",
    },
    [123878] = {
        name = "Parche",
    },
    [124062] = {
        name = "Rey Rastakhan",
    },
    [124063] = {
        name = "Jol el Anciano",
    },
    [124289] = {
        name = "Liz \"la Riesgosa\" Seminario",
    },
    [124376] = {
        name = "Médico brujo Zentimo",
    },
    [124629] = {
        name = "Kaza'jin el Vinculaolas",
    },
    [124630] = {
        name = "Guardia kultirana",
    },
    [124641] = {
        name = "Cazadora de las Sombras Mutumba",
    },
    [124655] = {
        name = "Rey Rastakhan",
    },
    [124915] = {
        name = "Rey Rastakhan",
    },
    [125039] = {
        name = "Comerciante Kro",
    },
    [125041] = {
        name = "Sabio de pergaminos Goji",
    },
    [125093] = {
        name = "Habitante de Albergue del Ocaso",
    },
    [125312] = {
        name = "Sabia de pergaminos Rooka",
    },
    [125317] = {
        name = "Cazadora de las Sombras Narez",
    },
    [125342] = {
        name = "Capitana Keelson",
    },
    [125380] = {
        name = "Lucille Crestavía",
    },
    [125385] = {
        name = "Mariscal Everit Reade",
    },
    [125394] = {
        name = "Alguacil Henry Framer",
    },
    [125486] = {
        name = "Alajinete Nivek",
    },
    [125922] = {
        name = "Hermano Therold",
    },
    [125962] = {
        name = "Gerente Yerold",
    },
    [126039] = {
        name = "Mag'ash el Venenoso",
    },
    [126079] = {
        name = "Caminamuerte Kol'jun",
    },
    [126080] = {
        name = "Caminamuerte Shinga",
    },
    [126148] = {
        name = "Médica bruja Jala",
    },
    [126158] = {
        name = "Flynn Vientopropicio",
    },
    [126210] = {
        name = "Custodio Allen",
    },
    [126213] = {
        name = "Princesa Talanji",
    },
    [126240] = {
        name = "Bridget Aguaclara",
    },
    [126298] = {
        name = "Brannon Canto Tormenta",
    },
    [126560] = {
        name = "Druida de guerra Loti",
    },
    [126564] = {
        name = "Señor de los maleficios Raal",
    },
    [126620] = {
        name = "Flynn Vientopropicio",
    },
    [126804] = {
        name = "Saurolisco atrapado",
    },
    [126814] = {
        name = "Rinah",
    },
    [127015] = {
        name = "Abuelo Thaddeus Fuertefalla",
    },
    [127080] = {
        name = "Lord Valleotoño",
    },
    [127112] = {
        name = "Maestro de forja Zak'aal",
    },
    [127157] = {
        name = "Marcus Aullavalle",
    },
    [127215] = {
        name = "Cazador de las Sombras Da'jul",
    },
    [127216] = {
        name = "Zardrax el Potenciador",
    },
    [127391] = {
        name = "Buscasangre Jo'chenga",
    },
    [127396] = {
        name = "Iniciada Peony",
    },
    [127489] = {
        name = "Señor de los maleficios Raal",
    },
    [127492] = {
        name = "Mallo",
    },
    [127570] = {
        name = "Guardafilada Kaja",
    },
    [127715] = {
        name = "Lucille Crestavía",
    },
    [127743] = {
        name = "Tía Amanda Hale",
    },
    [127837] = {
        name = "Kaza'jin el Vinculaolas",
    },
    [127961] = {
        name = "Princesa Talanji",
    },
    [127980] = {
        name = "Akunda de la Sensatez",
    },
    [127992] = {
        name = "Akunda de la Exaltación",
    },
    [128228] = {
        name = "Sam el Hambriento",
    },
    [128229] = {
        name = "Jane Puñaladas",
    },
    [128261] = {
        name = "Contramaestre Jamboya",
    },
    [128276] = {
        name = "Jo'chenga",
    },
    [128349] = {
        name = "Hilde Rompefuegos",
    },
    [128353] = {
        name = "Pendi Doblafusible",
    },
    [128377] = {
        name = "Peinaplayas Bob",
    },
    [128381] = {
        name = "Drogrin Barbacerveza",
    },
    [128457] = {
        name = "Maude Fuertefalla",
    },
    [128618] = {
        name = "Maestro de embarcadero Herrington",
    },
    [128679] = {
        name = "Rosalina Madison",
    },
    [128680] = {
        name = "Okri Tirallave",
    },
    [129164] = {
        name = "Cronista Jabari",
    },
    [129165] = {
        name = "Guarda Satao",
    },
    [129291] = {
        name = "Jefe Tak",
    },
    [129378] = {
        name = "Jo'chenga",
    },
    [129392] = {
        name = "Henry el \"Indefenso\"",
    },
    [129491] = {
        name = "Rey Rastakhan",
    },
    [129561] = {
        name = "Druida de guerra Loti",
    },
    [129642] = {
        name = "Lucille Crestavía",
    },
    [129643] = {
        name = "Mariscal Everit Reade",
    },
    [129670] = {
        name = "Lyssa Custodiárbol",
    },
    [129703] = {
        name = "Señor de los maleficios Raal",
    },
    [129757] = {
        name = "Rey Rastakhan",
    },
    [129808] = {
        name = "Granjero Campodorado",
    },
    [129858] = {
        name = "Wulferd Burbujeta",
    },
    [129907] = {
        name = "Zul el Profeta",
    },
    [129956] = {
        name = "Maestro de embarcadero Tyndall",
    },
    [129983] = {
        name = "Inquisidora Albaclara",
    },
    [130101] = {
        name = "Recluta Brutis",
    },
    [130190] = {
        name = "Sargento Calvin",
    },
    [130216] = {
        name = "Magni Barbabronce",
    },
    [130341] = {
        name = "Guardafilada Kaja",
    },
    [130375] = {
        name = "Tallis Almacielo",
    },
    [130377] = {
        name = "Mensajero Gerald",
    },
    [130399] = {
        name = "Zooey Tintengranaje",
    },
    [130424] = {
        name = "Henry el \"Indefenso\"",
    },
    [130450] = {
        name = "Guardafilada Sonji",
    },
    [130468] = {
        name = "Pequeña Tika",
    },
    [130481] = {
        name = "Caminamuerte Shinga",
    },
    [130576] = {
        name = "Hermano Pike",
    },
    [130603] = {
        name = "Rompebestias Hakid",
    },
    [130660] = {
        name = "Guardia bélica Rakera",
    },
    [130667] = {
        name = "Guardia bélica Rakera",
    },
    [130694] = {
        name = "Alcaldesa Roz",
    },
    [130697] = {
        name = "Bombera Jill",
    },
    [130706] = {
        name = "Espíritu de Izita",
    },
    [130714] = {
        name = "Hermano Pike",
    },
    [130750] = {
        name = "Capitán Grez'ko",
    },
    [130785] = {
        name = "Maestra de caza Kil'ja",
    },
    [130821] = {
        name = "Maestra de las olas Lanfa",
    },
    [130833] = {
        name = "Capitán Grez'ko",
    },
    [130844] = {
        name = "Princesa Talanji",
    },
    [130901] = {
        name = "Cronista Grazzul",
    },
    [130905] = {
        name = "Cala Crisopeya",
    },
    [130929] = {
        name = "Médica bruja Jangalar",
    },
    [131000] = {
        name = "Comandante Kellam",
    },
    [131001] = {
        name = "Teniente Harris",
    },
    [131002] = {
        name = "Teniente Bauer",
    },
    [131003] = {
        name = "Especialista Wembley",
    },
    [131004] = {
        name = "Escudero Augustus III",
    },
    [131048] = {
        name = "Teniente Tarenfold",
    },
    [131253] = {
        name = "Guardián de los titanes Hezrel",
    },
    [131290] = {
        name = "Flynn Vientopropicio",
    },
    [131354] = {
        name = "Madre de bestias Jabati",
    },
    [131443] = {
        name = "Jefe Telemante Oculeth\0",
    },
    [131579] = {
        name = "Aldeano cautivo",
    },
    [131580] = {
        name = "Aprendiz de telemántico Astrandis",
    },
    [131582] = {
        name = "Examinadora Tae'shara Mirasangre",
    },
    [131636] = {
        name = "Mariscal Everit Reade",
    },
    [131638] = {
        name = "Lucille Crestavía",
    },
    [131639] = {
        name = "Inquisidora Mace",
    },
    [131640] = {
        name = "Inquisidor Notley",
    },
    [131641] = {
        name = "Inquisidor Yorrick",
    },
    [131642] = {
        name = "Inquisidor Mareasevera",
    },
    [131656] = {
        name = "Maestro de canes Archibald",
    },
    [131657] = {
        name = "Compendio de sangre",
    },
    [131684] = {
        name = "Penny \"Preciosa\" Hardwick",
    },
    [131763] = {
        name = "Excavador Morgrum Brasasílex",
    },
    [131775] = {
        name = "Joe el Sordo",
    },
    [131777] = {
        name = "Acadia Rocacincel",
    },
    [131840] = {
        name = "Shuga Revientatapas",
    },
    [131879] = {
        name = "Inquisidora Albaclara",
    },
    [132118] = {
        name = "Granjero Burton",
    },
    [132228] = {
        name = "Elric Trismagisto",
    },
    [132332] = {
        name = "Princesa Talanji",
    },
    [132333] = {
        name = "Princesa Talanji",
    },
    [132617] = {
        name = "Bently Fulgorgraso",
    },
    [132720] = {
        name = "Maestro de halcones Lloyd",
    },
    [132966] = {
        name = "Lynn Dulce",
    },
    [132988] = {
        name = "Parche",
    },
    [132994] = {
        name = "Lord Arthur Crestavía",
    },
    [133035] = {
        name = "Oficial Jovan",
    },
    [133050] = {
        name = "Princesa Talanji",
    },
    [133098] = {
        name = "Inquisidora Albaclara",
    },
    [133125] = {
        name = "Princesa Talanji",
    },
    [133324] = {
        name = "Señor de los maleficios Raal",
    },
    [133476] = {
        name = "Princesa Talanji",
    },
    [133489] = {
        name = "Ormhun Rocamartillo",
    },
    [133523] = {
        name = "Ji Zarpa Ígnea",
    },
    [133536] = {
        name = "Grix \"Puños de hierro\" Barlow",
    },
    [133550] = {
        name = "Minero joven Joe",
    },
    [133551] = {
        name = "Minero jefe Theock",
    },
    [133552] = {
        name = "Químico jefe Walters",
    },
    [133576] = {
        name = "Timonel Garfio",
    },
    [133577] = {
        name = "Maestro de armas Sedal",
    },
    [133578] = {
        name = "Escafandro",
    },
    [133640] = {
        name = "Wayne el Ancestral",
    },
    [133653] = {
        name = "Señor de los maleficios Raal",
    },
    [133953] = {
        name = "Sargento Calvin",
    },
    [134009] = {
        name = "Ciudadana de Corlain",
    },
    [134166] = {
        name = "Flynn Vientopropicio",
    },
    [134345] = {
        name = "Coleccionista Tojo",
    },
    [134408] = {
        name = "Supervisor Jethek",
    },
    [134509] = {
        name = "Guía principal Cierrallave",
    },
    [134628] = {
        name = "Técnica civil Alena",
    },
    [134639] = {
        name = "Hermano Pike",
    },
    [134702] = {
        name = "Nedly Sonrisas",
    },
    [134752] = {
        name = "Alcaldesa Roz",
    },
    [134776] = {
        name = "Davey Atigrado",
    },
    [135021] = {
        name = "Inquisidora Albaclara",
    },
    [135067] = {
        name = "Moxie Girallave",
    },
    [135085] = {
        name = "Capitana Lilian Nottley",
    },
    [135133] = {
        name = "Guardia bélica Rakera",
    },
    [135179] = {
        name = "Mard Archfeld",
    },
    [135205] = {
        name = "Nathanos Clamañublo",
    },
    [135308] = {
        name = "Alero Goja",
    },
    [135330] = {
        name = "Nedly Sonrisas",
    },
    [135517] = {
        name = "Guardia de las mareas Victoria",
    },
    [135534] = {
        name = "Hermano Pike",
    },
    [135541] = {
        name = "Incinerador de Pantoque",
    },
    [135612] = {
        name = "Halford Aterravermis",
    },
    [135614] = {
        name = "Maestro Mathias Shaw",
    },
    [135618] = {
        name = "Falstad Martillo Salvaje",
    },
    [135620] = {
        name = "Kelsey Chispacero",
    },
    [135673] = {
        name = "Explorador McKellis",
    },
    [135681] = {
        name = "Gran almirante Jes-Tereth",
    },
    [135690] = {
        name = "Almirante del terror Velandrajo",
    },
    [135691] = {
        name = "Nathanos Clamañublo",
    },
    [135784] = {
        name = "Guardia imperial",
    },
    [135793] = {
        name = "Coleccionista Tojo",
    },
    [135794] = {
        name = "Sabia de pergaminos Nola",
    },
    [135801] = {
        name = "Señor de los maleficios Raal",
    },
    [135855] = {
        name = "Teekay Pisabobina",
    },
    [135861] = {
        name = "Adalyn Vigilabosque",
    },
    [135890] = {
        name = "Rey Rastakhan",
    },
    [135901] = {
        name = "Fungálido xilosangre",
    },
    [135976] = {
        name = "Morwin Claroalma",
    },
    [136041] = {
        name = "Emily Buentiempo",
    },
    [136059] = {
        name = "Layla Marcalmo",
    },
    [136140] = {
        name = "Klonk Piezagrasienta",
    },
    [136195] = {
        name = "Médica Feorea",
    },
    [136227] = {
        name = "Fixi Pincholadino",
    },
    [136233] = {
        name = "Klause Vientopropicio",
    },
    [136234] = {
        name = "Cesi Gatillofácil",
    },
    [136309] = {
        name = "Contramaestre Jamboya",
    },
    [136310] = {
        name = "Contramaestre Jamboya",
    },
    [136414] = {
        name = "Pastora Muelearroyo",
    },
    [136432] = {
        name = "Brann Barbabronce",
    },
    [136458] = {
        name = "Cesi Gatillofácil",
    },
    [136497] = {
        name = "Guardia de las mareas Victoria",
    },
    [136562] = {
        name = "Intendente Alfin",
    },
    [136568] = {
        name = "Capitana Conrad",
    },
    [136576] = {
        name = "Maestra de embarcadero Leighton",
    },
    [136641] = {
        name = "Brann Barbabronce",
    },
    [136645] = {
        name = "Brann Barbabronce",
    },
    [136675] = {
        name = "Brann Barbabronce",
    },
    [136683] = {
        name = "Príncipe mercante Gallywix",
    },
    [136779] = {
        name = "Contramaestre Jamboya",
    },
    [136907] = {
        name = "Magni Barbabronce",
    },
    [136933] = {
        name = "Hermano Pike",
    },
    [137008] = {
        name = "Sargento Ermey",
    },
    [137075] = {
        name = "Teniente Dennis Cuentotriste",
    },
    [137094] = {
        name = "Granjero Max",
    },
    [137112] = {
        name = "Guardián de los titanes Hezrel",
    },
    [137213] = {
        name = "Halford Aterravermis",
    },
    [137337] = {
        name = "Sargento Ermey",
    },
    [137401] = {
        name = "Maestro del yunque Thurgaden",
    },
    [137506] = {
        name = "Hermano Pike",
    },
    [137543] = {
        name = "Sargento Ermey",
    },
    [137613] = {
        name = "Hobart Martillazos",
    },
    [137675] = {
        name = "Cazador de las Sombras Ty'jin",
    },
    [137691] = {
        name = "Hermano Pike",
    },
    [137694] = {
        name = "Parin Pensadije",
    },
    [137727] = {
        name = "Contramaestre Owings",
    },
    [137742] = {
        name = "Cazador de las Sombras Ty'jin",
    },
    [137818] = {
        name = "Myxle \"la Rata Marina\" Sacatripas",
    },
    [137837] = {
        name = "Señora suprema Geya'rah",
    },
    [137867] = {
        name = "Halford Aterravermis",
    },
    [137878] = {
        name = "Maestro Gadrin",
    },
    [138138] = {
        name = "Princesa Talanji",
    },
    [138285] = {
        name = "Nathanos Clamañublo",
    },
    [138352] = {
        name = "Gran señor de la guerra Cromush",
    },
    [138365] = {
        name = "Gran señor de la guerra Cromush",
    },
    [138520] = {
        name = "Habitante de Zeb'ahari",
    },
    [138521] = {
        name = "Técnico de minas",
    },
    [138688] = {
        name = "Centurión Kega Rocardiente",
    },
    [138708] = {
        name = "Garona Semiorco",
    },
    [138735] = {
        name = "Felecia Rocalegre",
    },
    [139061] = {
        name = "Nathanos Clamañublo",
    },
    [139069] = {
        name = "Contramaestre Redmond",
    },
    [139070] = {
        name = "Capitán Redmond",
    },
    [139089] = {
        name = "Guardia de Vaderia",
    },
    [139568] = {
        name = "Magíster Umbric",
    },
    [139705] = {
        name = "Halford Aterravermis",
    },
    [139719] = {
        name = "Shandris Plumaluna",
    },
    [139722] = {
        name = "Explosionador Mecafusible",
    },
    [139912] = {
        name = "Forestal Wons",
    },
    [139926] = {
        name = "Sotoabedul Hablaespinas",
    },
    [139928] = {
        name = "Maestro Gadrin",
    },
    [140048] = {
        name = "Arthur Vientos Alisios",
    },
    [140105] = {
        name = "Forestal oscuro",
    },
    [140176] = {
        name = "Nathanos Clamañublo",
    },
    [140258] = {
        name = "Shandris Plumaluna",
    },
    [140484] = {
        name = "Capitana Amalia Stone",
    },
    [140485] = {
        name = "Nathanos Clamañublo",
    },
    [140495] = {
        name = "Katherine Valiente",
    },
    [140590] = {
        name = "Capitán Grez'ko",
    },
    [140724] = {
        name = "Princesa Talanji",
    },
    [140725] = {
        name = "Espíritu de Vol'jin",
    },
    [140752] = {
        name = "Jenny Arroyovivo",
    },
    [141078] = {
        name = "Refugiado de Alto del Vigía",
    },
    [141555] = {
        name = "Baine Pezuña de Sangre",
    },
    [141602] = {
        name = "Sabiomar resucitado",
    },
    [141643] = {
        name = "Pinzacoja del fondo marino",
    },
    [141644] = {
        name = "Nathanos Clamañublo",
    },
    [141672] = {
        name = "Capitán de barco ahogado",
    },
    [141815] = {
        name = "Marinero ahogado",
    },
    [141952] = {
        name = "Cuernoatroz joven",
    },
    [142275] = {
        name = "Grommash Grito Infernal",
    },
    [142651] = {
        name = "Lucille Crestavía",
    },
    [142930] = {
        name = "Halford Aterravermis",
    },
    [143536] = {
        name = "Gran señor de la guerra Volrath",
    },
    [143559] = {
        name = "Gran mariscal Tremblade",
    },
    [143565] = {
        name = "Wayne el Ancestral",
    },
    [143692] = {
        name = "Anacronos",
    },
    [143777] = {
        name = "Hasani el Alto",
    },
    [143787] = {
        name = "Ala-Ala",
    },
    [143845] = {
        name = "Señora suprema Geya'rah",
    },
    [143846] = {
        name = "Alleria Brisaveloz",
    },
    [143851] = {
        name = "Kelsey Chispacero",
    },
    [143871] = {
        name = "Supervisora Ejebotón",
    },
    [143878] = {
        name = "Reez Cierrelúgubre",
    },
    [143908] = {
        name = "Cuerpo destrozado",
    },
    [144095] = {
        name = "Maestro Mathias Shaw",
    },
    [145005] = {
        name = "Errante de élite",
    },
    [145022] = {
        name = "Tejetiempo Delormi",
    },
    [145131] = {
        name = "Gurú de datos Gryzix",
    },
    [145190] = {
        name = "Princesa Talanji",
    },
    [145225] = {
        name = "Espíritu de Vol'jin",
    },
    [145359] = {
        name = "Princesa Talanji",
    },
    [145411] = {
        name = "Lady Sylvanas Brisaveloz",
    },
    [145424] = {
        name = "Baine Pezuña de Sangre",
    },
    [145462] = {
        name = "Brann Barbabronce",
    },
    [145464] = {
        name = "Consejero Belgrum",
    },
    [145580] = {
        name = "Lady Jaina Valiente",
    },
    [145632] = {
        name = "Okri Tirallave",
    },
    [145751] = {
        name = "Príncipe mercante Gallywix",
    },
    [145816] = {
        name = "MGOD",
    },
    [145965] = {
        name = "Espíritu de Vol'jin",
    },
    [145981] = {
        name = "Espíritu de Vol'jin",
    },
    [146010] = {
        name = "Forestal oscura Lyana",
    },
    [146011] = {
        name = "Varok Colmillosauro",
    },
    [146013] = {
        name = "Forestal oscura Alina",
    },
    [146050] = {
        name = "Maiev Cantosombrío",
    },
    [146073] = {
        name = "Príncipe mercante Gallywix",
    },
    [146208] = {
        name = "Krag'wa el Enorme",
    },
    [146290] = {
        name = "Espíritu de Vol'jin",
    },
    [146323] = {
        name = "Nathanos Clamañublo",
    },
    [146325] = {
        name = "Maestro triturador Blix",
    },
    [146335] = {
        name = "Reina Talanji",
    },
    [146373] = {
        name = "Maiev Cantosombrío",
    },
    [146374] = {
        name = "Shandris Plumaluna",
    },
    [146375] = {
        name = "Sira Guardaluna",
    },
    [146462] = {
        name = "Rabioso de la Horda",
    },
    [146536] = {
        name = "Fuego fatuo perdido",
    },
    [146601] = {
        name = "Sira Guardaluna",
    },
    [146623] = {
        name = "MGOD",
    },
    [146630] = {
        name = "Espíritu de Vol'jin",
    },
    [146654] = {
        name = "Lady Sylvanas Brisaveloz",
    },
    [146791] = {
        name = "Forestal oscura",
    },
    [146806] = {
        name = "Forestal oscura Lyana",
    },
    [146824] = {
        name = "Princesa Talanji",
    },
    [146877] = {
        name = "Princesa Talanji",
    },
    [146902] = {
        name = "Hermano Pike",
    },
    [146921] = {
        name = "Princesa Talanji",
    },
    [146937] = {
        name = "Forestal oscura",
    },
    [146939] = {
        name = "Embajadora Juraalba",
    },
    [146982] = {
        name = "Lady Jaina Valiente",
    },
    [146988] = {
        name = "Cavador Golad",
    },
    [147088] = {
        name = "Arcanista Valtrois",
    },
    [147135] = {
        name = "Nathanos Clamañublo",
    },
    [147145] = {
        name = "Nathanos Clamañublo",
    },
    [147149] = {
        name = "Morton Piñondez",
    },
    [147151] = {
        name = "Kelsey Chispacero",
    },
    [147155] = {
        name = "Parche",
    },
    [147210] = {
        name = "Forestal oscura Lyana",
    },
    [147293] = {
        name = "Defensor Da'kani",
    },
    [147311] = {
        name = "Morton Piñondez",
    },
    [147519] = {
        name = "Kelsey Chispacero",
    },
    [147819] = {
        name = "Maestro del acero Telaamon",
    },
    [147842] = {
        name = "Lady Jaina Valiente",
    },
    [147843] = {
        name = "Maestro Mathias Shaw",
    },
    [147844] = {
        name = "Maestro del acero Telaamon",
    },
    [147939] = {
        name = "As de la aviación Tormentuerca",
    },
    [147943] = {
        name = "Capitán Tread Chispaboquilla",
    },
    [147950] = {
        name = "Capitán engranaje Resortinkle",
    },
    [147952] = {
        name = "Fizzi Arcojalata",
    },
    [148015] = {
        name = "Taelia Fordragón",
    },
    [148096] = {
        name = "Suma prelada Ranta",
    },
    [148339] = {
        name = "Parche",
    },
    [148798] = {
        name = "Lady Jaina Valiente",
    },
    [148870] = {
        name = "Dorian Navalmar",
    },
    [149084] = {
        name = "Caminaespíritus Ussoh",
    },
    [149088] = {
        name = "Caminaespíritus Isahi",
    },
    [149143] = {
        name = "Nathanos Clamañublo",
    },
    [149252] = {
        name = "Cielo vinculado",
    },
    [149471] = {
        name = "Forestal oscura Velonara",
    },
    [149503] = {
        name = "Capitán engranaje Resortinkle",
    },
    [149528] = {
        name = "Baine Pezuña de Sangre",
    },
    [149529] = {
        name = "Caminaespíritus Ussoh",
    },
    [149612] = {
        name = "Shandris Plumaluna",
    },
    [149736] = {
        name = "Imagen de Mimiron",
    },
    [149815] = {
        name = "Grizzek Llavesilbo",
    },
    [149823] = {
        name = "Magni Barbabronce",
    },
    [149842] = {
        name = "Baine Pezuña de Sangre",
    },
    [149864] = {
        name = "Maestro manitas Sobrechispa",
    },
    [149867] = {
        name = "Magni Barbabronce",
    },
    [149870] = {
        name = "Grif Corazón Salvaje",
    },
    [149877] = {
        name = "Maestro manitas Sobrechispa",
    },
    [149904] = {
        name = "Neri Escama Letal",
    },
    [150086] = {
        name = "Bolten Chispaelástico",
    },
    [150087] = {
        name = "Genn Cringris",
    },
    [150101] = {
        name = "Lady Jaina Valiente",
    },
    [150115] = {
        name = "Princesa Tess Cringris",
    },
    [150145] = {
        name = "Gina Cableado",
    },
    [150187] = {
        name = "Nathanos Clamañublo",
    },
    [150196] = {
        name = "Primera Arcanista Thalyssra",
    },
    [150200] = {
        name = "Mensajera Claridge",
    },
    [150206] = {
        name = "Jefe Telemante Oculeth",
    },
    [150208] = {
        name = "Maestro manitas Sobrechispa",
    },
    [150209] = {
        name = "Neri Escama Letal",
    },
    [150309] = {
        name = "Baine Pezuña de Sangre",
    },
    [150391] = {
        name = "Imagen de Mimiron",
    },
    [150433] = {
        name = "Vigía de la cima Cicatriz Orgullosa",
    },
    [150515] = {
        name = "Cyrus Catacresta",
    },
    [150555] = {
        name = "Waren Remache",
    },
    [150573] = {
        name = "Reciclador Kerchunk",
    },
    [150574] = {
        name = "Lady Jaina Valiente",
    },
    [150630] = {
        name = "Flip Supercarga",
    },
    [150631] = {
        name = "Pristy Supercarga",
    },
    [150633] = {
        name = "Lady Jaina Valiente",
    },
    [150637] = {
        name = "Kelsey Chispacero",
    },
    [150640] = {
        name = "Maestro Mathias Shaw",
    },
    [150690] = {
        name = "Jefa Mida",
    },
    [150796] = {
        name = "Kelsey Chispacero",
    },
    [150885] = {
        name = "Bestia de mimbre",
    },
    [150893] = {
        name = "Santuario del Mar",
    },
    [150894] = {
        name = "Altar de la naturaleza",
    },
    [150895] = {
        name = "Altar de las arenas",
    },
    [150896] = {
        name = "Altar del manto nocturno",
    },
    [150897] = {
        name = "Santuario del Alba",
    },
    [150898] = {
        name = "Altar de las tormentas",
    },
    [150956] = {
        name = "Plataforma de excavación averiada",
    },
    [151000] = {
        name = "Maestro del acero Okani",
    },
    [151100] = {
        name = "Gina Cableado",
    },
    [151129] = {
        name = "Sapphronetta Tartanas",
    },
    [151130] = {
        name = "Grizzek Silballave",
    },
    [151132] = {
        name = "Plumas",
    },
    [151134] = {
        name = "Tejetiempo Delormi",
    },
    [151137] = {
        name = "Sastra sincrónica",
    },
    [151162] = {
        name = "Atikka \"As\" Cazalunas",
    },
    [151173] = {
        name = "Daniss Danzaespíritus",
    },
    [151283] = {
        name = "Prole de cuernoatroz",
    },
    [151285] = {
        name = "Mevris Danzafantasma",
    },
    [151286] = {
        name = "Cría de Torcali",
    },
    [151462] = {
        name = "Danielle Pescadores",
    },
    [151626] = {
        name = "Cazador Akana",
    },
    [151641] = {
        name = "Caminaespíritus Ebacuerno",
    },
    [151682] = {
        name = "Merithra del Sueño",
    },
    [151693] = {
        name = "Merithra del Sueño",
    },
    [151695] = {
        name = "Caminaespíritus Ebacuerno",
    },
    [151704] = {
        name = "Valithria Caminasueños",
    },
    [151741] = {
        name = "Aprendiz Odari",
    },
    [151761] = {
        name = "Vassandra Garratormenta",
    },
    [151784] = {
        name = "Mía Cringris",
    },
    [151825] = {
        name = "Merithra del Sueño",
    },
    [151851] = {
        name = "Jefe Telemante Oculeth",
    },
    [151887] = {
        name = "Merithra del Sueño",
    },
    [151947] = {
        name = "Príncipe Erazmin",
    },
    [151999] = {
        name = "Jo'nok, Baluarte de Torcali",
    },
    [152002] = {
        name = "Imagen de Mimiron",
    },
    [152047] = {
        name = "Poen Branquen",
    },
    [152066] = {
        name = "Primera Arcanista Thalyssra",
    },
    [152095] = {
        name = "Magni Barbabronce",
    },
    [152108] = {
        name = "Exploradora aletina",
    },
    [152194] = {
        name = "MADRE",
    },
    [152206] = {
        name = "Magni Barbabronce",
    },
    [152238] = {
        name = "Riathia Astroargenta",
    },
    [152316] = {
        name = "Imagen de Thalyssra",
    },
    [152385] = {
        name = "Chamán de Altamontaña",
    },
    [152484] = {
        name = "Maestro manitas Sobrechispa",
    },
    [152489] = {
        name = "Altar de las tormentas",
    },
    [152490] = {
        name = "Santuario del Alba",
    },
    [152493] = {
        name = "Altar de las arenas",
    },
    [152495] = {
        name = "Santuario del Mar",
    },
    [152496] = {
        name = "Altar de la naturaleza",
    },
    [152497] = {
        name = "Altar del manto nocturno",
    },
    [152747] = {
        name = "Christy Engranazo",
    },
    [152815] = {
        name = "Magni Barbabronce",
    },
    [152820] = {
        name = "Príncipe Erazmin",
    },
    [152851] = {
        name = "Príncipe Erazmin",
    },
    [152864] = {
        name = "Maestro manitas Sobrechispa",
    },
    [153253] = {
        name = "Lady Jaina Valiente",
    },
    [153365] = {
        name = "Madre de la colmena mielomo",
    },
    [153385] = {
        name = "Maestro del acero Okani",
    },
    [153422] = {
        name = "Jefe telemante Oculeth",
    },
    [153509] = {
        name = "Artesana Okata",
    },
    [153510] = {
        name = "Artesano Itanu",
    },
    [153512] = {
        name = "Buscador Pruc",
    },
    [153514] = {
        name = "Buscadora Palta",
    },
    [153617] = {
        name = "Shandris Plumaluna",
    },
    [153670] = {
        name = "Luchador de Resistencia de Pernoxidado",
    },
    [153932] = {
        name = "Genn Cringris",
    },
    [153936] = {
        name = "Sobrestante Hajeer",
    },
    [154002] = {
        name = "Atolia Perlamar",
    },
    [154023] = {
        name = "Cosechadora naciente",
    },
    [154143] = {
        name = "Coleccionista Tojo",
    },
    [154248] = {
        name = "Esgrimidor Inowari",
    },
    [154444] = {
        name = "Hablatormentas Qian",
    },
    [154514] = {
        name = "Kelya Puestaluna",
    },
    [154520] = {
        name = "Primera Arcanista Thalyssra",
    },
    [154522] = {
        name = "Shandris Plumaluna",
    },
    [154532] = {
        name = "Magni Barbabronce",
    },
    [154533] = {
        name = "Magni Barbabronce",
    },
    [154574] = {
        name = "Kelya Puestaluna",
    },
    [154601] = {
        name = "Kelya Puestaluna",
    },
    [154607] = {
        name = "Imagen de Torcali",
    },
    [154640] = {
        name = "Gran mariscal Hojatemblorosa",
    },
    [154660] = {
        name = "Shandris Plumaluna",
    },
    [154661] = {
        name = "Primera Arcanista Thalyssra",
    },
    [154958] = {
        name = "Obrero Mitchell",
    },
    [155071] = {
        name = "Shandris Plumaluna",
    },
    [155095] = {
        name = "Rey Phaoris",
    },
    [155102] = {
        name = "Alta expedicionaria Dellorah",
    },
    [155325] = {
        name = "Primera Arcanista Thalyssra",
    },
    [155336] = {
        name = "Guerrero mogu",
    },
    [155482] = {
        name = "Centinela",
    },
    [155562] = {
        name = "Maestra del Shadopan",
    },
    [155785] = {
        name = "Lady Jaina Valiente",
    },
    [155786] = {
        name = "Varok Colmillosauro",
    },
    [156003] = {
        name = "Eremita Cho",
    },
    [156297] = {
        name = "Chen Cerveza de Trueno",
    },
    [156390] = {
        name = "Chen Cerveza de Trueno",
    },
    [156391] = {
        name = "Li Li Cerveza de Trueno",
    },
    [156396] = {
        name = "Sassy Malallave",
    },
    [156423] = {
        name = "Lady Sylvanas Brisaveloz",
    },
    [156425] = {
        name = "Forestal oscura Lenara",
    },
    [156440] = {
        name = "Nathanos Clamañublo",
    },
    [156520] = {
        name = "Hobart Martillazos",
    },
    [156542] = {
        name = "Crank Grasamecha",
    },
    [156937] = {
        name = "Chen Cerveza de Trueno",
    },
    [156938] = {
        name = "Li Li Cerveza de Trueno",
    },
    [157180] = {
        name = "Barriles de Cerveza de Trueno abandonados",
    },
    [157491] = {
        name = "Hobart Martillazos",
    },
    [157997] = {
        name = "Kelsey Chispacero",
    },
    [158145] = {
        name = "Príncipe Erazmin",
    },
    [158672] = {
        name = "Vulpera temeraria",
    },
    [159544] = {
        name = "Arik Escorpunción",
    },
    [159560] = {
        name = "Escolta Lashan",
    },
    [159682] = {
        name = "Rastreadora Samara",
    },
    [159820] = {
        name = "Ensalmador Dyrin",
    },
    [159920] = {
        name = "Zahra Acecharenas",
    },
    [160101] = {
        name = "Kelsey Chispacero",
    },
    [160232] = {
        name = "Christy Engranazo",
    },
    [161031] = {
        name = "Capitán Hadan",
    },
    [161738] = {
        name = "H'parkho Ardoros",
    },
    [161805] = {
        name = "Magni Barbabronce",
    },
})
]])()
