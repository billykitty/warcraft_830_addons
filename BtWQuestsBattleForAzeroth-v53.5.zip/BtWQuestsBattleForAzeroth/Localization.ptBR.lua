----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "ptBR" then
    return
end

local L = BtWQuests.L
L["ALLIED_RACE_MECHAGNOME"] = "Allied Race: Gnomecânico"
L["BTWQUESTS_COSMETIC_WAIST_OF_TIME"] = "Cosmético: Cinto pelo Tempo Perdido"
L["BTWQUESTS_GIFT_OF_NZOTH"] = "Dádiva de N'Zoth"
L["BTWQUESTS_HATI_REBORN"] = "Hati Renascido"
L["BTWQUESTS_HERITAGE_OF_GILNEAS"] = "Tradição de Guilnéas"
L["BTWQUESTS_HERITAGE_OF_GNOMEREGAN"] = "Tradição de Gnomeregan"
L["BTWQUESTS_HERITAGE_OF_KEZAN"] = "Tradição de Kezan"
L["BTWQUESTS_HERITAGE_OF_THE_BRONZEBEARD"] = "Tradição dos Barbabronze"
L["BTWQUESTS_HERITAGE_OF_THE_SHUHALO"] = "Tradição dos Shu'halo"
L["BTWQUESTS_HERITAGE_OF_THE_SINDOREI"] = "Tradição dos Sin'dorei"
L["BTWQUESTS_MAGHAR_ORC"] = "Orc Mag'har"
L["BTWQUESTS_NIGHT_WARRIOR_NIGHT_ELF_CUSTOMIZATION"] = "Personalização Noctiélfica \"Guerreira da Noite\""
L["BTWQUESTS_THE_WAR_CAMPAIGN"] = "A Campanha de Guerra"
L["BTWQUESTS_THE_WAR_CAMPAIGN_8_1"] = "A Campanha de Guerra: Batalha de Dazar'alor"
L["BTWQUESTS_WARFRONT_THE_BATTLE_FOR_DARKSHORE"] = "Front de Guerra: A batalha pela Costa Negra"
L["DUNGEON_KINGS_REST"] = "Masmorra: Repouso do Rei"
L["DUNGEON_SIEGE_OF_BORALUS"] = "Masmorra: Cerco de Boralus"
L["MECHAGNOME"] = "Gnomecânico"
L["WAIST_OF_TIME"] = "Cinto pelo Tempo Perdido"
