----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "itIT" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateObjectsTable({
    [244983] = {
        name = "Orologio da Tasca Sporco",
    },
    [270917] = {
        name = "Registro degli Acqualunga",
    },
    [271706] = {
        name = "Tavola dei Cacciatori",
    },
    [272179] = {
        name = "Bollettino del Sindaco",
    },
    [272422] = {
        name = "Grimorio di Helena",
    },
    [273814] = {
        name = "Talismano Tagliente",
    },
    [273854] = {
        name = "Zaino",
    },
    [276251] = {
        name = "Inventario degli Scavi",
    },
    [276488] = {
        name = "Palla di Cannone d'Azerite",
    },
    [276513] = {
        name = "Pescefango Intatto",
    },
    [276515] = {
        name = "Bastone da Pesca",
    },
    [276837] = {
        name = "Roccia con Ricetta",
    },
    [277199] = {
        name = "Lista di Lavori Logora",
    },
    [277373] = {
        name = "Alga Marina Luccicante",
    },
    [277459] = {
        name = "Effige del Maiale",
    },
    [278197] = {
        name = "Fiala di Antidoto",
    },
    [278252] = {
        name = "Volantino di Lavoro",
    },
    [278313] = {
        name = "Lettera Severa",
    },
    [278368] = {
        name = "La nota lacera",
    },
    [278447] = {
        name = "Lancia del Bracconiere Senzafede",
    },
    [278570] = {
        name = "Diario Antico",
    },
    [278577] = {
        name = "Missiva dell'Orda Strappata",
    },
    [278669] = {
        name = "Libro Mastro di Malautunno",
    },
    [278675] = {
        name = "Effige Maledetta",
    },
    [279337] = {
        name = "Grimorio delle Frangicuore",
    },
    [279646] = {
        name = "Cronache della Guardia del Sangue",
    },
    [279647] = {
        name = "Tomo del Sacrificio",
    },
    [280576] = {
        name = "Pergamena Sigillata",
    },
    [280727] = {
        name = "Nota Carbonizzata",
    },
    [281230] = {
        name = "Invito Formale",
    },
    [281348] = {
        name = "Lettera Accartocciata",
    },
    [281551] = {
        name = "Manifesto Aiuto Cercasi",
    },
    [281583] = {
        name = "Reliquiario Antico",
    },
    [281639] = {
        name = "Statua Sgretolata",
    },
    [281647] = {
        name = "Avviso Appeso",
    },
    [281673] = {
        name = "Diario di Cittadino di Corlain",
    },
    [281718] = {
        name = "AIUTO CERCASI",
    },
    [282457] = {
        name = "Totem della Guardia dei Rovi",
    },
    [282478] = {
        name = "Cassa Vuota",
    },
    [282498] = {
        name = "Flauto del Deserto",
    },
    [284426] = {
        name = "Macchina da Estrazione Sepolta",
    },
    [286016] = {
        name = "Diario di Bordo",
    },
    [287081] = {
        name = "Antica Tavoletta",
    },
    [287185] = {
        name = "RICERCATO: Oratore Oscuro Jo'la",
    },
    [287189] = {
        name = "RICERCATO: Bestie Pericolose",
    },
    [287228] = {
        name = "RICERCATO: Storiografo Oscuro",
    },
    [287229] = {
        name = "RICERCATO: Storiografo Oscuro",
    },
    [287232] = {
        name = "Rapporto Esplorativo",
    },
    [287327] = {
        name = "Rapporto Esplorativo",
    },
    [287398] = {
        name = "RICERCATO: Za'roco",
    },
    [287440] = {
        name = "RICERCATO: Taz'raka",
    },
    [287441] = {
        name = "RICERCATO: Esploratore delle Sabbie Vesarik",
    },
    [287442] = {
        name = "RICERCATI: Partecipanti all'Escursione dei Cobra",
    },
    [287958] = {
        name = "Bacheca",
    },
    [288157] = {
        name = "Ricercato: Yarsel'ghun",
    },
    [288167] = {
        name = "Pacchetto di Marie",
    },
    [288214] = {
        name = "Manifesto dei Ricercati",
    },
    [288622] = {
        name = "Manifesto dei Ricercati",
    },
    [288641] = {
        name = "RICERCATO: Rapitore di Grifoni",
    },
    [289310] = {
        name = "RICERCATO: Guardiaterra Infuriato",
    },
    [289313] = {
        name = "RICERCATA: La Vespa",
    },
    [289361] = {
        name = "RICERCATO: Quartiermastro Ssylis",
    },
    [289365] = {
        name = "Manifesto dei Ricercati",
    },
    [289728] = {
        name = "Mappa del Tesoro del Capitano Gulnaku",
    },
    [290138] = {
        name = "Bomba Robodemolitrice",
    },
    [290419] = {
        name = "Manifesto dei Ricercati",
    },
    [290537] = {
        name = "Aiuto Cercasi",
    },
    [290750] = {
        name = "Deposito dei Jambani",
    },
    [290765] = {
        name = "Grande Pila di Monete d'Oro",
    },
    [290993] = {
        name = "Bottino dei Marferreo",
    },
    [291143] = {
        name = "La chiave meccanica di Ranah",
    },
    [291291] = {
        name = "RICERCATO: Bracconiere",
    },
    [292523] = {
        name = "Manifesto dei Ricercati",
    },
    [293567] = {
        name = "Manifesto dei Ricercati",
    },
    [293568] = {
        name = "Manifesto dei Ricercati",
    },
    [293985] = {
        name = "RICERCATO: Sbudellaguerra",
    },
    [297492] = {
        name = "Bacheca",
    },
    [298778] = {
        name = "Manifesto dei Ricercati",
    },
    [298849] = {
        name = "Manifesto dei Ricercati",
    },
    [298858] = {
        name = "Manifesto dei Ricercati",
    },
    [307748] = {
        name = "Lettera della S.P.R. & Co.",
    },
    [309498] = {
        name = "Supporto per Armatura",
    },
    [311155] = {
        name = "Antica Tavoletta",
    },
    [311218] = {
        name = "Xal'atath, Lama dell'Impero Nero",
    },
    [311885] = {
        name = "Xal'atath, Lama dell'Impero Nero",
    },
    [322533] = {
        name = "Tomo degli Elementi di Mardivas",
    },
    [326393] = {
        name = "Cassa d'Armi d'Azerite",
    },
    [326418] = {
        name = "Cassa Arcana",
    },
    [326588] = {
        name = "Cassa d'Armi d'Azerite",
    },
    [327170] = {
        name = "Rastrelliera delle Armi",
    },
    [327591] = {
        name = "Diario Conservato",
    },
    [327592] = {
        name = "Lucchetto Incantato",
    },
    [327596] = {
        name = "Focus Abissale Rotto",
    },
    [329805] = {
        name = "Cristallo Strano",
    },
})
]])()
