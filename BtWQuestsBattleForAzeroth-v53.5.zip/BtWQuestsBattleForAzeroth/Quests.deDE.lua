----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "deDE" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Blutspende",
    },
    [44785] = {
        name = "Teekränzchen",
    },
    [45079] = {
        name = "Das Dorf Schluchtbach",
    },
    [45972] = {
        name = "Das verfluchte Dickicht",
    },
    [46727] = {
        name = "Gezeiten des Krieges",
    },
    [46728] = {
        name = "Die Nation Kul Tiras",
    },
    [46729] = {
        name = "Der alte Ritter",
    },
    [46846] = {
        name = "Das Wort des Zul",
    },
    [46926] = {
        name = "Erpressung",
    },
    [46927] = {
        name = "Strafaktion in Tal'aman",
    },
    [46928] = {
        name = "Strafaktion in Tal'farrak",
    },
    [46929] = {
        name = "Abschreckung",
    },
    [46931] = {
        name = "Stimme der Horde",
    },
    [46957] = {
        name = "Willkommen in Zuldazar",
    },
    [47098] = {
        name = "Auf und davon mit Finn",
    },
    [47099] = {
        name = "Orientierungslauf",
    },
    [47103] = {
        name = "Reise nach Nazmir",
    },
    [47105] = {
        name = "In die Finsternis",
    },
    [47130] = {
        name = "Unangemessenes Begräbnis",
    },
    [47181] = {
        name = "Ein durchschlagender Beweis",
    },
    [47186] = {
        name = "Das Sanktum der Weisen",
    },
    [47188] = {
        name = "Die Hilfe der Loa",
    },
    [47189] = {
        name = "Eine gespaltene Nation",
    },
    [47198] = {
        name = "Sie wollen uns lebend",
    },
    [47199] = {
        name = "Das Bluttor",
    },
    [47200] = {
        name = "Zecken",
    },
    [47204] = {
        name = "Die neue Frontlinie",
    },
    [47205] = {
        name = "Kriegsmatrone",
    },
    [47226] = {
        name = "Das Waisenjunge",
    },
    [47228] = {
        name = "Tierpopulation von Xibala",
    },
    [47229] = {
        name = "Bollwerk von Torcali",
    },
    [47235] = {
        name = "Mit Hellsicht zum Auge",
    },
    [47241] = {
        name = "Der Schatten des Todes",
    },
    [47244] = {
        name = "Die Seelenausmerzung",
    },
    [47245] = {
        name = "Die Nachricht kommt an",
    },
    [47247] = {
        name = "Die Heimsuchung der Toten",
    },
    [47248] = {
        name = "Bis dass der Tod uns scheidet",
    },
    [47249] = {
        name = "Seelengebunden",
    },
    [47250] = {
        name = "Wir sehen uns wieder",
    },
    [47257] = {
        name = "Die Knochen von Xibala",
    },
    [47258] = {
        name = "Vorbereitung auf eine Belagerung",
    },
    [47259] = {
        name = "Terrorhorn-Betreuung",
    },
    [47260] = {
        name = "Mögliche Nebenwirkungen...",
    },
    [47261] = {
        name = "Terrorhornzähmen leicht gemacht",
    },
    [47262] = {
        name = "Das Ende der Bluttrolle",
    },
    [47263] = {
        name = "Eine Zeit der Offenbarung",
    },
    [47264] = {
        name = "Lasst keinen am Leben!",
    },
    [47272] = {
        name = "Wachstumshormon für Terrorhörner",
    },
    [47289] = {
        name = "Tierische Teestunde",
    },
    [47310] = {
        name = "Nickerchen",
    },
    [47311] = {
        name = "Kopfstoß für Anfänger",
    },
    [47312] = {
        name = "Federkönigin",
    },
    [47313] = {
        name = "Diskrete Gespräche",
    },
    [47314] = {
        name = "Exilgerüchte",
    },
    [47315] = {
        name = "Auf in die Dünen",
    },
    [47316] = {
        name = "Geheimnisse im Sand",
    },
    [47317] = {
        name = "Suche nach Überlebenden",
    },
    [47319] = {
        name = "Heilendes Gift",
    },
    [47320] = {
        name = "Ein beruhigender Balsam",
    },
    [47321] = {
        name = "Kampf um den Krimskrams",
    },
    [47322] = {
        name = "Flucht mit Unterstützung",
    },
    [47324] = {
        name = "Unwahrscheinliche Verbündete",
    },
    [47327] = {
        name = "Antwort auf ihre Angriffe",
    },
    [47329] = {
        name = "Das Erbe der Blutwächter",
    },
    [47332] = {
        name = "Der nächste Schritt",
    },
    [47418] = {
        name = "Wachstumsschmerzen",
    },
    [47422] = {
        name = "Höhentroll",
    },
    [47423] = {
        name = "Verbotene Praktiken",
    },
    [47428] = {
        name = "Miezi?",
    },
    [47432] = {
        name = "Abgemacht ist abgemacht",
    },
    [47433] = {
        name = "Offensive Defensive",
    },
    [47434] = {
        name = "Ordnung wiederherstellen",
    },
    [47435] = {
        name = "Pterrorfax'n dicke",
    },
    [47437] = {
        name = "Mit voller Hingabe",
    },
    [47438] = {
        name = "Eine fällige Entscheidung",
    },
    [47439] = {
        name = "Gonk, Anführer des Rudels",
    },
    [47440] = {
        name = "Pa'ku, Herrin der Winde",
    },
    [47441] = {
        name = "Nervige Schädlinge",
    },
    [47442] = {
        name = "Fluch von Jani",
    },
    [47445] = {
        name = "Der Rat der Zanchuli",
    },
    [47485] = {
        name = "Die Handelskompanie Aschenwind",
    },
    [47486] = {
        name = "Verdächtige Lieferungen",
    },
    [47487] = {
        name = "Arbeitskampf",
    },
    [47488] = {
        name = "Kleine Knechte",
    },
    [47489] = {
        name = "Verladen und verschickt",
    },
    [47491] = {
        name = "Überreste der Verdammten",
    },
    [47497] = {
        name = "Grüßt die Goldhauerbande",
    },
    [47498] = {
        name = "Rhan'kas verschollener Freund",
    },
    [47499] = {
        name = "Die grinsenden Götzen",
    },
    [47501] = {
        name = "Drecksarbeit und billiger Fusel",
    },
    [47502] = {
        name = "Die große Schädelschikane",
    },
    [47503] = {
        name = "Gozda'kun der Sklaventreiber",
    },
    [47509] = {
        name = "Die Terrasse der Auserwählten",
    },
    [47520] = {
        name = "Wände haben Ohren",
    },
    [47521] = {
        name = "Mitternacht im Garten der Loa",
    },
    [47522] = {
        name = "Der Jäger",
    },
    [47525] = {
        name = "Im Verborgenen bleiben",
    },
    [47527] = {
        name = "Ketzerische Rituale",
    },
    [47528] = {
        name = "Herrin der Lügen",
    },
    [47540] = {
        name = "Totemische Wiederherstellung",
    },
    [47564] = {
        name = "Das Büffet aufstocken",
    },
    [47570] = {
        name = "Geheime Vorhaben",
    },
    [47571] = {
        name = "Die Weisheit des Ältesten",
    },
    [47573] = {
        name = "Dschungelnetzbefall",
    },
    [47574] = {
        name = "Total versponnen",
    },
    [47576] = {
        name = "Zorn des Tigers",
    },
    [47577] = {
        name = "Sie kamen aus dem Meer",
    },
    [47578] = {
        name = "Mal des Loas",
    },
    [47580] = {
        name = "Der Fluch der Mepjila",
    },
    [47581] = {
        name = "Segen von Kimbul",
    },
    [47583] = {
        name = "Dimetrodons müssen sterben!",
    },
    [47584] = {
        name = "Ein Dorn im Auge",
    },
    [47585] = {
        name = "Raubtierhaft",
    },
    [47586] = {
        name = "Jagd auf den Jäger",
    },
    [47587] = {
        name = "Kopfjäger Jo",
    },
    [47596] = {
        name = "Kein Plan B",
    },
    [47597] = {
        name = "Kein Goblin wird zurückgelassen",
    },
    [47598] = {
        name = "Hamstern und hehlen",
    },
    [47599] = {
        name = "Rache, heiß serviert",
    },
    [47601] = {
        name = "Einsatzbeurteilung",
    },
    [47602] = {
        name = "Einsatzbereit",
    },
    [47621] = {
        name = "Ein wahrer Loafestschmaus",
    },
    [47622] = {
        name = "Ein zauberhaftes Leuchten",
    },
    [47623] = {
        name = "Der letzte Hexendoktor von Krag'wa",
    },
    [47631] = {
        name = "Treffen mit der Goldkelch",
    },
    [47638] = {
        name = "Mächtige Geister",
    },
    [47647] = {
        name = "Monster von Zem'lan",
    },
    [47659] = {
        name = "Jagt den Jäger",
    },
    [47660] = {
        name = "Gefallene Götzen",
    },
    [47695] = {
        name = "Verlockende Lieder",
    },
    [47696] = {
        name = "Krag'wa der Schreckliche",
    },
    [47697] = {
        name = "Krag'was Hilfe",
    },
    [47706] = {
        name = "Jagd auf König K'tal",
    },
    [47711] = {
        name = "Kopf der Schlange",
    },
    [47716] = {
        name = "Durchsuchung der Ruinen",
    },
    [47733] = {
        name = "Verrat der Loasprecherin",
    },
    [47734] = {
        name = "Gemeinsame Ketzerei",
    },
    [47735] = {
        name = "Uralte Tortollanerarznei",
    },
    [47736] = {
        name = "Köpfe werden rollen",
    },
    [47737] = {
        name = "Der Tempel von Rezan",
    },
    [47738] = {
        name = "Der Wille des Loas",
    },
    [47739] = {
        name = "Der Geruch der Vergeltung",
    },
    [47740] = {
        name = "Haus des Königs",
    },
    [47741] = {
        name = "Wer den Loa opfert",
    },
    [47742] = {
        name = "Zuls Meuterei",
    },
    [47755] = {
        name = "Gefangen und betört",
    },
    [47756] = {
        name = "Befreiung der Goldkelch",
    },
    [47797] = {
        name = "Besetzungsrisiko",
    },
    [47868] = {
        name = "Die Nekropole",
    },
    [47870] = {
        name = "Die Toten schweigen",
    },
    [47871] = {
        name = "Seefahrerausrüstung",
    },
    [47873] = {
        name = "Der Schatz des Käpt'ns",
    },
    [47874] = {
        name = "Ein klarer Kopf",
    },
    [47880] = {
        name = "Ein Tribut für den Tod",
    },
    [47894] = {
        name = "Hüpf, hüpf!",
    },
    [47897] = {
        name = "Zanchuliverräter",
    },
    [47915] = {
        name = "Gefangene retten",
    },
    [47918] = {
        name = "Im Dienste von Krag'wa",
    },
    [47919] = {
        name = "Keine Macht dem Kannibalismus",
    },
    [47924] = {
        name = "Profanitätsfilter",
    },
    [47925] = {
        name = "Shoak auf der Speisekarte",
    },
    [47928] = {
        name = "Opfergaben für den Loa",
    },
    [47939] = {
        name = "Wenn der Schlüssel passt",
    },
    [47943] = {
        name = "Krabbenfangen",
    },
    [47945] = {
        name = "Zum Markt, zum Markt",
    },
    [47946] = {
        name = "Der Speck muss weg",
    },
    [47947] = {
        name = "Große, böse Wölfe",
    },
    [47948] = {
        name = "Schweinskotelett",
    },
    [47949] = {
        name = "Das ist nicht mein Fetisch",
    },
    [47950] = {
        name = "Räucherschinken",
    },
    [47952] = {
        name = "Die verschollene Flotte",
    },
    [47959] = {
        name = "Die Spur der Kriegswache",
    },
    [47960] = {
        name = "Der Tiragardesund",
    },
    [47962] = {
        name = "Das Sturmsangtal",
    },
    [47963] = {
        name = "Uralte Göttin",
    },
    [47965] = {
        name = "Der verfallene Tempel",
    },
    [47968] = {
        name = "Zeichen und Omen",
    },
    [47969] = {
        name = "Der Fluch von Fallhafen",
    },
    [47978] = {
        name = "Die Alte auf Abwegen",
    },
    [47979] = {
        name = "Hexenjagd",
    },
    [47980] = {
        name = "Furioses Vieh",
    },
    [47981] = {
        name = "Fort mit dem Fluch",
    },
    [47982] = {
        name = "Das letzte Bildnis",
    },
    [47996] = {
        name = "Rachenscheusalausrottung",
    },
    [47998] = {
        name = "Kannibalen killen",
    },
    [48003] = {
        name = "Auf Geheiß des Lords",
    },
    [48004] = {
        name = "Reiten für Anfänger",
    },
    [48005] = {
        name = "Seid hier Gast",
    },
    [48008] = {
        name = "Gefährliche Fracht",
    },
    [48009] = {
        name = "Der Verrat der Wache",
    },
    [48014] = {
        name = "Gilblingesindel",
    },
    [48015] = {
        name = "Die Schriftrollen des Gral",
    },
    [48025] = {
        name = "Gras darüber wachsen lassen",
    },
    [48026] = {
        name = "Unter den Wellen",
    },
    [48070] = {
        name = "Das Fest der Norwinsens",
    },
    [48077] = {
        name = "Die Wieseljagd",
    },
    [48080] = {
        name = "Ein gewisser Anteil an Gefahr",
    },
    [48087] = {
        name = "Pferdebringdienst",
    },
    [48088] = {
        name = "Nichts geht über eine Troggparty",
    },
    [48089] = {
        name = "Der Klang der Berge",
    },
    [48090] = {
        name = "Krag'was Auserwählte",
    },
    [48092] = {
        name = "Rache der Frösche",
    },
    [48093] = {
        name = "Naga? Nein danke!",
    },
    [48104] = {
        name = "Eine größere Herausforderung",
    },
    [48108] = {
        name = "Die Tochter der Familie Kronsteig",
    },
    [48109] = {
        name = "Die Augen des Waldes",
    },
    [48110] = {
        name = "Im Falle eines Überfalls",
    },
    [48111] = {
        name = "Prüfungen des Aberglaubens",
    },
    [48113] = {
        name = "Die Lösung stinkt",
    },
    [48165] = {
        name = "Risiken und Nebenwirkungen",
    },
    [48170] = {
        name = "Blutsaugersammlung",
    },
    [48171] = {
        name = "Der Fluch von Schnitztal",
    },
    [48179] = {
        name = "Waldläufer retten",
    },
    [48180] = {
        name = "Ernsthaft großes Problem",
    },
    [48181] = {
        name = "Neeeein",
    },
    [48182] = {
        name = "So eine Steinerei!",
    },
    [48183] = {
        name = "Die lebenden Hügel",
    },
    [48184] = {
        name = "Teile der Geschichte",
    },
    [48195] = {
        name = "Lästige Troglodyten",
    },
    [48196] = {
        name = "Auf Emils Spuren",
    },
    [48198] = {
        name = "Die Beweislast",
    },
    [48237] = {
        name = "Besiegt Nekthara",
    },
    [48283] = {
        name = "Die Beschuldigte",
    },
    [48313] = {
        name = "Naturheilmittel",
    },
    [48314] = {
        name = "Krabbelnder Tod",
    },
    [48315] = {
        name = "Ausgehöhlte, leere Augen",
    },
    [48317] = {
        name = "Eine Nase für Magie",
    },
    [48320] = {
        name = "Kein Puls",
    },
    [48321] = {
        name = "Kreative Vermarktung",
    },
    [48322] = {
        name = "Begrüßung im Goldhauer",
    },
    [48324] = {
        name = "Verloren in Zem'lan",
    },
    [48326] = {
        name = "Das is' Meuterei",
    },
    [48327] = {
        name = "Eine seltsame Lieferung",
    },
    [48329] = {
        name = "Besiegt, aber nicht gebrochen",
    },
    [48330] = {
        name = "Schatzkammer der Zandalari",
    },
    [48331] = {
        name = "Seelen entziehen",
    },
    [48332] = {
        name = "Ranishuressourcen",
    },
    [48334] = {
        name = "Die haben Golems",
    },
    [48335] = {
        name = "Das stärkste Tauwerk in Vol'dun",
    },
    [48347] = {
        name = "Die Angelpunktwerft",
    },
    [48348] = {
        name = "Stechende Dorne",
    },
    [48352] = {
        name = "Ein Heilmittel aus dem Meer",
    },
    [48353] = {
        name = "Das Geschehen an den Docks",
    },
    [48354] = {
        name = "Kontaminierte Lieferungen",
    },
    [48355] = {
        name = "Evakuierung der Gefahrenbereiche",
    },
    [48356] = {
        name = "Besitzergreifende Kopfbedeckung",
    },
    [48365] = {
        name = "Der junge Lord Sturmsang",
    },
    [48366] = {
        name = "In Sicherheit rudern",
    },
    [48367] = {
        name = "Das sind keine Fischeier",
    },
    [48368] = {
        name = "Die entweihte Tiefsee",
    },
    [48369] = {
        name = "Neue Strategie",
    },
    [48370] = {
        name = "Der Tod in den Tiefen",
    },
    [48372] = {
        name = "Unheimliche Anrufung",
    },
    [48399] = {
        name = "Dunkle (Eisen-)Flut",
    },
    [48400] = {
        name = "Telemantischer Coup",
    },
    [48402] = {
        name = "Giftige Berührung",
    },
    [48404] = {
        name = "Die Strolche",
    },
    [48405] = {
        name = "Herr Nett",
    },
    [48419] = {
        name = "Geködert und gefangen",
    },
    [48421] = {
        name = "Blutgetränkte Fluten",
    },
    [48452] = {
        name = "Der Rote Markt",
    },
    [48454] = {
        name = "Beweise des Bösen",
    },
    [48456] = {
        name = "Hexendoktorin Jala",
    },
    [48468] = {
        name = "Bwonsamdis Erlösung",
    },
    [48473] = {
        name = "Respekt für die Rituale",
    },
    [48474] = {
        name = "Gruftwächter",
    },
    [48475] = {
        name = "Geister sehen",
    },
    [48476] = {
        name = "Eine geteilte Gruppe",
    },
    [48477] = {
        name = "Eine fehlt noch",
    },
    [48478] = {
        name = "Kel'vax' Heim",
    },
    [48479] = {
        name = "Schützende Knochen",
    },
    [48480] = {
        name = "Der Untergang von Kel'vax",
    },
    [48492] = {
        name = "Nehmt die Beine in die Hand",
    },
    [48496] = {
        name = "Wiedervereinigung des Trupps",
    },
    [48497] = {
        name = "Machtdemonstration",
    },
    [48498] = {
        name = "Kein Erbarmen für Sithis",
    },
    [48499] = {
        name = "Zurück in den Staub",
    },
    [48504] = {
        name = "Die alten Straßen entlang",
    },
    [48505] = {
        name = "Verliebt und verloren",
    },
    [48515] = {
        name = "Silberne Klingen",
    },
    [48516] = {
        name = "Giftige Gefilde",
    },
    [48517] = {
        name = "Ehrenhafte Entladung",
    },
    [48518] = {
        name = "Retten, wen wir können",
    },
    [48519] = {
        name = "Hoffentlich können sie nicht schwimmen",
    },
    [48520] = {
        name = "Die drei Schwestern",
    },
    [48521] = {
        name = "Bezaubern der Leblosen",
    },
    [48522] = {
        name = "Ein aufschlussreicher Brief",
    },
    [48523] = {
        name = "Die mörderische Matrone",
    },
    [48524] = {
        name = "Ziel ist der Zirkel",
    },
    [48525] = {
        name = "Macht sie zu Kleinholz",
    },
    [48527] = {
        name = "Unersättliche Landhaie",
    },
    [48529] = {
        name = "Immer dieser Hunger",
    },
    [48530] = {
        name = "Herde gesucht",
    },
    [48531] = {
        name = "Eigenartiges Fleisch",
    },
    [48532] = {
        name = "Alpakas vom Acker",
    },
    [48533] = {
        name = "Frittiertes Huhn nach Vol'dunart",
    },
    [48534] = {
        name = "Fletschzahn hat ausgelacht",
    },
    [48535] = {
        name = "Nazmir, der verbotene Sumpf",
    },
    [48538] = {
        name = "Ein wasserdichtes Alibi",
    },
    [48539] = {
        name = "Freihafen",
    },
    [48540] = {
        name = "Unterstützung für die Werft",
    },
    [48549] = {
        name = "Grozztok der Schwarzherzige",
    },
    [48550] = {
        name = "Gestohlene Säckchen",
    },
    [48551] = {
        name = "Wässern oder Welken",
    },
    [48553] = {
        name = "Lasst es sprudeln",
    },
    [48554] = {
        name = "Die Problemquelle",
    },
    [48555] = {
        name = "Die Saat ist noch zu retten",
    },
    [48557] = {
        name = "Setzlinge setzen",
    },
    [48558] = {
        name = "Die Eisenfluträuber",
    },
    [48573] = {
        name = "Krokiliskenleben",
    },
    [48574] = {
        name = "Zähne ziehen",
    },
    [48576] = {
        name = "Sicherer Flug",
    },
    [48577] = {
        name = "Eier abschrecken",
    },
    [48578] = {
        name = "Ein Auge auf den Himmelsschrecken",
    },
    [48581] = {
        name = "Ein paar kräftige Klapse",
    },
    [48584] = {
        name = "Das Blut meiner Feinde",
    },
    [48585] = {
        name = "Überleben in der Ödnis",
    },
    [48588] = {
        name = "Heilung der Infektion",
    },
    [48590] = {
        name = "Kopf und Schulter",
    },
    [48591] = {
        name = "Uroks wahrer Tod",
    },
    [48597] = {
        name = "Sauroliskenflucht",
    },
    [48606] = {
        name = "Geladen und bereit",
    },
    [48616] = {
        name = "Bolas und Vögel",
    },
    [48622] = {
        name = "Der verschwundene Fürst",
    },
    [48655] = {
        name = "Der Lehrling des Kochs",
    },
    [48656] = {
        name = "Wilde Saurolisken",
    },
    [48657] = {
        name = "Möglicherweise lecker",
    },
    [48669] = {
        name = "Urok, Schrecken des Sumpflands",
    },
    [48670] = {
        name = "Fluchtreiter",
    },
    [48677] = {
        name = "Weidenverehrung",
    },
    [48678] = {
        name = "Fragwürdige Opfergaben",
    },
    [48679] = {
        name = "Vorsicht vor dem Schwarm",
    },
    [48680] = {
        name = "Nicht die Bienen!",
    },
    [48682] = {
        name = "Ein einfaches Opfer",
    },
    [48683] = {
        name = "Wechselnde Jahreszeiten",
    },
    [48684] = {
        name = "Unterwegs",
    },
    [48699] = {
        name = "Heimlich nach Zalamar",
    },
    [48715] = {
        name = "Akunda erwartet Euch",
    },
    [48773] = {
        name = "Papiere bitte",
    },
    [48774] = {
        name = "Die Schläge hören nicht auf",
    },
    [48776] = {
        name = "Tauziehen",
    },
    [48778] = {
        name = "Steinsuppe",
    },
    [48790] = {
        name = "Gestohlene Waren",
    },
    [48792] = {
        name = "Bedrohung für die Gesellschaft",
    },
    [48793] = {
        name = "Der Abenteurerclub",
    },
    [48800] = {
        name = "Zeichen der Fledermaus",
    },
    [48801] = {
        name = "Zalamar isolieren",
    },
    [48804] = {
        name = "Alle machen Fehler",
    },
    [48805] = {
        name = "Forschungsrettung",
    },
    [48823] = {
        name = "Knochenzerstörung",
    },
    [48825] = {
        name = "Macht verweigert",
    },
    [48840] = {
        name = "Ruinöse Werbung",
    },
    [48846] = {
        name = "Flüssige Motivation",
    },
    [48847] = {
        name = "Stammesbewaffnung",
    },
    [48852] = {
        name = "Zardrax aufhalten",
    },
    [48853] = {
        name = "Abschlussarbeit",
    },
    [48854] = {
        name = "Machtköder",
    },
    [48855] = {
        name = "Demütigen der Schrecken",
    },
    [48856] = {
        name = "Kanalisierung kappen",
    },
    [48857] = {
        name = "Keine Hoffnung mehr",
    },
    [48869] = {
        name = "Ärger-Licher Zahltag",
    },
    [48871] = {
        name = "Relikte retten",
    },
    [48872] = {
        name = "Die Ausgrabung beschleunigen",
    },
    [48873] = {
        name = "Flauschig und warm",
    },
    [48874] = {
        name = "Wenn doch der Rost nicht wäre",
    },
    [48879] = {
        name = "Jagd auf Falkeneier",
    },
    [48880] = {
        name = "Miese Möwen",
    },
    [48881] = {
        name = "Angebissen",
    },
    [48882] = {
        name = "Messer rein, Gedärme raus",
    },
    [48883] = {
        name = "Mach die Flatter!",
    },
    [48887] = {
        name = "Reinigung des Geistes",
    },
    [48888] = {
        name = "Der Quell ist ewig",
    },
    [48889] = {
        name = "Heilen der Vergangenheit",
    },
    [48890] = {
        name = "Pflichten eines Bluttrolls",
    },
    [48894] = {
        name = "Prüfung der Wahrheit",
    },
    [48895] = {
        name = "Die perfekte Opfergabe",
    },
    [48896] = {
        name = "Wissen der Vergangenheit",
    },
    [48898] = {
        name = "Glücksbringer",
    },
    [48899] = {
        name = "Sicherheit geht vor",
    },
    [48902] = {
        name = "Monströse Energie",
    },
    [48903] = {
        name = "Das perfekte Pferd ist es wert",
    },
    [48904] = {
        name = "Friss den Köder",
    },
    [48905] = {
        name = "Ungewollte Schriftrollen",
    },
    [48909] = {
        name = "Noble Pflichten",
    },
    [48934] = {
        name = "Mal der Verdammten",
    },
    [48939] = {
        name = "Zeigt, was in Euch steckt",
    },
    [48941] = {
        name = "Ein kleiner Umweg",
    },
    [48942] = {
        name = "Yetirandale",
    },
    [48943] = {
        name = "Bergungsrechte",
    },
    [48944] = {
        name = "Geschichtsstunde",
    },
    [48945] = {
        name = "Die Ruinen von Gol Var",
    },
    [48946] = {
        name = "Der Glutorden",
    },
    [48948] = {
        name = "Die Nordpasshöhlen",
    },
    [48963] = {
        name = "Ablenkungstaktiken",
    },
    [48965] = {
        name = "Eine offene Rechnung",
    },
    [48986] = {
        name = "Auf nach Aroms Wehr",
    },
    [48987] = {
        name = "Das Kummertal",
    },
    [48988] = {
        name = "Erinnerungslücke",
    },
    [48991] = {
        name = "Widerlicher Befall",
    },
    [48992] = {
        name = "Heilige Überreste",
    },
    [48993] = {
        name = "Machtvolle Leiter",
    },
    [48996] = {
        name = "Das Ende des Wahnsinns",
    },
    [49001] = {
        name = "Unbequeme Geister",
    },
    [49002] = {
        name = "Erzwungene Landung",
    },
    [49003] = {
        name = "Rache von oben",
    },
    [49005] = {
        name = "Zersplittert und zerbrochen",
    },
    [49028] = {
        name = "Ein Pulli für Rupert",
    },
    [49036] = {
        name = "Meisterleistung",
    },
    [49039] = {
        name = "Der Beginn einer Monsterjagd",
    },
    [49040] = {
        name = "Herzlicher Abschied",
    },
    [49059] = {
        name = "Die Knochen von Xibala",
    },
    [49060] = {
        name = "Tierpopulation von Xibala",
    },
    [49064] = {
        name = "Torga, der Schildkrötenloa",
    },
    [49066] = {
        name = "Gut gekühlt",
    },
    [49067] = {
        name = "Bitte an Bwonsamdi",
    },
    [49069] = {
        name = "GESUCHT: Alte Frostklaue",
    },
    [49070] = {
        name = "Seelen für den Todesloa",
    },
    [49071] = {
        name = "Explodierende Sauger",
    },
    [49072] = {
        name = "Adliger gen Westen",
    },
    [49078] = {
        name = "Die Brut vergiften",
    },
    [49079] = {
        name = "Hir'eek, der Fledermausloa",
    },
    [49080] = {
        name = "Das Ende aller Beschwörungen",
    },
    [49081] = {
        name = "Tod eines Loas",
    },
    [49082] = {
        name = "Rauf und immer weiter",
    },
    [49120] = {
        name = "Mit den Toten sprechen",
    },
    [49122] = {
        name = "Ein Hafen in Not",
    },
    [49125] = {
        name = "Negatives Blut",
    },
    [49126] = {
        name = "Die Hand des Schicksals führen",
    },
    [49130] = {
        name = "Loa-freie Ernährung",
    },
    [49131] = {
        name = "Den Boden heiligen",
    },
    [49132] = {
        name = "Die Schädel der Schädelberster zerbersten",
    },
    [49136] = {
        name = "Jungo, Herold von G'huun",
    },
    [49138] = {
        name = "Käpt'n Gulnakus Schatz",
    },
    [49139] = {
        name = "Das Arsenal einer Armee",
    },
    [49141] = {
        name = "Diplomatie und Dominanz",
    },
    [49144] = {
        name = "Zorn der Zandalari",
    },
    [49145] = {
        name = "Kein Troll wird zurückgelassen",
    },
    [49146] = {
        name = "Geistiges Eigentum",
    },
    [49147] = {
        name = "Demonstration der Stärke",
    },
    [49148] = {
        name = "Alles zerfällt",
    },
    [49149] = {
        name = "Heißt das Voodoo willkommen",
    },
    [49160] = {
        name = "Torgas ewige Rückkehr",
    },
    [49178] = {
        name = "Meine liebsten Dinge",
    },
    [49181] = {
        name = "Glänzendes Medaillon",
    },
    [49185] = {
        name = "Ein Wiedersehen",
    },
    [49218] = {
        name = "Die Schiffbrüchigen",
    },
    [49223] = {
        name = "Ein großes Ding will Weile haben",
    },
    [49225] = {
        name = "Der Anführerin hinterher",
    },
    [49226] = {
        name = "Verstummen der Schwestern",
    },
    [49227] = {
        name = "Der Generalschlüssel",
    },
    [49229] = {
        name = "Kampf der Ruinen",
    },
    [49230] = {
        name = "Lokale Spezialitäten",
    },
    [49232] = {
        name = "Retten, was zu retten ist",
    },
    [49233] = {
        name = "Ich bin Druide, kein Priester",
    },
    [49234] = {
        name = "Marinesoldat an Land",
    },
    [49239] = {
        name = "Kleider machen Leute",
    },
    [49242] = {
        name = "Stachel um Stachel",
    },
    [49259] = {
        name = "Und Gerechtigkeit für alle",
    },
    [49260] = {
        name = "Hilfe beim Packen",
    },
    [49261] = {
        name = "Krabbeneintopf für die Mannschaft",
    },
    [49262] = {
        name = "Bandenjagd",
    },
    [49268] = {
        name = "Haialarm",
    },
    [49274] = {
        name = "Morgrums Untersuchung",
    },
    [49276] = {
        name = "Spannende Erkundung",
    },
    [49278] = {
        name = "Spirituelle Wiederherstellung",
    },
    [49282] = {
        name = "Morgrums ausgedehnte Untersuchung",
    },
    [49283] = {
        name = "Wer sucht die Sucher?",
    },
    [49284] = {
        name = "Frohe Kunde",
    },
    [49285] = {
        name = "Winzige Schätze",
    },
    [49286] = {
        name = "Weisheit hinter Schloss und Riegel",
    },
    [49287] = {
        name = "Verschollene Schildkröten",
    },
    [49288] = {
        name = "Papierjäger",
    },
    [49289] = {
        name = "Ein besonderer Stein",
    },
    [49290] = {
        name = "Zur Perfektion gereift",
    },
    [49292] = {
        name = "Algencocktail",
    },
    [49295] = {
        name = "Kanten schneiden",
    },
    [49299] = {
        name = "Innerer Feind",
    },
    [49300] = {
        name = "Verderbte Wildnis",
    },
    [49302] = {
        name = "Der tödlichste Fang",
    },
    [49309] = {
        name = "Sturz des Donners",
    },
    [49310] = {
        name = "Prophetenplan",
    },
    [49314] = {
        name = "Jagd auf Zardrax",
    },
    [49315] = {
        name = "Schreckensperlenabsprache",
    },
    [49327] = {
        name = "Drängt sie zurück!",
    },
    [49333] = {
        name = "Aufbau eines Arsenals",
    },
    [49334] = {
        name = "Ein mächtiger Gefangener",
    },
    [49335] = {
        name = "Himmelsrufergemetzel",
    },
    [49340] = {
        name = "Die Schlüssel der Hüter",
    },
    [49348] = {
        name = "Der entweihte Tempel",
    },
    [49366] = {
        name = "Hilfe für den Verwundeten",
    },
    [49370] = {
        name = "Rettung des Chronisten",
    },
    [49375] = {
        name = "[LARRY TEST QUEST]",
    },
    [49377] = {
        name = "Runter mit ihrem Kopf",
    },
    [49378] = {
        name = "Vertrauen verdienen",
    },
    [49379] = {
        name = "Kroggs unerwünscht",
    },
    [49380] = {
        name = "Finsteres Juju",
    },
    [49382] = {
        name = "Ein neuer Freund",
    },
    [49393] = {
        name = "Die Raubeine",
    },
    [49394] = {
        name = "Stillhalten",
    },
    [49395] = {
        name = "Von Bären und Bienen",
    },
    [49398] = {
        name = "Hoch die Tassen!",
    },
    [49399] = {
        name = "Das große Ding",
    },
    [49400] = {
        name = "Rekrutierung? Nein Danke!",
    },
    [49401] = {
        name = "Rodrigos Horst",
    },
    [49402] = {
        name = "Einer flog über das Aranest",
    },
    [49403] = {
        name = "Rodrigos Rache",
    },
    [49404] = {
        name = "Alte \"Freunde\"",
    },
    [49405] = {
        name = "Die Verteidiger von Daelins Tor",
    },
    [49406] = {
        name = "Schlachtfest in Zalamar",
    },
    [49407] = {
        name = "Maat meucheln",
    },
    [49408] = {
        name = "Piratenwürfel",
    },
    [49409] = {
        name = "Wo ist der Schatz?",
    },
    [49411] = {
        name = "Kasernenbau",
    },
    [49412] = {
        name = "Henris Helfer",
    },
    [49417] = {
        name = "Reiter der Raubeine",
    },
    [49418] = {
        name = "Der große Boss",
    },
    [49419] = {
        name = "Gefroren",
    },
    [49421] = {
        name = "Die Jagd auf Zul",
    },
    [49422] = {
        name = "Ketzer",
    },
    [49424] = {
        name = "Die ganze Prophezeiung",
    },
    [49425] = {
        name = "Die Goldene Stadt",
    },
    [49426] = {
        name = "Der Schachzug des Königs",
    },
    [49427] = {
        name = "Nicht unsere lila Elfen",
    },
    [49428] = {
        name = "Telemantischer Coup",
    },
    [49431] = {
        name = "Gemütlich und warm",
    },
    [49432] = {
        name = "Die trostlose Seele",
    },
    [49435] = {
        name = "Wo sind alle hin?",
    },
    [49437] = {
        name = "Zerfledderte Notiz",
    },
    [49439] = {
        name = "Rache ist süß",
    },
    [49440] = {
        name = "Nach außen ein Bluttroll",
    },
    [49443] = {
        name = "Eine Lektion in Sachen Hexenjagd",
    },
    [49450] = {
        name = "Ereignisprotokoll",
    },
    [49451] = {
        name = "Sonderurlaub",
    },
    [49452] = {
        name = "Inventardefizit",
    },
    [49453] = {
        name = "VerDAMMt nochmal",
    },
    [49454] = {
        name = "Spinneneiomelette",
    },
    [49464] = {
        name = "Sauroliskenschwänze",
    },
    [49465] = {
        name = "Optimale Ressourcenauslastung",
    },
    [49467] = {
        name = "Hexe des Waldes",
    },
    [49468] = {
        name = "Gut vernetzt",
    },
    [49477] = {
        name = "Überraschende Unterstützung",
    },
    [49479] = {
        name = "Über das Ziel hinaus",
    },
    [49489] = {
        name = "Ein wenig mehr Körper",
    },
    [49490] = {
        name = "Die Urne der Stimmen",
    },
    [49491] = {
        name = "Nahrung für das Voodoo",
    },
    [49492] = {
        name = "Vol'jambas Arroganz",
    },
    [49493] = {
        name = "Zuls ethisches Dilemma",
    },
    [49494] = {
        name = "Zuvembibräu",
    },
    [49495] = {
        name = "Das Schicksal erzwingen",
    },
    [49522] = {
        name = "Karl-Jans Bezahlung",
    },
    [49523] = {
        name = "Ein Minusgeschäft",
    },
    [49529] = {
        name = "Frühjahrsputz",
    },
    [49531] = {
        name = "Effektive Werbung",
    },
    [49569] = {
        name = "Unten am Fluss",
    },
    [49570] = {
        name = "Ein steiniger Start",
    },
    [49571] = {
        name = "Die Vergangenheit durchgraben",
    },
    [49572] = {
        name = "Der Schrein der See",
    },
    [49573] = {
        name = "Der Schrein der Abendflut",
    },
    [49574] = {
        name = "Der Schrein der Stürme",
    },
    [49575] = {
        name = "Tol Dagor: Juwel der Gezeiten",
    },
    [49576] = {
        name = "Höhensondierung",
    },
    [49577] = {
        name = "Unter der Oberfläche",
    },
    [49581] = {
        name = "Sonnengesprenkelte Dünen",
    },
    [49582] = {
        name = "Atal'Dazar: Nicht alles, was glänzt...",
    },
    [49583] = {
        name = "Aus Alt mach Neu",
    },
    [49584] = {
        name = "Das fehlende Kapitel",
    },
    [49585] = {
        name = "Ein steiniger Start",
    },
    [49586] = {
        name = "Die Vergangenheit durchgraben",
    },
    [49587] = {
        name = "Der Schrein der Natur",
    },
    [49588] = {
        name = "Der Schrein der Sande",
    },
    [49589] = {
        name = "Der Schrein der Dämmerung",
    },
    [49599] = {
        name = "Das fehlende Kapitel",
    },
    [49615] = {
        name = "Des Königs Vertrauen",
    },
    [49661] = {
        name = "Eier aus der Region",
    },
    [49662] = {
        name = "Der fehlende Schlüssel",
    },
    [49663] = {
        name = "Falsche Prophezeiungen",
    },
    [49664] = {
        name = "In Anarchie verbündet",
    },
    [49665] = {
        name = "Aufruf zum Aufruhr",
    },
    [49666] = {
        name = "Lasst sie uns fürchten",
    },
    [49667] = {
        name = "Die Kleinen",
    },
    [49668] = {
        name = "Die Schlucht soll brennen",
    },
    [49669] = {
        name = "Entfesselt die Bestien",
    },
    [49676] = {
        name = "Kampfgarderobe",
    },
    [49677] = {
        name = "Angriffspläne",
    },
    [49678] = {
        name = "Sie treiben es auf die Spitze",
    },
    [49679] = {
        name = "Die Sethrakinvasion",
    },
    [49680] = {
        name = "Himmelsruferin Soltok",
    },
    [49681] = {
        name = "Klein Tika",
    },
    [49694] = {
        name = "Wissensdrust",
    },
    [49703] = {
        name = "Haus Sturmsang",
    },
    [49704] = {
        name = "Ernter außer Kontrolle",
    },
    [49705] = {
        name = "Unnötige Härten",
    },
    [49706] = {
        name = "Proklamation - Information",
    },
    [49710] = {
        name = "Eiertanz",
    },
    [49715] = {
        name = "Ärger in der Grausteinfeste",
    },
    [49716] = {
        name = "Eine Lektion in Sachen Vertrauen",
    },
    [49719] = {
        name = "Zahltag",
    },
    [49720] = {
        name = "Frei wie ein Vogel",
    },
    [49725] = {
        name = "Riskanter Plan",
    },
    [49730] = {
        name = "GESUCHT: Donnerschnauze",
    },
    [49731] = {
        name = "Herzlicher Abschied",
    },
    [49733] = {
        name = "Notdürftig zusammengeflickt",
    },
    [49734] = {
        name = "Einen Meuterer meucheln",
    },
    [49735] = {
        name = "Nestschutz",
    },
    [49736] = {
        name = "Für Kul Tiras!",
    },
    [49737] = {
        name = "Luftangriff",
    },
    [49738] = {
        name = "Hände weg von meiner Beute!",
    },
    [49739] = {
        name = "Der Feind vor den Toren",
    },
    [49740] = {
        name = "Feuer einstellen!",
    },
    [49741] = {
        name = "Rechtmäßige Vergeltung",
    },
    [49744] = {
        name = "Bombenklau",
    },
    [49745] = {
        name = "Ihr habt deren Befehle",
    },
    [49746] = {
        name = "Löscharbeiten",
    },
    [49753] = {
        name = "Arsenalbau",
    },
    [49754] = {
        name = "Nicht \"Nur Zul\"",
    },
    [49755] = {
        name = "Schwere Artillerie",
    },
    [49757] = {
        name = "Die Katze auf dem heißen Kupferdach",
    },
    [49758] = {
        name = "Sendet das Signal!",
    },
    [49759] = {
        name = "Werkstattbau",
    },
    [49766] = {
        name = "Der nächste Schritt",
    },
    [49767] = {
        name = "Der nächste Schritt",
    },
    [49768] = {
        name = "Nesingwarys Posten",
    },
    [49769] = {
        name = "Zerstörung des Kataklysmus",
    },
    [49774] = {
        name = "Ein Blatt in den Mund nehmen",
    },
    [49775] = {
        name = "Schlüssel zur Brigg",
    },
    [49776] = {
        name = "Teer ist die Lösung",
    },
    [49777] = {
        name = "Auf der Flucht",
    },
    [49778] = {
        name = "Geht nicht ins Licht",
    },
    [49779] = {
        name = "Durch und durch böse",
    },
    [49780] = {
        name = "Bergung uralten Feuers",
    },
    [49781] = {
        name = "Fangt mich doch",
    },
    [49785] = {
        name = "Vernichtung der Waffe",
    },
    [49791] = {
        name = "Verloren, aber nicht vergessen",
    },
    [49792] = {
        name = "Gebunden und unterdrückt",
    },
    [49793] = {
        name = "Mittel zum Zweck",
    },
    [49794] = {
        name = "Stürmische Gezeiten",
    },
    [49801] = {
        name = "Aggressive Paarungsstrategie",
    },
    [49803] = {
        name = "Wachwechsel",
    },
    [49804] = {
        name = "Scharf nachgedacht",
    },
    [49805] = {
        name = "Instrumente böser Absichten",
    },
    [49806] = {
        name = "Geheime Machenschaften",
    },
    [49807] = {
        name = "Ein neuer Orden",
    },
    [49810] = {
        name = "Kolossale Kuppelei",
    },
    [49814] = {
        name = "Die richtige Stimmung",
    },
    [49818] = {
        name = "Ärger in Fort Daelin",
    },
    [49831] = {
        name = "Aus den Tiefen",
    },
    [49832] = {
        name = "Eine unlesbare Schriftrolle",
    },
    [49869] = {
        name = "Verzweifelte Verteidigung",
    },
    [49870] = {
        name = "Manchmal kommt es eben doch auf die Größe an",
    },
    [49871] = {
        name = "Gegen die Flut",
    },
    [49873] = {
        name = "Die Opferschriften",
    },
    [49874] = {
        name = "Nach Lehrbuch",
    },
    [49876] = {
        name = "Linien im Sand",
    },
    [49877] = {
        name = "Tempel von Sethraliss: Ein gebuchter Gefallen",
    },
    [49878] = {
        name = "Schützende Schrift",
    },
    [49879] = {
        name = "Tödliche Texte",
    },
    [49881] = {
        name = "Der letzte Vers",
    },
    [49882] = {
        name = "Die Federkielprüfung",
    },
    [49884] = {
        name = "Das blaue Licht der Hoffnung",
    },
    [49886] = {
        name = "Immer der Nase nach",
    },
    [49887] = {
        name = "Zwangsarbeit",
    },
    [49896] = {
        name = "Auf nach Falkenforst!",
    },
    [49897] = {
        name = "Das Unerklärliche schaffen",
    },
    [49898] = {
        name = "Klarer Sieg",
    },
    [49901] = {
        name = "Atal'Dazar: Yazma, die gefallene Priesterin",
    },
    [49902] = {
        name = "Zum Trübsumpf",
    },
    [49905] = {
        name = "Überraschende Wendung",
    },
    [49908] = {
        name = "Zurück in Brennadam",
    },
    [49917] = {
        name = "Mit Kaja'mit",
    },
    [49918] = {
        name = "Der Gorillagraben",
    },
    [49919] = {
        name = "Kaja'mittendrin",
    },
    [49920] = {
        name = "Gorillakriegsführung",
    },
    [49922] = {
        name = "König Da'ka",
    },
    [49926] = {
        name = "Die Straße nach Korlach",
    },
    [49932] = {
        name = "Schluss mit Schlummern",
    },
    [49935] = {
        name = "Titanenhüterreparatur leicht gemacht",
    },
    [49937] = {
        name = "Überreste bergen",
    },
    [49938] = {
        name = "Verderbte Erde",
    },
    [49939] = {
        name = "Auf bald, Schwester",
    },
    [49940] = {
        name = "Die Sandnarbenbresche",
    },
    [49941] = {
        name = "Knochenanalyse",
    },
    [49943] = {
        name = "Blutspende",
    },
    [49944] = {
        name = "Wissensdrust",
    },
    [49946] = {
        name = "Linien im Sand",
    },
    [49949] = {
        name = "Unerwünschte Untote",
    },
    [49950] = {
        name = "Blutläuterung",
    },
    [49955] = {
        name = "Nicht von dieser Welt",
    },
    [49956] = {
        name = "Leere verboten",
    },
    [49957] = {
        name = "Protokollwiederherstellung",
    },
    [49960] = {
        name = "Macht sie alle!",
    },
    [49965] = {
        name = "Das Kriegsrudel",
    },
    [49969] = {
        name = "Einen Gott erwecken",
    },
    [49975] = {
        name = "Ruhet in den Tiefen",
    },
    [49980] = {
        name = "Eindämmungsverfahren",
    },
    [49985] = {
        name = "Rückkehr zum Trübsumpf",
    },
    [49995] = {
        name = "Fabrizierte Fabrikationen",
    },
    [49996] = {
        name = "Neubewaffnung",
    },
    [49997] = {
        name = "Das Urteil des Sturms",
    },
    [49998] = {
        name = "Stimmen in der Tiefe",
    },
    [50001] = {
        name = "Hexen behexen",
    },
    [50002] = {
        name = "Eine äußerst wertvolle Fracht",
    },
    [50003] = {
        name = "Die erste Wache",
    },
    [50005] = {
        name = "Händchenhalten",
    },
    [50009] = {
        name = "Schiffswrackbergung",
    },
    [50026] = {
        name = "Rettet unsere Besatzung",
    },
    [50036] = {
        name = "Eine Waffe aus vergangenen Zeiten",
    },
    [50041] = {
        name = "Eine Handvoll Geschosse",
    },
    [50043] = {
        name = "Archäologische Effizienz",
    },
    [50044] = {
        name = "Archäologische Effizienz",
    },
    [50058] = {
        name = "Das Hexenhaustier",
    },
    [50059] = {
        name = "Nichts gehört",
    },
    [50063] = {
        name = "Mit Feuer bekämpfen",
    },
    [50064] = {
        name = "Geht nicht in den Keller",
    },
    [50065] = {
        name = "Ein Grund zu bleiben",
    },
    [50069] = {
        name = "Goldfelds Krieg",
    },
    [50070] = {
        name = "Detektiv Mildenhall",
    },
    [50074] = {
        name = "Brutalitätsschub",
    },
    [50076] = {
        name = "Sammeln der Krieger",
    },
    [50078] = {
        name = "Unvergängliche Totems",
    },
    [50079] = {
        name = "Die Bombe macht bumm",
    },
    [50080] = {
        name = "Plünderer ausplündern",
    },
    [50081] = {
        name = "Der Weg des Schmerzes",
    },
    [50082] = {
        name = "Gelegenheit macht Ziele",
    },
    [50083] = {
        name = "Die Kroggmutter",
    },
    [50085] = {
        name = "Eine Nachricht von Blut und Feuer",
    },
    [50087] = {
        name = "Ateenas Tod",
    },
    [50088] = {
        name = "Goldene Felder der Ewigkeit",
    },
    [50090] = {
        name = "Aufbau der Verteidigung",
    },
    [50091] = {
        name = "Dorfreparatur",
    },
    [50092] = {
        name = "Sind sie zu stark...",
    },
    [50110] = {
        name = "Überbringer schlechter Nachrichten",
    },
    [50112] = {
        name = "Den ersten Stein werfen",
    },
    [50113] = {
        name = "Okulare Extrakte",
    },
    [50114] = {
        name = "Informationen raushämmern",
    },
    [50115] = {
        name = "Standortwechsel",
    },
    [50116] = {
        name = "Eine mögliche Lösung",
    },
    [50117] = {
        name = "Ein tödlicher Trunk",
    },
    [50118] = {
        name = "Nur einen Steinwurf",
    },
    [50119] = {
        name = "Chemische Kreation",
    },
    [50120] = {
        name = "Ein Erfolgsrezept",
    },
    [50121] = {
        name = "Den ersten Stein werfen",
    },
    [50122] = {
        name = "Okulare Extrakte",
    },
    [50123] = {
        name = "Eine Anleitung für die Ewigkeit",
    },
    [50124] = {
        name = "Standortwechsel",
    },
    [50125] = {
        name = "Eine mögliche Lösung",
    },
    [50126] = {
        name = "Ein tödlicher Trunk",
    },
    [50127] = {
        name = "Nur einen Steinwurf",
    },
    [50128] = {
        name = "Chemische Kreation",
    },
    [50129] = {
        name = "Ein Erfolgsrezept",
    },
    [50133] = {
        name = "Unkraut vergeht nicht",
    },
    [50134] = {
        name = "Geräte und Dingsbumse in Hülle und Fülle",
    },
    [50135] = {
        name = "Weist die Ranken in die Schranken!",
    },
    [50136] = {
        name = "Landwirtschaftsstimulator",
    },
    [50138] = {
        name = "Die Schlacht um die Blutfeuerschlucht",
    },
    [50139] = {
        name = "Das fehlende Glied",
    },
    [50149] = {
        name = "Ein scharfes Auge",
    },
    [50150] = {
        name = "Für die richtige Stimmung sorgen",
    },
    [50151] = {
        name = "Ballastbarer Schmied gesucht",
    },
    [50152] = {
        name = "Metalldetektor",
    },
    [50154] = {
        name = "Angeblich eine Delikatesse",
    },
    [50157] = {
        name = "Das Gold in diesen Feldern",
    },
    [50158] = {
        name = "Versenkt",
    },
    [50161] = {
        name = "Raimund retten",
    },
    [50162] = {
        name = "Klebrige Komplikationen",
    },
    [50165] = {
        name = "Die B-Mannschaft",
    },
    [50168] = {
        name = "Königliche Nachfolge",
    },
    [50172] = {
        name = "Der Blutrote Wald",
    },
    [50173] = {
        name = "Silberner Hoffnungsschimmer",
    },
    [50174] = {
        name = "Ordentlich eingewickelt",
    },
    [50175] = {
        name = "Widerlinge mit acht Beinen",
    },
    [50177] = {
        name = "Haltet die Barrikade!",
    },
    [50178] = {
        name = "Probleme am Wurzelpfad",
    },
    [50195] = {
        name = "Bilgenspalters Brigade",
    },
    [50206] = {
        name = "Gegenschlag",
    },
    [50235] = {
        name = "Keine sichere Zuflucht",
    },
    [50238] = {
        name = "Stacheldorn",
    },
    [50240] = {
        name = "Es liegt mir auf der Zunge",
    },
    [50249] = {
        name = "Die dreifache Bedrohung von Boralus",
    },
    [50251] = {
        name = "Geschlossener Kreis",
    },
    [50252] = {
        name = "Paarungshalbzeit",
    },
    [50253] = {
        name = "Ein verbessertes Arsenal",
    },
    [50264] = {
        name = "Rettung der Landarbeiter",
    },
    [50265] = {
        name = "Meister Eschtal retten",
    },
    [50266] = {
        name = "Bittersüß",
    },
    [50268] = {
        name = "Mit ein wenig Geschmack",
    },
    [50270] = {
        name = "Tief im Kern",
    },
    [50271] = {
        name = "Hammer und Tasche",
    },
    [50272] = {
        name = "Mit einem Ohr am Boden",
    },
    [50274] = {
        name = "Schmiedekunst der Titanen",
    },
    [50275] = {
        name = "Ambossangeberei",
    },
    [50276] = {
        name = "Eine Anleitung für die Ewigkeit",
    },
    [50277] = {
        name = "Informationen raushämmern",
    },
    [50278] = {
        name = "Tief im Kern",
    },
    [50279] = {
        name = "Ambossangeberei",
    },
    [50288] = {
        name = "Therazanes Wahl",
    },
    [50297] = {
        name = "Der Kopf ihres Feindes",
    },
    [50306] = {
        name = "Dies und Das",
    },
    [50325] = {
        name = "Schluss mit dem Großritual",
    },
    [50327] = {
        name = "Hallo Wach",
    },
    [50328] = {
        name = "Ungewöhnliche Aromen",
    },
    [50329] = {
        name = "Die Matronen vom Blutholz",
    },
    [50331] = {
        name = "Ein anderes Resultat",
    },
    [50332] = {
        name = "Großa Jägamacka",
    },
    [50340] = {
        name = "Zurückgeklaut",
    },
    [50343] = {
        name = "Mutig in die Metbrauerei Mildenhall",
    },
    [50349] = {
        name = "Überrannte Mine",
    },
    [50350] = {
        name = "Chemiker gesucht",
    },
    [50351] = {
        name = "Gute Mine im bösen Spiel",
    },
    [50352] = {
        name = "Eine Prise Azerit",
    },
    [50353] = {
        name = "Yippie-Ya-Yeah, Schweinebacke",
    },
    [50354] = {
        name = "Augen auf!",
    },
    [50356] = {
        name = "Stein trifft Dynamit",
    },
    [50359] = {
        name = "Putztrupp gesucht",
    },
    [50363] = {
        name = "Kriegsschweine",
    },
    [50365] = {
        name = "Über alle Berge",
    },
    [50367] = {
        name = "Zorn in der Flasche",
    },
    [50368] = {
        name = "Schrecken des Krals",
    },
    [50370] = {
        name = "Tiefer in den Wald",
    },
    [50376] = {
        name = "Seemannsgarn: Dicker Fisch",
    },
    [50381] = {
        name = "Der große Hutraub",
    },
    [50385] = {
        name = "Unermüdliche Bestimmung",
    },
    [50386] = {
        name = "Treibt sie davon",
    },
    [50387] = {
        name = "Schmuck und Tand",
    },
    [50388] = {
        name = "Die Last meines Ehrgeizes",
    },
    [50389] = {
        name = "Bösartige Inspiration",
    },
    [50391] = {
        name = "Seemannsgarn: Angeln mit Blei",
    },
    [50393] = {
        name = "Ein Spross von Pa'ku",
    },
    [50394] = {
        name = "Jetzt Euer Problem",
    },
    [50395] = {
        name = "Der Ruf des Himmels",
    },
    [50396] = {
        name = "Pterrordaxschicksal",
    },
    [50397] = {
        name = "Hochfliegende Ambitionen",
    },
    [50401] = {
        name = "Die Angst vorm Fallen",
    },
    [50402] = {
        name = "SKRIIIII!",
    },
    [50412] = {
        name = "Zurück ins Nest",
    },
    [50417] = {
        name = "Der Ruin ist über uns gekommen",
    },
    [50418] = {
        name = "Seemannsgarn: Sinken und Schwimmen",
    },
    [50433] = {
        name = "Treuer Rat ist teuer",
    },
    [50444] = {
        name = "Falscher Fuffziger",
    },
    [50445] = {
        name = "Kontrollieren der Lage",
    },
    [50446] = {
        name = "Hexenschießen",
    },
    [50447] = {
        name = "Gedenken an die Gefallenen",
    },
    [50448] = {
        name = "Korlach zurückerobern",
    },
    [50449] = {
        name = "Stinkende Zuflucht",
    },
    [50450] = {
        name = "Offensive Ernte",
    },
    [50451] = {
        name = "Durch die Verteidigung fressen",
    },
    [50452] = {
        name = "Wirkungsvoller Schutz",
    },
    [50453] = {
        name = "Barrierenbrecher",
    },
    [50454] = {
        name = "Tod eines Verräters",
    },
    [50455] = {
        name = "Nestflucht",
    },
    [50456] = {
        name = "Verhexte Küken",
    },
    [50457] = {
        name = "Erzielt einen Durchbruch",
    },
    [50466] = {
        name = "Er ist verrückt geworden!",
    },
    [50481] = {
        name = "In den Hallen des Drustkönigs",
    },
    [50493] = {
        name = "Rex holen",
    },
    [50504] = {
        name = "Mit Honig glasierter Sven",
    },
    [50520] = {
        name = "Wo ist Sam?",
    },
    [50530] = {
        name = "Wie verhext",
    },
    [50531] = {
        name = "Direkt vor der Nase",
    },
    [50533] = {
        name = "Auf sie mit Gehölz!",
    },
    [50534] = {
        name = "Wendigo, leb wohl",
    },
    [50535] = {
        name = "Macht der Aufseherin",
    },
    [50536] = {
        name = "Magisches Entschlüsselungsgerät",
    },
    [50538] = {
        name = "Der vermisste Tierführer",
    },
    [50539] = {
        name = "Die Geheimnisse von Zul'Ahjin",
    },
    [50542] = {
        name = "Eine explosive Gelegenheit",
    },
    [50544] = {
        name = "Die Jäger von Kenningers Jagdhütte",
    },
    [50550] = {
        name = "Der Fall von Imperator Korthek",
    },
    [50551] = {
        name = "Tempel von Sethraliss: Avatar des Loas",
    },
    [50553] = {
        name = "Zurück ins Labor",
    },
    [50561] = {
        name = "Sulthis' Stein",
    },
    [50573] = {
        name = "Mitteilung der Verwaltung",
    },
    [50583] = {
        name = "Auf der Anderen Seite",
    },
    [50584] = {
        name = "Ruinöse Rituale",
    },
    [50585] = {
        name = "Hexekution",
    },
    [50586] = {
        name = "Der Untergang von Korlach",
    },
    [50588] = {
        name = "Sturm auf das Anwesen",
    },
    [50593] = {
        name = "Eine blutige Angelegenheit",
    },
    [50594] = {
        name = "Hinter dem Schleier",
    },
    [50595] = {
        name = "Keine Gnade",
    },
    [50596] = {
        name = "Ungeziefer beseitigen",
    },
    [50598] = {
        name = "Zandalariimperium",
    },
    [50599] = {
        name = "Prachtmeeradmiralität",
    },
    [50600] = {
        name = "Der Glutorden",
    },
    [50601] = {
        name = "Die Sturmwacht",
    },
    [50602] = {
        name = "Talanjis Expedition",
    },
    [50605] = {
        name = "Kriegsanstrengungen der Allianz",
    },
    [50606] = {
        name = "Kriegsanstrengungen der Horde",
    },
    [50608] = {
        name = "Verbotene Riten",
    },
    [50609] = {
        name = "Aus dem Schlund des Wahnsinns",
    },
    [50610] = {
        name = "Der aufziehende Sturm",
    },
    [50611] = {
        name = "Die Rache des Sturms",
    },
    [50612] = {
        name = "Ein gespaltenes Haus",
    },
    [50614] = {
        name = "Freiheit für das Meer",
    },
    [50616] = {
        name = "Dringende Verbindlichkeiten",
    },
    [50621] = {
        name = "Ins Netz gegangen",
    },
    [50622] = {
        name = "Für Deike wird es heikel",
    },
    [50635] = {
        name = "Wogende Gezeiten",
    },
    [50639] = {
        name = "Das Kronsteiganwesen: Die gefallene Mutter",
    },
    [50640] = {
        name = "Im Schweinsgalopp",
    },
    [50641] = {
        name = "Die Reihen lichten",
    },
    [50644] = {
        name = "Gegen die Eindringlinge",
    },
    [50645] = {
        name = "Denn der Aalfisch, der hat Zähne",
    },
    [50649] = {
        name = "Von Räubern rauben",
    },
    [50653] = {
        name = "Wiedereroberung der Verteidigung",
    },
    [50656] = {
        name = "Riskante Rettung",
    },
    [50672] = {
        name = "Bei Munition nicht wählerisch",
    },
    [50674] = {
        name = "Hinterlistiges Piratengesindel",
    },
    [50675] = {
        name = "Jäger des verlorenen Schatzes",
    },
    [50679] = {
        name = "Den Schild durchbohren",
    },
    [50690] = {
        name = "Mit Moxi",
    },
    [50691] = {
        name = "Nicht für unser Geld",
    },
    [50696] = {
        name = "Spaß mit Magneten",
    },
    [50697] = {
        name = "Bombe schlägt Stein",
    },
    [50698] = {
        name = "Problemlösung mit Schießpulver",
    },
    [50699] = {
        name = "Arbeiterrechte",
    },
    [50700] = {
        name = "Nichts als Drust",
    },
    [50702] = {
        name = "Jakra'zet besiegen",
    },
    [50703] = {
        name = "Die Horde informieren",
    },
    [50704] = {
        name = "Watt man so findet",
    },
    [50705] = {
        name = "Eine dreiköpfige Schlange",
    },
    [50706] = {
        name = "Reinigung des Deltas",
    },
    [50733] = {
        name = "Ein neuer Morgen",
    },
    [50739] = {
        name = "Vermisste Freunde",
    },
    [50741] = {
        name = "Kröte geht flöten",
    },
    [50742] = {
        name = "Alles wie für uns bestellt",
    },
    [50743] = {
        name = "Das unmittelbare Problem",
    },
    [50745] = {
        name = "Die Infiltration des Reichs",
    },
    [50746] = {
        name = "Krater erobert",
    },
    [50748] = {
        name = "Nicht fallen lassen... noch nicht",
    },
    [50749] = {
        name = "Kostenloser Ritt",
    },
    [50750] = {
        name = "Den Imperator zur Weißglut bringen",
    },
    [50751] = {
        name = "Das belagerte Sanktum",
    },
    [50752] = {
        name = "Relikte von Sethraliss",
    },
    [50753] = {
        name = "Den letzten Bot fressen die Würmer",
    },
    [50754] = {
        name = "Liebe und Verlust",
    },
    [50755] = {
        name = "Vogelfutter",
    },
    [50757] = {
        name = "Ungezähmtes Gemetzel",
    },
    [50758] = {
        name = "Schmerzhafte Erinnerungen",
    },
    [50759] = {
        name = "Spät dran",
    },
    [50760] = {
        name = "Von diesem Tage an",
    },
    [50761] = {
        name = "Blut in der Kapelle",
    },
    [50762] = {
        name = "Das Schicksal der Lady",
    },
    [50763] = {
        name = "Eine letzte Bitte",
    },
    [50769] = {
        name = "Flucht aus Sturmwind",
    },
    [50770] = {
        name = "Effektives Gegengift",
    },
    [50771] = {
        name = "Ein Job für die Aufräumer",
    },
    [50773] = {
        name = "Ihr seid ein Hai",
    },
    [50774] = {
        name = "Kein Bot wird zurückgelassen",
    },
    [50775] = {
        name = "Sand zum Strand",
    },
    [50777] = {
        name = "Der Sturm erwacht",
    },
    [50778] = {
        name = "Böse Absichten",
    },
    [50779] = {
        name = "Ein Neuanfang",
    },
    [50780] = {
        name = "Schwurgebunden",
    },
    [50781] = {
        name = "Über diese Brücke müsst Ihr gehen",
    },
    [50783] = {
        name = "Der Abyssische Rat",
    },
    [50784] = {
        name = "Auge des Sturms",
    },
    [50787] = {
        name = "Augen öffnen",
    },
    [50788] = {
        name = "Der Gegner in den eigenen Reihen",
    },
    [50789] = {
        name = "Frische Luft",
    },
    [50790] = {
        name = "Verfolgungsjagd",
    },
    [50791] = {
        name = "Skrii...",
    },
    [50793] = {
        name = "Höhlenaufruhr",
    },
    [50794] = {
        name = "Zuflucht suchen",
    },
    [50795] = {
        name = "Jetzt gibt's Ärger",
    },
    [50796] = {
        name = "SKRIIIII!",
    },
    [50797] = {
        name = "Eine schildkrötige Einladung",
    },
    [50798] = {
        name = "Hoch hinaus",
    },
    [50801] = {
        name = "Ein Gespür für Ptrobleme",
    },
    [50802] = {
        name = "Eisenebbe",
    },
    [50803] = {
        name = "Ich will alles und ich will es jetzt",
    },
    [50805] = {
        name = "Himmelsruferstilllegung",
    },
    [50808] = {
        name = "Den Fall des Imperiums aufhalten",
    },
    [50810] = {
        name = "Zerbrecht ihre Ketten",
    },
    [50812] = {
        name = "Erwachte Elemente",
    },
    [50814] = {
        name = "Ein schrecklicher Ort",
    },
    [50817] = {
        name = "Schlangen bespielen",
    },
    [50818] = {
        name = "Eine verlorene Flöte",
    },
    [50824] = {
        name = "Das Ende des Sturms",
    },
    [50825] = {
        name = "Der Schrein des Sturms: Geflüster aus der Tiefe",
    },
    [50834] = {
        name = "Ruhe da unten!",
    },
    [50835] = {
        name = "Der Hafen von Zandalar",
    },
    [50838] = {
        name = "Ein Gespür für Ptrobleme",
    },
    [50839] = {
        name = "SKRIIIII!",
    },
    [50841] = {
        name = "SKRIIIII!",
    },
    [50842] = {
        name = "Masthocker",
    },
    [50860] = {
        name = "Ein Gespür für Ptrobleme",
    },
    [50881] = {
        name = "Königlicher Bericht",
    },
    [50886] = {
        name = "Ersatzschwinge",
    },
    [50887] = {
        name = "Ptrau dich",
    },
    [50897] = {
        name = "Feuerrückstoß",
    },
    [50900] = {
        name = "Spätzünder",
    },
    [50901] = {
        name = "Saurid à la Surprise",
    },
    [50903] = {
        name = "Meister vermisst",
    },
    [50904] = {
        name = "Die Verwaiste Passage",
    },
    [50908] = {
        name = "Riecht nach Ärger",
    },
    [50909] = {
        name = "Hauptsache gut bewaffnet",
    },
    [50910] = {
        name = "Gefährliche Jagd",
    },
    [50911] = {
        name = "Einer gegen die Horde",
    },
    [50912] = {
        name = "Ein zündender Einfall",
    },
    [50913] = {
        name = "Segen von Akunda",
    },
    [50929] = {
        name = "Azerit für alle",
    },
    [50930] = {
        name = "Fallen mit Stil",
    },
    [50933] = {
        name = "Ein bedauernswerter Vorfall",
    },
    [50934] = {
        name = "Zufällige Sichtung",
    },
    [50940] = {
        name = "Weisheit der Flügellosen",
    },
    [50942] = {
        name = "Angemessene Kleidung",
    },
    [50943] = {
        name = "Die Freuden des Fliegens",
    },
    [50944] = {
        name = "Fix, aber nicht fertig",
    },
    [50953] = {
        name = "Grünpirscher",
    },
    [50954] = {
        name = "Zandalar für immer!",
    },
    [50955] = {
        name = "Wir sind keine Freunde",
    },
    [50956] = {
        name = "Taschengeld",
    },
    [50959] = {
        name = "Plündernde Piraten",
    },
    [50960] = {
        name = "Harlans Befehle",
    },
    [50963] = {
        name = "Von finsteren Taten und finsteren Tagen",
    },
    [50965] = {
        name = "Das, was bleibt",
    },
    [50967] = {
        name = "Im Wald vermisst",
    },
    [50970] = {
        name = "Schicksal eines Bauern",
    },
    [50972] = {
        name = "Prachtmeers Parley",
    },
    [50976] = {
        name = "Ein uralter Fluch",
    },
    [50978] = {
        name = "Raus mit dem alten Boss",
    },
    [50979] = {
        name = "Nur ein kleiner Schnitt",
    },
    [50980] = {
        name = "Meine hungrige Nachbarin",
    },
    [50988] = {
        name = "Potential für profitable Profite",
    },
    [50990] = {
        name = "Brathühnchenwissenschaft",
    },
    [51001] = {
        name = "Alltägliches Schmuggelgeschäft",
    },
    [51018] = {
        name = "Im Namen eines Freundes",
    },
    [51019] = {
        name = "Sie hat, worauf es ankommt",
    },
    [51020] = {
        name = "Halsabschneiderische Geschäftspraktiken",
    },
    [51052] = {
        name = "Azerit für die Allianz!",
    },
    [51053] = {
        name = "Der Tag, an dem der Hafen fiel",
    },
    [51054] = {
        name = "Überfällige Meuterei",
    },
    [51055] = {
        name = "Die lange Rah des Gesetzes",
    },
    [51056] = {
        name = "Mein letzter Tag im Leben",
    },
    [51057] = {
        name = "Im Feuer zurückgelassen",
    },
    [51059] = {
        name = "Die Goldene Insel",
    },
    [51060] = {
        name = "Unser Anteil an der Beute",
    },
    [51061] = {
        name = "Als ich zum ersten Mal starb",
    },
    [51062] = {
        name = "Zem'lan entkommen",
    },
    [51069] = {
        name = "GESUCHT: Dunkelsprecher Jo'la",
    },
    [51071] = {
        name = "GESUCHT: Kaiserin der Säbelhauer",
    },
    [51072] = {
        name = "GESUCHT: Alpha der Eisenknöchel",
    },
    [51085] = {
        name = "GESUCHT: Dunkler Chronist",
    },
    [51087] = {
        name = "GESUCHT: Dunkler Chronist",
    },
    [51088] = {
        name = "Das Herz der Dunkelheit",
    },
    [51089] = {
        name = "GESUCHT: Tojek",
    },
    [51091] = {
        name = "GESUCHT: Ten'gor und Nol'ixwan",
    },
    [51101] = {
        name = "Der verwundete König",
    },
    [51111] = {
        name = "König oder Beute?",
    },
    [51129] = {
        name = "Eine zweifelhafte Opfergabe",
    },
    [51134] = {
        name = "Wenn Knochen sprechen könnten",
    },
    [51139] = {
        name = "GESUCHT: Tojek",
    },
    [51140] = {
        name = "Den Reichtum teilen",
    },
    [51142] = {
        name = "Nervige Schädlinge",
    },
    [51144] = {
        name = "Ein Bündel Felle",
    },
    [51145] = {
        name = "Fluch von Jani",
    },
    [51146] = {
        name = "Kua'fon macht blau",
    },
    [51147] = {
        name = "Kua'fon macht blau",
    },
    [51149] = {
        name = "Im Hafen vergessen",
    },
    [51150] = {
        name = "Ehrung der Gefallenen",
    },
    [51151] = {
        name = "Ein Brief an die Liga",
    },
    [51159] = {
        name = "Her mit den schweren Geschützen",
    },
    [51161] = {
        name = "GESUCHT: Za'roco",
    },
    [51162] = {
        name = "GESUCHT: Taz'raka der Verräter",
    },
    [51164] = {
        name = "GESUCHT: Teilnehmer für Kobraausflug",
    },
    [51165] = {
        name = "GESUCHT: Sandspäher Vesarik",
    },
    [51167] = {
        name = "Blut von Hir'eek",
    },
    [51168] = {
        name = "Zeloten von Zalamar",
    },
    [51169] = {
        name = "Flucht vor dem Sturz",
    },
    [51170] = {
        name = "Hafenrundfahrt",
    },
    [51177] = {
        name = "Lektionen der Verfluchten",
    },
    [51190] = {
        name = "Eine Atempause verschaffen",
    },
    [51191] = {
        name = "Rettet sie alle",
    },
    [51192] = {
        name = "Vorratsmangel",
    },
    [51193] = {
        name = "Das ist meiner!",
    },
    [51199] = {
        name = "Der Ruhm der Jagd",
    },
    [51200] = {
        name = "Das schwarze Schaf",
    },
    [51201] = {
        name = "Die Geschichte des Trolls",
    },
    [51203] = {
        name = "Im Wolfspelz",
    },
    [51204] = {
        name = "GESUCHT: Klingenklauenalpha",
    },
    [51205] = {
        name = "Rattzifist",
    },
    [51207] = {
        name = "W-Ettin, dass...?",
    },
    [51208] = {
        name = "Ährenvolle Aufgabe",
    },
    [51209] = {
        name = "Mächtiger Grokkfaust",
    },
    [51211] = {
        name = "Das Herz von Azeroth",
    },
    [51214] = {
        name = "Seid ein Schatz",
    },
    [51215] = {
        name = "Ziegen melken",
    },
    [51217] = {
        name = "GESUCHT: Yarsel'ghun",
    },
    [51218] = {
        name = "Nicht zugestelltes Paket",
    },
    [51220] = {
        name = "Schwimmlektionen",
    },
    [51221] = {
        name = "Reaktion erforderlich",
    },
    [51222] = {
        name = "Vermintes Gelände",
    },
    [51224] = {
        name = "Profit und Aufklärung",
    },
    [51226] = {
        name = "Tod aus zwei Richtungen",
    },
    [51229] = {
        name = "Errichtet einen Brückenkopf",
    },
    [51231] = {
        name = "Hexophobie",
    },
    [51233] = {
        name = "Hoffentlich keine Hexen in den Hügeln",
    },
    [51234] = {
        name = "Der Außenposten Krazzelfrazz",
    },
    [51240] = {
        name = "GESUCHT: Ankermaul",
    },
    [51244] = {
        name = "Die Verderbnis in der Tiefe",
    },
    [51246] = {
        name = "Gehörige Abwrackung",
    },
    [51247] = {
        name = "Was sie bei sich trugen",
    },
    [51248] = {
        name = "Produktive Plagegeister",
    },
    [51249] = {
        name = "Krabbenfestmahl",
    },
    [51251] = {
        name = "Kellerbewohner",
    },
    [51278] = {
        name = "Verloren und vergessen",
    },
    [51279] = {
        name = "Nazmanikultisten",
    },
    [51280] = {
        name = "Opfergaben für G'huun",
    },
    [51282] = {
        name = "Hauptmann Conrad",
    },
    [51283] = {
        name = "Reise nach Westen",
    },
    [51286] = {
        name = "Verhindert die Evakuierung",
    },
    [51302] = {
        name = "Der Tiefenpfuhl: Versiegeln von G'huuns Verderbnis",
    },
    [51308] = {
        name = "Stützpunkt in Zuldazar",
    },
    [51309] = {
        name = "Steine von Ragnaros",
    },
    [51310] = {
        name = "Räuber der verlorenen Ernte",
    },
    [51314] = {
        name = "Zorn um das Korn",
    },
    [51319] = {
        name = "Der letzte Aufstieg",
    },
    [51320] = {
        name = "Besiegeltes Schicksal",
    },
    [51331] = {
        name = "Maulwurfmachenschaften",
    },
    [51332] = {
        name = "Reise über das Meer",
    },
    [51335] = {
        name = "Kekse mit Milch",
    },
    [51339] = {
        name = "Federweißer",
    },
    [51340] = {
        name = "Drustvar voraus!",
    },
    [51341] = {
        name = "Tochter der See",
    },
    [51342] = {
        name = "Die Schlacht um Stromgarde",
    },
    [51343] = {
        name = "Schwimmunterricht",
    },
    [51349] = {
        name = "Ehrengebunden",
    },
    [51350] = {
        name = "Unerwartete Hilfe",
    },
    [51351] = {
        name = "Giftige Stacheln",
    },
    [51352] = {
        name = "Mit Feuer spielt man nicht",
    },
    [51353] = {
        name = "Ai'twens Höhle",
    },
    [51354] = {
        name = "Zorn in der Flasche",
    },
    [51356] = {
        name = "GESUCHT: Schwester Lilias",
    },
    [51357] = {
        name = "Bewaffnet und bereit",
    },
    [51358] = {
        name = "GESUCHT: Greifenentführer",
    },
    [51359] = {
        name = "Fragment der Feuerlande",
    },
    [51364] = {
        name = "Ein explosiver Abgang",
    },
    [51366] = {
        name = "Heilende Salbe",
    },
    [51367] = {
        name = "GESUCHT: Tobender Erdwächter",
    },
    [51368] = {
        name = "GESUCHT: Die Hornisse",
    },
    [51369] = {
        name = "Freunde auf Abwegen",
    },
    [51370] = {
        name = "Belohnungen sind knapp",
    },
    [51371] = {
        name = "Eine schmackhafte Opfergabe",
    },
    [51384] = {
        name = "GESUCHT: Rüstmeister Ssylis",
    },
    [51386] = {
        name = "Siegreich im Kampf",
    },
    [51389] = {
        name = "Ausbruch",
    },
    [51390] = {
        name = "GESUCHT: Die blutigen Halsabschneider",
    },
    [51391] = {
        name = "Den Treulosen die Zähne ziehen",
    },
    [51394] = {
        name = "Die Belagerung durchbrechen",
    },
    [51395] = {
        name = "Die Schlüssel der Hüter",
    },
    [51401] = {
        name = "Weitermachen",
    },
    [51402] = {
        name = "Bericht erstatten",
    },
    [51403] = {
        name = "Das Gebot des Sprechers",
    },
    [51407] = {
        name = "Findet ihre Worte",
    },
    [51421] = {
        name = "Potz Blitz",
    },
    [51425] = {
        name = "Am schönsten ist es zu Hause",
    },
    [51426] = {
        name = "Gefährliche Gerätschaften",
    },
    [51427] = {
        name = "Ich mag Schildkröten",
    },
    [51430] = {
        name = "Umgekehrte Tüftelei",
    },
    [51435] = {
        name = "Modisches Säbelrasseln",
    },
    [51436] = {
        name = "Parley mit Piraten",
    },
    [51437] = {
        name = "Fassanstich",
    },
    [51438] = {
        name = "Unser Territorium markieren",
    },
    [51439] = {
        name = "Kanonenkugelkoller",
    },
    [51440] = {
        name = "Richtungswechsel",
    },
    [51441] = {
        name = "Versenkt!",
    },
    [51442] = {
        name = "Wer ist hier der Käpt'n?",
    },
    [51443] = {
        name = "Missionsrichtlinie",
    },
    [51445] = {
        name = "Thros, die Verseuchten Lande",
    },
    [51465] = {
        name = "Ein Haufen Schrott",
    },
    [51472] = {
        name = "Lebenserhaltung",
    },
    [51474] = {
        name = "In Feuer und Flamme geschmiedet",
    },
    [51479] = {
        name = "Die Unverderbten",
    },
    [51483] = {
        name = "Tradition der Dunkeleisenzwerge",
    },
    [51484] = {
        name = "Tradition der Mag'har",
    },
    [51485] = {
        name = "Für die Horde",
    },
    [51486] = {
        name = "Für die Allianz",
    },
    [51487] = {
        name = "Auf der Suche nach Antworten",
    },
    [51488] = {
        name = "Archiviertes Wissen",
    },
    [51489] = {
        name = "Zeit zu gehen",
    },
    [51490] = {
        name = "Grenzprobleme",
    },
    [51492] = {
        name = "Pulververschwörung",
    },
    [51504] = {
        name = "Kekslieferung",
    },
    [51513] = {
        name = "Zalazanes Rückkehr",
    },
    [51514] = {
        name = "Gescheiterter Handel",
    },
    [51515] = {
        name = "Rache für Vol'jin",
    },
    [51516] = {
        name = "Atal'Dazar: Die Asche eines Kriegshäuptlings",
    },
    [51517] = {
        name = "Ihr schuldet mir einen Geist",
    },
    [51518] = {
        name = "Der verlorene Geist",
    },
    [51519] = {
        name = "Geisterruf",
    },
    [51520] = {
        name = "Gerechtigkeit für die Gefallenen",
    },
    [51521] = {
        name = "Die wahre Anführerin von Zandalar",
    },
    [51526] = {
        name = "Ruf des Kriegsfürsten",
    },
    [51532] = {
        name = "In den Sturm",
    },
    [51533] = {
        name = "Vol'jins Gleve",
    },
    [51534] = {
        name = "Die Schlacht um Brennadam",
    },
    [51536] = {
        name = "Auf der Jagd",
    },
    [51538] = {
        name = "Nachricht aus der Tiefe",
    },
    [51539] = {
        name = "Unterrichtet die Horde!",
    },
    [51543] = {
        name = "Setzlinge im Schnee",
    },
    [51544] = {
        name = "Kanonen ausschalten",
    },
    [51545] = {
        name = "Böser Brecher",
    },
    [51547] = {
        name = "GESUCHT: Wassergram",
    },
    [51552] = {
        name = "So viel zu tun",
    },
    [51554] = {
        name = "Nachladen",
    },
    [51555] = {
        name = "Auf Kurs halten",
    },
    [51557] = {
        name = "Warnung der Eisenfluträuber",
    },
    [51569] = {
        name = "Die Zandalarkampagne",
    },
    [51573] = {
        name = "Rückendeckung",
    },
    [51574] = {
        name = "Frisch gepresst",
    },
    [51582] = {
        name = "Wie das Land, so der Mildenhall",
    },
    [51587] = {
        name = "Vorwärts!",
    },
    [51589] = {
        name = "Brechen der Moral von Kul Tiras",
    },
    [51590] = {
        name = "Ins Herz von Tiragarde",
    },
    [51591] = {
        name = "Unser Berg",
    },
    [51592] = {
        name = "Gemütlich einrichten",
    },
    [51593] = {
        name = "Untersuchung von Bronhavn",
    },
    [51594] = {
        name = "Sprengstoff in der Gießerei",
    },
    [51595] = {
        name = "Hochexplosiv",
    },
    [51596] = {
        name = "Munitionsbeschaffung",
    },
    [51597] = {
        name = "Schießpulverforschung",
    },
    [51598] = {
        name = "Für eine Handvoll Chaos",
    },
    [51599] = {
        name = "Todesfalle",
    },
    [51601] = {
        name = "Die Bronhavnfahrt",
    },
    [51602] = {
        name = "Banditenklingen",
    },
    [51643] = {
        name = "Ein eiserner Wall",
    },
    [51663] = {
        name = "Vorbereitung auf den Untergang",
    },
    [51674] = {
        name = "Die Flammen löschen",
    },
    [51675] = {
        name = "Bringt sie zur Strecke",
    },
    [51677] = {
        name = "Körper und Geist heilen",
    },
    [51678] = {
        name = "Die Rastakhans Macht",
    },
    [51679] = {
        name = "Ein merkwürdiger Anlaufhafen",
    },
    [51680] = {
        name = "In Bwonsamdis Schatten",
    },
    [51689] = {
        name = "Tortollanerrettung",
    },
    [51691] = {
        name = "Beinahe rettungswürdig",
    },
    [51696] = {
        name = "Zurückfordern, was uns gehört",
    },
    [51711] = {
        name = "Bombenstimmung",
    },
    [51712] = {
        name = "Auge um Auge",
    },
    [51714] = {
        name = "Mission vom König",
    },
    [51715] = {
        name = "Krieg der Schatten",
    },
    [51717] = {
        name = "Der beste Honig in Vol'dun",
    },
    [51718] = {
        name = "\"Honig\" ernten",
    },
    [51720] = {
        name = "Auf zum Schreddern",
    },
    [51723] = {
        name = "Sägebespänt",
    },
    [51726] = {
        name = "Nichts wie raus hier",
    },
    [51728] = {
        name = "Brennt alles nieder",
    },
    [51752] = {
        name = "Gräulich",
    },
    [51770] = {
        name = "Mission vom Kriegshäuptling",
    },
    [51771] = {
        name = "Krieg der Schatten",
    },
    [51772] = {
        name = "Der Stamm der Tortaka",
    },
    [51773] = {
        name = "Die Aschenwindbedrohung",
    },
    [51775] = {
        name = "Das Letztwindlager",
    },
    [51784] = {
        name = "Spaziergang auf einem Friedhof",
    },
    [51785] = {
        name = "Grabinschriften untersuchen",
    },
    [51786] = {
        name = "Im Zustand der Unruhe",
    },
    [51787] = {
        name = "Unser Los im Leben",
    },
    [51788] = {
        name = "Der Gruftwächter",
    },
    [51789] = {
        name = "Was von Marschall M. Valentin übrig blieb",
    },
    [51795] = {
        name = "Die Schlacht um Lordaeron",
    },
    [51796] = {
        name = "Die Schlacht um Lordaeron",
    },
    [51797] = {
        name = "Gezeitenweisen aufspüren",
    },
    [51798] = {
        name = "Kein Preis ist zu hoch",
    },
    [51803] = {
        name = "Die Kampagne in Kul Tiras",
    },
    [51805] = {
        name = "Sie werden das Fürchten lernen",
    },
    [51810] = {
        name = "Kapitän Hartford",
    },
    [51813] = {
        name = "Die Schwarzfelstiefen",
    },
    [51818] = {
        name = "Kommandant und Kapitänin",
    },
    [51819] = {
        name = "Zerstreuung unserer Feinde",
    },
    [51829] = {
        name = "Ranahs Schraubenschlüssel",
    },
    [51830] = {
        name = "Zellings Potenzial",
    },
    [51837] = {
        name = "Was sein wird, wird sein",
    },
    [51870] = {
        name = "Inselexpedition",
    },
    [51881] = {
        name = "Der Minenräumer",
    },
    [51888] = {
        name = "Inselexpedition",
    },
    [51903] = {
        name = "Inselexpedition",
    },
    [51904] = {
        name = "Inselexpedition",
    },
    [51916] = {
        name = "Die Vereinigung von Zandalar",
    },
    [51918] = {
        name = "Die Vereinigung von Kul Tiras",
    },
    [51961] = {
        name = "Die andauernde Kampagne",
    },
    [51967] = {
        name = "Rückkehr nach Boralus",
    },
    [51968] = {
        name = "Rückkehr nach Boralus",
    },
    [51969] = {
        name = "Rückkehr nach Boralus",
    },
    [51975] = {
        name = "Champion: Schattenjäger Ty'jin",
    },
    [51979] = {
        name = "Die andauernde Kampagne",
    },
    [51980] = {
        name = "GESUCHT: Jabra'kan",
    },
    [51984] = {
        name = "Rückkehr nach Zuldazar",
    },
    [51985] = {
        name = "Rückkehr nach Zuldazar",
    },
    [51986] = {
        name = "Rückkehr nach Zuldazar",
    },
    [51987] = {
        name = "Champion: Hobart Wurfhammer",
    },
    [51990] = {
        name = "Schwingen für den Kral",
    },
    [51991] = {
        name = "Die Batterien aufladen",
    },
    [51998] = {
        name = "WFT: Jetzt mit echtem Terrorhorn",
    },
    [52003] = {
        name = "Champion: Kelsey Stahlfunken",
    },
    [52026] = {
        name = "Attentat in Übersee",
    },
    [52027] = {
        name = "Der Plan für Vol'dun",
    },
    [52028] = {
        name = "Durchkämmt die Wüste",
    },
    [52029] = {
        name = "Schmutzige Arbeit",
    },
    [52030] = {
        name = "Weiterkämmen",
    },
    [52031] = {
        name = "Klassische Archäologie",
    },
    [52032] = {
        name = "Hört niemals auf zu kämmen",
    },
    [52033] = {
        name = "GESUCHT: Die Frostjägerin",
    },
    [52034] = {
        name = "Eine Botschaft an die Zandalari",
    },
    [52035] = {
        name = "Improvisierte Überlebenskunst",
    },
    [52036] = {
        name = "Sie haben hier Alpakas",
    },
    [52038] = {
        name = "Aufteilen",
    },
    [52039] = {
        name = "Verspätete Todifizierung",
    },
    [52040] = {
        name = "Von Pfeilen durchlöchert",
    },
    [52041] = {
        name = "Bei Wyrmbann melden",
    },
    [52042] = {
        name = "Der große Knall",
    },
    [52061] = {
        name = "Eikceps das Schwein!",
    },
    [52065] = {
        name = "Schlimmer als es aussieht",
    },
    [52067] = {
        name = "Überlebende",
    },
    [52068] = {
        name = "Wieder helfen, aber anderswo",
    },
    [52069] = {
        name = "Mehr Kanonenfutter",
    },
    [52070] = {
        name = "Bauer auf der Lauer",
    },
    [52073] = {
        name = "Bittgesuch an Krag'wa",
    },
    [52074] = {
        name = "Rettung",
    },
    [52075] = {
        name = "Verknöchert",
    },
    [52113] = {
        name = "Vol'jin, Sohn von Sen'jin",
    },
    [52114] = {
        name = "Einen wahren Anführer ehren",
    },
    [52122] = {
        name = "Verlassen sein",
    },
    [52127] = {
        name = "Der Wolfsbau",
    },
    [52128] = {
        name = "Fährenpass",
    },
    [52129] = {
        name = "Energieprobleme",
    },
    [52130] = {
        name = "Seemannsgarn: Carpe Diem",
    },
    [52131] = {
        name = "Wir brauchen einander",
    },
    [52132] = {
        name = "Beweis für Piraterie",
    },
    [52139] = {
        name = "Wichtige Angelegenheiten",
    },
    [52146] = {
        name = "Blutgetränkter Sand",
    },
    [52147] = {
        name = "Hordenlähmung",
    },
    [52149] = {
        name = "Ewige Flamme",
    },
    [52150] = {
        name = "Wie man einen Dunklen Waldläufer tötet",
    },
    [52151] = {
        name = "Eine vereinte Nation",
    },
    [52153] = {
        name = "Belagerung von Boralus: Lady Aschenwinds Rückkehr",
    },
    [52154] = {
        name = "Unser nächstes Ziel",
    },
    [52156] = {
        name = "Tortollaner in Bedrängnis",
    },
    [52158] = {
        name = "Die wilde Jagd",
    },
    [52170] = {
        name = "Areiels Ende",
    },
    [52171] = {
        name = "Eine Option: Feuer",
    },
    [52172] = {
        name = "Sie dürfen hier nicht bleiben",
    },
    [52173] = {
        name = "Die Leerenelfen sind in Bereitschaft",
    },
    [52183] = {
        name = "Ein Plan, der funktioniert",
    },
    [52184] = {
        name = "Ritualrelikte",
    },
    [52185] = {
        name = "Ein gut platziertes Portal",
    },
    [52186] = {
        name = "Der Großteil der Wache",
    },
    [52187] = {
        name = "Alte Kollegen",
    },
    [52188] = {
        name = "Lehren der Gezeitenweisen",
    },
    [52189] = {
        name = "Verwirkte Seelen",
    },
    [52190] = {
        name = "Die Oberhand gewinnen",
    },
    [52191] = {
        name = "Gefangenes Leben",
    },
    [52192] = {
        name = "Gezeitenhilfe",
    },
    [52194] = {
        name = "Was Ihr vielleicht bereut",
    },
    [52203] = {
        name = "Papierkrieg",
    },
    [52204] = {
        name = "Die Leerenlösung",
    },
    [52205] = {
        name = "Die Bilgewasserbonanza macht Bumm",
    },
    [52208] = {
        name = "Begegnung des Bösen",
    },
    [52210] = {
        name = "SOS auf hoher See",
    },
    [52212] = {
        name = "Die Schlacht um Stromgarde",
    },
    [52219] = {
        name = "Ziel: Blutprinz Dreven",
    },
    [52241] = {
        name = "Ein Paradies für gierige Goblins",
    },
    [52246] = {
        name = "Verschollene Fracht",
    },
    [52247] = {
        name = "Jagd auf Gallywix",
    },
    [52252] = {
        name = "Ein explosiver Auftritt",
    },
    [52253] = {
        name = "Die Schlüssel zum Erfolg in Freihafen",
    },
    [52258] = {
        name = "Mit Muscheln muss man manchmal meckern",
    },
    [52259] = {
        name = "Auf dass ihm die Lust vergehe",
    },
    [52260] = {
        name = "In die Ecke gedrängt",
    },
    [52261] = {
        name = "Gallywix auf der Flucht",
    },
    [52281] = {
        name = "Im Schutz von Flinkschwinge",
    },
    [52282] = {
        name = "Wie man ein Schlachtschiff der Zandalari versenkt",
    },
    [52283] = {
        name = "Die Pa'ku sabotieren",
    },
    [52284] = {
        name = "Schiffslogbücher",
    },
    [52285] = {
        name = "Das vergrößerte Miniaturunterseeboot",
    },
    [52286] = {
        name = "Direkt vor ihrer Nase",
    },
    [52287] = {
        name = "Informationsvorenthaltung",
    },
    [52288] = {
        name = "Reise ins Leere",
    },
    [52289] = {
        name = "Der Sieg ist sicher",
    },
    [52290] = {
        name = "Der Feind meines Feindes ist meine Verkleidung",
    },
    [52291] = {
        name = "Der Sieg war sicher",
    },
    [52294] = {
        name = "Gefallene Götzen",
    },
    [52305] = {
        name = "Umwelt gegen Veranlagung",
    },
    [52308] = {
        name = "Abgefangene Befehle",
    },
    [52311] = {
        name = "Die Schließkassette des Schmierigen",
    },
    [52317] = {
        name = "Nicht nehmen, nur werfen",
    },
    [52428] = {
        name = "Das Herz erfüllen",
    },
    [52431] = {
        name = "Nicht-Landezone",
    },
    [52443] = {
        name = "Der letzte Stützpunkt",
    },
    [52444] = {
        name = "Der letzte Stützpunkt",
    },
    [52445] = {
        name = "Tol Dagor: Der vierte Schlüssel",
    },
    [52447] = {
        name = "Freiraum zum Wachsen",
    },
    [52449] = {
        name = "Die geheimnisvolle Insel",
    },
    [52450] = {
        name = "Die Vereinigung von Kul Tiras",
    },
    [52453] = {
        name = "Eine aussichtslose Hoffnung",
    },
    [52472] = {
        name = "Na'logo muss wandern",
    },
    [52473] = {
        name = "Die Flotte versenken",
    },
    [52477] = {
        name = "GESUCHT: Ayame",
    },
    [52480] = {
        name = "GESUCHT: Ayame",
    },
    [52481] = {
        name = "Aus Mythen und Märchen",
    },
    [52482] = {
        name = "Der alte Bär",
    },
    [52483] = {
        name = "Alptraumfänger",
    },
    [52484] = {
        name = "Vergrabene Macht",
    },
    [52485] = {
        name = "Fokus des Hasses",
    },
    [52486] = {
        name = "Das Kronsteiganwesen: Den Herzbann absorbieren",
    },
    [52487] = {
        name = "In die Dunkelheit",
    },
    [52488] = {
        name = "Renitente Runen",
    },
    [52489] = {
        name = "Die Jagd auf Blutprinz Dreven",
    },
    [52490] = {
        name = "Hinter feindlichen Schiffen",
    },
    [52491] = {
        name = "Breitseitenbambule",
    },
    [52492] = {
        name = "Die Wildhämmerspezialität",
    },
    [52493] = {
        name = "Eine unnatürliche Mannschaft",
    },
    [52494] = {
        name = "Garstige Kristalle garstiger Leute",
    },
    [52495] = {
        name = "Beendet die Bedohung durch die San'layn",
    },
    [52496] = {
        name = "Eine saubere Flucht",
    },
    [52508] = {
        name = "Ritualgegenstände",
    },
    [52509] = {
        name = "Die Stärke des Sturms",
    },
    [52510] = {
        name = "Schrein des Sturms: Das fehlende Ritual",
    },
    [52511] = {
        name = "Öffnen des Weges",
    },
    [52512] = {
        name = "Schicksalsend",
    },
    [52513] = {
        name = "In Dunkelheit verloren",
    },
    [52544] = {
        name = "Der Kriegsvorrat",
    },
    [52654] = {
        name = "Die Kriegskampagne",
    },
    [52746] = {
        name = "Der Kriegsvorrat",
    },
    [52748] = {
        name = "Mit Blick auf den Himmel",
    },
    [52749] = {
        name = "Die Kriegskampagne",
    },
    [52750] = {
        name = "Bewaffnete Bauern",
    },
    [52762] = {
        name = "Der Fremdenführer",
    },
    [52764] = {
        name = "Reise mitten ins Nirgendwo",
    },
    [52765] = {
        name = "In die Tiefe tauchen",
    },
    [52766] = {
        name = "Ein Wrack am Meeresboden",
    },
    [52767] = {
        name = "Erkennungsmarken überprüfen",
    },
    [52768] = {
        name = "Der versunkene Friedhof",
    },
    [52769] = {
        name = "Ein Kapitän nach dem anderen",
    },
    [52770] = {
        name = "Nerviges Leuchten",
    },
    [52772] = {
        name = "Das Riff unterm Meer",
    },
    [52773] = {
        name = "Wasseratmender Drache",
    },
    [52774] = {
        name = "Schnappen und rennen",
    },
    [52782] = {
        name = "Ruf zu den Waffen: Sturmsangtal",
    },
    [52787] = {
        name = "Schmerzlinderung",
    },
    [52788] = {
        name = "Keiner darf überleben",
    },
    [52789] = {
        name = "Mit ihrem Rat am Ende",
    },
    [52790] = {
        name = "Das Töten beenden",
    },
    [52793] = {
        name = "Zum Wagen wagen",
    },
    [52795] = {
        name = "Da ist jemand sauer",
    },
    [52796] = {
        name = "Weniger ist manchmal mehr",
    },
    [52800] = {
        name = "Tol Dagor: Der Aschenwindaufseher",
    },
    [52855] = {
        name = "Alchemie ist eine ungenaue Wissenschaft",
    },
    [52857] = {
        name = "Zur weiteren Beobachtung festgehalten",
    },
    [52876] = {
        name = "GESUCHT: Schlachtmetzler",
    },
    [52942] = {
        name = "Alte Bande neu knüpfen",
    },
    [52943] = {
        name = "Respekt für die Klans",
    },
    [52944] = {
        name = "Ruf zu den Waffen: Drustvar",
    },
    [52945] = {
        name = "Bindungen, im Kampf geschmiedet",
    },
    [52946] = {
        name = "Eine sterbende Welt",
    },
    [52948] = {
        name = "Ruf zu den Waffen: Tiragardesund",
    },
    [52949] = {
        name = "Ruf zu den Waffen: Nazmir",
    },
    [52950] = {
        name = "Ruf zu den Waffen: Vol'dun",
    },
    [52953] = {
        name = "Ruf zu den Waffen: Vol'dun",
    },
    [52954] = {
        name = "Ruf zu den Waffen: Nazmir",
    },
    [52955] = {
        name = "Tyrannei des Lichts",
    },
    [52956] = {
        name = "Ruf zu den Waffen: Tiragardesund",
    },
    [52958] = {
        name = "Ruf zu den Waffen: Drustvar",
    },
    [52965] = {
        name = "Ein Winterhauchgeschenk",
    },
    [52978] = {
        name = "Prinz im Schlepptau",
    },
    [52990] = {
        name = "Zum Hafen zurückkehren",
    },
    [53003] = {
        name = "Ein Teufelskreis",
    },
    [53011] = {
        name = "Ein leicht geschütteltes Geschenk",
    },
    [53028] = {
        name = "Eine sterbende Welt",
    },
    [53031] = {
        name = "Das Gebot des Sprechers",
    },
    [53041] = {
        name = "Stichproben",
    },
    [53045] = {
        name = "Bestandsaufnahme am Kai",
    },
    [53050] = {
        name = "Tiefer nach Kul Tiras hinein",
    },
    [53052] = {
        name = "Tiefer nach Zandalar hinein",
    },
    [53055] = {
        name = "Unseren Einfluss ausweiten",
    },
    [53056] = {
        name = "Unseren Einfluss ausweiten",
    },
    [53061] = {
        name = "Der Azeritauftrieb",
    },
    [53062] = {
        name = "Der Azeritauftrieb",
    },
    [53063] = {
        name = "Eine Mission der Einheit",
    },
    [53065] = {
        name = "Operation: Totengräber",
    },
    [53066] = {
        name = "Operation: Wasserweisheit",
    },
    [53067] = {
        name = "Operation: Gründler",
    },
    [53068] = {
        name = "Operation: Haken und Leine",
    },
    [53069] = {
        name = "Operation: Blutpfeil",
    },
    [53070] = {
        name = "Operation: Taschendieb",
    },
    [53071] = {
        name = "Operation: Greifenklaue",
    },
    [53072] = {
        name = "Operation: Mitten ins Herz",
    },
    [53074] = {
        name = "Verstärkung",
    },
    [53079] = {
        name = "Verstärkung",
    },
    [53097] = {
        name = "Verzweifelte Waschungen",
    },
    [53098] = {
        name = "Champion: Shandris Mondfeder",
    },
    [53099] = {
        name = "Ein Körnchen kosmischer Wahrheit",
    },
    [53105] = {
        name = "Fehlbesetzter Glaube",
    },
    [53109] = {
        name = "Haus Kronsteig",
    },
    [53110] = {
        name = "Der Oberste Dornsprecher",
    },
    [53121] = {
        name = "Die Belagerung von Boralus",
    },
    [53128] = {
        name = "Die Klage des Lordadmirals",
    },
    [53131] = {
        name = "Die Königsruh",
    },
    [53185] = {
        name = "Beitrag für die Kriegsfront",
    },
    [53194] = {
        name = "An die Front",
    },
    [53197] = {
        name = "Erkundung der Front",
    },
    [53198] = {
        name = "Zurück nach Boralus",
    },
    [53208] = {
        name = "An die Front",
    },
    [53209] = {
        name = "Beitrag für die Kriegsfront",
    },
    [53210] = {
        name = "Erkundung der Front",
    },
    [53212] = {
        name = "Zurück nach Zuldazar",
    },
    [53330] = {
        name = "GESUCHT: Klingenklauenalpha",
    },
    [53332] = {
        name = "Zeit für Krieg",
    },
    [53333] = {
        name = "Zeit für Krieg",
    },
    [53336] = {
        name = "GESUCHT: Kaiserin der Säbelhauer",
    },
    [53337] = {
        name = "GESUCHT: Alpha der Eisenknöchel",
    },
    [53342] = {
        name = "Der Geschmolzene Kern",
    },
    [53347] = {
        name = "Hummelbummel will sich tummeln",
    },
    [53348] = {
        name = "GESUCHT: Donnerschnauze",
    },
    [53351] = {
        name = "Das RIESENFLÖZ!!: Eisenfeind",
    },
    [53352] = {
        name = "Die Feuerlande",
    },
    [53353] = {
        name = "Echo von Kriegsfürstin Zaela",
    },
    [53354] = {
        name = "Echo von Gul'dan",
    },
    [53355] = {
        name = "Echo von Garrosh Höllschrei",
    },
    [53369] = {
        name = "Na'logo muss wandern",
    },
    [53370] = {
        name = "Stunde der Abrechnung",
    },
    [53371] = {
        name = "Flotte Biene",
    },
    [53372] = {
        name = "Stunde der Abrechnung",
    },
    [53406] = {
        name = "Die Herzkammer",
    },
    [53430] = {
        name = "Armbrust des Glutordens",
    },
    [53431] = {
        name = "Fläschchen des Glutordens",
    },
    [53432] = {
        name = "Messer des Glutordens",
    },
    [53433] = {
        name = "Hut des Glutordens",
    },
    [53438] = {
        name = "GESUCHT: Wyvernwilderer",
    },
    [53440] = {
        name = "GESUCHT: Die Hornisse",
    },
    [53449] = {
        name = "Wildgewordene Affenbande",
    },
    [53450] = {
        name = "König Da'ka",
    },
    [53451] = {
        name = "GESUCHT: Tobender Erdwächter",
    },
    [53452] = {
        name = "Gorillakriegsführung",
    },
    [53453] = {
        name = "Gorillas im Schmock",
    },
    [53454] = {
        name = "GESUCHT: Rüstmeister Ssylis",
    },
    [53455] = {
        name = "GESUCHT: Die blutigen Halsabschneider",
    },
    [53456] = {
        name = "GESUCHT: Die Frostjägerin",
    },
    [53458] = {
        name = "GESUCHT: Wassergram",
    },
    [53459] = {
        name = "GESUCHT: Schwester Lilias",
    },
    [53461] = {
        name = "Silberner Hoffnungsschimmer",
    },
    [53462] = {
        name = "Ordentlich eingewickelt",
    },
    [53463] = {
        name = "Widerlinge mit acht Beinen",
    },
    [53464] = {
        name = "Das Dorf Schluchtbach",
    },
    [53465] = {
        name = "Teekränzchen",
    },
    [53466] = {
        name = "Vision der Zeit",
    },
    [53467] = {
        name = "Höhlen der Zeit",
    },
    [53566] = {
        name = "Dunkeleisenzwerge",
    },
    [53583] = {
        name = "Unsere Taktik anpassen",
    },
    [53602] = {
        name = "Unsere Taktik anpassen",
    },
    [53719] = {
        name = "Gefolgschaft der Zandalari",
    },
    [53720] = {
        name = "Gefolgschaft von Kul Tiras",
    },
    [53725] = {
        name = "Ein zerschmettertes Volk",
    },
    [53734] = {
        name = "Unter Geistern wandeln",
    },
    [53735] = {
        name = "Die ersten Gefallenen",
    },
    [53736] = {
        name = "Wehklagen der Hochgeborenen",
    },
    [53737] = {
        name = "Der Tag, als die Hoffnung starb",
    },
    [53738] = {
        name = "Die Verteidigung von Quel'Danas",
    },
    [53760] = {
        name = "Unbeabsichtigte Konsequenzen",
    },
    [53761] = {
        name = "Der Schatz der Piratin",
    },
    [53762] = {
        name = "Die Orkanruferkrone",
    },
    [53763] = {
        name = "Das Messer drehen",
    },
    [53765] = {
        name = "Sein Blick ruht auf Euch",
    },
    [53766] = {
        name = "Sein Blick ruht auf Euch",
    },
    [53774] = {
        name = "Weisheit des Kriegshäuptlings",
    },
    [53775] = {
        name = "Störende Schemen",
    },
    [53776] = {
        name = "Zur Verheerten Küste",
    },
    [53777] = {
        name = "Wo der Tod ihn erwartete",
    },
    [53778] = {
        name = "Wo er fiel",
    },
    [53779] = {
        name = "Die Lügen eines Loas",
    },
    [53780] = {
        name = "Kerkermeister der Verdammten",
    },
    [53782] = {
        name = "Geheimnisse des Todes",
    },
    [53783] = {
        name = "In den Dünen",
    },
    [53791] = {
        name = "Der Stolz der Sin'dorei",
    },
    [53802] = {
        name = "Überzeugungsarbeit bei den Sethrak",
    },
    [53805] = {
        name = "Durchs Nadelöhr",
    },
    [53806] = {
        name = "Schwer wiegt das Haupt",
    },
    [53807] = {
        name = "Ein Stich zur rechten Zeit",
    },
    [53810] = {
        name = "Der durchtrennte Faden",
    },
    [53813] = {
        name = "Ärmel hochkrempeln",
    },
    [53815] = {
        name = "Was ist eigentlich mit Saffy Chaise?",
    },
    [53816] = {
        name = "Wiederzusammenbau benötigt",
    },
    [53817] = {
        name = "Was geschah wirklich mit Grizzek Zischzang?",
    },
    [53818] = {
        name = "Federpflege",
    },
    [53819] = {
        name = "Kehrt zum Nest zurück",
    },
    [53820] = {
        name = "Sie ist jetzt an einem besseren Ort",
    },
    [53821] = {
        name = "Er ist tot, Jastor",
    },
    [53823] = {
        name = "Gefolge der Königin",
    },
    [53824] = {
        name = "Ritus der Königinnen und Könige",
    },
    [53825] = {
        name = "Der neue Rat der Zanchuli",
    },
    [53826] = {
        name = "Anstifter unter uns",
    },
    [53827] = {
        name = "Der Rat hat gesprochen",
    },
    [53828] = {
        name = "Blick der Loa",
    },
    [53830] = {
        name = "Königin der Zandalari",
    },
    [53831] = {
        name = "Ein königlicher Anlass",
    },
    [53833] = {
        name = "Rachsüchtige Reise",
    },
    [53835] = {
        name = "Vielleicht etwas Wertvolles?",
    },
    [53836] = {
        name = "Uralte Rüstung, uraltes Geheimnis",
    },
    [53837] = {
        name = "Immer gut aufpassen",
    },
    [53838] = {
        name = "Bleibt auf dem Boden",
    },
    [53840] = {
        name = "Kann ich Euch für ein Gebräu begeistern?",
    },
    [53841] = {
        name = "Fragmente der Vergangenheit",
    },
    [53842] = {
        name = "Segen der Erde",
    },
    [53844] = {
        name = "Rekrutierung des Meisters des Eisenwerks",
    },
    [53845] = {
        name = "Schmieden der Rüstung",
    },
    [53846] = {
        name = "Erbe der Bronzebarts",
    },
    [53847] = {
        name = "Das Wispern im Wind",
    },
    [53848] = {
        name = "Werkzeug in Vol'dun",
    },
    [53849] = {
        name = "Schwindende Hoffnung",
    },
    [53851] = {
        name = "Unser Krieg geht weiter",
    },
    [53852] = {
        name = "Kein Azerit für Euch",
    },
    [53853] = {
        name = "Die untergehende Sonne",
    },
    [53856] = {
        name = "Der Zorn der Horde",
    },
    [53858] = {
        name = "In ihren Fußstapfen",
    },
    [53866] = {
        name = "Wem der Schuh passt...",
    },
    [53868] = {
        name = "Rettet Neun",
    },
    [53869] = {
        name = "Zeit totschlagen",
    },
    [53870] = {
        name = "Gäste in der Feste Grommash",
    },
    [53879] = {
        name = "Räumung des Anwesens",
    },
    [53880] = {
        name = "Kriegsgerät und Azerit",
    },
    [53881] = {
        name = "Aus demselben Stoff",
    },
    [53882] = {
        name = "Es begann an der Mauer",
    },
    [53887] = {
        name = "Der Krieg marschiert weiter",
    },
    [53888] = {
        name = "Zur Angelpunktwerft",
    },
    [53889] = {
        name = "Eine Absichtserklärung",
    },
    [53890] = {
        name = "Neue Verbündete, neue Probleme",
    },
    [53891] = {
        name = "Kein Problem ist zu klein",
    },
    [53892] = {
        name = "Wo sind die Arbeiter?",
    },
    [53893] = {
        name = "Ein wenig guter Wille",
    },
    [53894] = {
        name = "Lohnende Reparaturen",
    },
    [53895] = {
        name = "Peonbeförderungen!",
    },
    [53896] = {
        name = "Durchhalten",
    },
    [53897] = {
        name = "Eine Party zu Euren Ehren",
    },
    [53898] = {
        name = "Kraft und Ehre",
    },
    [53899] = {
        name = "In den Außenbezirken",
    },
    [53900] = {
        name = "Wir benutzen ihre Waffen",
    },
    [53901] = {
        name = "Explosionen zeigen immer die gewünschte Wirkung",
    },
    [53902] = {
        name = "Die Gezeitenruferin ausschalten",
    },
    [53903] = {
        name = "Treffen mit Meerah",
    },
    [53904] = {
        name = "Die Winzerassistenten",
    },
    [53905] = {
        name = "Ihre Stärken nutzen",
    },
    [53906] = {
        name = "Für die Horde fermentiert",
    },
    [53907] = {
        name = "Nippen und genießen",
    },
    [53908] = {
        name = "Unsere Ankunft wird erwartet",
    },
    [53909] = {
        name = "Belagerte Verbündete",
    },
    [53910] = {
        name = "Schlagt die Horde zurück!",
    },
    [53912] = {
        name = "Die Jagd ist nie zu Ende",
    },
    [53913] = {
        name = "Mit Ehre",
    },
    [53916] = {
        name = "Sturmtakler auftakeln",
    },
    [53919] = {
        name = "Gluck, gluck, gluck",
    },
    [53936] = {
        name = "Die Pioniere aufhalten",
    },
    [53937] = {
        name = "Der Üb3r-Schrauber",
    },
    [53938] = {
        name = "Durchs Nadelöhr",
    },
    [53940] = {
        name = "Ein Stich zur rechten Zeit",
    },
    [53941] = {
        name = "Ein Mech für einen Goblin",
    },
    [53942] = {
        name = "Der richtige Mech für den Job",
    },
    [53947] = {
        name = "In den Dünen",
    },
    [53948] = {
        name = "Rachsüchtige Reise",
    },
    [53949] = {
        name = "Der Üb3r-Schrauber",
    },
    [53962] = {
        name = "Aus demselben Stoff",
    },
    [53973] = {
        name = "Rausfliegen und Draufhauen",
    },
    [53978] = {
        name = "Pulverpläne",
    },
    [53981] = {
        name = "Ein ruhmreicher Tag",
    },
    [53986] = {
        name = "Die Ruhe vor dem Sturm",
    },
    [53988] = {
        name = "Gestade des Schicksals",
    },
    [53989] = {
        name = "Hoffnung",
    },
    [53990] = {
        name = "In dunkelster Nacht",
    },
    [53993] = {
        name = "Eine Stimme im Wind",
    },
    [53995] = {
        name = "Der Taurengerber",
    },
    [53996] = {
        name = "Stöckchen holen",
    },
    [53997] = {
        name = "Der sechste Sinn",
    },
    [53998] = {
        name = "Exhumiert",
    },
    [53999] = {
        name = "Seidiges Haftmittel",
    },
    [54000] = {
        name = "Herzschlagfinale",
    },
    [54001] = {
        name = "Wir gehen rein",
    },
    [54002] = {
        name = "Das große Ganze",
    },
    [54004] = {
        name = "Testlauf Nr. 1: Mech gegen Mekkadrill",
    },
    [54005] = {
        name = "Das Wissen der Drust",
    },
    [54007] = {
        name = "Versicherungspolice",
    },
    [54008] = {
        name = "Erneuerung der Versicherung",
    },
    [54009] = {
        name = "Blutiger Nebenjob",
    },
    [54012] = {
        name = "Noch mal davongekommen",
    },
    [54015] = {
        name = "Tiefer hinein",
    },
    [54018] = {
        name = "Abstieg",
    },
    [54021] = {
        name = "Die erste Arkanistin",
    },
    [54022] = {
        name = "Mekkadrills Schlachtpläne",
    },
    [54026] = {
        name = "Arbeit erledigt",
    },
    [54027] = {
        name = "Bedrohung gebannt",
    },
    [54028] = {
        name = "Mech gegen Luftschiff",
    },
    [54031] = {
        name = "Blick der Loa: Krag'wa",
    },
    [54032] = {
        name = "Blick der Loa: Pa'ku",
    },
    [54033] = {
        name = "Blick der Loa: Gonk",
    },
    [54034] = {
        name = "Blick der Loa: Bwonsamdi",
    },
    [54036] = {
        name = "Pedantischer Prozess",
    },
    [54041] = {
        name = "Keine Überlebenden",
    },
    [54042] = {
        name = "Ärger an der Dunkelküste",
    },
    [54043] = {
        name = "Der Waldläufer dunkle Wiederkehr",
    },
    [54044] = {
        name = "Schwarzer Mond am Himmel",
    },
    [54045] = {
        name = "Ausgerankt",
    },
    [54046] = {
        name = "Verirrwischt",
    },
    [54047] = {
        name = "Wo die Hoffnung stirbt",
    },
    [54049] = {
        name = "Finstere Nacht",
    },
    [54050] = {
        name = "Nachspiel",
    },
    [54058] = {
        name = "Unbeabsichtigte Konsequenzen",
    },
    [54059] = {
        name = "Die Nachtkriegerin",
    },
    [54083] = {
        name = "Gut schmieren, niemals verlieren",
    },
    [54086] = {
        name = "Der richtige Bot für den Job",
    },
    [54087] = {
        name = "Mindestgröße einhalten!",
    },
    [54088] = {
        name = "Die Legende von Mechagon",
    },
    [54094] = {
        name = "Die Goblindefinition von Erfolg",
    },
    [54096] = {
        name = "Der Untergang des Sonnenbrunnens",
    },
    [54097] = {
        name = "Die Dunkle Fürstin ruft",
    },
    [54099] = {
        name = "Der Hochfürst",
    },
    [54100] = {
        name = "Alternativen finden",
    },
    [54101] = {
        name = "Auf der Spur",
    },
    [54102] = {
        name = "Flucht gen Osten",
    },
    [54103] = {
        name = "Über drei Ecken",
    },
    [54104] = {
        name = "Spuren von Saurfang",
    },
    [54105] = {
        name = "Immer Richtung Osten",
    },
    [54106] = {
        name = "Hinweisen folgen",
    },
    [54107] = {
        name = "Finstere Kunde",
    },
    [54108] = {
        name = "Tod eines Kriegers",
    },
    [54109] = {
        name = "Gunst der Königin",
    },
    [54113] = {
        name = "Jeder kleine Tod hilft",
    },
    [54114] = {
        name = "Jeder kleine Tod hilft",
    },
    [54117] = {
        name = "Jeder kleine Tod hilft",
    },
    [54118] = {
        name = "Jeder kleine Tod hilft",
    },
    [54120] = {
        name = "Nach Orgrimmar",
    },
    [54121] = {
        name = "Aschenwinds Ausbruch",
    },
    [54123] = {
        name = "Das gehört in meinen Mech!",
    },
    [54124] = {
        name = "Vermeidung von Zivilklagen für Anfänger",
    },
    [54126] = {
        name = "Das Messer drehen",
    },
    [54128] = {
        name = "Notwendige Vorsichtsmaßnahmen",
    },
    [54139] = {
        name = "Der Krieg ist gekommen",
    },
    [54140] = {
        name = "Marsch der Zandalari",
    },
    [54141] = {
        name = "Das Medaillon von Azshara",
    },
    [54144] = {
        name = "Befehle von Azshara",
    },
    [54145] = {
        name = "Der Loa des Todes",
    },
    [54147] = {
        name = "Die Val'kyr konfrontieren",
    },
    [54156] = {
        name = "Ein blutiger Pfad",
    },
    [54157] = {
        name = "Niemand wird zurückgelassen",
    },
    [54161] = {
        name = "Das Wissen der Drust",
    },
    [54163] = {
        name = "Der Staub legt sich",
    },
    [54164] = {
        name = "Der Tod des Königs",
    },
    [54165] = {
        name = "Die Rückkehr von Derek Prachtmeer",
    },
    [54169] = {
        name = "Schatzkammerjäger",
    },
    [54171] = {
        name = "Das Abyssische Szepter",
    },
    [54174] = {
        name = "Befehle von Azshara",
    },
    [54175] = {
        name = "Stellt Euch Eurem Feind",
    },
    [54176] = {
        name = "In Uniform gebracht",
    },
    [54177] = {
        name = "Eine brillante Ablenkung",
    },
    [54178] = {
        name = "Mitfahrgelegenheit",
    },
    [54179] = {
        name = "Durch die Vordertür",
    },
    [54183] = {
        name = "Kursbestimmung",
    },
    [54191] = {
        name = "Kursänderung",
    },
    [54192] = {
        name = "Heikle Informationen",
    },
    [54193] = {
        name = "Das ist riesig!",
    },
    [54194] = {
        name = "Wahrlich große Macht",
    },
    [54195] = {
        name = "Ein Wildtier mit Grips",
    },
    [54196] = {
        name = "Keine andere Option",
    },
    [54197] = {
        name = "Freiheit für die Da'kani",
    },
    [54198] = {
        name = "Bittersüßer Abschied",
    },
    [54199] = {
        name = "Das Wohl der Vielen",
    },
    [54200] = {
        name = "Grundlegende Aufgaben",
    },
    [54201] = {
        name = "Grongs Größe",
    },
    [54202] = {
        name = "Kernkalibrierung",
    },
    [54203] = {
        name = "Die Großmachung",
    },
    [54204] = {
        name = "Totale Tempelzerstörung",
    },
    [54205] = {
        name = "Ein hübsches Nickerchen",
    },
    [54206] = {
        name = "Der Schläfer",
    },
    [54207] = {
        name = "Rückeroberung des Außenpostens",
    },
    [54208] = {
        name = "Das reinste Minenfeld",
    },
    [54211] = {
        name = "Kein Goblin bleibt zurück",
    },
    [54212] = {
        name = "Den A.F.M.O.D. wieder zusammenbauen",
    },
    [54213] = {
        name = "Es lebt!",
    },
    [54224] = {
        name = "Die Schlacht um die Ruinen von Zul'jan",
    },
    [54244] = {
        name = "In die Ecke gedrängt",
    },
    [54249] = {
        name = "Zandalarigerechtigkeit",
    },
    [54265] = {
        name = "Befehle von Azshara",
    },
    [54269] = {
        name = "Niemand soll entkommen",
    },
    [54270] = {
        name = "Spiegelscherben",
    },
    [54271] = {
        name = "Telaamons Eliminierung",
    },
    [54275] = {
        name = "Den Nebel teilen",
    },
    [54280] = {
        name = "Fliegt ihnen entgegen",
    },
    [54282] = {
        name = "Die Schlacht von Dazar'alor",
    },
    [54300] = {
        name = "Glaubensbruch",
    },
    [54301] = {
        name = "Talanjis Gnade",
    },
    [54302] = {
        name = "Der Fall von Zuldazar",
    },
    [54303] = {
        name = "Der Marsch nach Nazmir",
    },
    [54310] = {
        name = "Unser Dorf soll schöner werden",
    },
    [54312] = {
        name = "Nebel des Krieges",
    },
    [54402] = {
        name = "In Bewegung",
    },
    [54404] = {
        name = "Dunkeleisenumtriebe",
    },
    [54407] = {
        name = "Lauern im Sumpf",
    },
    [54412] = {
        name = "Regenguss von Zul'jan",
    },
    [54416] = {
        name = "Vorbereitungen für die Kriegsfront",
    },
    [54417] = {
        name = "Machtdemonstration",
    },
    [54418] = {
        name = "Der Mechaoberdampfhammer",
    },
    [54419] = {
        name = "Deeskalation",
    },
    [54421] = {
        name = "Ihre Bestien zähmen",
    },
    [54433] = {
        name = "Befehle von Azshara",
    },
    [54438] = {
        name = "Der Tiegel der Stürme: Relikte des Schattens",
    },
    [54439] = {
        name = "Der Tiegel der Stürme: Relikte des Schattens",
    },
    [54441] = {
        name = "Das Bluttor einnehmen",
    },
    [54459] = {
        name = "Der im Licht wandelt",
    },
    [54485] = {
        name = "Die Schlacht von Dazar'alor",
    },
    [54510] = {
        name = "Missetat begangen",
    },
    [54518] = {
        name = "Zeppelinzäsur",
    },
    [54519] = {
        name = "Patrouille in Bredouille",
    },
    [54559] = {
        name = "Befreit Hakenschnabel!",
    },
    [54576] = {
        name = "Gnomeregans Beste",
    },
    [54577] = {
        name = "Finstere Hallen und verstaubte Zahnräder",
    },
    [54580] = {
        name = "Dilemma in der Tundra",
    },
    [54581] = {
        name = "Und jetzt zu mechanischerem Federvieh",
    },
    [54582] = {
        name = "Schlauer als der Durchschnittstrogg",
    },
    [54639] = {
        name = "Ein Signal vom Sturmgipfel",
    },
    [54640] = {
        name = "Gnomen est Omen",
    },
    [54641] = {
        name = "Für Gnomeregan!",
    },
    [54642] = {
        name = "F.L.U.G.-bereit",
    },
    [54703] = {
        name = "Expresslieferung",
    },
    [54706] = {
        name = "Handarbeit aus Kul Tiras",
    },
    [54708] = {
        name = "Ein Leben auf dem Lande",
    },
    [54721] = {
        name = "Ich bin zu alt für diesen Schiffskram",
    },
    [54723] = {
        name = "Masten im Nebel",
    },
    [54725] = {
        name = "Aus der Tiefe",
    },
    [54726] = {
        name = "Gut gesägt ist halb gewonnen",
    },
    [54727] = {
        name = "Packesel",
    },
    [54728] = {
        name = "Verfluchtes Holz",
    },
    [54729] = {
        name = "Die Rauhügel",
    },
    [54730] = {
        name = "Gorak Tuls Einfluss",
    },
    [54731] = {
        name = "Das Gleichgewicht aller Dinge",
    },
    [54732] = {
        name = "Fallen lassen!",
    },
    [54733] = {
        name = "Das ist es Werth",
    },
    [54734] = {
        name = "Nachricht von Dorian",
    },
    [54735] = {
        name = "Eine würdige Mannschaft",
    },
    [54754] = {
        name = "Für die Königin",
    },
    [54759] = {
        name = "Wenn Geister flüstern",
    },
    [54760] = {
        name = "Die Geistwandler",
    },
    [54761] = {
        name = "Geisterführer",
    },
    [54762] = {
        name = "Ein kleiner Rückzugsort",
    },
    [54763] = {
        name = "Die andere Seite",
    },
    [54764] = {
        name = "Dorf in Bedrängnis",
    },
    [54765] = {
        name = "Dank dem Geisterführer",
    },
    [54766] = {
        name = "Dem Ruf gefolgt",
    },
    [54787] = {
        name = "Gasmaskerade",
    },
    [54851] = {
        name = "Segen der Gezeiten",
    },
    [54871] = {
        name = "Wir kommen",
    },
    [54913] = {
        name = "Geistesblitz",
    },
    [54915] = {
        name = "Telemetrie aktiv",
    },
    [54916] = {
        name = "Bekenntnis des Jägers",
    },
    [54917] = {
        name = "Mit Blut bezahlt",
    },
    [54918] = {
        name = "Funke der Imagination",
    },
    [54919] = {
        name = "Bande des Donners",
    },
    [54920] = {
        name = "Zurück nach Hause",
    },
    [54922] = {
        name = "Bis zur letzten Schraube",
    },
    [54925] = {
        name = "Ketzerei!",
    },
    [54929] = {
        name = "Fäuste hoch",
    },
    [54930] = {
        name = "Mechanische Befreiungsaktion",
    },
    [54938] = {
        name = "Brüderliche Hilfe",
    },
    [54939] = {
        name = "Störrisch wie ein Bronzebart",
    },
    [54940] = {
        name = "MUTTER weiß mehr",
    },
    [54945] = {
        name = "Kickstart",
    },
    [54946] = {
        name = "Auf zu Gila",
    },
    [54947] = {
        name = "Klein aber fein",
    },
    [54958] = {
        name = "Schiffe in der Nacht",
    },
    [54959] = {
        name = "Hinter Schloss und Riegel",
    },
    [54960] = {
        name = "Ein bitteres Wiedersehen",
    },
    [54961] = {
        name = "Wiedergutmachung",
    },
    [54964] = {
        name = "Mitten ins Herz",
    },
    [54965] = {
        name = "Zerteilte Bots",
    },
    [54969] = {
        name = "Abstieg",
    },
    [54972] = {
        name = "Ein Heimweg",
    },
    [54975] = {
        name = "Ein kurzer Aufschub",
    },
    [54976] = {
        name = "Der Schatten von Gilneas",
    },
    [54977] = {
        name = "In den Dämmerwald",
    },
    [54980] = {
        name = "Nachtheulerbändigung",
    },
    [54981] = {
        name = "Anrufung des Mondes",
    },
    [54982] = {
        name = "Der Geist des Jägers",
    },
    [54983] = {
        name = "Das Wecken eines Träumers",
    },
    [54984] = {
        name = "Schlafende Wölfe soll man nicht wecken",
    },
    [54990] = {
        name = "Die neue Garde",
    },
    [54992] = {
        name = "Der Beginn von etwas Größerem",
    },
    [54997] = {
        name = "Klar Schiff machen",
    },
    [54999] = {
        name = "Unter falscher Flagge",
    },
    [55028] = {
        name = "Schrott zu Schrott...",
    },
    [55031] = {
        name = "Schrott zu Schrott...",
    },
    [55033] = {
        name = "Asche zu Aschenwind",
    },
    [55034] = {
        name = "Unter falscher Flagge",
    },
    [55039] = {
        name = "Das Schiffsbaugenie",
    },
    [55040] = {
        name = "Ein Blick ins Innere",
    },
    [55043] = {
        name = "Seemannstratsch und Küstenklatsch",
    },
    [55044] = {
        name = "Den Boten trifft keine Schuld",
    },
    [55045] = {
        name = "Nicht ohne meinen Bruder",
    },
    [55047] = {
        name = "Die Reißzahnfeste sichern",
    },
    [55048] = {
        name = "Lizenz zum Töten",
    },
    [55049] = {
        name = "Kommunikationsstörung",
    },
    [55050] = {
        name = "Ticketkontrolle",
    },
    [55051] = {
        name = "Eine Machtdemonstration",
    },
    [55052] = {
        name = "Die Reißzahnfeste sichern",
    },
    [55053] = {
        name = "Ein Heimweg",
    },
    [55054] = {
        name = "Aufruhr",
    },
    [55055] = {
        name = "Riesige Reuse",
    },
    [55087] = {
        name = "Der drohende Sturm",
    },
    [55088] = {
        name = "Im Einsatz vermisst",
    },
    [55089] = {
        name = "Mission auf Messers Schneide",
    },
    [55090] = {
        name = "Eine feindliche Versammlung",
    },
    [55092] = {
        name = "Störung der Macht",
    },
    [55094] = {
        name = "Kopf runter, Beine in die Hand!",
    },
    [55095] = {
        name = "Aufruhr",
    },
    [55096] = {
        name = "Eine Nachricht für meinen Vater",
    },
    [55101] = {
        name = "Schrottplatztüfteleien für jedermann",
    },
    [55103] = {
        name = "Ideen kommen von überall her",
    },
    [55116] = {
        name = "Entziffereien",
    },
    [55117] = {
        name = "Korrespondenzscharade",
    },
    [55118] = {
        name = "Ungeklärte Angelegenheiten",
    },
    [55119] = {
        name = "Melde mich zum Dienst!",
    },
    [55121] = {
        name = "Mardivas' Labor",
    },
    [55124] = {
        name = "Wiedergutmachung",
    },
    [55136] = {
        name = "Ihre Hundstage sind vorbei",
    },
    [55153] = {
        name = "Konstruktionskollaboration",
    },
    [55171] = {
        name = "Ausgespäht",
    },
    [55175] = {
        name = "Immer der Nase nach",
    },
    [55177] = {
        name = "Die Zerreißprobe",
    },
    [55179] = {
        name = "Vergeltungsmaßnahmen",
    },
    [55182] = {
        name = "Die fehlenden Bauteile",
    },
    [55183] = {
        name = "Auf in höhere Lagen",
    },
    [55185] = {
        name = "Lauscher auf!",
    },
    [55188] = {
        name = "Die Zerreißprobe",
    },
    [55195] = {
        name = "Nachhall",
    },
    [55210] = {
        name = "Batterien nicht im Lieferumfang enthalten",
    },
    [55211] = {
        name = "Neuer Saft für den Rostbolzen",
    },
    [55214] = {
        name = "Reißende Naht",
    },
    [55216] = {
        name = "Die Probe",
    },
    [55217] = {
        name = "Die Lebensschuld begleichen",
    },
    [55218] = {
        name = "Shezas wertvolles Leder",
    },
    [55219] = {
        name = "Dubben in Donnertotem",
    },
    [55220] = {
        name = "Schlagen, bis die Schuppen fliegen",
    },
    [55221] = {
        name = "Knochenarbeit",
    },
    [55222] = {
        name = "Schlagende Instrumente",
    },
    [55223] = {
        name = "Instrumente der Zerstörung",
    },
    [55227] = {
        name = "Die Äonenhandwerkerin",
    },
    [55228] = {
        name = "Die Probe",
    },
    [55229] = {
        name = "Schulden begleichen",
    },
    [55230] = {
        name = "Telonis' wertvolles Leder",
    },
    [55231] = {
        name = "Noch ein Geisttänzer",
    },
    [55232] = {
        name = "Mevris' Monster",
    },
    [55233] = {
        name = "Knochenarbeit",
    },
    [55234] = {
        name = "Schlagende Instrumente",
    },
    [55235] = {
        name = "Instrumente der Zerstörung",
    },
    [55247] = {
        name = "Verdientes Vertrauen",
    },
    [55252] = {
        name = "Ein Loa ohne Tempel",
    },
    [55253] = {
        name = "Eine Demonstration des Glaubens",
    },
    [55254] = {
        name = "Ein nie endender Schlaf",
    },
    [55258] = {
        name = "Schlafen, essen, schlafen, essen...",
    },
    [55298] = {
        name = "Nach dem Riesen angeln",
    },
    [55339] = {
        name = "Staubsaugen unter Wasser",
    },
    [55361] = {
        name = "Der verlorene Schamane",
    },
    [55362] = {
        name = "Elementarer Zorn",
    },
    [55363] = {
        name = "Rettet den Scharfseher",
    },
    [55373] = {
        name = "Haut sie aus dem Kasten",
    },
    [55374] = {
        name = "Eine unterirdische Störung",
    },
    [55384] = {
        name = "Eingewöhnung",
    },
    [55385] = {
        name = "Erkundungen in den Pferchen",
    },
    [55390] = {
        name = "Mein Traum in der Finsternis",
    },
    [55392] = {
        name = "In den Traumpfad",
    },
    [55393] = {
        name = "Die Leere ausradieren",
    },
    [55394] = {
        name = "Smaragdene Splitter",
    },
    [55395] = {
        name = "Schließt Eure Augen nicht",
    },
    [55396] = {
        name = "Der Stoff, aus dem die Träume sind",
    },
    [55397] = {
        name = "Bevor ich erwache",
    },
    [55398] = {
        name = "Das lange Erwachen",
    },
    [55400] = {
        name = "Nehmt meine Hand",
    },
    [55407] = {
        name = "Den Rücken beruhigen",
    },
    [55425] = {
        name = "Den Unbeugsamen beugen",
    },
    [55462] = {
        name = "Ruf der Reisenden",
    },
    [55465] = {
        name = "Wir müssen tiefer hinein",
    },
    [55469] = {
        name = "Nach Zin-Azshari",
    },
    [55481] = {
        name = "Aufklärung im Palast",
    },
    [55482] = {
        name = "Hallo? Vermittlung?",
    },
    [55485] = {
        name = "Entsetzen in der Tiefe",
    },
    [55486] = {
        name = "Geheimnisse der Telemantie",
    },
    [55488] = {
        name = "Sprecht mit den Toten",
    },
    [55489] = {
        name = "Der Report der Hofdame",
    },
    [55490] = {
        name = "Der ganz große Wurf",
    },
    [55497] = {
        name = "Ein vertrautes Gesicht",
    },
    [55500] = {
        name = "Freundesrettung",
    },
    [55503] = {
        name = "Das Terrorhorn und der Saurid",
    },
    [55504] = {
        name = "Wegschreine von Zuldazar",
    },
    [55505] = {
        name = "Gedenken an Roo'li",
    },
    [55506] = {
        name = "Eine Straße endet",
    },
    [55507] = {
        name = "Torcalis Segen",
    },
    [55519] = {
        name = "Eine frische Wunde",
    },
    [55520] = {
        name = "Heilung von Nordrassil",
    },
    [55521] = {
        name = "Macht es azerichtig",
    },
    [55529] = {
        name = "Kein Zurück",
    },
    [55530] = {
        name = "Ein sicherer Ort",
    },
    [55533] = {
        name = "MUTTER weiß es besser",
    },
    [55558] = {
        name = "Sicher ist sicher",
    },
    [55560] = {
        name = "Utamas Vergeltung",
    },
    [55561] = {
        name = "Die Überreste von Zin-Azshari",
    },
    [55565] = {
        name = "Manareserven sammeln",
    },
    [55569] = {
        name = "Echos des Schmerzes",
    },
    [55570] = {
        name = "Geheimnisse der Ruinen",
    },
    [55571] = {
        name = "Öffnet ihnen die Augen",
    },
    [55573] = {
        name = "Entfernt die Entweiher",
    },
    [55574] = {
        name = "Die Wurfspeere von Azshara.",
    },
    [55585] = {
        name = "Ein vielversprechender Anfang",
    },
    [55586] = {
        name = "Aufpoliert",
    },
    [55590] = {
        name = "Fassung bewahren",
    },
    [55592] = {
        name = "Ein vielversprechender Anfang",
    },
    [55593] = {
        name = "Erkenntnisse über unsere Feinde",
    },
    [55594] = {
        name = "Aufpoliert",
    },
    [55595] = {
        name = "Wissensverfall",
    },
    [55596] = {
        name = "Fassung bewahren",
    },
    [55597] = {
        name = "Durch Ehre gebunden",
    },
    [55598] = {
        name = "Was wir über die Naga wissen",
    },
    [55599] = {
        name = "Erkundungen im Geheimen",
    },
    [55600] = {
        name = "Drachensättigen leicht gemacht",
    },
    [55601] = {
        name = "Begehrte Kristalle",
    },
    [55608] = {
        name = "Werkstattprojekt",
    },
    [55618] = {
        name = "Die Herzschmiede",
    },
    [55622] = {
        name = "Noch heute losfahren",
    },
    [55630] = {
        name = "Kickstart",
    },
    [55632] = {
        name = "Mindestgröße einhalten!",
    },
    [55635] = {
        name = "Eine Stimme im Wind",
    },
    [55645] = {
        name = "Prinzenbesuch",
    },
    [55646] = {
        name = "Die Legende von Mechagon",
    },
    [55647] = {
        name = "Die Wände haben Ohren",
    },
    [55648] = {
        name = "Das ist jetzt unsere Kammer",
    },
    [55649] = {
        name = "Mechmachenschaften für Mechagon",
    },
    [55650] = {
        name = "Nur das Beste ist gut genug",
    },
    [55651] = {
        name = "Auf nach Mechagon!",
    },
    [55652] = {
        name = "Die Bilderbuchbucht",
    },
    [55657] = {
        name = "Im Schatten der blutroten Schwingen",
    },
    [55685] = {
        name = "Wir kommen in Frieden... und Profitgier",
    },
    [55694] = {
        name = "Da ist etwas im Wasser",
    },
    [55696] = {
        name = "Testfahrt",
    },
    [55697] = {
        name = "Ein bisschen Beinarbeit",
    },
    [55707] = {
        name = "Die erste gibts umsonst",
    },
    [55708] = {
        name = "Aufgewertet",
    },
    [55729] = {
        name = "Der Widerstand braucht EUCH!",
    },
    [55730] = {
        name = "Den Widerstand retten",
    },
    [55731] = {
        name = "Die Armeen meines Vaters",
    },
    [55732] = {
        name = "Eine alte Narbe",
    },
    [55734] = {
        name = "Bohrmaschinenbau",
    },
    [55735] = {
        name = "Verteidigung des Mahlstroms",
    },
    [55736] = {
        name = "Willkommen beim Widerstand",
    },
    [55737] = {
        name = "Zur azerichtigen Zeit",
    },
    [55752] = {
        name = "Gemeinsam sind wir stark",
    },
    [55753] = {
        name = "Robo-Raubkopie",
    },
    [55778] = {
        name = "Visionen der Gefahr",
    },
    [55779] = {
        name = "Von Richtern und Henkern",
    },
    [55780] = {
        name = "Alte Verbündete",
    },
    [55781] = {
        name = "Alte Verbündete",
    },
    [55782] = {
        name = "Von Richtern und Henkern",
    },
    [55783] = {
        name = "Von Richtern und Henkern",
    },
    [55784] = {
        name = "Gleiches mit Gleichem",
    },
    [55795] = {
        name = "Berg in Bewegung",
    },
    [55796] = {
        name = "Ketzerei am Wegekreuz",
    },
    [55797] = {
        name = "Die Wut einer Mutter der Terrorhörner",
    },
    [55798] = {
        name = "Nie allein auf Reisen",
    },
    [55799] = {
        name = "Das Blatt wendet sich",
    },
    [55860] = {
        name = "Liquidierung von Seeschnecken",
    },
    [55861] = {
        name = "Lasst Euch von den Rückständen leiten",
    },
    [55862] = {
        name = "Erkenntnisse über unsere Feinde",
    },
    [55863] = {
        name = "Wissensverfall",
    },
    [55864] = {
        name = "Der Preis ist der Tod",
    },
    [55865] = {
        name = "Was wir über die Naga wissen",
    },
    [55866] = {
        name = "Erkundungen im Geheimen",
    },
    [55867] = {
        name = "Begehrte Kristalle",
    },
    [55868] = {
        name = "Lasst Euch von den Rückständen leiten",
    },
    [55869] = {
        name = "Das Versteck ausräumen",
    },
    [55870] = {
        name = "Liquidierung von Seeschnecken",
    },
    [55937] = {
        name = "Das Versteck ausräumen",
    },
    [55967] = {
        name = "Drachensättigen leicht gemacht",
    },
    [55983] = {
        name = "Ein sicherer Ort",
    },
    [55995] = {
        name = "Wir bekommen das hin",
    },
    [56030] = {
        name = "Befehl des Kriegshäuptlings",
    },
    [56031] = {
        name = "Die Offensive des Wolfs",
    },
    [56037] = {
        name = "Nagageheimnisse stehlen",
    },
    [56038] = {
        name = "Zweckgerichtet arbeiten",
    },
    [56039] = {
        name = "Stumpfe Waffen taugen nichts",
    },
    [56043] = {
        name = "Schickt die Flotte",
    },
    [56044] = {
        name = "Schickt die Flotte",
    },
    [56045] = {
        name = "Nagageheimnisse stehlen",
    },
    [56046] = {
        name = "Zweckgerichtet arbeiten",
    },
    [56047] = {
        name = "Stumpfe Waffen taugen nichts",
    },
    [56063] = {
        name = "Dunkle Gezeiten",
    },
    [56095] = {
        name = "Das Erbe von Nar'anan",
    },
    [56118] = {
        name = "Schnappt zurück",
    },
    [56143] = {
        name = "Das Schicksal von Professorin Elryna",
    },
    [56156] = {
        name = "Eine gehärtete Klinge",
    },
    [56167] = {
        name = "Hochlanduntersuchung",
    },
    [56168] = {
        name = "Fabriküberholt",
    },
    [56175] = {
        name = "Emissionsfrei",
    },
    [56181] = {
        name = "Der geht auf mich",
    },
    [56209] = {
        name = "Die Hallen des Ursprungs",
    },
    [56210] = {
        name = "Sehersteine",
    },
    [56211] = {
        name = "Sehersteine",
    },
    [56234] = {
        name = "Freunde in der Not",
    },
    [56235] = {
        name = "Hinein nach Nazjatar",
    },
    [56236] = {
        name = "Erloschen, aber nicht erledigt",
    },
    [56239] = {
        name = "Seltsames Silbermesser",
    },
    [56240] = {
        name = "Seltsames Silbermesser",
    },
    [56241] = {
        name = "Konservierte Hinweise",
    },
    [56242] = {
        name = "Konservierte Hinweise",
    },
    [56243] = {
        name = "Tagebücher der Toten",
    },
    [56244] = {
        name = "Tagebücher der Toten",
    },
    [56245] = {
        name = "Verzaubertes Schloss",
    },
    [56246] = {
        name = "Verzaubertes Schloss",
    },
    [56247] = {
        name = "Schatzgeschichten",
    },
    [56248] = {
        name = "Schatzgeschichten",
    },
    [56304] = {
        name = "Hoch geboren, tief gefallen",
    },
    [56305] = {
        name = "Gehen wir fischen!",
    },
    [56309] = {
        name = "Stadt der ertrunkenen Freunde",
    },
    [56310] = {
        name = "Stadt der ertrunkenen Freunde",
    },
    [56311] = {
        name = "Ewiges Ertrinken",
    },
    [56312] = {
        name = "Ewiges Ertrinken",
    },
    [56313] = {
        name = "Die Kriegsbringerin",
    },
    [56314] = {
        name = "Die Kriegsbringerin",
    },
    [56315] = {
        name = "Sie haben ihre Wahl getroffen",
    },
    [56316] = {
        name = "Sie haben ihre Wahl getroffen",
    },
    [56319] = {
        name = "Der Blitzladevertrag",
    },
    [56320] = {
        name = "Die erste Aufladung ist kostenlos!",
    },
    [56321] = {
        name = "Corin retten",
    },
    [56325] = {
        name = "Das Blatt wendet sich",
    },
    [56346] = {
        name = "Uralte Technologie",
    },
    [56347] = {
        name = "Eine abgrundtiefe Gelegenheit",
    },
    [56348] = {
        name = "Der Ewige Palast: Wir können ihn stärker machen...",
    },
    [56349] = {
        name = "Der Ewige Palast: Grenzen austesten",
    },
    [56350] = {
        name = "Aufklärung im Palast",
    },
    [56351] = {
        name = "Der Ewige Palast: Grenzen austesten",
    },
    [56352] = {
        name = "Der Ewige Palast: Wir können ihn stärker machen...",
    },
    [56353] = {
        name = "Eine abgrundtiefe Gelegenheit",
    },
    [56354] = {
        name = "Uralte Technologie",
    },
    [56356] = {
        name = "Der Ewige Palast: Schachzug der Königin",
    },
    [56358] = {
        name = "Der Ewige Palast: Schachzug der Königin",
    },
    [56374] = {
        name = "Ein titanisches Problem",
    },
    [56375] = {
        name = "Nach Ramkahen",
    },
    [56376] = {
        name = "Auftretende Bedrohungen",
    },
    [56377] = {
        name = "Die Zukunft schmieden",
    },
    [56378] = {
        name = "Die vermisste Besatzung",
    },
    [56379] = {
        name = "Die vermisste Besatzung",
    },
    [56401] = {
        name = "Ein Blitz aus dem Blauen",
    },
    [56422] = {
        name = "Auf Geisterschwingen",
    },
    [56429] = {
        name = "Mit dem Rücken zur Wand",
    },
    [56472] = {
        name = "Das Abkommen von Uldum",
    },
    [56494] = {
        name = "Der Abend vor der Schlacht",
    },
    [56495] = {
        name = "Sie ziehen gegen uns zu Felde",
    },
    [56496] = {
        name = "Der Abend vor der Schlacht",
    },
    [56536] = {
        name = "Einfach ist es nie",
    },
    [56537] = {
        name = "Das geheimnisvolle Siegel",
    },
    [56538] = {
        name = "Klans der Mogu",
    },
    [56539] = {
        name = "Auf der Suche nach den Rajani",
    },
    [56540] = {
        name = "Beweis der Hartnäckigkeit",
    },
    [56541] = {
        name = "Die Maschine von Nalak'sha",
    },
    [56542] = {
        name = "Wiederhergestellte Hoffnung",
    },
    [56560] = {
        name = "Eine merkwürdige Entdeckung",
    },
    [56561] = {
        name = "Eine merkwürdige Entdeckung",
    },
    [56574] = {
        name = "Spiegelungen im Bern",
    },
    [56575] = {
        name = "Rückkehr nach Kor'vess",
    },
    [56576] = {
        name = "Auslöschung der Aqir",
    },
    [56577] = {
        name = "Den Schwarm lahmlegen",
    },
    [56578] = {
        name = "Fäulnis von der Wurzel her",
    },
    [56580] = {
        name = "Geheimnisse im Bern",
    },
    [56616] = {
        name = "Alte Gesichter, neue Probleme",
    },
    [56617] = {
        name = "Ein vereinter Schwarm",
    },
    [56640] = {
        name = "Noch mal davongekommen",
    },
    [56641] = {
        name = "Störung der Macht",
    },
    [56642] = {
        name = "Dunkle Gezeiten",
    },
    [56643] = {
        name = "Tiefer hinein",
    },
    [56644] = {
        name = "Mit dem Rücken zur Wand",
    },
    [56645] = {
        name = "Das Herz des Schwarms",
    },
    [56647] = {
        name = "Bedrohung durch die Mantis",
    },
    [56719] = {
        name = "Nicht meins",
    },
    [56739] = {
        name = "Die Macht der Anbetung",
    },
    [56741] = {
        name = "Der Speer des Schicksals",
    },
    [56771] = {
        name = "Zeitverlorene Krieger",
    },
    [56833] = {
        name = "Anführer der Horde",
    },
    [56979] = {
        name = "Rettung der Belagerung",
    },
    [56980] = {
        name = "Bereits unter uns",
    },
    [56981] = {
        name = "Strategischer Einsatz",
    },
    [56982] = {
        name = "Vor den Toren von Orgrimmar",
    },
    [56993] = {
        name = "Der Preis des Sieges",
    },
    [57002] = {
        name = "Alter Soldat",
    },
    [57005] = {
        name = "Freunde werden",
    },
    [57006] = {
        name = "Ein würdiger Verbündeter",
    },
    [57010] = {
        name = "Geballte Macht",
    },
    [57043] = {
        name = "Alte Freunde, neue Chancen",
    },
    [57045] = {
        name = "Eine Sonderzustellung",
    },
    [57047] = {
        name = "Ein einfaches Experiment",
    },
    [57048] = {
        name = "Teile einkaufen",
    },
    [57051] = {
        name = "Schulden eintreiben!",
    },
    [57052] = {
        name = "Ich hab, was Ihr braucht",
    },
    [57053] = {
        name = "Stumpfe Gewalt",
    },
    [57058] = {
        name = "Spaß mit Tretminen",
    },
    [57059] = {
        name = "Lasst uns kämpfen!",
    },
    [57067] = {
        name = "Mogu vor den Toren",
    },
    [57068] = {
        name = "Überwachen mit Drachen",
    },
    [57069] = {
        name = "Weg mit den Köpfen",
    },
    [57070] = {
        name = "Mogumassaker",
    },
    [57071] = {
        name = "Kein Gebräu wird zurückgelassen",
    },
    [57072] = {
        name = "Yak in allen Gassen",
    },
    [57074] = {
        name = "Mit dem Rücken zum Tor",
    },
    [57075] = {
        name = "Flüssiger Mut",
    },
    [57076] = {
        name = "Kehrt nach Nebelhauch zurück",
    },
    [57077] = {
        name = "Käufer gesucht!",
    },
    [57078] = {
        name = "Die VIP-Liste",
    },
    [57079] = {
        name = "Lasst ihn Dreckopolis fressen!",
    },
    [57080] = {
        name = "Eine passende Belohnung",
    },
    [57088] = {
        name = "Nicht meins",
    },
    [57090] = {
        name = "Rettung der Belagerung",
    },
    [57091] = {
        name = "Bereits unter uns",
    },
    [57092] = {
        name = "Strategischer Einsatz",
    },
    [57093] = {
        name = "Vor den Toren von Orgrimmar",
    },
    [57094] = {
        name = "Der Preis des Sieges",
    },
    [57095] = {
        name = "Alter Soldat",
    },
    [57126] = {
        name = "Glück und Segen...",
    },
    [57130] = {
        name = "Verräter unter uns",
    },
    [57147] = {
        name = "Nicht mein Kriegshäuptling",
    },
    [57148] = {
        name = "Belagerungsbrecher",
    },
    [57149] = {
        name = "Propagandakontrolle",
    },
    [57150] = {
        name = "Miliz",
    },
    [57151] = {
        name = "Eine Linie im Sand",
    },
    [57152] = {
        name = "Treu ergeben",
    },
    [57198] = {
        name = "Pflichtgefühl",
    },
    [57220] = {
        name = "Einleitung des Energieprotokolls",
    },
    [57221] = {
        name = "Neuerschaffung",
    },
    [57222] = {
        name = "Die Hallen untersuchen",
    },
    [57290] = {
        name = "Beginn des Abstiegs",
    },
    [57324] = {
        name = "Mit der Flut segeln",
    },
    [57362] = {
        name = "Tiefer in die Finsternis",
    },
    [57373] = {
        name = "Abstieg in den Wahnsinn",
    },
    [57374] = {
        name = "Die dunkelsten Abgründe",
    },
    [57376] = {
        name = "Das verborgene Bedürfnis",
    },
    [57378] = {
        name = "Überreste einer zerschmetterten Welt",
    },
    [57448] = {
        name = "Neue Verbündete unter uns",
    },
    [57486] = {
        name = "Schwindende Energie",
    },
    [57487] = {
        name = "Jemand, der helfen kann",
    },
    [57488] = {
        name = "Aktueller Bauplan",
    },
    [57490] = {
        name = "Reise in die Sicherheit",
    },
    [57491] = {
        name = "Besser... stärker... weniger tot",
    },
    [57492] = {
        name = "Er?",
    },
    [57493] = {
        name = "Mentale Abstimmung",
    },
    [57494] = {
        name = "Ein starkes Herz",
    },
    [57495] = {
        name = "Die Zukunft von Mechagon",
    },
    [57496] = {
        name = "Aufstieg",
    },
    [57497] = {
        name = "Verbreitet die Neuigkeiten",
    },
    [57524] = {
        name = "Archivzugriff",
    },
    [57873] = {
        name = "Nachricht aus Orsis",
    },
    [57915] = {
        name = "Suche nach Überlebenden",
    },
    [57954] = {
        name = "Verbrennt die Leichen",
    },
    [57955] = {
        name = "Zum Hafen von Ankhaten",
    },
    [57956] = {
        name = "Befallene Wüstenwanderer",
    },
    [57969] = {
        name = "Pflege für die Verwundeten",
    },
    [57971] = {
        name = "Die Ruinen von Ammon",
    },
    [57990] = {
        name = "Der Obelisk der Sonne",
    },
    [58008] = {
        name = "Aufgetankt",
    },
    [58009] = {
        name = "Zum Mond",
    },
    [58087] = {
        name = "Die Quelle zerstören",
    },
    [58214] = {
        name = "Notfallbehandlung",
    },
    [58496] = {
        name = "Ein unangenehmer Berater",
    },
    [58498] = {
        name = "Die Rückkehr des Kriegerkönigs",
    },
    [58502] = {
        name = "Herzensangelegenheit",
    },
    [58506] = {
        name = "Netzwerkdiagnose",
    },
    [58582] = {
        name = "Rückkehr des Schwarzen Prinzen",
    },
    [58583] = {
        name = "Herzensangelegenheit",
    },
    [58606] = {
        name = "Teilchenforschung",
    },
    [58615] = {
        name = "Stimmen in der Dunkelheit",
    },
    [58631] = {
        name = "Hinein in die Träume",
    },
    [58632] = {
        name = "Ny'alotha, die Erwachte Stadt: Das Ende des Verderbers",
    },
    [58634] = {
        name = "Öffnung des Tors",
    },
    [58636] = {
        name = "Blick auf die Amathet",
    },
    [58638] = {
        name = "Tiefer eintauchen",
    },
    [58639] = {
        name = "Vergrabene Geschichte",
    },
    [58640] = {
        name = "Ein Sprung in der Rüstung",
    },
    [58641] = {
        name = "Verderbnissucher",
    },
    [58642] = {
        name = "Gemeinsame Ziele",
    },
    [58643] = {
        name = "Gegenseitig zugesicherte Vernichtung",
    },
    [58645] = {
        name = "Rettenswerte Welt",
    },
    [58646] = {
        name = "Da habt ihr was zum Beißen!",
    },
    [58737] = {
        name = "Magnis Erkenntnisse",
    },
})
]])()
