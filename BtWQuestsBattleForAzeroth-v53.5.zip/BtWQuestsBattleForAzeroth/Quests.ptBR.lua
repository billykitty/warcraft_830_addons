----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "ptBR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Tirando sangue",
    },
    [44785] = {
        name = "Chá das cinco",
    },
    [45079] = {
        name = "A vila de Arroio do Vale",
    },
    [45972] = {
        name = "A mata amaldiçoada",
    },
    [46727] = {
        name = "Marés da guerra",
    },
    [46728] = {
        name = "A nação de Kul Tiraz",
    },
    [46729] = {
        name = "O velho cavaleiro",
    },
    [46846] = {
        name = "A palavra de Zul",
    },
    [46926] = {
        name = "Recadinho",
    },
    [46927] = {
        name = "A punição de Tal'aman",
    },
    [46928] = {
        name = "A punição de Tal'farrak",
    },
    [46929] = {
        name = "Impedimento",
    },
    [46931] = {
        name = "Representante da Horda",
    },
    [46957] = {
        name = "Boas-vindas a Zuldazar",
    },
    [47098] = {
        name = "Fuga estilo Filinto",
    },
    [47099] = {
        name = "Familiarização",
    },
    [47103] = {
        name = "Jornada a Nazmir",
    },
    [47105] = {
        name = "Trevas adentro",
    },
    [47130] = {
        name = "Enterro impróprio",
    },
    [47181] = {
        name = "Armado e perigoso",
    },
    [47186] = {
        name = "Sacrário dos Sábios",
    },
    [47188] = {
        name = "A ajuda dos loas",
    },
    [47189] = {
        name = "Uma nação dividida",
    },
    [47198] = {
        name = "Eles querem a gente vivo",
    },
    [47199] = {
        name = "O Portal Sangrento",
    },
    [47200] = {
        name = "Carrapatos",
    },
    [47204] = {
        name = "A nova linha de frente",
    },
    [47205] = {
        name = "Mãe-da-guerra",
    },
    [47226] = {
        name = "O filhote órfão",
    },
    [47228] = {
        name = "Ecologia xibalana",
    },
    [47229] = {
        name = "Baluarte de Torcali",
    },
    [47235] = {
        name = "A busca pelo Olho",
    },
    [47241] = {
        name = "A sombra da morte",
    },
    [47244] = {
        name = "Uma limpa de almas",
    },
    [47245] = {
        name = "Recepção da mensagem",
    },
    [47247] = {
        name = "Aquilo que assombra os mortos",
    },
    [47248] = {
        name = "Até que a morte nos separe",
    },
    [47249] = {
        name = "Alma atada",
    },
    [47250] = {
        name = "Nos veremos de novo",
    },
    [47257] = {
        name = "Ossada de Xibala",
    },
    [47258] = {
        name = "Preparativos contra cerco",
    },
    [47259] = {
        name = "Creche escornante",
    },
    [47260] = {
        name = "Efeitos colaterais",
    },
    [47261] = {
        name = "Como treinar seu escornante",
    },
    [47262] = {
        name = "Acabando com os trolls sangrentos",
    },
    [47263] = {
        name = "A hora da verdade",
    },
    [47264] = {
        name = "Não deixe ninguém de pé",
    },
    [47272] = {
        name = "Hormônio de Crescimento de Escornante",
    },
    [47289] = {
        name = "Ursinhos e chá",
    },
    [47310] = {
        name = "Hora da soneca",
    },
    [47311] = {
        name = "Primeiras cabeçadas",
    },
    [47312] = {
        name = "Pena-rainha",
    },
    [47313] = {
        name = "Discussões discretas",
    },
    [47314] = {
        name = "Cheirinho de exílio no ar",
    },
    [47315] = {
        name = "De cabeça nas dunas",
    },
    [47316] = {
        name = "Segredos na areia",
    },
    [47317] = {
        name = "Tem alguém vivo aí?",
    },
    [47319] = {
        name = "Veneno restaurativo",
    },
    [47320] = {
        name = "Bálsamo que acalma",
    },
    [47321] = {
        name = "Passa pra cá!",
    },
    [47322] = {
        name = "Fuga auxiliada",
    },
    [47324] = {
        name = "Aliados improváveis",
    },
    [47327] = {
        name = "Em resposta aos ataques",
    },
    [47329] = {
        name = "O Legado Vigiassangre",
    },
    [47332] = {
        name = "Seu próximo passo",
    },
    [47418] = {
        name = "Dor de crescimento",
    },
    [47422] = {
        name = "Situação hedionda",
    },
    [47423] = {
        name = "Práticas proibidas",
    },
    [47428] = {
        name = "Gatinho?",
    },
    [47432] = {
        name = "Barganha firmada",
    },
    [47433] = {
        name = "Ofensivamente defensivo",
    },
    [47434] = {
        name = "Ordem restritiva",
    },
    [47435] = {
        name = "Disputa pterritorial",
    },
    [47437] = {
        name = "Devoção competitiva",
    },
    [47438] = {
        name = "Escolhendo lados",
    },
    [47439] = {
        name = "Gonk, Senhor da Matilha",
    },
    [47440] = {
        name = "Pa'kul, Mestre dos Ventos",
    },
    [47441] = {
        name = "Pragas",
    },
    [47442] = {
        name = "Maldição de Jani",
    },
    [47445] = {
        name = "O Conselho Zanchuli",
    },
    [47485] = {
        name = "Companhia Comercial Grimpagris",
    },
    [47486] = {
        name = "Carregamento suspeito",
    },
    [47487] = {
        name = "Disputa trabalhista",
    },
    [47488] = {
        name = "Trabalho infantil",
    },
    [47489] = {
        name = "Clandestinos",
    },
    [47491] = {
        name = "Resquícios dos malditos",
    },
    [47497] = {
        name = "Apresentando: Gangue Presa de Ouro",
    },
    [47498] = {
        name = "O amigo perdido de Rhan'ka",
    },
    [47499] = {
        name = "Os ídolos risonhos",
    },
    [47501] = {
        name = "Trabalho pesado, drinque da pesada",
    },
    [47502] = {
        name = "O grande esquema cranial",
    },
    [47503] = {
        name = "Gozda'kun, o Escravizador",
    },
    [47509] = {
        name = "Terraço dos Escolhidos",
    },
    [47520] = {
        name = "Paredes têm ouvidos",
    },
    [47521] = {
        name = "Meia-noite no Jardim dos Loas",
    },
    [47522] = {
        name = "O caçador",
    },
    [47525] = {
        name = "Na maciota",
    },
    [47527] = {
        name = "Rituais de heresia",
    },
    [47528] = {
        name = "Máter das mentiras",
    },
    [47540] = {
        name = "Restauração Totêmica",
    },
    [47564] = {
        name = "Reabastecendo o bufê",
    },
    [47570] = {
        name = "Motivações ocultas",
    },
    [47571] = {
        name = "A sabedoria do ancião",
    },
    [47573] = {
        name = "Infestação de teias da selva",
    },
    [47574] = {
        name = "Sem enrolação",
    },
    [47576] = {
        name = "A ira do tigre",
    },
    [47577] = {
        name = "Elas vieram do mar",
    },
    [47578] = {
        name = "A marca dos loa",
    },
    [47580] = {
        name = "A maldição de Mepjila",
    },
    [47581] = {
        name = "Bênção de Kimbul",
    },
    [47583] = {
        name = "Dimetrodontes aos montes",
    },
    [47584] = {
        name = "Casa de ferreiro, courespeto de pau",
    },
    [47585] = {
        name = "Predatório",
    },
    [47586] = {
        name = "O caçador virou caça",
    },
    [47587] = {
        name = "Caçador de Cabeças Jô",
    },
    [47596] = {
        name = "Não tem Plano \"B\"",
    },
    [47597] = {
        name = "Nenhum goblin fica para trás",
    },
    [47598] = {
        name = "Latrocínio e receptação",
    },
    [47599] = {
        name = "Vingança: servida quente",
    },
    [47601] = {
        name = "Avaliação de campo",
    },
    [47602] = {
        name = "Prontos para agir",
    },
    [47621] = {
        name = "Um banquete digno de loa",
    },
    [47622] = {
        name = "Um luzir mágico",
    },
    [47623] = {
        name = "O último mandingueiro de Krag'wa",
    },
    [47631] = {
        name = "Encontro com a libação",
    },
    [47638] = {
        name = "Espíritos poderosos",
    },
    [47647] = {
        name = "Monstros de Zem'lan",
    },
    [47659] = {
        name = "Caça à caçadora",
    },
    [47660] = {
        name = "Ídolos caídos",
    },
    [47695] = {
        name = "O som dos mares",
    },
    [47696] = {
        name = "Krag'wa, o Terrível",
    },
    [47697] = {
        name = "Auxílio de Krag'wa",
    },
    [47706] = {
        name = "Caça ao Rei K'tal",
    },
    [47711] = {
        name = "Cabeça da víbora",
    },
    [47716] = {
        name = "Vasculhando as ruinas",
    },
    [47733] = {
        name = "A traição da voz-dos-loas",
    },
    [47734] = {
        name = "Parceiros na heresia",
    },
    [47735] = {
        name = "Remédios tortollanos ancestrais",
    },
    [47736] = {
        name = "Cabeças vão rolar",
    },
    [47737] = {
        name = "O Templo de Rezan",
    },
    [47738] = {
        name = "A vontade do Loa",
    },
    [47739] = {
        name = "O cheiro da vingança",
    },
    [47740] = {
        name = "A casa do Rei",
    },
    [47741] = {
        name = "Sacrificando Loa",
    },
    [47742] = {
        name = "Motim de Zul",
    },
    [47755] = {
        name = "Desencanto",
    },
    [47756] = {
        name = "A liberação da Libação",
    },
    [47797] = {
        name = "Profissão perigo",
    },
    [47868] = {
        name = "A Necrópole",
    },
    [47870] = {
        name = "Morto não conta história",
    },
    [47871] = {
        name = "Kit básico do marinheiro",
    },
    [47873] = {
        name = "O cofre do capitão",
    },
    [47874] = {
        name = "Clareando as ideias",
    },
    [47880] = {
        name = "Um tributo à morte",
    },
    [47894] = {
        name = "[Jump Around]",
    },
    [47897] = {
        name = "Traidores Zanchuli",
    },
    [47915] = {
        name = "O resgate dos prisioneiros",
    },
    [47918] = {
        name = "A serviço de Krag'wa",
    },
    [47919] = {
        name = "Diga não ao canibalismo",
    },
    [47924] = {
        name = "Filtro de profanidade",
    },
    [47925] = {
        name = "Shoak ensopadinho",
    },
    [47928] = {
        name = "Oferenda para o loa",
    },
    [47939] = {
        name = "Se a chave servir...",
    },
    [47943] = {
        name = "Pesca de caranguejo",
    },
    [47945] = {
        name = "Salsichas lentas",
    },
    [47946] = {
        name = "Toucinho de gente",
    },
    [47947] = {
        name = "Lobos maus",
    },
    [47948] = {
        name = "Costeleta",
    },
    [47949] = {
        name = "Esse fetiche não é meu não",
    },
    [47950] = {
        name = "Presunto curado",
    },
    [47952] = {
        name = "A frota desaparecida",
    },
    [47959] = {
        name = "O rastro da Guarda Bélica",
    },
    [47960] = {
        name = "Estreito Tiragarde",
    },
    [47962] = {
        name = "Vale Trovamare",
    },
    [47963] = {
        name = "O Ancião",
    },
    [47965] = {
        name = "O templo arruinado",
    },
    [47968] = {
        name = "Sinais e portentos",
    },
    [47969] = {
        name = "Maldição de Refúgio Outonal",
    },
    [47978] = {
        name = "A velha volúvel",
    },
    [47979] = {
        name = "Caça à bruxa",
    },
    [47980] = {
        name = "Animais assassinos",
    },
    [47981] = {
        name = "A maldição partida",
    },
    [47982] = {
        name = "A efígie final",
    },
    [47996] = {
        name = "Extermínio de mandíbulos",
    },
    [47998] = {
        name = "Carne de canibal",
    },
    [48003] = {
        name = "As ordens do lorde",
    },
    [48004] = {
        name = "Equitação para principiantes",
    },
    [48005] = {
        name = "A casa é sua",
    },
    [48008] = {
        name = "Carga perigosa",
    },
    [48009] = {
        name = "Traição da Guarda",
    },
    [48014] = {
        name = "Poda de gentalha",
    },
    [48015] = {
        name = "Os pergaminhos de Gral",
    },
    [48025] = {
        name = "Guardando para mais tarde",
    },
    [48026] = {
        name = "Debaixo das ondas",
    },
    [48070] = {
        name = "O Festival da Casa Lancastre",
    },
    [48077] = {
        name = "Caça aos arminhos",
    },
    [48080] = {
        name = "Uma pitada de perigo",
    },
    [48087] = {
        name = "Caminhada equestre",
    },
    [48088] = {
        name = "Troggs bons de bico",
    },
    [48089] = {
        name = "Sons da montanha",
    },
    [48090] = {
        name = "Os escolhidos de Krag'wa",
    },
    [48092] = {
        name = "A vingança dos sapos",
    },
    [48093] = {
        name = "Nagando a ameaça",
    },
    [48104] = {
        name = "Um desafio maior",
    },
    [48108] = {
        name = "A filha dos Capelo",
    },
    [48109] = {
        name = "As florestas têm olhos",
    },
    [48110] = {
        name = "Em caso de emboscada",
    },
    [48111] = {
        name = "Julgamento por superstição",
    },
    [48113] = {
        name = "Uma pungente solução",
    },
    [48165] = {
        name = "Nocivo se engolido",
    },
    [48170] = {
        name = "Mosca na sopa",
    },
    [48171] = {
        name = "A maldição da Clareira do Flecheiro",
    },
    [48179] = {
        name = "Resgate dos patrulheiros",
    },
    [48180] = {
        name = "Um baita dum problemão",
    },
    [48181] = {
        name = "Nananinanão",
    },
    [48182] = {
        name = "Marcação cerrada",
    },
    [48183] = {
        name = "As colinas vivem",
    },
    [48184] = {
        name = "Fragmentos de História",
    },
    [48195] = {
        name = "Trogloditas truculentos",
    },
    [48196] = {
        name = "No rastro de Edu",
    },
    [48198] = {
        name = "O ônus da prova",
    },
    [48237] = {
        name = "Derrote Nekthara",
    },
    [48283] = {
        name = "Indiciada",
    },
    [48313] = {
        name = "Remédio da natureza",
    },
    [48314] = {
        name = "Morte rastejante",
    },
    [48315] = {
        name = "Olhos ausentes e vazios",
    },
    [48317] = {
        name = "Um faro para magia",
    },
    [48320] = {
        name = "Cutucar vespeiro com vara curta",
    },
    [48321] = {
        name = "Marketing criativo",
    },
    [48322] = {
        name = "Recepção na Presa de Ouro",
    },
    [48324] = {
        name = "Perdidos em Zem'lan",
    },
    [48326] = {
        name = "É motim, cambada",
    },
    [48327] = {
        name = "Uma entrega estranha",
    },
    [48329] = {
        name = "Machucado, mas vivo",
    },
    [48330] = {
        name = "A pilha de tesouros dos Zandalari",
    },
    [48331] = {
        name = "Drenando almas",
    },
    [48332] = {
        name = "Ranishu, mil e uma utilidades",
    },
    [48334] = {
        name = "Golens a granel",
    },
    [48335] = {
        name = "O tecido mais forte de Vol'Dun",
    },
    [48347] = {
        name = "Cais do Caniço",
    },
    [48348] = {
        name = "Esporões perfurantes",
    },
    [48352] = {
        name = "Cura que vem do mar",
    },
    [48353] = {
        name = "Fofocas do porto",
    },
    [48354] = {
        name = "Carregamentos contaminados",
    },
    [48355] = {
        name = "Evacuação de emergência",
    },
    [48356] = {
        name = "Elmo possessivo",
    },
    [48365] = {
        name = "O jovem Lorde Trovamare",
    },
    [48366] = {
        name = "Bote seguro",
    },
    [48367] = {
        name = "Isso não é ovo de peixe",
    },
    [48368] = {
        name = "Profanação das profundezas do mar",
    },
    [48369] = {
        name = "Estratégia emergente",
    },
    [48370] = {
        name = "Morte nas Profundezas",
    },
    [48372] = {
        name = "Invocações Sobrenaturais",
    },
    [48399] = {
        name = "Onda de Ferro Negro",
    },
    [48400] = {
        name = "O grande roubo telemântico",
    },
    [48402] = {
        name = "Um toque venenoso",
    },
    [48404] = {
        name = "Os Pivetes",
    },
    [48405] = {
        name = "Seu Maneiro",
    },
    [48419] = {
        name = "Como abelha no mel",
    },
    [48421] = {
        name = "Marés de sangue",
    },
    [48452] = {
        name = "Mercado vermelho",
    },
    [48454] = {
        name = "Mal comprovado",
    },
    [48456] = {
        name = "Mandingueira Jala",
    },
    [48468] = {
        name = "A liberdade por Bwonsamdi",
    },
    [48473] = {
        name = "Respeito aos ritos",
    },
    [48474] = {
        name = "Guardiões da cripta",
    },
    [48475] = {
        name = "Espíritos à vista",
    },
    [48476] = {
        name = "Grupo dividido",
    },
    [48477] = {
        name = "Em busca de mais um",
    },
    [48478] = {
        name = "O lar de Kel'vax",
    },
    [48479] = {
        name = "Proteção óssea",
    },
    [48480] = {
        name = "A queda de Kel'vax",
    },
    [48492] = {
        name = "Pernas pra que te quero",
    },
    [48496] = {
        name = "Reunião da companhia",
    },
    [48497] = {
        name = "Demonstração de força",
    },
    [48498] = {
        name = "Sem piedade para Sithis",
    },
    [48499] = {
        name = "Retorno ao pó",
    },
    [48504] = {
        name = "Pela estrada afora",
    },
    [48505] = {
        name = "Perdido de paixão",
    },
    [48515] = {
        name = "Lâminas de Prata",
    },
    [48516] = {
        name = "Comunidade Tóxica",
    },
    [48517] = {
        name = "Dispensa honrosa",
    },
    [48518] = {
        name = "Salve quem você puder",
    },
    [48519] = {
        name = "Tomara que eles não saibam nadar",
    },
    [48520] = {
        name = "As três irmãs",
    },
    [48521] = {
        name = "Encantando os sem-vida",
    },
    [48522] = {
        name = "Uma missiva reveladora",
    },
    [48523] = {
        name = "A máter matadora",
    },
    [48524] = {
        name = "Tolhendo o covil",
    },
    [48525] = {
        name = "Faça-os em pedaços",
    },
    [48527] = {
        name = "Tubarões terrestres vorazes",
    },
    [48529] = {
        name = "Bocas famintas para alimentar",
    },
    [48530] = {
        name = "Em busca das alpacas perdidas",
    },
    [48531] = {
        name = "Carne misteriosa",
    },
    [48532] = {
        name = "Alpacas alopradas",
    },
    [48533] = {
        name = "Frango frito vol'duni",
    },
    [48534] = {
        name = "A risada derradeira de Rosnadente",
    },
    [48535] = {
        name = "Nazmir, o Pântano Proibido",
    },
    [48538] = {
        name = "Um álibi hermético",
    },
    [48539] = {
        name = "Angra do Facão",
    },
    [48540] = {
        name = "Ajuda ao cais",
    },
    [48549] = {
        name = "Grozztok, o Coração das Trevas",
    },
    [48550] = {
        name = "Algibeiras afanadas",
    },
    [48551] = {
        name = "Planta sem água é mágoa",
    },
    [48553] = {
        name = "Vai no fluxo",
    },
    [48554] = {
        name = "A fonte do problema",
    },
    [48555] = {
        name = "As sementes têm salvação",
    },
    [48557] = {
        name = "Semeando brotos",
    },
    [48558] = {
        name = "O bando da Maré-férrea",
    },
    [48573] = {
        name = "Vida de crocolisco",
    },
    [48574] = {
        name = "Extração presária",
    },
    [48576] = {
        name = "Voo seguro",
    },
    [48577] = {
        name = "Aterrorizando os ovos",
    },
    [48578] = {
        name = "De olho no Celesterror",
    },
    [48581] = {
        name = "Um tapinha não dói",
    },
    [48584] = {
        name = "O sangue dos meus inimigos",
    },
    [48585] = {
        name = "Sobrevivente das Terras Devastadas",
    },
    [48588] = {
        name = "Expurgue a infecção",
    },
    [48590] = {
        name = "Cabeça e ombro",
    },
    [48591] = {
        name = "A morte e a morte de Urok",
    },
    [48597] = {
        name = "A fuga dos sauroliscos",
    },
    [48606] = {
        name = "Carregado para caçar ursos",
    },
    [48616] = {
        name = "Aves boladas",
    },
    [48622] = {
        name = "O lorde desaparecido",
    },
    [48655] = {
        name = "O aprendiz do chef",
    },
    [48656] = {
        name = "Sauroliscos selvagens",
    },
    [48657] = {
        name = "Deve ser uma delícia",
    },
    [48669] = {
        name = "Urok, o terror dos charcos",
    },
    [48670] = {
        name = "Cavalgante em fuga",
    },
    [48677] = {
        name = "Adoração vímica",
    },
    [48678] = {
        name = "Oferendas questionáveis",
    },
    [48679] = {
        name = "Se liga nas colmeias",
    },
    [48680] = {
        name = "Abelhas não!",
    },
    [48682] = {
        name = "Um simples sacrifício",
    },
    [48683] = {
        name = "Mudança de estação",
    },
    [48684] = {
        name = "A caminho",
    },
    [48699] = {
        name = "Missão Zalamar",
    },
    [48715] = {
        name = "Akunda aguarda",
    },
    [48773] = {
        name = "Quero provas!",
    },
    [48774] = {
        name = "É surra pra todo lado",
    },
    [48776] = {
        name = "Ladrão de cordame",
    },
    [48778] = {
        name = "Sopa de pedra",
    },
    [48790] = {
        name = "Mercadorias Roubadas",
    },
    [48792] = {
        name = "Ameaça à sociedade",
    },
    [48793] = {
        name = "A Sociedade de Aventureiros",
    },
    [48800] = {
        name = "Marca da morcega",
    },
    [48801] = {
        name = "O isolamento de Zalamar",
    },
    [48804] = {
        name = "Erros foram cometidos",
    },
    [48805] = {
        name = "Recuperação de pesquisa",
    },
    [48823] = {
        name = "Destruição projetada",
    },
    [48825] = {
        name = "Poder negado",
    },
    [48840] = {
        name = "Marketing de escombros",
    },
    [48846] = {
        name = "Motivação líquida",
    },
    [48847] = {
        name = "Armas para a tribo",
    },
    [48852] = {
        name = "A ferramenta contra Zardrax",
    },
    [48853] = {
        name = "Grau terminal",
    },
    [48854] = {
        name = "Oferta de poder",
    },
    [48855] = {
        name = "Abaixo os terrores",
    },
    [48856] = {
        name = "Conduítes interrompidos",
    },
    [48857] = {
        name = "A esperança já era",
    },
    [48869] = {
        name = "Jogando o Lich fora",
    },
    [48871] = {
        name = "Resgate as relíquias",
    },
    [48872] = {
        name = "Acelere a escavação",
    },
    [48873] = {
        name = "Um fim cinzento",
    },
    [48874] = {
        name = "Armação ilimitada",
    },
    [48879] = {
        name = "Em busca dos ovos mexidos",
    },
    [48880] = {
        name = "Gaivotas marotas",
    },
    [48881] = {
        name = "A grande fisgada",
    },
    [48882] = {
        name = "Não tem tripa melhor que tripa de peixe",
    },
    [48883] = {
        name = "Gaivotão da peste",
    },
    [48887] = {
        name = "Purificação da mente",
    },
    [48888] = {
        name = "A nascente eterna",
    },
    [48889] = {
        name = "Consertando o passado",
    },
    [48890] = {
        name = "Como ser um troll sangrento",
    },
    [48894] = {
        name = "Prova da verdade",
    },
    [48895] = {
        name = "A oferenda perfeita",
    },
    [48896] = {
        name = "Sabedoria do passado",
    },
    [48898] = {
        name = "Patuá da sorte",
    },
    [48899] = {
        name = "Segurança em primeiro lugar",
    },
    [48902] = {
        name = "Energia monstro",
    },
    [48903] = {
        name = "Sem dúvida, o cavalo perfeito",
    },
    [48904] = {
        name = "Coleta de isca",
    },
    [48905] = {
        name = "Pergaminhos desprezados",
    },
    [48909] = {
        name = "Fera formidável",
    },
    [48934] = {
        name = "Marca dos Condenados",
    },
    [48939] = {
        name = "Mostre o que sabe",
    },
    [48941] = {
        name = "Um pequeno desvio",
    },
    [48942] = {
        name = "Peste de yeti",
    },
    [48943] = {
        name = "Direitos de resgate",
    },
    [48944] = {
        name = "Destrancando a história",
    },
    [48945] = {
        name = "As ruínas de Gol Var",
    },
    [48946] = {
        name = "A Ordem das Brasas",
    },
    [48948] = {
        name = "As Cavernas do Passo Norte",
    },
    [48963] = {
        name = "Táticas de distração",
    },
    [48965] = {
        name = "Acerto de contas",
    },
    [48986] = {
        name = "O caminho da Estrada Alta",
    },
    [48987] = {
        name = "Vale das lamentações",
    },
    [48988] = {
        name = "Quebra de memória",
    },
    [48991] = {
        name = "Infestação repugnante",
    },
    [48992] = {
        name = "Restos Mortais Sagrados",
    },
    [48993] = {
        name = "Condutores poderosos",
    },
    [48996] = {
        name = "Dando um fim à loucura",
    },
    [49001] = {
        name = "Espíritos da inconveniência",
    },
    [49002] = {
        name = "Pouso forçado",
    },
    [49003] = {
        name = "A vingança vem de cima",
    },
    [49005] = {
        name = "Cacos e estilhaços",
    },
    [49028] = {
        name = "Um suéter para Roberto",
    },
    [49036] = {
        name = "Melhor do show",
    },
    [49039] = {
        name = "O começo de uma caça ao monstro",
    },
    [49040] = {
        name = "Despedidas afáveis",
    },
    [49059] = {
        name = "Ossada de Xibala",
    },
    [49060] = {
        name = "Ecologia xibalana",
    },
    [49064] = {
        name = "Torga, o Loa Tartaruga",
    },
    [49066] = {
        name = "Canela de pedreiro",
    },
    [49067] = {
        name = "Buscando o Bwonsamdi",
    },
    [49069] = {
        name = "PROCURA-SE: Velho Garra de Gelo",
    },
    [49070] = {
        name = "Almas para o loa da morte",
    },
    [49071] = {
        name = "Carrapatrozes pelos ares",
    },
    [49072] = {
        name = "Escolta ocidental",
    },
    [49078] = {
        name = "Envenenando geral",
    },
    [49079] = {
        name = "Hir'eek, o Loa Morcego",
    },
    [49080] = {
        name = "Evocação revogada",
    },
    [49081] = {
        name = "Morte ao Loa",
    },
    [49082] = {
        name = "Para o alto e avante",
    },
    [49120] = {
        name = "Falando com os mortos",
    },
    [49122] = {
        name = "Um porto em perigo",
    },
    [49125] = {
        name = "Sangue negativo",
    },
    [49126] = {
        name = "Revelando a mão do destino",
    },
    [49130] = {
        name = "Carne imprópria para consumo",
    },
    [49131] = {
        name = "Solo santificado",
    },
    [49132] = {
        name = "Quebrando os quebra-crânios",
    },
    [49136] = {
        name = "Jungo, o Arauto de G'huun",
    },
    [49138] = {
        name = "Tesouro do Capitão Gulnaku",
    },
    [49139] = {
        name = "Um arsenal de exército",
    },
    [49141] = {
        name = "Diplomacia e dominância",
    },
    [49144] = {
        name = "Ira dos Zandalari",
    },
    [49145] = {
        name = "Nenhum troll fica para trás",
    },
    [49146] = {
        name = "Pertences dos espíritos",
    },
    [49147] = {
        name = "Mostrando uma força de responsa",
    },
    [49148] = {
        name = "Desmantelando o inimigo",
    },
    [49149] = {
        name = "Abraça o vodu",
    },
    [49160] = {
        name = "Eterno Retorno de Torga",
    },
    [49178] = {
        name = "Minhas lembranças favoritas",
    },
    [49181] = {
        name = "Medalhão luzente",
    },
    [49185] = {
        name = "Papo em Dia",
    },
    [49218] = {
        name = "Os náufragos",
    },
    [49223] = {
        name = "Negócios escusos",
    },
    [49225] = {
        name = "Seguindo o líder",
    },
    [49226] = {
        name = "Silenciando as irmãs",
    },
    [49227] = {
        name = "Chave-mestra",
    },
    [49229] = {
        name = "A revolta das ruínas",
    },
    [49230] = {
        name = "Sabor local",
    },
    [49232] = {
        name = "Resgatando um desastre",
    },
    [49233] = {
        name = "Sou um druida, não um sacerdote",
    },
    [49234] = {
        name = "Um fuzileiro fora d'água",
    },
    [49239] = {
        name = "Vestir-se para a ocasião",
    },
    [49242] = {
        name = "Tarefa espinhosa",
    },
    [49259] = {
        name = "E justiça para todos",
    },
    [49260] = {
        name = "Proteção na empacotação",
    },
    [49261] = {
        name = "Sopão da tripulação",
    },
    [49262] = {
        name = "Desbaratando a quadrilha",
    },
    [49268] = {
        name = "Infestação de tubarões",
    },
    [49274] = {
        name = "A sondagem de Morgrum",
    },
    [49276] = {
        name = "A adrenalina da exploração",
    },
    [49278] = {
        name = "Restauração espiritual",
    },
    [49282] = {
        name = "A sondagem estendida de Morgrum",
    },
    [49283] = {
        name = "Em peregrinação pelos peregrinos",
    },
    [49284] = {
        name = "Notícias perfeitas",
    },
    [49285] = {
        name = "Pequenos tesouros",
    },
    [49286] = {
        name = "Sabedoria enjaulada",
    },
    [49287] = {
        name = "Quelônios perdidos",
    },
    [49288] = {
        name = "Os caça-pergaminhos",
    },
    [49289] = {
        name = "Uma pedra especial",
    },
    [49290] = {
        name = "Envelhecido à perfeição",
    },
    [49292] = {
        name = "Vitamina de algas",
    },
    [49295] = {
        name = "Limpa florestal",
    },
    [49299] = {
        name = "Lado a lado com o inimigo",
    },
    [49300] = {
        name = "Corrupção de criaturas",
    },
    [49302] = {
        name = "Pesca mortal",
    },
    [49309] = {
        name = "Queda do trovão",
    },
    [49310] = {
        name = "O fianqueto do profeta",
    },
    [49314] = {
        name = "A caçada a Zardrax",
    },
    [49315] = {
        name = "Conluio da Pérola Medonha",
    },
    [49327] = {
        name = "Afugentem-nos!",
    },
    [49333] = {
        name = "Criando um arsenal",
    },
    [49334] = {
        name = "Um prisioneiro poderoso",
    },
    [49335] = {
        name = "Massacre de Clamacéus",
    },
    [49340] = {
        name = "As chaves dos guardiões",
    },
    [49348] = {
        name = "O Templo Profanado",
    },
    [49366] = {
        name = "Ajuda necessária",
    },
    [49370] = {
        name = "Ao resgate do cronista",
    },
    [49375] = {
        name = "[LARRY TEST QUEST]",
    },
    [49377] = {
        name = "Cortem a cabeça dela",
    },
    [49378] = {
        name = "Conquiste a confiança deles",
    },
    [49379] = {
        name = "Zona franca de crorgs",
    },
    [49380] = {
        name = "Urucubaca ruim",
    },
    [49382] = {
        name = "Você fez um amigo",
    },
    [49393] = {
        name = "Os Casca Grossa",
    },
    [49394] = {
        name = "Paradinha aí",
    },
    [49395] = {
        name = "Ursos no mel",
    },
    [49398] = {
        name = "Erga um copo!",
    },
    [49399] = {
        name = "O grande esquema",
    },
    [49400] = {
        name = "Em busca de reforços",
    },
    [49401] = {
        name = "Poleiro do Rodrigo",
    },
    [49402] = {
        name = "Debandada do poleiro",
    },
    [49403] = {
        name = "A vingança de Rodrigo",
    },
    [49404] = {
        name = "Belvento de tempestade",
    },
    [49405] = {
        name = "Defensores do Portão de Daelin",
    },
    [49406] = {
        name = "Matança em Zalamar",
    },
    [49407] = {
        name = "Negócios arriscados",
    },
    [49408] = {
        name = "Dados piratas",
    },
    [49409] = {
        name = "Tesouro perdido!",
    },
    [49411] = {
        name = "Construir quartel",
    },
    [49412] = {
        name = "Ajudando o Henrique",
    },
    [49417] = {
        name = "Cavalgantes Casca Grossa",
    },
    [49418] = {
        name = "Chefão",
    },
    [49419] = {
        name = "Picolé falante",
    },
    [49421] = {
        name = "Caça ao Zul",
    },
    [49422] = {
        name = "Hereges",
    },
    [49424] = {
        name = "A profecia completa",
    },
    [49425] = {
        name = "Cidade de Ouro",
    },
    [49426] = {
        name = "O gambito do Rei",
    },
    [49427] = {
        name = "Não são nossos elfos roxos",
    },
    [49428] = {
        name = "O grande roubo telemântico",
    },
    [49431] = {
        name = "Quentinho e aconchegante",
    },
    [49432] = {
        name = "A alma desamparada",
    },
    [49433] = {
        name = "Wengos",
    },
    [49435] = {
        name = "Onde foram parar?",
    },
    [49437] = {
        name = "Nota Esfarrapada",
    },
    [49439] = {
        name = "A vingança do chefe",
    },
    [49440] = {
        name = "Quem vê cara...",
    },
    [49443] = {
        name = "Uma lição de caça às bruxas",
    },
    [49450] = {
        name = "Relatórios de incidentes",
    },
    [49451] = {
        name = "Pedidos de folga",
    },
    [49452] = {
        name = "Déficit de inventário",
    },
    [49453] = {
        name = "Vidas represadas",
    },
    [49454] = {
        name = "Prevenção de pragas",
    },
    [49464] = {
        name = "Rabos de saurolisco",
    },
    [49465] = {
        name = "Maximizando recursos",
    },
    [49467] = {
        name = "Bruxa do Bosque",
    },
    [49468] = {
        name = "Webinário necessário",
    },
    [49477] = {
        name = "Reforço inesperado",
    },
    [49479] = {
        name = "Uma boa ideia?",
    },
    [49489] = {
        name = "Falta encorpar",
    },
    [49490] = {
        name = "Urna das Vozes",
    },
    [49491] = {
        name = "Lenha de vodu",
    },
    [49492] = {
        name = "Arrogância de Vol'jamba",
    },
    [49493] = {
        name = "A escolha de Zul",
    },
    [49494] = {
        name = "Cerveja Zuvembi",
    },
    [49495] = {
        name = "Guiando o destino",
    },
    [49522] = {
        name = "Pagamento de Carentan",
    },
    [49523] = {
        name = "Péssimo negócio",
    },
    [49529] = {
        name = "Faxina geral",
    },
    [49531] = {
        name = "Marketing de ocasião",
    },
    [49569] = {
        name = "Rio abaixo",
    },
    [49570] = {
        name = "Pesquisa de texto",
    },
    [49571] = {
        name = "Escavando o passado",
    },
    [49572] = {
        name = "O Altar do Mar",
    },
    [49573] = {
        name = "O Altar do Anoitecer",
    },
    [49574] = {
        name = "O Altar das Tormentas",
    },
    [49575] = {
        name = "Tol Dagor: Joia das Marés",
    },
    [49576] = {
        name = "Gemas elementais",
    },
    [49577] = {
        name = "Sob a superfície",
    },
    [49581] = {
        name = "Dunas salpicadas de sol",
    },
    [49582] = {
        name = "Atal'Dazar: Nem tudo o que reluz...",
    },
    [49583] = {
        name = "Renovação reluzente",
    },
    [49584] = {
        name = "O capítulo perdido",
    },
    [49585] = {
        name = "Pesquisa de texto",
    },
    [49586] = {
        name = "Escavando o passado",
    },
    [49587] = {
        name = "O Altar da Natureza",
    },
    [49588] = {
        name = "O Altar das Areias",
    },
    [49589] = {
        name = "O Altar do Alvorecer",
    },
    [49599] = {
        name = "O capítulo perdido",
    },
    [49615] = {
        name = "A confiança de um rei",
    },
    [49661] = {
        name = "Ovos de produção local",
    },
    [49662] = {
        name = "A chave perdida",
    },
    [49663] = {
        name = "Profecias falsas",
    },
    [49664] = {
        name = "Aliança anárquica",
    },
    [49665] = {
        name = "Rebelião já!",
    },
    [49666] = {
        name = "Seremos o terror deles",
    },
    [49667] = {
        name = "Os pequeninos",
    },
    [49668] = {
        name = "Acendendo a ravina",
    },
    [49669] = {
        name = "Feras à solta",
    },
    [49676] = {
        name = "Traje de Batalha a Rigor",
    },
    [49677] = {
        name = "Planos de ataque",
    },
    [49678] = {
        name = "Choque de culturas",
    },
    [49679] = {
        name = "A incursão sethrak",
    },
    [49680] = {
        name = "Clamacéus Soltok",
    },
    [49681] = {
        name = "Tikinha",
    },
    [49694] = {
        name = "Drusta causa",
    },
    [49703] = {
        name = "Casa Trovamare",
    },
    [49704] = {
        name = "Ceifadores escangalhados",
    },
    [49705] = {
        name = "Desgaste desnecessário",
    },
    [49706] = {
        name = "Investigação dos decretos",
    },
    [49710] = {
        name = "Uma oferta de ovos",
    },
    [49715] = {
        name = "Problema na Bastilha Rochagris",
    },
    [49716] = {
        name = "Uma lição de confiança",
    },
    [49719] = {
        name = "Bolso cheio",
    },
    [49720] = {
        name = "Livres para voar",
    },
    [49725] = {
        name = "Uma trama arriscada",
    },
    [49730] = {
        name = "PROCURA-SE: Fuça Trovejante",
    },
    [49731] = {
        name = "Despedidas Afáveis",
    },
    [49733] = {
        name = "Remendando a retaguarda",
    },
    [49734] = {
        name = "Extermínio do Vira-casaca",
    },
    [49735] = {
        name = "Defesa dos ninhos",
    },
    [49736] = {
        name = "Por Kul Tiraz!",
    },
    [49737] = {
        name = "Assalto Aéreo",
    },
    [49738] = {
        name = "Ninguém toca na minha poupança!",
    },
    [49739] = {
        name = "Inimigos no portão",
    },
    [49740] = {
        name = "Cessar fogo!",
    },
    [49741] = {
        name = "Retaliação justa",
    },
    [49744] = {
        name = "Lançar bombas!",
    },
    [49745] = {
        name = "Essas são as ordens deles",
    },
    [49746] = {
        name = "Extinção de incêndio",
    },
    [49753] = {
        name = "Construir armaria",
    },
    [49754] = {
        name = "\"Só Zul\" uma ova!",
    },
    [49755] = {
        name = "Artilharia pesada",
    },
    [49757] = {
        name = "Gata em teto de cobre quente",
    },
    [49758] = {
        name = "Mande o sinal!",
    },
    [49759] = {
        name = "Construir oficina",
    },
    [49766] = {
        name = "Seu próximo passo",
    },
    [49767] = {
        name = "Seu próximo passo",
    },
    [49768] = {
        name = "Trilha de Rosarães",
    },
    [49769] = {
        name = "Destroços do Cataclismo",
    },
    [49774] = {
        name = "Morrer está folha de questão!",
    },
    [49775] = {
        name = "Chave de cadeia",
    },
    [49776] = {
        name = "Não há problema que o piche não resolva",
    },
    [49777] = {
        name = "Prisioneiros em fuga",
    },
    [49778] = {
        name = "Não siga a luz",
    },
    [49779] = {
        name = "Roendo o osso",
    },
    [49780] = {
        name = "Recuperação do fogo ancestral",
    },
    [49781] = {
        name = "Agarre-me se for capaz",
    },
    [49785] = {
        name = "Destrua a arma",
    },
    [49791] = {
        name = "Perdidos, mas não esquecidos",
    },
    [49792] = {
        name = "Atados e oprimidos",
    },
    [49793] = {
        name = "Meios para um fim",
    },
    [49794] = {
        name = "A maré crescente",
    },
    [49801] = {
        name = "Tática de acasalamento agressiva",
    },
    [49803] = {
        name = "Troca da guarda",
    },
    [49804] = {
        name = "Ideia afiada",
    },
    [49805] = {
        name = "Instrumentos de má índole",
    },
    [49806] = {
        name = "Negociatas ocultas",
    },
    [49807] = {
        name = "Uma nova Ordem",
    },
    [49810] = {
        name = "Casamenteira de monstro",
    },
    [49814] = {
        name = "Perfume de brutossauro",
    },
    [49818] = {
        name = "Problemas no Forte Daelin",
    },
    [49831] = {
        name = "Das profundezas",
    },
    [49832] = {
        name = "Um pergaminho ilegível",
    },
    [49869] = {
        name = "Defesa desesperada",
    },
    [49870] = {
        name = "Questão de tamanho",
    },
    [49871] = {
        name = "Contra a maré",
    },
    [49873] = {
        name = "Éditos sacrificiais",
    },
    [49874] = {
        name = "Ao pé da letra",
    },
    [49876] = {
        name = "Linhas na Areia",
    },
    [49877] = {
        name = "Templo de Sethraliss: Livrando-se de um favor",
    },
    [49878] = {
        name = "Proteção a pena",
    },
    [49879] = {
        name = "Rabiscos mortais",
    },
    [49881] = {
        name = "Os versos finais",
    },
    [49882] = {
        name = "Uma provação de dar pena",
    },
    [49884] = {
        name = "Luz azul da esperança",
    },
    [49886] = {
        name = "Faro fino",
    },
    [49887] = {
        name = "Trabalho forçado",
    },
    [49890] = {
        name = "Queda drusta",
    },
    [49896] = {
        name = "Para Mata do Falcão!",
    },
    [49897] = {
        name = "Criando mistérios",
    },
    [49898] = {
        name = "Clara vitória",
    },
    [49901] = {
        name = "Atal'Dazar: Yazma, a Sacerdotisa Caída",
    },
    [49902] = {
        name = "Nessa rua tem um bosque",
    },
    [49905] = {
        name = "Reviravolta",
    },
    [49908] = {
        name = "De volta a Brennadam",
    },
    [49917] = {
        name = "Jakamita? Mita mesmo!",
    },
    [49918] = {
        name = "Garganta do Gorila",
    },
    [49919] = {
        name = "Confisco de jakamita",
    },
    [49920] = {
        name = "Gorilismo de guerrilha",
    },
    [49922] = {
        name = "Rei Da'ka",
    },
    [49926] = {
        name = "A estrada para Corlain",
    },
    [49932] = {
        name = "Alguma coisa desperta",
    },
    [49935] = {
        name = "Como consertar um guardião titânico",
    },
    [49937] = {
        name = "Reciclagem",
    },
    [49938] = {
        name = "Terra corrompida",
    },
    [49939] = {
        name = "Adeus, irmã",
    },
    [49940] = {
        name = "Fenda Escareia",
    },
    [49941] = {
        name = "Procissão dos ossos",
    },
    [49943] = {
        name = "Tirando sangue",
    },
    [49944] = {
        name = "Drusta causa",
    },
    [49946] = {
        name = "Linhas na Areia",
    },
    [49949] = {
        name = "Boa noite e boa morte",
    },
    [49950] = {
        name = "Purificação de sangue",
    },
    [49955] = {
        name = "Presença incômoda",
    },
    [49956] = {
        name = "Proibido caos",
    },
    [49957] = {
        name = "Recuperação de protocolo",
    },
    [49960] = {
        name = "Pega eles!",
    },
    [49965] = {
        name = "O bando de guerra",
    },
    [49969] = {
        name = "Despertando um deus",
    },
    [49975] = {
        name = "Descanso nas profundezas",
    },
    [49980] = {
        name = "Procedimento de contenção",
    },
    [49985] = {
        name = "Retornar ao Bosque da Solidão",
    },
    [49995] = {
        name = "Fabricações fabricadas",
    },
    [49996] = {
        name = "Rearmamento",
    },
    [49997] = {
        name = "Julgamento da tempestade",
    },
    [49998] = {
        name = "Vozes abaixo",
    },
    [50001] = {
        name = "A bruxaria do mal",
    },
    [50002] = {
        name = "Uma carga muito preciosa",
    },
    [50003] = {
        name = "A primeira vigília",
    },
    [50005] = {
        name = "Segure na minha mão",
    },
    [50009] = {
        name = "Tripulação de recuperação de naufrágio",
    },
    [50026] = {
        name = "Resgatar nossos companheiros de bordo",
    },
    [50036] = {
        name = "Armas de outrora",
    },
    [50041] = {
        name = "De bolsos cheios",
    },
    [50043] = {
        name = "Eficiência arqueológica",
    },
    [50044] = {
        name = "Eficiência arqueológica",
    },
    [50058] = {
        name = "O bicho de estimação da bruxa",
    },
    [50059] = {
        name = "Não ouço nada",
    },
    [50063] = {
        name = "Combatendo com fogo",
    },
    [50064] = {
        name = "Não desça ao porão",
    },
    [50065] = {
        name = "Um motivo para ficar",
    },
    [50069] = {
        name = "A guerra dos Campodouro",
    },
    [50070] = {
        name = "Detetive Mildião",
    },
    [50074] = {
        name = "Bombada brutal",
    },
    [50076] = {
        name = "Reunir os guerreiros",
    },
    [50078] = {
        name = "Totens imortais",
    },
    [50079] = {
        name = "A bombinha faz bum ah buum",
    },
    [50080] = {
        name = "Saqueando os saqueadores",
    },
    [50081] = {
        name = "A estrada da dor",
    },
    [50082] = {
        name = "Alvo de oportunidade",
    },
    [50083] = {
        name = "A ma'ma dos crorgs",
    },
    [50085] = {
        name = "Uma mensagem de sangue e fogo",
    },
    [50087] = {
        name = "A queda de Ateena",
    },
    [50088] = {
        name = "Campos eternamente dourados",
    },
    [50090] = {
        name = "Construindo defesas",
    },
    [50091] = {
        name = "Reparos na vila",
    },
    [50092] = {
        name = "Alívio refrescante",
    },
    [50110] = {
        name = "Arautos das más notícias",
    },
    [50111] = {
        name = "Totens, totens, totens!",
    },
    [50112] = {
        name = "Atirando a primeira pedra",
    },
    [50113] = {
        name = "Extratos oculares",
    },
    [50114] = {
        name = "Martelando a informação",
    },
    [50115] = {
        name = "Mudando as coisas",
    },
    [50116] = {
        name = "Uma possível solução",
    },
    [50117] = {
        name = "Um trago mortal",
    },
    [50118] = {
        name = "Pedrada",
    },
    [50119] = {
        name = "Química cavernosa",
    },
    [50120] = {
        name = "Receita de sucesso",
    },
    [50121] = {
        name = "Atirando a primeira pedra",
    },
    [50122] = {
        name = "Extratos oculares",
    },
    [50123] = {
        name = "Uma receita eterna",
    },
    [50124] = {
        name = "Mudando as coisas",
    },
    [50125] = {
        name = "Uma possível solução",
    },
    [50126] = {
        name = "Um trago mortal",
    },
    [50127] = {
        name = "Pedrada",
    },
    [50128] = {
        name = "Química cavernosa",
    },
    [50129] = {
        name = "Receita de sucesso",
    },
    [50133] = {
        name = "Batendo pela raiz",
    },
    [50134] = {
        name = "Troços e engenhocas aos borbotões",
    },
    [50135] = {
        name = "O tempo urze!",
    },
    [50136] = {
        name = "Estimulador de Fazenda",
    },
    [50138] = {
        name = "A batalha pela Ravina Rubrofogo",
    },
    [50139] = {
        name = "O elo perdido",
    },
    [50149] = {
        name = "Um olho para o tempo",
    },
    [50150] = {
        name = "Criando o clima",
    },
    [50151] = {
        name = "Um lastro estável",
    },
    [50152] = {
        name = "Escavando retalhos",
    },
    [50154] = {
        name = "Dizem que é uma delícia",
    },
    [50157] = {
        name = "Esses campos valem ouro",
    },
    [50158] = {
        name = "Conferindo o estrago",
    },
    [50161] = {
        name = "Recuperação do Raimundo",
    },
    [50162] = {
        name = "Situação grudenta",
    },
    [50165] = {
        name = "Esquadrão Classe Bzz",
    },
    [50168] = {
        name = "Sucessão real",
    },
    [50172] = {
        name = "Rubralenha adentro",
    },
    [50173] = {
        name = "Metais preciosos",
    },
    [50174] = {
        name = "Tudo embrulhadinho",
    },
    [50175] = {
        name = "Maldição de oito patas",
    },
    [50177] = {
        name = "Defenda a barricada!",
    },
    [50178] = {
        name = "Perigo na Senda do Raizedo",
    },
    [50195] = {
        name = "Brigada de Malhoquilha",
    },
    [50206] = {
        name = "Contra-ataque",
    },
    [50235] = {
        name = "Sem refúgio",
    },
    [50238] = {
        name = "Arbusto Espinhoso",
    },
    [50240] = {
        name = "Pterrordax quer biscoito?",
    },
    [50249] = {
        name = "Ameaça tripla",
    },
    [50251] = {
        name = "Enfeitiçados",
    },
    [50252] = {
        name = "Intervalo na temporada reprodutiva",
    },
    [50253] = {
        name = "Um arsenal improvisado",
    },
    [50264] = {
        name = "Liberte os lavradores",
    },
    [50265] = {
        name = "O resgate do Mestre Azinhal",
    },
    [50266] = {
        name = "Encrenca nectarina",
    },
    [50268] = {
        name = "Dando uma forcinha",
    },
    [50270] = {
        name = "Nas profundezas do núcleo",
    },
    [50271] = {
        name = "Arrebentamento e fuga",
    },
    [50272] = {
        name = "De orelha no chão",
    },
    [50274] = {
        name = "Forja Titânica",
    },
    [50275] = {
        name = "Bigornas a caminho",
    },
    [50276] = {
        name = "Uma receita eterna",
    },
    [50277] = {
        name = "Martelando a informação",
    },
    [50278] = {
        name = "Nas profundezas do núcleo",
    },
    [50279] = {
        name = "Bigornas a caminho",
    },
    [50288] = {
        name = "A escolha de Therazane",
    },
    [50297] = {
        name = "A cabeça do inimigo dela",
    },
    [50306] = {
        name = "Coisas Diversas",
    },
    [50325] = {
        name = "Um fim ao Grande Ritual",
    },
    [50327] = {
        name = "Uma dose revigorante",
    },
    [50328] = {
        name = "Aroma exótico",
    },
    [50329] = {
        name = "Máteres de Rubralenha",
    },
    [50331] = {
        name = "Um resultado inesperado",
    },
    [50332] = {
        name = "Maluco caçador",
    },
    [50340] = {
        name = "Reembolso por roubo",
    },
    [50343] = {
        name = "Meleira na Hidromelaria",
    },
    [50349] = {
        name = "Uma mina dominada",
    },
    [50350] = {
        name = "Precisamos de um químico",
    },
    [50351] = {
        name = "Operação de minerador",
    },
    [50352] = {
        name = "Pitada de azerita",
    },
    [50353] = {
        name = "Javaliu a pena",
    },
    [50354] = {
        name = "Ah, tá, laia!",
    },
    [50356] = {
        name = "Picadinho de pedra",
    },
    [50359] = {
        name = "Faxina geral",
    },
    [50363] = {
        name = "Porcos de guerra",
    },
    [50365] = {
        name = "Corra para as colinas",
    },
    [50367] = {
        name = "Ira engarrafada",
    },
    [50368] = {
        name = "O terror do urzal",
    },
    [50370] = {
        name = "Na mata cerrada",
    },
    [50376] = {
        name = "Baú Mortífero: Peixão para valer",
    },
    [50381] = {
        name = "O grande roubo de chapéu",
    },
    [50385] = {
        name = "Propósito infatigável",
    },
    [50386] = {
        name = "Revelação",
    },
    [50387] = {
        name = "Bugigangas e ninharias",
    },
    [50388] = {
        name = "O peso da minha ambição",
    },
    [50389] = {
        name = "Inspiração maligna",
    },
    [50391] = {
        name = "Baú Mortífero: Pesca de fogo",
    },
    [50393] = {
        name = "Um filho de Pa'kul",
    },
    [50394] = {
        name = "Problema teu",
    },
    [50395] = {
        name = "O chamado dos céus",
    },
    [50396] = {
        name = "Um destino pterrível",
    },
    [50397] = {
        name = "Aspirações aéreas",
    },
    [50401] = {
        name = "Medo da queda",
    },
    [50412] = {
        name = "De volta ao ninho",
    },
    [50417] = {
        name = "A ruína chegou",
    },
    [50418] = {
        name = "Baú Mortífero: prende a respiração e vai",
    },
    [50433] = {
        name = "Debandada em Zanchuli",
    },
    [50444] = {
        name = "No caminho do loa",
    },
    [50445] = {
        name = "No controle da situação",
    },
    [50446] = {
        name = "Hora do desbruxamento",
    },
    [50447] = {
        name = "Em memória dos caídos",
    },
    [50448] = {
        name = "A retomada de Corlain",
    },
    [50449] = {
        name = "Refúgio nauseante",
    },
    [50450] = {
        name = "Colheita agressiva",
    },
    [50451] = {
        name = "As defesas estão no papo",
    },
    [50452] = {
        name = "Proteção potente",
    },
    [50453] = {
        name = "A barreira fez bum",
    },
    [50454] = {
        name = "Morte ao traidor",
    },
    [50455] = {
        name = "Adeus ao ninho",
    },
    [50456] = {
        name = "Filhotes amaldiçoados",
    },
    [50457] = {
        name = "Escapatória",
    },
    [50466] = {
        name = "Ele está enlouquecido!",
    },
    [50481] = {
        name = "Nos salões do Rei Drusto",
    },
    [50493] = {
        name = "Wrex, cadê você, meu filho?",
    },
    [50504] = {
        name = "Sam melado",
    },
    [50520] = {
        name = "Cadê o Sam?",
    },
    [50530] = {
        name = "Bruxa vida, para onde agora?",
    },
    [50531] = {
        name = "Bem debaixo dos narizes",
    },
    [50533] = {
        name = "Acaba com eles!",
    },
    [50534] = {
        name = "Fora, wendigo!",
    },
    [50535] = {
        name = "O poder da feitora",
    },
    [50536] = {
        name = "Dispositivo decodificador mágico",
    },
    [50538] = {
        name = "O tratador desaparecido",
    },
    [50539] = {
        name = "Os segredos de Zul'Ahjin",
    },
    [50542] = {
        name = "Uma oportunidade explosiva",
    },
    [50544] = {
        name = "Caçadores do Rancho Kennings",
    },
    [50550] = {
        name = "A queda do Imperador Korthek",
    },
    [50551] = {
        name = "Templo de Sethraliss: o avatar da loa",
    },
    [50553] = {
        name = "De volta ao laboratório",
    },
    [50561] = {
        name = "Pedra de Sulthis",
    },
    [50573] = {
        name = "Memorando da diretoria",
    },
    [50583] = {
        name = "Para o outro lado",
    },
    [50584] = {
        name = "Ritual ruinoso",
    },
    [50585] = {
        name = "Rainha da bagata",
    },
    [50586] = {
        name = "A queda de Corlain",
    },
    [50588] = {
        name = "Ataque à mansão",
    },
    [50593] = {
        name = "Um banho de sangue",
    },
    [50594] = {
        name = "Por sob o véu",
    },
    [50595] = {
        name = "Sem piedade",
    },
    [50596] = {
        name = "Extermínio de pragas",
    },
    [50598] = {
        name = "Império Zandalari",
    },
    [50599] = {
        name = "Almirantado Proudmore",
    },
    [50600] = {
        name = "Ordem das Brasas",
    },
    [50601] = {
        name = "Rastro da Tempestade",
    },
    [50602] = {
        name = "Expedição de Talanji",
    },
    [50605] = {
        name = "Esforços de Guerra da Aliança",
    },
    [50606] = {
        name = "Esforços de Guerra da Horda",
    },
    [50608] = {
        name = "Ritos proibidos",
    },
    [50609] = {
        name = "Do ventre da loucura",
    },
    [50610] = {
        name = "Tempestade iminente",
    },
    [50611] = {
        name = "Vingança da tempestade",
    },
    [50612] = {
        name = "Uma casa dividida",
    },
    [50614] = {
        name = "Por um mar de liberdade",
    },
    [50616] = {
        name = "Um vínculo perigoso",
    },
    [50621] = {
        name = "Caiu na rede, é aldeão",
    },
    [50622] = {
        name = "Infortúnios",
    },
    [50635] = {
        name = "Marés irregulares",
    },
    [50639] = {
        name = "Mansão Capelo: a matriarca decaída",
    },
    [50640] = {
        name = "Ameaça esmigalhada",
    },
    [50641] = {
        name = "Reduzindo as fileiras inimigas",
    },
    [50644] = {
        name = "Enfrente as invasoras",
    },
    [50645] = {
        name = "Enguias e engodos",
    },
    [50649] = {
        name = "Rasteira em ladrões",
    },
    [50653] = {
        name = "Recuperando nossas defesas",
    },
    [50656] = {
        name = "Resgate de risco",
    },
    [50672] = {
        name = "Não tem munição, caça com naga",
    },
    [50674] = {
        name = "Piratinha ordinário de duas caras",
    },
    [50675] = {
        name = "Caçada ao tesouro",
    },
    [50679] = {
        name = "Atravessando a barreira",
    },
    [50690] = {
        name = "[UNUSED]",
    },
    [50691] = {
        name = "Fora da folha de pagamento",
    },
    [50696] = {
        name = "Diversão magnética",
    },
    [50697] = {
        name = "Bomba ganha de pedra",
    },
    [50698] = {
        name = "Método Pólvora de resolução de problemas",
    },
    [50699] = {
        name = "Direitos trabalhistas",
    },
    [50700] = {
        name = "Uma situação drústica",
    },
    [50702] = {
        name = "Derrote Jakra'zet",
    },
    [50703] = {
        name = "Informe à Horda",
    },
    [50704] = {
        name = "Reaproveitamento total",
    },
    [50705] = {
        name = "As três cabeças da sérpera",
    },
    [50706] = {
        name = "Abrindo o delta",
    },
    [50733] = {
        name = "Um novo amanhecer",
    },
    [50739] = {
        name = "Desaparecidos",
    },
    [50741] = {
        name = "Deixe de tortollice",
    },
    [50742] = {
        name = "Tudo no esquema",
    },
    [50743] = {
        name = "O problema imediato",
    },
    [50745] = {
        name = "Infiltrando-se no império",
    },
    [50746] = {
        name = "Cratera conquistada",
    },
    [50748] = {
        name = "Não solte... ainda",
    },
    [50749] = {
        name = "Viagem grátis",
    },
    [50750] = {
        name = "Imperador de pavio curto",
    },
    [50751] = {
        name = "Santuário sob cerco",
    },
    [50752] = {
        name = "Relíquias de Sethraliss",
    },
    [50753] = {
        name = "Quem não tem cão, caça com Uolly",
    },
    [50754] = {
        name = "Amores vêm e vão",
    },
    [50755] = {
        name = "Comida de pássaro",
    },
    [50757] = {
        name = "Massacre indomado",
    },
    [50758] = {
        name = "Lembranças dolorosas",
    },
    [50759] = {
        name = "Atrasando-se",
    },
    [50760] = {
        name = "Deste dia em diante",
    },
    [50761] = {
        name = "Sangue na Capela",
    },
    [50762] = {
        name = "O destino da dama",
    },
    [50763] = {
        name = "Um último pedido",
    },
    [50769] = {
        name = "A extração de Ventobravo",
    },
    [50770] = {
        name = "Antídoto eficaz",
    },
    [50771] = {
        name = "Convoca-se limpadores",
    },
    [50773] = {
        name = "Hora do tubarão",
    },
    [50774] = {
        name = "Onde está Uolly",
    },
    [50775] = {
        name = "Queremos sol, areia e mar",
    },
    [50777] = {
        name = "A tempestade acorda",
    },
    [50778] = {
        name = "Intenções perversas",
    },
    [50779] = {
        name = "Quadro em branco",
    },
    [50780] = {
        name = "Sob juramento",
    },
    [50781] = {
        name = "A uma ponte de distância",
    },
    [50783] = {
        name = "O Conselho Abissal",
    },
    [50784] = {
        name = "Olho da Tormenta",
    },
    [50787] = {
        name = "Evidências reveladas",
    },
    [50788] = {
        name = "Inimigos íntimos",
    },
    [50789] = {
        name = "Purificando o ambiente",
    },
    [50790] = {
        name = "Perseguição implacável",
    },
    [50791] = {
        name = "Scriii...",
    },
    [50793] = {
        name = "Comoção na caverna",
    },
    [50794] = {
        name = "Atrás de abrigo",
    },
    [50795] = {
        name = "Prepare-se para enfrentar o problema",
    },
    [50796] = {
        name = "SCRIIIIIIIII!",
    },
    [50797] = {
        name = "Sopa no casco da tartaruga",
    },
    [50798] = {
        name = "No limbo",
    },
    [50801] = {
        name = "Pterencrenca",
    },
    [50802] = {
        name = "Maré-ferrada",
    },
    [50803] = {
        name = "Eu quero tudo agora",
    },
    [50805] = {
        name = "Clamacéus em calamidade",
    },
    [50808] = {
        name = "Interrompendo a queda do império",
    },
    [50810] = {
        name = "Liberdade para os trabalhadores",
    },
    [50812] = {
        name = "Elementos despertados",
    },
    [50814] = {
        name = "Um lugar horrível",
    },
    [50817] = {
        name = "Caudinha encantadora",
    },
    [50818] = {
        name = "Flauta perdida",
    },
    [50824] = {
        name = "Fim da tempestade",
    },
    [50825] = {
        name = "Santuário da Tempestade: sussurros abaixo",
    },
    [50834] = {
        name = "Maneirem no barulho!",
    },
    [50835] = {
        name = "O Porto de Zandalar",
    },
    [50838] = {
        name = "Pterencrenca",
    },
    [50839] = {
        name = "SCRIIIIIIIII!",
    },
    [50841] = {
        name = "SCRIIIIIIIII!",
    },
    [50842] = {
        name = "Efeito em massa",
    },
    [50860] = {
        name = "Pterencrenca",
    },
    [50881] = {
        name = "Relatório real",
    },
    [50886] = {
        name = "Prótasas",
    },
    [50887] = {
        name = "Pipaterrordax",
    },
    [50897] = {
        name = "Fogo que esquenta cá queima lá",
    },
    [50900] = {
        name = "Quem sabe quando você tiver idade...",
    },
    [50901] = {
        name = "Surpresa saurídea",
    },
    [50903] = {
        name = "Mestre sumido",
    },
    [50904] = {
        name = "A passagem abandonada",
    },
    [50908] = {
        name = "Cheiro de problema",
    },
    [50909] = {
        name = "Desprevenidos, jamais",
    },
    [50910] = {
        name = "Um jogo perigoso",
    },
    [50911] = {
        name = "Um contra a Horda",
    },
    [50912] = {
        name = "Ignição por fusão",
    },
    [50913] = {
        name = "Bênção de Akunda",
    },
    [50929] = {
        name = "Povo em polvorosa",
    },
    [50930] = {
        name = "Caindo com estilo",
    },
    [50933] = {
        name = "Um evento lamentável",
    },
    [50934] = {
        name = "Avistamento fortuito",
    },
    [50940] = {
        name = "Sabedoria dos sem-asa",
    },
    [50942] = {
        name = "Proteção nunca é demais",
    },
    [50943] = {
        name = "O prazer de voar",
    },
    [50944] = {
        name = "Pé no chão, mas cabeça erguida",
    },
    [50953] = {
        name = "Espreitaverde",
    },
    [50954] = {
        name = "Zandalar para sempre!",
    },
    [50955] = {
        name = "Amigos uma ova",
    },
    [50956] = {
        name = "Pagamento adiantado",
    },
    [50959] = {
        name = "Piratas pilhadores",
    },
    [50960] = {
        name = "As ordens do Mel",
    },
    [50963] = {
        name = "Dias sombrios, feitos sombrios",
    },
    [50965] = {
        name = "O que resta",
    },
    [50967] = {
        name = "Perdida no bosque",
    },
    [50970] = {
        name = "O destino do fazendeiro",
    },
    [50972] = {
        name = "A oferta de Proudmore",
    },
    [50976] = {
        name = "Maldição ancestral",
    },
    [50978] = {
        name = "Um cai, outro entra no lugar",
    },
    [50979] = {
        name = "Gel de atrivax",
    },
    [50980] = {
        name = "Um vizinho esfomeado",
    },
    [50988] = {
        name = "Uma oportunidade econômica",
    },
    [50990] = {
        name = "Avicultura de vanguarda",
    },
    [51001] = {
        name = "Muambar, muambei",
    },
    [51018] = {
        name = "Um amigo que pediu",
    },
    [51019] = {
        name = "Na hora do vamos ver, ela não faz feio",
    },
    [51020] = {
        name = "Práticas comerciais agressivas",
    },
    [51052] = {
        name = "Azerita para a Aliança!",
    },
    [51053] = {
        name = "O dia em que o porto foi morto",
    },
    [51054] = {
        name = "Motim tardio",
    },
    [51055] = {
        name = "Castigo de pirata",
    },
    [51056] = {
        name = "Meu último suspiro",
    },
    [51057] = {
        name = "Ilhados pelo fogaréu",
    },
    [51059] = {
        name = "A Ilha Dourada",
    },
    [51060] = {
        name = "Nosso quinhão do saque",
    },
    [51061] = {
        name = "A primeira vez que morri",
    },
    [51062] = {
        name = "Fugindo de Zem'lan",
    },
    [51069] = {
        name = "PROCURA-SE: Orador Sombrio Jo'la",
    },
    [51071] = {
        name = "PROCURA-SE: Imperatriz Sabretusco",
    },
    [51072] = {
        name = "PROCURA-SE: Esmurrento Primordial",
    },
    [51085] = {
        name = "PROCURA-SE: Cronista das Trevas",
    },
    [51087] = {
        name = "PROCURA-SE: Cronista das Trevas",
    },
    [51088] = {
        name = "Coração das trevas",
    },
    [51089] = {
        name = "PROCURA-SE: Tojek",
    },
    [51091] = {
        name = "PROCURA-SE: Ten'gor e Nol'ixwan",
    },
    [51101] = {
        name = "Fera ferida",
    },
    [51111] = {
        name = "Ou rei, ou subjugado",
    },
    [51129] = {
        name = "Oferenda duvidosa",
    },
    [51134] = {
        name = "Se ossadas falassem...",
    },
    [51139] = {
        name = "PROCURA-SE: Tojek",
    },
    [51140] = {
        name = "Riqueza repartida",
    },
    [51142] = {
        name = "Pestes",
    },
    [51144] = {
        name = "Uma trouxa de peles",
    },
    [51145] = {
        name = "Maldição de Jani",
    },
    [51146] = {
        name = "O dia de folga do Kua'fon",
    },
    [51147] = {
        name = "O dia de folga do Kua'fon",
    },
    [51149] = {
        name = "Ih, ficou no porto!",
    },
    [51150] = {
        name = "Em honra aos caídos",
    },
    [51151] = {
        name = "Carta à Liga",
    },
    [51159] = {
        name = "Hora do canhãozão",
    },
    [51161] = {
        name = "PROCURA-SE: Za'roco",
    },
    [51162] = {
        name = "PROCURA-SE: Taz'raka, o Traidor",
    },
    [51164] = {
        name = "PROCURAM-SE: participantes para a excursão da naja",
    },
    [51165] = {
        name = "PROCURA-SE: Batedor de Areia Vesarik",
    },
    [51167] = {
        name = "Sangue de Hir'eek",
    },
    [51168] = {
        name = "Zelotes de Zalamar",
    },
    [51169] = {
        name = "Voo da queda",
    },
    [51170] = {
        name = "Uuurrááá!",
    },
    [51177] = {
        name = "Lições dos condenados",
    },
    [51190] = {
        name = "Ganhando tempo",
    },
    [51191] = {
        name = "Salve a todos",
    },
    [51192] = {
        name = "Falta de suprimentos",
    },
    [51193] = {
        name = "Isso é meu",
    },
    [51199] = {
        name = "A glória da caçada",
    },
    [51200] = {
        name = "A ovelha negra",
    },
    [51201] = {
        name = "O conto do troll",
    },
    [51203] = {
        name = "Alarme de lobo",
    },
    [51204] = {
        name = "PROCURA-SE: Alfa Garraguda",
    },
    [51205] = {
        name = "Ahh, qual é!",
    },
    [51207] = {
        name = "Gorjala é comigo",
    },
    [51208] = {
        name = "Um minutinho trigonometrado",
    },
    [51209] = {
        name = "O poderoso Mão-de-grok",
    },
    [51211] = {
        name = "O Coração de Azeroth",
    },
    [51214] = {
        name = "Um amor de pessoa",
    },
    [51215] = {
        name = "A ordenha das cabras",
    },
    [51217] = {
        name = "PROCURA-SE: Yarsel'ghun",
    },
    [51218] = {
        name = "Nova tentativa de entrega",
    },
    [51220] = {
        name = "Empreendimento no mar profundo",
    },
    [51221] = {
        name = "Reação obrigatória",
    },
    [51222] = {
        name = "A mina da hora!",
    },
    [51224] = {
        name = "Lucro e reconhecimento",
    },
    [51226] = {
        name = "Morte de todos os lados",
    },
    [51229] = {
        name = "Estabeleça uma cabeça de ponte.",
    },
    [51231] = {
        name = "Wiccanofobia",
    },
    [51233] = {
        name = "Espero que não tenha bruxas nas montanhas...",
    },
    [51234] = {
        name = "Posto Torquetrena",
    },
    [51240] = {
        name = "PROCURA-SE: Ancorote",
    },
    [51244] = {
        name = "A podridão inferior",
    },
    [51246] = {
        name = "Naufragicídio",
    },
    [51247] = {
        name = "A bagagem que carregam",
    },
    [51248] = {
        name = "Pestes produtivas",
    },
    [51249] = {
        name = "Banquete praiano",
    },
    [51251] = {
        name = "Os moradores do porão",
    },
    [51278] = {
        name = "Perdidos e esquecidos",
    },
    [51279] = {
        name = "Sectários Nazmani",
    },
    [51280] = {
        name = "Oferendas para G'huun",
    },
    [51282] = {
        name = "Capitã Conrado",
    },
    [51283] = {
        name = "Viagem ao Oeste",
    },
    [51286] = {
        name = "Interromper a evacuação",
    },
    [51302] = {
        name = "A Terra Podre: contendo a corrupção de G'huun",
    },
    [51308] = {
        name = "Base Zuldazar",
    },
    [51309] = {
        name = "Rochas de Ragnaros",
    },
    [51310] = {
        name = "Caçadores da safra perdida",
    },
    [51314] = {
        name = "Grão-grãos",
    },
    [51319] = {
        name = "Escalada final",
    },
    [51320] = {
        name = "Destino selado",
    },
    [51331] = {
        name = "Maquinações touperísticas",
    },
    [51332] = {
        name = "Uma jornada além-mar",
    },
    [51335] = {
        name = "Sabor crocante",
    },
    [51339] = {
        name = "Maçaricos limpinhos",
    },
    [51340] = {
        name = "Drustvar a vista!",
    },
    [51341] = {
        name = "Filha do mar",
    },
    [51342] = {
        name = "Batalha por Stromgarde",
    },
    [51343] = {
        name = "Aula de natação",
    },
    [51349] = {
        name = "Questão de honra",
    },
    [51350] = {
        name = "Auxílio inesperado",
    },
    [51351] = {
        name = "Aguilhões peçonhentos",
    },
    [51352] = {
        name = "Quem brinca com fogo...",
    },
    [51353] = {
        name = "Caverna de Ai'twen",
    },
    [51354] = {
        name = "[Anger in a Bottle]",
    },
    [51356] = {
        name = "PROCURA-SE: Irmã Lílias",
    },
    [51357] = {
        name = "Armada e perigosa",
    },
    [51358] = {
        name = "PROCURA-SE: Sequestradores de Grifos",
    },
    [51359] = {
        name = "Fragmento das Terras do Fogo",
    },
    [51364] = {
        name = "Uma saída explosiva",
    },
    [51366] = {
        name = "Aplicação de antídoto",
    },
    [51367] = {
        name = "PROCURA-SE: Terraguarda Enraivecido",
    },
    [51368] = {
        name = "PROCURA-SE: o Marimbondo",
    },
    [51369] = {
        name = "Amigos em lugares estranhos",
    },
    [51370] = {
        name = "Recompensa rara",
    },
    [51371] = {
        name = "Oferenda saborosa",
    },
    [51384] = {
        name = "PROCURA-SE: Intendente Ssylis",
    },
    [51386] = {
        name = "Vitoria em batalha",
    },
    [51389] = {
        name = "Libertação",
    },
    [51390] = {
        name = "PROCURA-SE: Os Degoladores Carmesim",
    },
    [51391] = {
        name = "Enfraquecendo os Ímpios",
    },
    [51394] = {
        name = "Rompa o cerco",
    },
    [51395] = {
        name = "Chaves dos Guardiões",
    },
    [51401] = {
        name = "Siga em frente",
    },
    [51402] = {
        name = "Relatório em três vias",
    },
    [51403] = {
        name = "Imperativo do mensageiro",
    },
    [51407] = {
        name = "Encontre as palavras deles",
    },
    [51421] = {
        name = "Tartarugas me levem",
    },
    [51425] = {
        name = "Não há lugar como o lar",
    },
    [51426] = {
        name = "Geringonça de inspeção",
    },
    [51427] = {
        name = "Eu gosto de tartarugas",
    },
    [51430] = {
        name = "Improvisação reversa",
    },
    [51435] = {
        name = "Estilo espadachinesco",
    },
    [51436] = {
        name = "Papeando com piratas",
    },
    [51437] = {
        name = "Estragação do goró",
    },
    [51438] = {
        name = "Marcando nosso território",
    },
    [51439] = {
        name = "Coleção de bala de canhão",
    },
    [51440] = {
        name = "Mudança de direção",
    },
    [51441] = {
        name = "Lá vai ela!",
    },
    [51442] = {
        name = "Agora o capitão sou eu",
    },
    [51443] = {
        name = "Instrução de missão",
    },
    [51445] = {
        name = "Thros, a Terra Morta",
    },
    [51465] = {
        name = "Um monte de sucata",
    },
    [51472] = {
        name = "Salva-vidas",
    },
    [51474] = {
        name = "Forjado a ferro e fogo",
    },
    [51479] = {
        name = "Os impolutos",
    },
    [51483] = {
        name = "Herança do clã Ferro Negro",
    },
    [51484] = {
        name = "Tradição dos Mag'har",
    },
    [51485] = {
        name = "Pela Horda",
    },
    [51486] = {
        name = "Pela Aliança",
    },
    [51487] = {
        name = "Em busca de respostas",
    },
    [51488] = {
        name = "Conhecimento arquivado",
    },
    [51489] = {
        name = "Hora de partir",
    },
    [51490] = {
        name = "Problemas de fronteira",
    },
    [51492] = {
        name = "O plano da pólvora",
    },
    [51504] = {
        name = "Entrega de biscoitos",
    },
    [51513] = {
        name = "O retorno de Zalazane",
    },
    [51514] = {
        name = "Barganha rompida",
    },
    [51515] = {
        name = "Vingança por Vol'jin",
    },
    [51516] = {
        name = "Atal'Dazar: Cinzas de um Chefe Guerreiro",
    },
    [51517] = {
        name = "Você me deve um espírito",
    },
    [51518] = {
        name = "O espírito perdido",
    },
    [51519] = {
        name = "Chamado espiritual",
    },
    [51520] = {
        name = "Justiça pelos caídos",
    },
    [51521] = {
        name = "A verdadeira líder de Zandalar",
    },
    [51526] = {
        name = "O chamado do Senhor da Guerra",
    },
    [51532] = {
        name = "Invasão",
    },
    [51533] = {
        name = "A glaive de Vol'jin",
    },
    [51534] = {
        name = "A batalha por Brennadam",
    },
    [51536] = {
        name = "À caçada",
    },
    [51538] = {
        name = "Palavras das profundezas",
    },
    [51539] = {
        name = "Informe a Horda!",
    },
    [51540] = {
        name = "Situação explosiva",
    },
    [51543] = {
        name = "Brotos na neve",
    },
    [51544] = {
        name = "Desarmando os canhões",
    },
    [51545] = {
        name = "Ou vai ou racha",
    },
    [51547] = {
        name = "PROCURA-SE: Corgossombroso",
    },
    [51552] = {
        name = "Os dias estão todos ocupados",
    },
    [51554] = {
        name = "Recarregando",
    },
    [51555] = {
        name = "Apelou, perdeu",
    },
    [51557] = {
        name = "O aviso da Maré-férrea",
    },
    [51569] = {
        name = "A campanha de Zandalar",
    },
    [51573] = {
        name = "Eu dou cobertura",
    },
    [51574] = {
        name = "Suco fresquinho",
    },
    [51582] = {
        name = "Que seja Mildião",
    },
    [51587] = {
        name = "Avante!",
    },
    [51589] = {
        name = "Acabe com o moral dos kultirenos",
    },
    [51590] = {
        name = "No coração de Tiragarde",
    },
    [51591] = {
        name = "Nossa montanha agora",
    },
    [51592] = {
        name = "Conforto nunca é demais",
    },
    [51593] = {
        name = "Investigação em Porto da Ponte",
    },
    [51594] = {
        name = "Explosivos na fundição",
    },
    [51595] = {
        name = "Explosividade",
    },
    [51596] = {
        name = "Aquisição de munição",
    },
    [51597] = {
        name = "Pesquisa de pólvora",
    },
    [51598] = {
        name = "Um pouquinho de caos",
    },
    [51599] = {
        name = "Armadilha mortal",
    },
    [51601] = {
        name = "A rota de Porto da Ponte",
    },
    [51602] = {
        name = "Lâminas de bandidos",
    },
    [51643] = {
        name = "O muro de ferro",
    },
    [51663] = {
        name = "Preparativos para a queda",
    },
    [51674] = {
        name = "Apagando as chamas",
    },
    [51675] = {
        name = "A caçada",
    },
    [51677] = {
        name = "Remédio para corpo e alma",
    },
    [51678] = {
        name = "Força de Rastakhan",
    },
    [51679] = {
        name = "Um estranho porto de escala",
    },
    [51680] = {
        name = "À sombra de Bwonsamdi",
    },
    [51689] = {
        name = "Resgatando tortollanos",
    },
    [51691] = {
        name = "Até que vale a pena salvar",
    },
    [51696] = {
        name = "Reivindicar o que é nosso",
    },
    [51711] = {
        name = "Um estouro",
    },
    [51712] = {
        name = "Olho por olho",
    },
    [51714] = {
        name = "Uma missão do rei",
    },
    [51715] = {
        name = "A guerra das sombras",
    },
    [51717] = {
        name = "O melhor mel de Vol'dun",
    },
    [51718] = {
        name = "Colhendo \"mel\"",
    },
    [51720] = {
        name = "Retalhador de segunda mão",
    },
    [51723] = {
        name = "Com pó de serra",
    },
    [51726] = {
        name = "Saia daqui!",
    },
    [51728] = {
        name = "Bota fogo",
    },
    [51752] = {
        name = "Grisalho",
    },
    [51753] = {
        name = "Campeão: Rexxar",
    },
    [51770] = {
        name = "Uma missão da Chefe Guerreira",
    },
    [51771] = {
        name = "A guerra das sombras",
    },
    [51772] = {
        name = "A tribo Tortaka",
    },
    [51773] = {
        name = "A ameaça dos Grimpagris",
    },
    [51775] = {
        name = "Acampamento Ventadoiro",
    },
    [51784] = {
        name = "Um passeio pelo cemitério",
    },
    [51785] = {
        name = "Examinando epitáfios",
    },
    [51786] = {
        name = "Um espírito inquieto",
    },
    [51787] = {
        name = "A parte que nos cabe",
    },
    [51788] = {
        name = "O guardião da cripta",
    },
    [51789] = {
        name = "Os restos mortais do Marechal M. Valentim",
    },
    [51795] = {
        name = "A Batalha por Lordaeron",
    },
    [51796] = {
        name = "A Batalha por Lordaeron",
    },
    [51797] = {
        name = "No rastro dos sábios das marés",
    },
    [51798] = {
        name = "Nenhum preço é alto demais",
    },
    [51803] = {
        name = "A campanha de Kul Tiraz",
    },
    [51805] = {
        name = "Eles vão descobrir o medo",
    },
    [51810] = {
        name = "Capitão Hartford",
    },
    [51813] = {
        name = "Abismo Rocha Negra",
    },
    [51818] = {
        name = "O comandante e a capitã",
    },
    [51819] = {
        name = "Espalhando os inimigos",
    },
    [51829] = {
        name = "A chave de Ranah",
    },
    [51830] = {
        name = "O potencial de Zelão",
    },
    [51837] = {
        name = "Que será, será",
    },
    [51870] = {
        name = "Expedição Insular",
    },
    [51881] = {
        name = "O detector de minas",
    },
    [51888] = {
        name = "Expedição insular",
    },
    [51903] = {
        name = "Expedição insular",
    },
    [51904] = {
        name = "Expedição insular",
    },
    [51916] = {
        name = "A unificação de Zandalar",
    },
    [51918] = {
        name = "A unificação de Kul Tiraz",
    },
    [51961] = {
        name = "Campanha em andamento",
    },
    [51967] = {
        name = "Retorno a Boralus",
    },
    [51968] = {
        name = "Retorno a Boralus",
    },
    [51969] = {
        name = "Retorno a Boralus",
    },
    [51975] = {
        name = "Campeão: Caçador Sombrio Ty'jin",
    },
    [51979] = {
        name = "Campanha em andamento",
    },
    [51980] = {
        name = "PROCURA-SE: Jabra'kan",
    },
    [51984] = {
        name = "Retorno a Zuldazar",
    },
    [51985] = {
        name = "Retorno a Zuldazar",
    },
    [51986] = {
        name = "Retorno a Zuldazar",
    },
    [51987] = {
        name = "Campeão: Roberto Agarramalho",
    },
    [51990] = {
        name = "Asas para o Kraal",
    },
    [51991] = {
        name = "Carregando as baterias",
    },
    [51998] = {
        name = "HCE: Agora com escornantes de verdade",
    },
    [52003] = {
        name = "Campeã: Kelsey Fagulhaço",
    },
    [52008] = {
        name = "Campeão: Magíster Umbric",
    },
    [52013] = {
        name = "Campeão: John J. Keeshan",
    },
    [52026] = {
        name = "Assassinato no além-mar",
    },
    [52027] = {
        name = "O plano para Vol'dun",
    },
    [52028] = {
        name = "Pente-fino no deserto",
    },
    [52029] = {
        name = "Trabalho sujo",
    },
    [52030] = {
        name = "O pente-fino continua",
    },
    [52031] = {
        name = "Relicário clássico",
    },
    [52032] = {
        name = "O pente-fino nunca termina",
    },
    [52033] = {
        name = "PROCURA-SE: A Caçadora da Geada",
    },
    [52034] = {
        name = "Uma mensagem para os Zandalari",
    },
    [52035] = {
        name = "Sobrevivência improvisada",
    },
    [52036] = {
        name = "Alpacas na área",
    },
    [52038] = {
        name = "Separação",
    },
    [52039] = {
        name = "Morticínio postergado",
    },
    [52040] = {
        name = "Crivado de flechas",
    },
    [52041] = {
        name = "Relatório a Serpecida",
    },
    [52042] = {
        name = "O grande bum",
    },
    [52061] = {
        name = "Odrogtap, o porco!",
    },
    [52065] = {
        name = "Pior do que parece",
    },
    [52067] = {
        name = "Sobreviventes",
    },
    [52068] = {
        name = "Uma ajuda em outro lugar",
    },
    [52069] = {
        name = "Mais buchas de canhão",
    },
    [52070] = {
        name = "Reforço para Hauer",
    },
    [52073] = {
        name = "Um pedido a Krag'wa",
    },
    [52074] = {
        name = "Entrega prioritária",
    },
    [52075] = {
        name = "Desossadas",
    },
    [52113] = {
        name = "Vol'jin, filho de Sen'jin",
    },
    [52114] = {
        name = "Honrarias para um verdadeiro líder",
    },
    [52122] = {
        name = "Ser um renegado",
    },
    [52127] = {
        name = "O Covil do Lobo",
    },
    [52128] = {
        name = "Passe de Balsa",
    },
    [52129] = {
        name = "Problema de energia",
    },
    [52130] = {
        name = "Baú Mortífero: Carpe Diem",
    },
    [52131] = {
        name = "Precisamos um do outro",
    },
    [52132] = {
        name = "A prova da pirataria",
    },
    [52139] = {
        name = "Ao que importa",
    },
    [52146] = {
        name = "Sangue na areia",
    },
    [52147] = {
        name = "Debilitando a Horda",
    },
    [52149] = {
        name = "Queima perene",
    },
    [52150] = {
        name = "Como matar uma patrulheira sombria",
    },
    [52151] = {
        name = "Uma nação unida",
    },
    [52153] = {
        name = "Cerco de Boralus: Retorno da Lady Grimpagris",
    },
    [52154] = {
        name = "Nosso próximo alvo",
    },
    [52156] = {
        name = "Tortollanos em perigo",
    },
    [52158] = {
        name = "A caçada selvagem",
    },
    [52170] = {
        name = "O fim de Areiel",
    },
    [52171] = {
        name = "Uma opção: fogo",
    },
    [52172] = {
        name = "Aqui, eles não ficam",
    },
    [52173] = {
        name = "Os elfos caóticos estão prontos",
    },
    [52183] = {
        name = "Um plano se forma",
    },
    [52184] = {
        name = "Relíquias de ritual",
    },
    [52185] = {
        name = "Um portal estratégico",
    },
    [52186] = {
        name = "Abrindo a guarda",
    },
    [52187] = {
        name = "Velhos amigos",
    },
    [52188] = {
        name = "Ensinamentos de sábio das marés",
    },
    [52189] = {
        name = "Confisco das almas",
    },
    [52190] = {
        name = "Saindo na vantagem",
    },
    [52191] = {
        name = "A vida como refém",
    },
    [52192] = {
        name = "A ajuda das marés",
    },
    [52194] = {
        name = "Um arrependimento",
    },
    [52203] = {
        name = "Atrás do rastro de papel",
    },
    [52204] = {
        name = "A solução caótica",
    },
    [52205] = {
        name = "Fim da farra dos Borraquilha",
    },
    [52208] = {
        name = "Encontro dos cabeças",
    },
    [52210] = {
        name = "Enviando um S.O.S.",
    },
    [52212] = {
        name = "Batalha por Stromgarde",
    },
    [52219] = {
        name = "Alvo: Príncipe de Sangue Dreven",
    },
    [52241] = {
        name = "O paraíso de um goblin ganancioso",
    },
    [52246] = {
        name = "Carregamento perdido",
    },
    [52247] = {
        name = "No encalço de Gallywix",
    },
    [52252] = {
        name = "Uma entrada explosiva",
    },
    [52253] = {
        name = "As chaves do sucesso na Angra do Facão",
    },
    [52258] = {
        name = "Chão cheio de conchas da maré cheia",
    },
    [52259] = {
        name = "Não estou me divertindo",
    },
    [52260] = {
        name = "Ele está encurralado",
    },
    [52261] = {
        name = "Gallywix se safou",
    },
    [52281] = {
        name = "Sob o abrigo de Asinha",
    },
    [52282] = {
        name = "Como afundar uma nau de batalha Zandalari",
    },
    [52283] = {
        name = "Sabotagem do Pa'kul",
    },
    [52284] = {
        name = "Registros navais",
    },
    [52285] = {
        name = "O submarino miniaturizado desminiaturizado",
    },
    [52286] = {
        name = "Bem debaixo do nariz deles",
    },
    [52287] = {
        name = "Negação de inteligência",
    },
    [52288] = {
        name = "Férias no caos",
    },
    [52289] = {
        name = "A vitória está assegurada",
    },
    [52290] = {
        name = "O inimigo do meu inimigo é o meu disfarce",
    },
    [52291] = {
        name = "A vitória estava assegurada",
    },
    [52294] = {
        name = "Ídolos caídos",
    },
    [52305] = {
        name = "Natureza versus criação",
    },
    [52308] = {
        name = "Ordens interceptadas",
    },
    [52311] = {
        name = "A caixa-forte do Arlão",
    },
    [52317] = {
        name = "Não ptira, só joga",
    },
    [52428] = {
        name = "Infusão do Coração",
    },
    [52431] = {
        name = "Zona de pouso proibido",
    },
    [52443] = {
        name = "A cabeça de ponte final",
    },
    [52444] = {
        name = "A cabeça de ponte final",
    },
    [52445] = {
        name = "Tol Dagor: A quarta chave",
    },
    [52447] = {
        name = "Espaço para crescer",
    },
    [52449] = {
        name = "A ilha misteriosa",
    },
    [52450] = {
        name = "A unificação de Kul Tiraz",
    },
    [52453] = {
        name = "Uma esperança abandonada",
    },
    [52472] = {
        name = "Vai logo, Loh",
    },
    [52473] = {
        name = "Naufrágio da frota",
    },
    [52477] = {
        name = "PROCURA-SE: Ayame",
    },
    [52480] = {
        name = "PROCURA-SE: Ayame",
    },
    [52481] = {
        name = "Mitos e fábulas",
    },
    [52482] = {
        name = "O urso velho",
    },
    [52483] = {
        name = "Apanhador de pesadelos",
    },
    [52484] = {
        name = "Poder enterrado",
    },
    [52485] = {
        name = "Foco do ódio",
    },
    [52486] = {
        name = "Mansão Capelo: drenando o sangra-coração",
    },
    [52487] = {
        name = "Às trevas",
    },
    [52488] = {
        name = "Resistência rúnica",
    },
    [52489] = {
        name = "Caça ao Príncipe de Sangue Dreven",
    },
    [52490] = {
        name = "Atrás dos barcos inimigos",
    },
    [52491] = {
        name = "Canhonada Caótica",
    },
    [52492] = {
        name = "A especialidade do Martelo Feroz",
    },
    [52493] = {
        name = "Tripulação sobrenatural",
    },
    [52494] = {
        name = "Cristais horrendos para gente horrenda",
    },
    [52495] = {
        name = "O fim da ameaça San'layn",
    },
    [52496] = {
        name = "Fuga Limpa",
    },
    [52508] = {
        name = "Paramentos ritualísticos",
    },
    [52509] = {
        name = "A Força da Tempestade",
    },
    [52510] = {
        name = "Santuário da Tempestade: o Ritual Ausente",
    },
    [52511] = {
        name = "Abrindo caminho",
    },
    [52512] = {
        name = "Fim do Destino",
    },
    [52513] = {
        name = "Perdida nas trevas",
    },
    [52544] = {
        name = "O estoque de guerra",
    },
    [52654] = {
        name = "A Campanha de Guerra",
    },
    [52746] = {
        name = "O estoque de guerra",
    },
    [52748] = {
        name = "Olhos nos céus",
    },
    [52749] = {
        name = "A Campanha de Guerra",
    },
    [52750] = {
        name = "Ferozes fazendeiros",
    },
    [52762] = {
        name = "Um guia nativo",
    },
    [52764] = {
        name = "Jornada ao meio do nada",
    },
    [52765] = {
        name = "Mergulho profundo",
    },
    [52766] = {
        name = "Naufrágio no leito marinho",
    },
    [52767] = {
        name = "Verificação de placas de identificação",
    },
    [52768] = {
        name = "O cemitério submerso",
    },
    [52769] = {
        name = "Capitão por capitão",
    },
    [52770] = {
        name = "Bioaborrecência",
    },
    [52772] = {
        name = "A plataforma submarina",
    },
    [52773] = {
        name = "Dragão aquático",
    },
    [52774] = {
        name = "Pega-e-foge",
    },
    [52782] = {
        name = "Chamado às armas: Vale Trovamare",
    },
    [52787] = {
        name = "Alívio da dor",
    },
    [52788] = {
        name = "Não deixe sobreviventes",
    },
    [52789] = {
        name = "Silenciando a conselheira",
    },
    [52790] = {
        name = "Um fim para a matança",
    },
    [52793] = {
        name = "Jornada insegura",
    },
    [52795] = {
        name = "Uma questão azeda",
    },
    [52796] = {
        name = "Às vezes, menos é mais",
    },
    [52800] = {
        name = "Tol Dagor: o Feitor Grimpagris",
    },
    [52855] = {
        name = "Alquimia é uma ciência inexata",
    },
    [52857] = {
        name = "Posto sob observação",
    },
    [52861] = {
        name = "Campeã: Lilian Voss",
    },
    [52876] = {
        name = "PROCURA-SE: Horror da Guerra",
    },
    [52942] = {
        name = "Recuperando velhos vínculos",
    },
    [52943] = {
        name = "Convocando os clãs",
    },
    [52944] = {
        name = "Chamado às armas: Drustvar",
    },
    [52945] = {
        name = "Vínculos forjados em combate",
    },
    [52946] = {
        name = "Um mundo moribundo",
    },
    [52948] = {
        name = "Chamado às armas: Estreito Tiragarde",
    },
    [52949] = {
        name = "Chamado às Armas: Nazmir",
    },
    [52950] = {
        name = "Chamado às Armas: Vol'dun",
    },
    [52953] = {
        name = "Chamado às Armas: Vol'dun",
    },
    [52954] = {
        name = "Chamado às Armas: Nazmir",
    },
    [52955] = {
        name = "Tirania da Luz",
    },
    [52956] = {
        name = "Chamado às armas: Estreito Tiragarde",
    },
    [52958] = {
        name = "Chamado às armas: Drustvar",
    },
    [52965] = {
        name = "Um presente de Véu de Inverno",
    },
    [52978] = {
        name = "Um príncipe no porão",
    },
    [52990] = {
        name = "Retorno ao porto",
    },
    [53003] = {
        name = "Ciclo de ódio",
    },
    [53011] = {
        name = "Um presente chacoalhado gentilmente",
    },
    [53028] = {
        name = "Um mundo moribundo",
    },
    [53031] = {
        name = "Imperativo do Mensageiro",
    },
    [53041] = {
        name = "Amostra da mercadoria",
    },
    [53045] = {
        name = "Verificação do cais",
    },
    [53050] = {
        name = "Mais fundo em Kul Tiraz",
    },
    [53052] = {
        name = "Mais fundo em Zandalar",
    },
    [53055] = {
        name = "Expansão de influência",
    },
    [53056] = {
        name = "Expansão de influência",
    },
    [53061] = {
        name = "A vantagem azerítica",
    },
    [53062] = {
        name = "A vantagem azerítica",
    },
    [53063] = {
        name = "Uma missão de unidade",
    },
    [53065] = {
        name = "Operação: Coveiro",
    },
    [53066] = {
        name = "Operação: Sabedoria Aquática",
    },
    [53067] = {
        name = "Operação: Come-lodo",
    },
    [53068] = {
        name = "Operação: anzol e linha",
    },
    [53069] = {
        name = "Operação: Flecha Sangrenta",
    },
    [53070] = {
        name = "Operação: Punguista",
    },
    [53071] = {
        name = "Operação: Garra do Grifo",
    },
    [53072] = {
        name = "Operação: Golpe no Coração",
    },
    [53074] = {
        name = "Reforços",
    },
    [53079] = {
        name = "Reforços",
    },
    [53096] = {
        name = "Recompensa rara",
    },
    [53097] = {
        name = "Abluções desesperadas",
    },
    [53098] = {
        name = "Campeã: Shandris Plumaluna",
    },
    [53099] = {
        name = "Uma partícula da verdade cósmica",
    },
    [53105] = {
        name = "Fé descabida",
    },
    [53109] = {
        name = "Casa Capelo",
    },
    [53110] = {
        name = "O Grande Voz-dos-espinhos",
    },
    [53121] = {
        name = "Cerco de Boralus",
    },
    [53128] = {
        name = "O lamento do Lorde-almirante",
    },
    [53131] = {
        name = "O Repouso do Rei",
    },
    [53185] = {
        name = "Contribuição para o Front de Guerra",
    },
    [53194] = {
        name = "Para o Front",
    },
    [53197] = {
        name = "Tour de front",
    },
    [53198] = {
        name = "De volta a Boralus",
    },
    [53208] = {
        name = "Para o Front",
    },
    [53209] = {
        name = "Contribuição para o Front de Guerra",
    },
    [53210] = {
        name = "Tour de front",
    },
    [53212] = {
        name = "De volta a Zuldazar",
    },
    [53330] = {
        name = "PROCURA-SE: Alfa Garraguda",
    },
    [53332] = {
        name = "Hora da guerra",
    },
    [53333] = {
        name = "Hora da guerra",
    },
    [53336] = {
        name = "PROCURA-SE: Imperatriz Sabretusco",
    },
    [53337] = {
        name = "PROCURA-SE: Esmurrento Primordial",
    },
    [53342] = {
        name = "Núcleo Derretido",
    },
    [53347] = {
        name = "Abelhão, a Abelha",
    },
    [53348] = {
        name = "PROCURA-SE: Fuça Trovejante",
    },
    [53351] = {
        name = "A MEGAMINA!!!: Inimigo de Ferro",
    },
    [53352] = {
        name = "Terras do Fogo",
    },
    [53353] = {
        name = "Eco da Senhora da Guerra Zaela",
    },
    [53354] = {
        name = "Eco de Gul'dan",
    },
    [53355] = {
        name = "Eco de Garrosh Grito Infernal",
    },
    [53369] = {
        name = "Vai logo, Loh",
    },
    [53370] = {
        name = "Ajuste de contas",
    },
    [53371] = {
        name = "Vamos ser amelgos",
    },
    [53372] = {
        name = "Ajuste de contas",
    },
    [53406] = {
        name = "A Câmara do Coração",
    },
    [53430] = {
        name = "Besta da Ordem das Brasas",
    },
    [53431] = {
        name = "Frasco da Ordem das Brasas",
    },
    [53432] = {
        name = "Faca da Ordem das Brasas",
    },
    [53433] = {
        name = "Chapéu da Ordem das Brasas",
    },
    [53438] = {
        name = "PROCURA-SE: Larápios de Mantícora",
    },
    [53440] = {
        name = "PROCURA-SE: O Marimbondo",
    },
    [53449] = {
        name = "Gorilas da ira",
    },
    [53450] = {
        name = "Rei Da'ka",
    },
    [53451] = {
        name = "PROCURA-SE: Terraguarda Enraivecido",
    },
    [53452] = {
        name = "Gorilismo de guerrilha",
    },
    [53453] = {
        name = "Pisadar ou não pisadar",
    },
    [53454] = {
        name = "PROCURA-SE: Intendente Ssylis",
    },
    [53455] = {
        name = "PROCURA-SE: Os Degoladores Carmesim",
    },
    [53456] = {
        name = "PROCURA-SE: A Caçadora da Geada",
    },
    [53458] = {
        name = "PROCURA-SE: Corgossombroso",
    },
    [53459] = {
        name = "PROCURA-SE: Irmã Lílias",
    },
    [53461] = {
        name = "Metais preciosos",
    },
    [53462] = {
        name = "Tudo embrulhadinho",
    },
    [53463] = {
        name = "Maldição de oito patas",
    },
    [53464] = {
        name = "A vila de Arroio do Vale",
    },
    [53465] = {
        name = "Chá das cinco",
    },
    [53466] = {
        name = "Visão do Tempo",
    },
    [53467] = {
        name = "Cavernas do Tempo",
    },
    [53566] = {
        name = "Anões Ferro Negro",
    },
    [53583] = {
        name = "Adaptando as táticas",
    },
    [53602] = {
        name = "Adaptando as táticas",
    },
    [53719] = {
        name = "Lealdade dos Zandalari",
    },
    [53720] = {
        name = "Lealdade de Kul Tiraz",
    },
    [53725] = {
        name = "Um povo estilhaçado",
    },
    [53734] = {
        name = "Caminhar dentre fantasmas",
    },
    [53735] = {
        name = "Os primeiros a cair",
    },
    [53736] = {
        name = "Lamento dos Altaneiros",
    },
    [53737] = {
        name = "O dia que a esperança morreu",
    },
    [53738] = {
        name = "Defesa de Quel'Danas",
    },
    [53760] = {
        name = "Consequências inesperadas",
    },
    [53761] = {
        name = "O tesouro pirata",
    },
    [53762] = {
        name = "A coroa da tempestade",
    },
    [53763] = {
        name = "Torcer a faca",
    },
    [53765] = {
        name = "Ele só tem olhos para você",
    },
    [53766] = {
        name = "Ele só tem olhos para você",
    },
    [53774] = {
        name = "Sabedoria do Chefe Guerreiro",
    },
    [53775] = {
        name = "Sombras de disrupção",
    },
    [53776] = {
        name = "Rumo à Costa Partida",
    },
    [53777] = {
        name = "Onde ele morreu",
    },
    [53778] = {
        name = "Onde ele tombou",
    },
    [53779] = {
        name = "Mentiras de loa",
    },
    [53780] = {
        name = "Carcereiro dos Malditos",
    },
    [53782] = {
        name = "Mistérios da morte",
    },
    [53783] = {
        name = "Nas dunas",
    },
    [53791] = {
        name = "Orgulho dos sin'dorei",
    },
    [53802] = {
        name = "Como não fazer amigos e influenciar sethraks",
    },
    [53805] = {
        name = "Costurando uma cooperação",
    },
    [53806] = {
        name = "Cabeção",
    },
    [53807] = {
        name = "A trama do tempo",
    },
    [53810] = {
        name = "O fio rompido",
    },
    [53813] = {
        name = "Arregaçando as mangas",
    },
    [53815] = {
        name = "O que será que aconteceu com Safi Flaivvers?",
    },
    [53816] = {
        name = "Montagem necessária",
    },
    [53817] = {
        name = "O que será que aconteceu com Grizzek Chave-frouxa?",
    },
    [53818] = {
        name = "Re-papagaiado",
    },
    [53819] = {
        name = "Retorno ao ninho",
    },
    [53820] = {
        name = "Ela está num lugar melhor",
    },
    [53821] = {
        name = "Ele está morto, Jastor",
    },
    [53823] = {
        name = "O séquito da rainha",
    },
    [53824] = {
        name = "O rito dos reis e rainhas",
    },
    [53825] = {
        name = "O novo Conselho Zanchuli",
    },
    [53826] = {
        name = "A instigadora entre nós",
    },
    [53827] = {
        name = "O conselho se pronunciou",
    },
    [53828] = {
        name = "Olhar dos loas",
    },
    [53830] = {
        name = "Rainha dos Zandalari",
    },
    [53831] = {
        name = "Uma ocasião real",
    },
    [53833] = {
        name = "Empreendimento vingativo",
    },
    [53835] = {
        name = "Algo valioso? Quem sabe?",
    },
    [53836] = {
        name = "Armadura ancestral, mistério antigo",
    },
    [53837] = {
        name = "Olho no lance",
    },
    [53838] = {
        name = "Mantenha os pés no chão",
    },
    [53840] = {
        name = "Vai um caneco aí?",
    },
    [53841] = {
        name = "Estilhaços do passado",
    },
    [53842] = {
        name = "Bênção terrana",
    },
    [53844] = {
        name = "Recrutamento de Mestre de Caldeira",
    },
    [53845] = {
        name = "Forjando a armadura",
    },
    [53846] = {
        name = "Legado dos Barbabronze",
    },
    [53847] = {
        name = "Rumores ao vento",
    },
    [53848] = {
        name = "Minhas queridas ferramentas",
    },
    [53849] = {
        name = "Esperança minguante",
    },
    [53851] = {
        name = "Nossa guerra continua",
    },
    [53852] = {
        name = "Azerita negada",
    },
    [53853] = {
        name = "O sol poente",
    },
    [53856] = {
        name = "A Fúria da Horda",
    },
    [53858] = {
        name = "Na pele dela",
    },
    [53866] = {
        name = "O fim do infinito",
    },
    [53868] = {
        name = "Prova dos nove",
    },
    [53869] = {
        name = "Matando o tempo",
    },
    [53870] = {
        name = "Visitas no Castelo Grommash",
    },
    [53879] = {
        name = "Limpando a herdade",
    },
    [53880] = {
        name = "Máquinas de guerra e azerita",
    },
    [53881] = {
        name = "Trapos do mesmo tecido",
    },
    [53882] = {
        name = "Já estava escrito",
    },
    [53887] = {
        name = "A marcha da guerra continua",
    },
    [53888] = {
        name = "Ao Caniço",
    },
    [53889] = {
        name = "Claras intenções",
    },
    [53890] = {
        name = "Mais aliados, mais problemas",
    },
    [53891] = {
        name = "Nenhum problema é pequeno demais",
    },
    [53892] = {
        name = "Cadê a peãozada?",
    },
    [53893] = {
        name = "Um cadinho de boa vontade",
    },
    [53894] = {
        name = "Manutenção necessária",
    },
    [53895] = {
        name = "A promoção dos peões!",
    },
    [53896] = {
        name = "Aguente firme",
    },
    [53897] = {
        name = "Uma festa em sua homenagem",
    },
    [53898] = {
        name = "Força e honra",
    },
    [53899] = {
        name = "Pelas beiradas",
    },
    [53900] = {
        name = "Vamos usar as armas delas",
    },
    [53901] = {
        name = "Explosão nunca falha",
    },
    [53902] = {
        name = "O fim da Chamaré",
    },
    [53903] = {
        name = "O encontro com Meerah",
    },
    [53904] = {
        name = "Os assistentes do vinheiro",
    },
    [53905] = {
        name = "Funções condizentes",
    },
    [53906] = {
        name = "Fermentando para a Horda",
    },
    [53907] = {
        name = "Sentir o gostinho",
    },
    [53908] = {
        name = "À nossa espera",
    },
    [53909] = {
        name = "Aliados sitiados",
    },
    [53910] = {
        name = "Rechace a Horda!",
    },
    [53912] = {
        name = "A caçada nunca acaba",
    },
    [53913] = {
        name = "Com honra",
    },
    [53916] = {
        name = "Provedores dos Rompe-ondas",
    },
    [53919] = {
        name = "Tiros disparados",
    },
    [53936] = {
        name = "Detendo os sapadores",
    },
    [53937] = {
        name = "A Ub3r-chave",
    },
    [53938] = {
        name = "Costurando uma cooperação",
    },
    [53940] = {
        name = "Costurar o tempo",
    },
    [53941] = {
        name = "Um meca, um goblin",
    },
    [53942] = {
        name = "O meca certo",
    },
    [53947] = {
        name = "Nas dunas",
    },
    [53948] = {
        name = "Empreendimento vingativo",
    },
    [53949] = {
        name = "A Ub3r-chave",
    },
    [53962] = {
        name = "Trapos do mesmo tecido",
    },
    [53973] = {
        name = "Carga de ursaria",
    },
    [53978] = {
        name = "Planos de pólvora",
    },
    [53981] = {
        name = "O dia foi salvo",
    },
    [53986] = {
        name = "A calmaria vem antes",
    },
    [53988] = {
        name = "Praias do destino",
    },
    [53989] = {
        name = "Esperança",
    },
    [53990] = {
        name = "Na noite mais densa",
    },
    [53993] = {
        name = "Uma voz ao vento",
    },
    [53995] = {
        name = "O Curtumeiro Tauren",
    },
    [53996] = {
        name = "Catando cavaco",
    },
    [53997] = {
        name = "O sexto sentido",
    },
    [53998] = {
        name = "Exumação",
    },
    [53999] = {
        name = "As fibras vitais",
    },
    [54000] = {
        name = "Tum, tum, bate coração",
    },
    [54001] = {
        name = "Vamos nessa",
    },
    [54002] = {
        name = "Juntando todas as peças",
    },
    [54004] = {
        name = "Caso de teste I: Meca versus Mekkatorque",
    },
    [54005] = {
        name = "O que sabiam os drustos",
    },
    [54007] = {
        name = "Apólice",
    },
    [54008] = {
        name = "Renovação do seguro",
    },
    [54009] = {
        name = "Matancinha extra",
    },
    [54012] = {
        name = "Almas afortunadas",
    },
    [54015] = {
        name = "Até o pescoço",
    },
    [54018] = {
        name = "Descenço",
    },
    [54021] = {
        name = "A Primeira Arcanista",
    },
    [54022] = {
        name = "Os planos de batalha do Mekkatorque",
    },
    [54026] = {
        name = "Tá feito",
    },
    [54027] = {
        name = "Ameaça contida",
    },
    [54028] = {
        name = "Meca contra aeronau",
    },
    [54031] = {
        name = "Olhar dos loas: Krag'wa",
    },
    [54032] = {
        name = "Olhar dos loas: Pa'kul",
    },
    [54033] = {
        name = "Olhar dos loas: Gonk",
    },
    [54034] = {
        name = "Olhar dos loas: Bwonsamdi",
    },
    [54036] = {
        name = "Um processo sistemático",
    },
    [54041] = {
        name = "Sem sobreviventes",
    },
    [54042] = {
        name = "Problema na Costa Negra",
    },
    [54043] = {
        name = "Arrebanhando a Patrulha Sombria",
    },
    [54044] = {
        name = "Nascer da Lua Negra",
    },
    [54045] = {
        name = "Vamos vazar com as vinhas!",
    },
    [54046] = {
        name = "Só acaba quando termina",
    },
    [54047] = {
        name = "Onde morre a esperança",
    },
    [54049] = {
        name = "Na calada da noite",
    },
    [54050] = {
        name = "Consequência",
    },
    [54058] = {
        name = "Consequências inesperadas",
    },
    [54059] = {
        name = "A Guerreira da Noite",
    },
    [54083] = {
        name = "Azeitando a roda",
    },
    [54086] = {
        name = "O robô ideal para o serviço",
    },
    [54087] = {
        name = "Altura mínima",
    },
    [54088] = {
        name = "A lenda de Gnomecan",
    },
    [54094] = {
        name = "Definição goblínica de sucesso",
    },
    [54096] = {
        name = "A queda da Nascente do Sol",
    },
    [54097] = {
        name = "A Dama Sombria chama",
    },
    [54099] = {
        name = "O Lorde Supremo",
    },
    [54100] = {
        name = "Uma saída",
    },
    [54101] = {
        name = "No encalço",
    },
    [54102] = {
        name = "Fuga para o leste",
    },
    [54103] = {
        name = "Passando pelas beiradas",
    },
    [54104] = {
        name = "Sinais de Saurfang",
    },
    [54105] = {
        name = "Sempre ao leste",
    },
    [54106] = {
        name = "Dicas para o rastreamento",
    },
    [54107] = {
        name = "Augúrios sinistros",
    },
    [54108] = {
        name = "Uma morte de guerreiro",
    },
    [54109] = {
        name = "Favor da rainha",
    },
    [54113] = {
        name = "Qualquer mortezinha ajuda",
    },
    [54114] = {
        name = "Qualquer mortezinha ajuda",
    },
    [54117] = {
        name = "Qualquer mortezinha ajuda",
    },
    [54118] = {
        name = "Qualquer mortezinha ajuda",
    },
    [54120] = {
        name = "A Orgrimmar",
    },
    [54121] = {
        name = "A fuga de Grimpagris",
    },
    [54123] = {
        name = "O lugar disso é no meu meca!",
    },
    [54124] = {
        name = "Como escapar dos processos trabalhistas",
    },
    [54126] = {
        name = "Torcer a faca",
    },
    [54128] = {
        name = "Precauções necessárias",
    },
    [54139] = {
        name = "A guerra bate à porta",
    },
    [54140] = {
        name = "Ascensão dos Zandalari",
    },
    [54141] = {
        name = "O medalhão de Azshara",
    },
    [54144] = {
        name = "Ordens de Azshara",
    },
    [54145] = {
        name = "O loa da morte",
    },
    [54147] = {
        name = "Confrontar a Val'kyr",
    },
    [54156] = {
        name = "Trilha de sangue",
    },
    [54157] = {
        name = "Ninguém fica pra trás",
    },
    [54161] = {
        name = "O conhecimento drusto",
    },
    [54163] = {
        name = "Quando a poeira baixa",
    },
    [54164] = {
        name = "A morte do rei",
    },
    [54165] = {
        name = "O retorno de Derek Proudmore",
    },
    [54169] = {
        name = "O golpe do tesouro",
    },
    [54171] = {
        name = "O Cetro Abissal",
    },
    [54174] = {
        name = "Ordens de Azshara",
    },
    [54175] = {
        name = "Face a face com seu inimigo",
    },
    [54176] = {
        name = "Uniformizando",
    },
    [54177] = {
        name = "Uma distração brilhante",
    },
    [54178] = {
        name = "Carona",
    },
    [54179] = {
        name = "Pela porta da frente",
    },
    [54183] = {
        name = "Desforra morta",
    },
    [54191] = {
        name = "Mudança de curso",
    },
    [54192] = {
        name = "Informações delicadas",
    },
    [54193] = {
        name = "Isso é enorme!",
    },
    [54194] = {
        name = "Baita poderzão",
    },
    [54195] = {
        name = "Uma fera que pensa",
    },
    [54196] = {
        name = "Sem opção",
    },
    [54197] = {
        name = "Liberdade para os Da'kani",
    },
    [54198] = {
        name = "Despedidas agridoces",
    },
    [54199] = {
        name = "As necessidades de muitos",
    },
    [54200] = {
        name = "Leve a base",
    },
    [54201] = {
        name = "Sob medida para o Grong",
    },
    [54202] = {
        name = "Calibrar o núcleo",
    },
    [54203] = {
        name = "O grandificamento",
    },
    [54204] = {
        name = "Destruição total de templo",
    },
    [54205] = {
        name = "Uma boa soneca",
    },
    [54206] = {
        name = "O agente adormecido",
    },
    [54207] = {
        name = "Retomando o posto avançado",
    },
    [54208] = {
        name = "Caça-minas",
    },
    [54211] = {
        name = "Colocando os goblins no G.O.P.E.",
    },
    [54212] = {
        name = "Re-reconstruindo o A.F.M.O.D.",
    },
    [54213] = {
        name = "Está vivo!",
    },
    [54224] = {
        name = "A batalha das Ruínas de Zul'jan",
    },
    [54244] = {
        name = "Eles estão encurralados",
    },
    [54249] = {
        name = "Justiça Zandalari",
    },
    [54265] = {
        name = "Ordens de Azshara",
    },
    [54269] = {
        name = "Ninguém escapará",
    },
    [54270] = {
        name = "Espelhos partidos",
    },
    [54271] = {
        name = "Expurgo de Telaamon",
    },
    [54275] = {
        name = "Abrindo as névoas",
    },
    [54280] = {
        name = "Voe para encontrá-los",
    },
    [54282] = {
        name = "Batalha de Dazar'alor",
    },
    [54300] = {
        name = "Fé irregular",
    },
    [54301] = {
        name = "A misericórdia de Talanji",
    },
    [54302] = {
        name = "A queda de Zuldazar",
    },
    [54303] = {
        name = "A marcha rumo a Nazmir",
    },
    [54310] = {
        name = "Reaproveitamento de aldeia",
    },
    [54312] = {
        name = "Nevoeiro de Guerra",
    },
    [54402] = {
        name = "Manutenção das engrenagens",
    },
    [54404] = {
        name = "Maquinações dos Ferro Negro",
    },
    [54407] = {
        name = "Esgueirando-se no pântano",
    },
    [54412] = {
        name = "Dilúvio de Zul'jan",
    },
    [54416] = {
        name = "Preparativos do front de guerra",
    },
    [54417] = {
        name = "Mostrando a nossa força",
    },
    [54418] = {
        name = "O meca da morte",
    },
    [54419] = {
        name = "Apaziguando a massa",
    },
    [54421] = {
        name = "Domando as feras",
    },
    [54433] = {
        name = "Ordens de Azshara",
    },
    [54438] = {
        name = "Caldeirão das Tempestades: relíquias das sombras",
    },
    [54439] = {
        name = "Caldeirão das Tempestades: relíquias das sombras",
    },
    [54441] = {
        name = "Tomando o Portal Sangrento",
    },
    [54459] = {
        name = "Aquele que caminha pela Luz",
    },
    [54485] = {
        name = "Batalha de Dazar'alor",
    },
    [54510] = {
        name = "Traquinagem controlada",
    },
    [54518] = {
        name = "Zero zepelins",
    },
    [54519] = {
        name = "Esquadrão classe A",
    },
    [54559] = {
        name = "Pluméria livre!",
    },
    [54576] = {
        name = "Os melhores de Gnomeregan",
    },
    [54577] = {
        name = "Salões escuros e engrenagens empoeiradas",
    },
    [54580] = {
        name = "Treta na tundra",
    },
    [54581] = {
        name = "Vamos soltar os passarinhos de ferro",
    },
    [54582] = {
        name = "Mais esperto do que a média dos troggs",
    },
    [54639] = {
        name = "Um sinal nos Picos Tempestuosos",
    },
    [54640] = {
        name = "Gnomisericórdia!",
    },
    [54641] = {
        name = "Por Gnomeregan!",
    },
    [54642] = {
        name = "G.E.N.I.O. indomável",
    },
    [54703] = {
        name = "Entrega expressa",
    },
    [54706] = {
        name = "Fabricado em Kul Tiraz",
    },
    [54708] = {
        name = "Não há lugar como o nosso lar",
    },
    [54721] = {
        name = "Estou velha demais para isso",
    },
    [54723] = {
        name = "Cobrindo nossos mastros",
    },
    [54725] = {
        name = "Os profundos",
    },
    [54726] = {
        name = "Esqueleto",
    },
    [54727] = {
        name = "Carregando a equipe",
    },
    [54728] = {
        name = "Esta madeira é assombrada",
    },
    [54729] = {
        name = "As Colinas Áridas",
    },
    [54730] = {
        name = "Influência de Gorak Tul",
    },
    [54731] = {
        name = "Equilíbrio em todas as coisas",
    },
    [54732] = {
        name = "Solta!",
    },
    [54733] = {
        name = "O minério da mina",
    },
    [54734] = {
        name = "Evocações de Dorian",
    },
    [54735] = {
        name = "Uma tripulação digna",
    },
    [54754] = {
        name = "Pela Rainha",
    },
    [54759] = {
        name = "Quando os espíritos sussurram",
    },
    [54760] = {
        name = "Os Andarilhos Espirituais",
    },
    [54761] = {
        name = "Guia espiritual",
    },
    [54762] = {
        name = "Um pequeno recuo",
    },
    [54763] = {
        name = "A travessia",
    },
    [54764] = {
        name = "Cerco em Casco Sangrento",
    },
    [54765] = {
        name = "O agradecimento ao guia",
    },
    [54766] = {
        name = "Atenda ao chamado",
    },
    [54787] = {
        name = "Máscara para um amigo",
    },
    [54850] = {
        name = "Operação: Troggargeddon",
    },
    [54851] = {
        name = "Bênção das Marés",
    },
    [54871] = {
        name = "Estamos chegando",
    },
    [54913] = {
        name = "Centelha de genialidade",
    },
    [54915] = {
        name = "Telemetria ativa",
    },
    [54916] = {
        name = "Tradição de guarda-caça",
    },
    [54917] = {
        name = "Pagamento em sangue",
    },
    [54918] = {
        name = "Centelha da imaginação",
    },
    [54919] = {
        name = "Laços do trovão",
    },
    [54920] = {
        name = "Vínculo fraterno",
    },
    [54922] = {
        name = "Trabalho braçal",
    },
    [54925] = {
        name = "Heresia!",
    },
    [54929] = {
        name = "Confusão armada",
    },
    [54930] = {
        name = "Liberação Mecânica",
    },
    [54938] = {
        name = "Dá uma ajudinha, irmão?",
    },
    [54939] = {
        name = "Teimoso como um Barbabronze",
    },
    [54940] = {
        name = "A necessidade é a M.A.D.R.E.",
    },
    [54945] = {
        name = "Mão na massa",
    },
    [54946] = {
        name = "Apresente-se a Gila",
    },
    [54947] = {
        name = "Uma equipe modesta",
    },
    [54958] = {
        name = "Navios na noite",
    },
    [54959] = {
        name = "Fechado a três chaves",
    },
    [54960] = {
        name = "Amargo reencontro",
    },
    [54961] = {
        name = "Corrigindo erros",
    },
    [54964] = {
        name = "Uma passagem só de ida para o coração",
    },
    [54965] = {
        name = "Robôs fatiados",
    },
    [54969] = {
        name = "Descenço",
    },
    [54972] = {
        name = "O caminho para casa",
    },
    [54975] = {
        name = "Uma breve trégua",
    },
    [54976] = {
        name = "A sombra de Guilnéas",
    },
    [54977] = {
        name = "Floresta do Crepúsculo",
    },
    [54980] = {
        name = "A noite dos Nocturnos",
    },
    [54981] = {
        name = "Um grito à lua",
    },
    [54982] = {
        name = "O espírito do caçador",
    },
    [54983] = {
        name = "O despertar do sonhador",
    },
    [54984] = {
        name = "O sono dos lobos",
    },
    [54990] = {
        name = "A nova guarda",
    },
    [54992] = {
        name = "O começo de uma coisa maior",
    },
    [54997] = {
        name = "Morreu na praia",
    },
    [54999] = {
        name = "Não dê bandeira",
    },
    [55028] = {
        name = "Metendo a mão na sucata",
    },
    [55031] = {
        name = "Metendo a mão na sucata",
    },
    [55033] = {
        name = "A fuga de Grimpagris",
    },
    [55034] = {
        name = "Não dê bandeira",
    },
    [55039] = {
        name = "Mestre da Construção Naval",
    },
    [55040] = {
        name = "Uma olhadela",
    },
    [55043] = {
        name = "Histórias de pescador e mares distantes",
    },
    [55044] = {
        name = "Não culpe o Mensageiro",
    },
    [55045] = {
        name = "Guardião do meu irmão",
    },
    [55047] = {
        name = "Varredura da Guarnição",
    },
    [55048] = {
        name = "Jogos de espionagem",
    },
    [55049] = {
        name = "Falha na comunicação",
    },
    [55050] = {
        name = "Ingresso, por favor?",
    },
    [55051] = {
        name = "Uma demonstração de poder",
    },
    [55052] = {
        name = "Varredura da Guarnição",
    },
    [55053] = {
        name = "O caminho para casa",
    },
    [55054] = {
        name = "Revolta",
    },
    [55055] = {
        name = "Uma armadilha para peixões",
    },
    [55087] = {
        name = "Tempestade iminente",
    },
    [55088] = {
        name = "Perdidos em campo",
    },
    [55089] = {
        name = "Um Shaw de liberdade",
    },
    [55090] = {
        name = "Um encontro de inimigos",
    },
    [55092] = {
        name = "Secando a fonte de poder",
    },
    [55094] = {
        name = "Só vai!",
    },
    [55095] = {
        name = "Revolta",
    },
    [55096] = {
        name = "Mensagem pro papai",
    },
    [55101] = {
        name = "A sucatrônica e você",
    },
    [55103] = {
        name = "Ideias podem vir de qualquer lugar",
    },
    [55116] = {
        name = "Onde fica a dica",
    },
    [55117] = {
        name = "Charada da correspondência",
    },
    [55118] = {
        name = "Fios soltos",
    },
    [55119] = {
        name = "Apresentando-se!",
    },
    [55121] = {
        name = "O laboratório de Mardivas",
    },
    [55124] = {
        name = "Corrigindo erros",
    },
    [55136] = {
        name = "O fim dos dias de cão",
    },
    [55153] = {
        name = "Construção colaborativa",
    },
    [55171] = {
        name = "Espião x Espião",
    },
    [55175] = {
        name = "Encontro em Mezzamar",
    },
    [55177] = {
        name = "Rasgando a costura",
    },
    [55179] = {
        name = "Coordenação da retaliação",
    },
    [55182] = {
        name = "Remontagem requerida",
    },
    [55183] = {
        name = "Buscando o terreno elevado",
    },
    [55185] = {
        name = "Escuta bem!",
    },
    [55188] = {
        name = "Rasgando a costura",
    },
    [55195] = {
        name = "Reverberação",
    },
    [55210] = {
        name = "Pilhas não inclusas",
    },
    [55211] = {
        name = "Recarregando Ferrúgia",
    },
    [55214] = {
        name = "Estresse no tecido",
    },
    [55216] = {
        name = "A audição",
    },
    [55217] = {
        name = "Pagando a dívida de vida e morte",
    },
    [55218] = {
        name = "O precioso couro de Sheza",
    },
    [55219] = {
        name = "Passando na base",
    },
    [55220] = {
        name = "Pesca esportiva",
    },
    [55221] = {
        name = "Catando ossos",
    },
    [55222] = {
        name = "Bate forte o tambor",
    },
    [55223] = {
        name = "Instrumentos da destruição",
    },
    [55227] = {
        name = "A artesã eônia",
    },
    [55228] = {
        name = "A audição",
    },
    [55229] = {
        name = "Pagando a dívida",
    },
    [55230] = {
        name = "O precioso couro de Telonis",
    },
    [55231] = {
        name = "O outro Bailalma",
    },
    [55232] = {
        name = "Ameaça de Mevris",
    },
    [55233] = {
        name = "Catando ossos",
    },
    [55234] = {
        name = "Bate forte o tambor",
    },
    [55235] = {
        name = "Instrumentos da destruição",
    },
    [55247] = {
        name = "A confiança conquistada",
    },
    [55252] = {
        name = "Uma loa sem templo",
    },
    [55253] = {
        name = "Uma prova de fé",
    },
    [55254] = {
        name = "Um sono infindo",
    },
    [55258] = {
        name = "Dormir, comer, repetir",
    },
    [55298] = {
        name = "Pescando, mas não peixe",
    },
    [55339] = {
        name = "Limpa nas manjubinhas",
    },
    [55361] = {
        name = "O xamã perdido",
    },
    [55362] = {
        name = "Fúria elemental",
    },
    [55363] = {
        name = "O resgate do clarividente",
    },
    [55373] = {
        name = "Pisa nos pilhadores",
    },
    [55374] = {
        name = "Perturbação sob a terra",
    },
    [55384] = {
        name = "Acomodação",
    },
    [55385] = {
        name = "De olho no pátio",
    },
    [55390] = {
        name = "Na escuridão, eu sonho",
    },
    [55392] = {
        name = "Dentro da Estrada Onírica",
    },
    [55393] = {
        name = "Contenção do Caos",
    },
    [55394] = {
        name = "Estilhaços de Esmeralda",
    },
    [55395] = {
        name = "Não feche os olhos",
    },
    [55396] = {
        name = "Do que sonhos são feitos",
    },
    [55397] = {
        name = "Antes do despertar",
    },
    [55398] = {
        name = "O longo despertar",
    },
    [55400] = {
        name = "Segure minha mão",
    },
    [55407] = {
        name = "Aplacando a Espinha",
    },
    [55425] = {
        name = "Domando o Indomável",
    },
    [55462] = {
        name = "O chamado da Andarilha",
    },
    [55465] = {
        name = "Sonho adentro",
    },
    [55469] = {
        name = "Zin-Azshari",
    },
    [55481] = {
        name = "Por dentro do palácio",
    },
    [55482] = {
        name = "Estabelecendo conexão",
    },
    [55485] = {
        name = "Terrores das profundezas",
    },
    [55486] = {
        name = "Segredos da telemancia",
    },
    [55488] = {
        name = "Diálogo com os mortos",
    },
    [55489] = {
        name = "O conto da aia",
    },
    [55490] = {
        name = "Vamos arrancar os olhos deles",
    },
    [55497] = {
        name = "Um rosto familiar",
    },
    [55500] = {
        name = "O resgate",
    },
    [55503] = {
        name = "O escornante e o saurídeo",
    },
    [55504] = {
        name = "Santuários de Zuldazar",
    },
    [55505] = {
        name = "Memória de Roo'li",
    },
    [55506] = {
        name = "O fim do caminho",
    },
    [55507] = {
        name = "Bênção de Torcali",
    },
    [55519] = {
        name = "Feridas abertas",
    },
    [55520] = {
        name = "A cura de Nordrassil",
    },
    [55521] = {
        name = "Uso para a azerita",
    },
    [55529] = {
        name = "Não fazemos trocas",
    },
    [55530] = {
        name = "Um lugar seguro",
    },
    [55533] = {
        name = "A M.A.D.R.E. sabe o que é melhor",
    },
    [55558] = {
        name = "Um esconderijo perfeito",
    },
    [55560] = {
        name = "Vingança de Utama",
    },
    [55561] = {
        name = "O que resta de Zin-Azshari",
    },
    [55565] = {
        name = "Reforço das reservas de mana",
    },
    [55569] = {
        name = "Ecos da dor",
    },
    [55570] = {
        name = "Segredos nas ruínas",
    },
    [55571] = {
        name = "A verdade revelada",
    },
    [55573] = {
        name = "Expurgo dos hereges",
    },
    [55574] = {
        name = "As Zagaias de Azshara",
    },
    [55585] = {
        name = "Começo promissor",
    },
    [55586] = {
        name = "Aquela polida",
    },
    [55590] = {
        name = "Toques finais",
    },
    [55592] = {
        name = "Começo promissor",
    },
    [55593] = {
        name = "Informações sobre os inimigos",
    },
    [55594] = {
        name = "Aquela polida",
    },
    [55595] = {
        name = "Deterioração do conhecimento",
    },
    [55596] = {
        name = "Toques finais",
    },
    [55597] = {
        name = "Dever de honra",
    },
    [55598] = {
        name = "O que sabemos sobre as nagas",
    },
    [55599] = {
        name = "Reconhecimento sob disfarce",
    },
    [55600] = {
        name = "Alimento para os dracoliscos",
    },
    [55601] = {
        name = "Cristais cobiçados",
    },
    [55608] = {
        name = "Mãos à obra",
    },
    [55618] = {
        name = "A Forja do Coração",
    },
    [55622] = {
        name = "Monte e saia andando",
    },
    [55630] = {
        name = "Mão na massa",
    },
    [55632] = {
        name = "Altura mínima",
    },
    [55635] = {
        name = "Uma voz ao vento",
    },
    [55645] = {
        name = "Visita principesca",
    },
    [55646] = {
        name = "A lenda de Gnomecan",
    },
    [55647] = {
        name = "Operação \"Na Moita\"",
    },
    [55648] = {
        name = "A câmara agora é nossa",
    },
    [55649] = {
        name = "Tramoias para Gnomecan",
    },
    [55650] = {
        name = "Tudo do bom e do melhor",
    },
    [55651] = {
        name = "Rumo à Gnomecan!",
    },
    [55652] = {
        name = "Baía do Prospecto",
    },
    [55657] = {
        name = "À sombra das Asas Rubras",
    },
    [55685] = {
        name = "Somos da paz... da \"passa\" a grana",
    },
    [55694] = {
        name = "Tem alguma coisa na água",
    },
    [55696] = {
        name = "Teste de estrada",
    },
    [55697] = {
        name = "Hora de bater perna",
    },
    [55707] = {
        name = "O primeiro é grátis",
    },
    [55708] = {
        name = "Aprimorado",
    },
    [55729] = {
        name = "A resistência quer VOCÊ!",
    },
    [55730] = {
        name = "Resgatando a resistência",
    },
    [55731] = {
        name = "Os exércitos do meu pai",
    },
    [55732] = {
        name = "Uma velha cicatriz",
    },
    [55734] = {
        name = "Construção de perfuratriz",
    },
    [55735] = {
        name = "Defendendo a Voragem",
    },
    [55736] = {
        name = "Boas-vindas à resistência",
    },
    [55737] = {
        name = "No tempo de azerita",
    },
    [55752] = {
        name = "Juntos venceremos",
    },
    [55753] = {
        name = "Um robô para chamar de seu",
    },
    [55778] = {
        name = "Visões do perigo",
    },
    [55779] = {
        name = "Suspensão da Execução",
    },
    [55780] = {
        name = "Aliados antigos",
    },
    [55781] = {
        name = "Aliados antigos",
    },
    [55782] = {
        name = "Suspensão da Execução",
    },
    [55783] = {
        name = "Suspensão da Execução",
    },
    [55784] = {
        name = "Pagamento em espécie",
    },
    [55795] = {
        name = "A montanha vai",
    },
    [55796] = {
        name = "Heresia na encruzilhada",
    },
    [55797] = {
        name = "Fúria da mãe do escornante",
    },
    [55798] = {
        name = "Não ande sozinho",
    },
    [55799] = {
        name = "Guinada da maré",
    },
    [55860] = {
        name = "Liquidação de Lesmas do Mar",
    },
    [55861] = {
        name = "Deixa o resíduo te levar",
    },
    [55862] = {
        name = "Informações sobre os inimigos",
    },
    [55863] = {
        name = "Deterioração do conhecimento",
    },
    [55864] = {
        name = "O preço é a morte",
    },
    [55865] = {
        name = "O que sabemos sobre as nagas",
    },
    [55866] = {
        name = "Reconhecimento sob disfarce",
    },
    [55867] = {
        name = "Cristais cobiçados",
    },
    [55868] = {
        name = "Deixa o resíduo te levar",
    },
    [55869] = {
        name = "Retirando o depósito",
    },
    [55870] = {
        name = "Liquidação de lesmas",
    },
    [55937] = {
        name = "Retirando o depósito",
    },
    [55967] = {
        name = "Alimento para os dracoliscos",
    },
    [55983] = {
        name = "Um lugar seguro",
    },
    [55995] = {
        name = "Tudo tem conserto nessa vida",
    },
    [56030] = {
        name = "Ordens da Chefe Guerreira",
    },
    [56031] = {
        name = "A ofensiva do lobo",
    },
    [56037] = {
        name = "Os segredos roubados das nagas",
    },
    [56038] = {
        name = "Um serviço com propósito",
    },
    [56039] = {
        name = "Lâmina cega não vence guerra",
    },
    [56043] = {
        name = "O envio da frota",
    },
    [56044] = {
        name = "O envio da frota",
    },
    [56045] = {
        name = "Os segredos roubados nas nagas",
    },
    [56046] = {
        name = "Um serviço com propósito",
    },
    [56047] = {
        name = "Lâmina cega não vence guerra",
    },
    [56063] = {
        name = "Marés sombrias",
    },
    [56095] = {
        name = "Legado de Nar'anan",
    },
    [56118] = {
        name = "Retrospectiva",
    },
    [56143] = {
        name = "O destino da Professora Elryna",
    },
    [56156] = {
        name = "Uma lâmina temperada",
    },
    [56167] = {
        name = "Investigando o Planalto",
    },
    [56168] = {
        name = "Retificado na fábrica",
    },
    [56175] = {
        name = "Livre de emissões",
    },
    [56181] = {
        name = "Esse é por minha conta",
    },
    [56209] = {
        name = "Os Salões Primordiais",
    },
    [56210] = {
        name = "Pedras divinatórias",
    },
    [56211] = {
        name = "Pedras divinatórias",
    },
    [56234] = {
        name = "Amigos em apuros",
    },
    [56235] = {
        name = "Nazjatar adentro",
    },
    [56236] = {
        name = "Pé no chão, mas cabeça erguida",
    },
    [56239] = {
        name = "Estranha faca de prata",
    },
    [56240] = {
        name = "Estranha faca de prata",
    },
    [56241] = {
        name = "Pistas preservadas",
    },
    [56242] = {
        name = "Pistas preservadas",
    },
    [56243] = {
        name = "Diários dos mortos",
    },
    [56244] = {
        name = "Diários dos mortos",
    },
    [56245] = {
        name = "A fechadura encantada",
    },
    [56246] = {
        name = "A fechadura encantada",
    },
    [56247] = {
        name = "A história do tesouro",
    },
    [56248] = {
        name = "A história do tesouro",
    },
    [56304] = {
        name = "Vida altaneira",
    },
    [56305] = {
        name = "Vamos pescar!",
    },
    [56309] = {
        name = "Amigos que o mar levou",
    },
    [56310] = {
        name = "Amigos que o mar levou",
    },
    [56311] = {
        name = "O eterno afogar",
    },
    [56312] = {
        name = "O eterno afogar",
    },
    [56313] = {
        name = "Beligerância",
    },
    [56314] = {
        name = "Beligerância",
    },
    [56315] = {
        name = "A escolha foi feita",
    },
    [56316] = {
        name = "A escolha foi feita",
    },
    [56319] = {
        name = "Contrato de Carga-rápida",
    },
    [56320] = {
        name = "A primeira carga é grátis!",
    },
    [56321] = {
        name = "Corin precisa de ajuda",
    },
    [56325] = {
        name = "A maré vira",
    },
    [56346] = {
        name = "Tecnologia ancestral",
    },
    [56347] = {
        name = "Uma oportunidade abissal",
    },
    [56348] = {
        name = "O Palácio Eterno: ainda dá para ficar mais forte...",
    },
    [56349] = {
        name = "O Palácio Eterno: ultrapassando os limites",
    },
    [56350] = {
        name = "Por dentro do palácio",
    },
    [56351] = {
        name = "O Palácio Eterno: ultrapassando os limites",
    },
    [56352] = {
        name = "O Palácio Eterno: Ainda dá para ficar mais forte...",
    },
    [56353] = {
        name = "Uma oportunidade abissal",
    },
    [56354] = {
        name = "Tecnologia ancestral",
    },
    [56356] = {
        name = "O Palácio Eterno: a artimanha da rainha",
    },
    [56358] = {
        name = "O Palácio Eterno: a artimanha da rainha",
    },
    [56374] = {
        name = "Um problema titânico",
    },
    [56375] = {
        name = "Rumo a Ramkahen",
    },
    [56376] = {
        name = "Ameaças emergentes",
    },
    [56377] = {
        name = "Forjando um caminho",
    },
    [56378] = {
        name = "Tripulação desaparecida",
    },
    [56379] = {
        name = "Tripulação desaparecida",
    },
    [56401] = {
        name = "Um súbito relâmpago",
    },
    [56422] = {
        name = "Em asas fantasmas",
    },
    [56429] = {
        name = "O que vamos enfrentar",
    },
    [56472] = {
        name = "O Acordo de Uldum",
    },
    [56494] = {
        name = "À véspera da batalha",
    },
    [56495] = {
        name = "Eles avançam contra nós",
    },
    [56496] = {
        name = "À véspera da batalha",
    },
    [56536] = {
        name = "Nunca é fácil",
    },
    [56537] = {
        name = "O signo misterioso",
    },
    [56538] = {
        name = "Clãs dos mogus",
    },
    [56539] = {
        name = "Em busca dos Rajani",
    },
    [56540] = {
        name = "Prova de tenacidade",
    },
    [56541] = {
        name = "O Engenho de Nalak'sha",
    },
    [56542] = {
        name = "Esperança reanimada",
    },
    [56560] = {
        name = "Uma descoberta curiosa",
    },
    [56561] = {
        name = "Uma descoberta curiosa",
    },
    [56574] = {
        name = "Reflexões ambarinas",
    },
    [56575] = {
        name = "Kor'vess 2, a missão",
    },
    [56576] = {
        name = "Exterminação aqir",
    },
    [56577] = {
        name = "Colmeia aleijada",
    },
    [56578] = {
        name = "Raízes podres",
    },
    [56580] = {
        name = "Segredos do âmbar",
    },
    [56616] = {
        name = "Velhas caras, novos problemas",
    },
    [56617] = {
        name = "Enxame unificado",
    },
    [56640] = {
        name = "Almas afortunadas",
    },
    [56641] = {
        name = "Ruptura de poder",
    },
    [56642] = {
        name = "Marés sombrias",
    },
    [56643] = {
        name = "Até o pescoço",
    },
    [56644] = {
        name = "O que vamos enfrentar",
    },
    [56645] = {
        name = "Coração do enxame",
    },
    [56647] = {
        name = "A ameaça mantídea",
    },
    [56719] = {
        name = "Não é meu, não",
    },
    [56739] = {
        name = "O poder da adoração",
    },
    [56741] = {
        name = "A lança do destino",
    },
    [56771] = {
        name = "Guerreiros perdidos para o tempo",
    },
    [56833] = {
        name = "Líderes da Horda",
    },
    [56979] = {
        name = "Salvamento do cerco",
    },
    [56980] = {
        name = "Já entre nós",
    },
    [56981] = {
        name = "Posicionamento estratégico",
    },
    [56982] = {
        name = "Diante dos Portões de Orgrimmar",
    },
    [56993] = {
        name = "O preço da vitória",
    },
    [57002] = {
        name = "Velho soldado",
    },
    [57005] = {
        name = "Fazendo amizade",
    },
    [57006] = {
        name = "Aliados dignos",
    },
    [57010] = {
        name = "Reunindo poder",
    },
    [57043] = {
        name = "Pequenos amigos, grandes negócios",
    },
    [57045] = {
        name = "Entrega especial",
    },
    [57047] = {
        name = "Um experimento simples",
    },
    [57048] = {
        name = "Compras de peças",
    },
    [57051] = {
        name = "Não consta para nós o pagamento desta fatura",
    },
    [57052] = {
        name = "Eu tenho o que você precisa",
    },
    [57053] = {
        name = "Teste de força bruta",
    },
    [57067] = {
        name = "Mogus nos portões",
    },
    [57068] = {
        name = "De butuca na pipa",
    },
    [57069] = {
        name = "Cortem as cabeças",
    },
    [57070] = {
        name = "Massacre dos mogus",
    },
    [57071] = {
        name = "Nenhuma cerveja fica para trás",
    },
    [57072] = {
        name = "Iaque multifuncional",
    },
    [57074] = {
        name = "Ao portão",
    },
    [57075] = {
        name = "Coragem líquida",
    },
    [57076] = {
        name = "Retorno ao Cair da Bruma",
    },
    [57077] = {
        name = "Procura-se compradores!",
    },
    [57078] = {
        name = "A lista VIP",
    },
    [57079] = {
        name = "Operação Sucatópolis",
    },
    [57080] = {
        name = "Recompensa adequada",
    },
    [57088] = {
        name = "Não é meu, não",
    },
    [57090] = {
        name = "Salvamento do cerco",
    },
    [57091] = {
        name = "Já entre nós",
    },
    [57092] = {
        name = "Posicionamento estratégico",
    },
    [57093] = {
        name = "Diante dos Portões de Orgrimmar",
    },
    [57094] = {
        name = "O preço da vitória",
    },
    [57095] = {
        name = "Velho soldado",
    },
    [57126] = {
        name = "... E seguindo mares",
    },
    [57130] = {
        name = "Traidores entre nós",
    },
    [57147] = {
        name = "Não é minha Chefe Guerreira",
    },
    [57148] = {
        name = "Quebra-cercos",
    },
    [57149] = {
        name = "Remoção de Propaganda",
    },
    [57150] = {
        name = "Milícia",
    },
    [57151] = {
        name = "Uma linha na areia",
    },
    [57152] = {
        name = "Mais leal",
    },
    [57198] = {
        name = "Senso de obrigação",
    },
    [57220] = {
        name = "Iniciação do protocolo de força",
    },
    [57221] = {
        name = "Recriação",
    },
    [57222] = {
        name = "Investigando os Salões",
    },
    [57290] = {
        name = "O início da descida",
    },
    [57324] = {
        name = "Zarpar na maré alta",
    },
    [57362] = {
        name = "Escuridão adentro",
    },
    [57373] = {
        name = "A espiral da loucura",
    },
    [57374] = {
        name = "Nas profundezas sombrias",
    },
    [57376] = {
        name = "Necessidade oculta",
    },
    [57378] = {
        name = "Vestígios de um Mundo Despedaçado",
    },
    [57448] = {
        name = "Nossos novos aliados",
    },
    [57486] = {
        name = "Energia minguante",
    },
    [57487] = {
        name = "Quem possa ajudar",
    },
    [57488] = {
        name = "O diagrama atual",
    },
    [57490] = {
        name = "Viagem rumo à segurança",
    },
    [57491] = {
        name = "Melhor... Mais forte... Menos morto",
    },
    [57492] = {
        name = "Ele?",
    },
    [57493] = {
        name = "Harmonização mental",
    },
    [57494] = {
        name = "Coração forte",
    },
    [57495] = {
        name = "O futuro de Gnomecan",
    },
    [57496] = {
        name = "Ascensão",
    },
    [57497] = {
        name = "Espalhar a notícia",
    },
    [57524] = {
        name = "Acessando os arquivos",
    },
    [57873] = {
        name = "Notícias de Orsis",
    },
    [57915] = {
        name = "Busca por sobreviventes",
    },
    [57954] = {
        name = "Queime os corpos",
    },
    [57955] = {
        name = "Ao porto Ankhaten",
    },
    [57956] = {
        name = "Hospedeiros Errantes",
    },
    [57969] = {
        name = "Cuidado dos feridos",
    },
    [57970] = {
        name = "Xok'nixx, o Arruinador",
    },
    [57971] = {
        name = "Ruínas de Ammon",
    },
    [57990] = {
        name = "Obelisco do Sol",
    },
    [58008] = {
        name = "A todo vapor",
    },
    [58009] = {
        name = "Até a Lua",
    },
    [58087] = {
        name = "Destruindo a fonte",
    },
    [58214] = {
        name = "Caso de urgência",
    },
    [58496] = {
        name = "Um conselheiro indesejado",
    },
    [58498] = {
        name = "O retorno do rei guerreiro",
    },
    [58502] = {
        name = "É onde fica o coração",
    },
    [58506] = {
        name = "Diagnóstico de rede",
    },
    [58582] = {
        name = "A volta ao Príncipe Negro",
    },
    [58583] = {
        name = "É onde fica o coração",
    },
    [58606] = {
        name = "Investigação de miudezas",
    },
    [58615] = {
        name = "Sussurros no escuro",
    },
    [58631] = {
        name = "Sonho adentro",
    },
    [58632] = {
        name = "Ny'alotha, a Cidade Desperta: o fim do Corruptor",
    },
    [58634] = {
        name = "A abertura do portal",
    },
    [58636] = {
        name = "De olho nos Amatet",
    },
    [58638] = {
        name = "Um mergulho profundo",
    },
    [58639] = {
        name = "História enterrada",
    },
    [58640] = {
        name = "Uma rachadura na armadura",
    },
    [58641] = {
        name = "Caçadores de corrupção",
    },
    [58642] = {
        name = "Objetivos compartilhados",
    },
    [58643] = {
        name = "Destruição mútua assegurada",
    },
    [58645] = {
        name = "Um mundo digno de salvação",
    },
    [58646] = {
        name = "Engole essa!",
    },
    [58737] = {
        name = "As descobertas de Magni",
    },
})
]])()
