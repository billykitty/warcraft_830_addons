----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "frFR" then
    return
end

local L = BtWQuests.L
L["ALLIED_RACE_MECHAGNOME"] = "Allied Race : Mécagnome"
L["ALLIED_RACE_VULPERA"] = "Allied Race : Vulpérin"
L["BTWQUESTS_COSMETIC_WAIST_OF_TIME"] = "Ornemental : Boucle temporelle"
L["BTWQUESTS_GIFT_OF_NZOTH"] = "Don de N’Zoth"
L["BTWQUESTS_HATI_REBORN"] = "Hati ressuscité"
L["BTWQUESTS_HERITAGE_OF_GILNEAS"] = "Armure ancestrale de Gilnéas"
L["BTWQUESTS_HERITAGE_OF_GNOMEREGAN"] = "Armure ancestrale de Gnomeregan"
L["BTWQUESTS_HERITAGE_OF_KEZAN"] = "Armure ancestrale de Kezan"
L["BTWQUESTS_HERITAGE_OF_THE_BRONZEBEARD"] = "Armure ancestrale des Barbe-de-Bronze"
L["BTWQUESTS_HERITAGE_OF_THE_SHUHALO"] = "Armure ancestrale des Shu’halo"
L["BTWQUESTS_HERITAGE_OF_THE_SINDOREI"] = "Armure ancestrale des Sin’dorei"
L["BTWQUESTS_MAGHAR_ORC"] = "Orc mag’har"
L["BTWQUESTS_NIGHT_WARRIOR_NIGHT_ELF_CUSTOMIZATION"] = "personnalisation pour les Elfes de la nuit."
L["BTWQUESTS_PROGRESS_THE_WAR_CAMPAIGN"] = "Progression Campagne Militaire"
L["BTWQUESTS_THE_WAR_CAMPAIGN"] = "La campagne militaire"
L["BTWQUESTS_THE_WAR_CAMPAIGN_8_1"] = "La campagne militaire: La bataille de Dazar’alor"
L["BTWQUESTS_WARFRONT_THE_BATTLE_FOR_DARKSHORE"] = "Front de guerre : la bataille de Sombrivage"
L["DUNGEON_KINGS_REST"] = "Donjon : Repos des rois"
L["DUNGEON_SIEGE_OF_BORALUS"] = "Donjon : Siège de Boralus"
L["MECHAGNOME"] = "Mécagnome"
L["VULPERA"] = "Vulpérin"
L["WAIST_OF_TIME"] = "Boucle temporelle"
