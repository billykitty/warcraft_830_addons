----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "ptBR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateObjectsTable({
    [244983] = {
        name = "Relógio de Bolso Sujo",
    },
    [270917] = {
        name = "Registros de Arroio do Vale",
    },
    [271706] = {
        name = "Quadro de Caçadores",
    },
    [272179] = {
        name = "Mural do Prefeito",
    },
    [272422] = {
        name = "Grimório do Gentil",
    },
    [273814] = {
        name = "Amuleto Laminado",
    },
    [273854] = {
        name = "Mochila",
    },
    [276251] = {
        name = "Inventário de Escavação",
    },
    [276488] = {
        name = "Bala de Canhão de Azerita",
    },
    [276513] = {
        name = "Muçum Intacto",
    },
    [276515] = {
        name = "Vara de Pescar",
    },
    [276837] = {
        name = "Rocha de Receita",
    },
    [277199] = {
        name = "Lista de Afazeres Surrada",
    },
    [277373] = {
        name = "Algas Marinhas Luzentes",
    },
    [277459] = {
        name = "Efígie do Porco",
    },
    [278197] = {
        name = "Ampola de Antídoto",
    },
    [278252] = {
        name = "Panfleto de Trabalho",
    },
    [278313] = {
        name = "Carta de Palavras Severas",
    },
    [278368] = {
        name = "Nota Esfarrapada",
    },
    [278447] = {
        name = "Lança de Coureador Ímpio",
    },
    [278570] = {
        name = "Diário Ancestral",
    },
    [278577] = {
        name = "Carta Rasgada da Horda",
    },
    [278669] = {
        name = "Livro de Registros de Refúgio Outonal",
    },
    [278675] = {
        name = "Efígie Amaldiçoada",
    },
    [279337] = {
        name = "Grimório Sangra-coração",
    },
    [279646] = {
        name = "Crônicas da Guarda de Sangue",
    },
    [279647] = {
        name = "Tomo do Sacrifício",
    },
    [280576] = {
        name = "Pergaminho Embrulhado",
    },
    [280727] = {
        name = "Bilhete Chamuscado",
    },
    [281230] = {
        name = "Convite Formal",
    },
    [281348] = {
        name = "Carta Arruinada",
    },
    [281551] = {
        name = "Cartaz de Oferta de Serviço",
    },
    [281583] = {
        name = "Relicário Antigo",
    },
    [281639] = {
        name = "Estátua Desmoronante",
    },
    [281647] = {
        name = "Divulgação",
    },
    [281673] = {
        name = "Diário de Cidadão de Corlain",
    },
    [281718] = {
        name = "PRECISA-SE DE AJUDA",
    },
    [282457] = {
        name = "Totem de Guarda Espinhoso",
    },
    [282478] = {
        name = "Caixote Vazio",
    },
    [282498] = {
        name = "Flauta do Deserto",
    },
    [284426] = {
        name = "Máquina de Mineração Enterrada",
    },
    [286016] = {
        name = "Registro de Bordo",
    },
    [287081] = {
        name = "Tabuleta Ancestral",
    },
    [287185] = {
        name = "Procura-se: Orador Sombrio Jo'la",
    },
    [287189] = {
        name = "Procura-se: Feras Perigosas",
    },
    [287228] = {
        name = "PROCURA-SE: Cronista das Trevas",
    },
    [287229] = {
        name = "PROCURA-SE: Cronista das Trevas",
    },
    [287232] = {
        name = "Relatório de Patrulha",
    },
    [287327] = {
        name = "Relatório de Patrulha",
    },
    [287398] = {
        name = "Procura-se: Za'roco",
    },
    [287440] = {
        name = "Procura-se: Taz'raka",
    },
    [287441] = {
        name = "Procura-se: Batedor de Areia Vesarik",
    },
    [287442] = {
        name = "Procura-se: participantes para a excursão da naja",
    },
    [287958] = {
        name = "Quadro de Avisos",
    },
    [288157] = {
        name = "Procura-se: Yarsel'ghun",
    },
    [288167] = {
        name = "Pacote de Maria",
    },
    [288214] = {
        name = "Cartaz de Procura-se",
    },
    [288622] = {
        name = "Cartaz de Procura-se",
    },
    [288641] = {
        name = "PROCURA-SE: Sequestradores de Grifos",
    },
    [289310] = {
        name = "PROCURA-SE: Terraguarda Enraivecido",
    },
    [289313] = {
        name = "PROCURA-SE: O Marimbondo",
    },
    [289361] = {
        name = "PROCURA-SE: Intendente Ssylis",
    },
    [289365] = {
        name = "Cartaz de Procura-se",
    },
    [289728] = {
        name = "Mapa do Tesouro do Capitão Gulnaku",
    },
    [290138] = {
        name = "Bomba-robô Pressurizada",
    },
    [290419] = {
        name = "Cartaz de Procura-se",
    },
    [290537] = {
        name = "Precisa-se",
    },
    [290750] = {
        name = "Reserva Jambani",
    },
    [290765] = {
        name = "Grande Pilha de Ouro",
    },
    [290993] = {
        name = "Saque dos Maré-férrea",
    },
    [291143] = {
        name = "A chave de Ranah",
    },
    [291291] = {
        name = "Procura-se: Larápio",
    },
    [292523] = {
        name = "Cartaz de Procura-se",
    },
    [293567] = {
        name = "Cartaz de Procura-se",
    },
    [293568] = {
        name = "Cartaz de Procura-se",
    },
    [293985] = {
        name = "Procura-se: Horror da Guerra",
    },
    [297492] = {
        name = "Quadro de Avisos",
    },
    [298778] = {
        name = "Cartaz de Procura-se",
    },
    [298849] = {
        name = "Cartaz de Procura-se",
    },
    [298858] = {
        name = "Cartaz de Procura-se",
    },
    [307748] = {
        name = "Carta da Empreendimentos S.A.",
    },
    [309498] = {
        name = "Estande de Armaduras",
    },
    [311155] = {
        name = "Tabuleta Ancestral",
    },
    [311218] = {
        name = "Xal'atath, a Lâmina do Império Negro",
    },
    [311885] = {
        name = "Xal'atath, a Lâmina do Império Negro",
    },
    [322533] = {
        name = "Tomo do Elementos de Mardivas",
    },
    [326393] = {
        name = "Depósito de Armas de Azerita",
    },
    [326418] = {
        name = "Baú Arcano",
    },
    [326588] = {
        name = "Depósito de Armas de Azerita",
    },
    [327170] = {
        name = "Cavalete de Armas",
    },
    [327591] = {
        name = "Diário Preservado",
    },
    [327592] = {
        name = "Fechadura Encantada",
    },
    [327596] = {
        name = "Foco Abissal Partido",
    },
    [329805] = {
        name = "Cristal Estranho",
    },
})
]])()
