----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "esES" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Sacar sangre",
    },
    [44785] = {
        name = "Tomar el té",
    },
    [45079] = {
        name = "La aldea de Valarroyo",
    },
    [45972] = {
        name = "El matorral maldito",
    },
    [46727] = {
        name = "Mareas de guerra",
    },
    [46728] = {
        name = "La nación de Kul Tiras",
    },
    [46729] = {
        name = "El viejo caballero",
    },
    [46846] = {
        name = "La palabra de Zul",
    },
    [46926] = {
        name = "Esto es una redada",
    },
    [46927] = {
        name = "El castigo de Tal'aman",
    },
    [46928] = {
        name = "El castigo de Tal'farrak",
    },
    [46929] = {
        name = "Elemento disuasorio",
    },
    [46931] = {
        name = "Portavoz de la Horda",
    },
    [46957] = {
        name = "Bienvenidos a Zuldazar",
    },
    [47098] = {
        name = "Flynn del encierro",
    },
    [47099] = {
        name = "Visita turística",
    },
    [47103] = {
        name = "Viaje a Nazmir",
    },
    [47105] = {
        name = "En la oscuridad",
    },
    [47130] = {
        name = "Entierro indecoroso",
    },
    [47181] = {
        name = "La pistola humeante",
    },
    [47186] = {
        name = "Santuario de los Sabios",
    },
    [47188] = {
        name = "La ayuda de los loa",
    },
    [47189] = {
        name = "Una nación dividida",
    },
    [47198] = {
        name = "Nos quieren vivos",
    },
    [47199] = {
        name = "La Puerta de Sangre",
    },
    [47200] = {
        name = "Garrapatas",
    },
    [47204] = {
        name = "El nuevo frente",
    },
    [47205] = {
        name = "Matriarca de guerra",
    },
    [47226] = {
        name = "La prole huérfana",
    },
    [47228] = {
        name = "Ecología de Xibala",
    },
    [47229] = {
        name = "El baluarte de Torcali",
    },
    [47235] = {
        name = "Localiza el ojo",
    },
    [47241] = {
        name = "La sombra de la muerte",
    },
    [47244] = {
        name = "Una matanza de almas",
    },
    [47245] = {
        name = "Captar el mensaje",
    },
    [47247] = {
        name = "Lo que atormenta a los muertos",
    },
    [47248] = {
        name = "Hasta que la muerte nos separe",
    },
    [47249] = {
        name = "Ligado al alma",
    },
    [47250] = {
        name = "Volveremos a vernos",
    },
    [47257] = {
        name = "Los huesos de Xibala",
    },
    [47258] = {
        name = "Preparación para un asedio",
    },
    [47259] = {
        name = "Guardería de cuernoatroces",
    },
    [47260] = {
        name = "Posibles efectos secundarios...",
    },
    [47261] = {
        name = "Cómo entrenar a tu cuernoatroz",
    },
    [47262] = {
        name = "Acabar con los trols de sangre",
    },
    [47263] = {
        name = "Tiempo de revelaciones",
    },
    [47264] = {
        name = "Que no quede ni uno en pie",
    },
    [47272] = {
        name = "Hormona de crecimiento cuernoatroz",
    },
    [47289] = {
        name = "Té y peluches",
    },
    [47310] = {
        name = "La siesta",
    },
    [47311] = {
        name = "Introducción a los cabezazos",
    },
    [47312] = {
        name = "Reinapluma",
    },
    [47313] = {
        name = "Conversaciones discretas",
    },
    [47314] = {
        name = "Rumores de exilio",
    },
    [47315] = {
        name = "Hacia las dunas",
    },
    [47316] = {
        name = "Secretos en la arena",
    },
    [47317] = {
        name = "Búsqueda de supervivientes",
    },
    [47319] = {
        name = "Veneno reconstituyente",
    },
    [47320] = {
        name = "Bálsamo balsámico",
    },
    [47321] = {
        name = "Recuperación de chismes",
    },
    [47322] = {
        name = "Huida con ayuda",
    },
    [47324] = {
        name = "Aliados insólitos",
    },
    [47327] = {
        name = "Responder a sus ataques",
    },
    [47329] = {
        name = "El legado Mirasangre",
    },
    [47332] = {
        name = "Tu siguiente paso",
    },
    [47418] = {
        name = "Los problemas crecen",
    },
    [47422] = {
        name = "Situación extrema",
    },
    [47423] = {
        name = "Prácticas prohibidas",
    },
    [47428] = {
        name = "¿Minino?",
    },
    [47432] = {
        name = "El trato está cerrado",
    },
    [47433] = {
        name = "Ofensivamente defensivo",
    },
    [47434] = {
        name = "Orden de alejamiento",
    },
    [47435] = {
        name = "Disputa pterritorial",
    },
    [47437] = {
        name = "Devoción competitiva",
    },
    [47438] = {
        name = "Elegir bando",
    },
    [47439] = {
        name = "Gonk, señor de la manada",
    },
    [47440] = {
        name = "Pa'ku, maestra de los vientos",
    },
    [47441] = {
        name = "Alimañas",
    },
    [47442] = {
        name = "Maldición de Jani",
    },
    [47445] = {
        name = "El Consejo Zanchuli",
    },
    [47485] = {
        name = "La Compañía Comercial Gobernalle",
    },
    [47486] = {
        name = "Envíos sospechosos",
    },
    [47487] = {
        name = "Disputa laboral",
    },
    [47488] = {
        name = "Pequeños transportistas",
    },
    [47489] = {
        name = "Viajar por la cara",
    },
    [47491] = {
        name = "Restos de los Malditos",
    },
    [47497] = {
        name = "Conoce a la banda Colmillo Dorado",
    },
    [47498] = {
        name = "El amigo perdido de Rhan'ka",
    },
    [47499] = {
        name = "Los ídolos sonrientes",
    },
    [47501] = {
        name = "Trabajo sucio con bebidas sucias",
    },
    [47502] = {
        name = "El gran golpe de los cráneos",
    },
    [47503] = {
        name = "Gozda'kun el Esclavista",
    },
    [47509] = {
        name = "El Bancal de los Elegidos",
    },
    [47520] = {
        name = "Las paredes oyen",
    },
    [47521] = {
        name = "Medianoche en el Jardín de los Loa",
    },
    [47522] = {
        name = "El cazador",
    },
    [47525] = {
        name = "Pemanecer oculto",
    },
    [47527] = {
        name = "Rituales heréticos",
    },
    [47528] = {
        name = "La maestra de las mentiras",
    },
    [47540] = {
        name = "Restauración totémica",
    },
    [47564] = {
        name = "Reabastecer el bufé",
    },
    [47570] = {
        name = "Motivos ocultos",
    },
    [47571] = {
        name = "La sabiduría del anciano",
    },
    [47573] = {
        name = "Infestación Selvaraña",
    },
    [47574] = {
        name = "Tela de telas",
    },
    [47576] = {
        name = "Cólera del tigre",
    },
    [47577] = {
        name = "Vinieron del mar",
    },
    [47578] = {
        name = "Marca de los loa",
    },
    [47580] = {
        name = "La maldición de Mepjila",
    },
    [47581] = {
        name = "Bendición de Kimbul",
    },
    [47583] = {
        name = "Muere, muere, diemetradón",
    },
    [47584] = {
        name = "Una espina en el costado",
    },
    [47585] = {
        name = "Depredadores",
    },
    [47586] = {
        name = "Cazar al cazador",
    },
    [47587] = {
        name = "Rebanacabezas Jo",
    },
    [47596] = {
        name = "No hay plan \"B\"",
    },
    [47597] = {
        name = "Ningún goblin se queda atrás",
    },
    [47598] = {
        name = "Pillaje para el mercado negro",
    },
    [47599] = {
        name = "Venganza: sírvase caliente",
    },
    [47601] = {
        name = "Evaluación sobre el terreno",
    },
    [47602] = {
        name = "A punto para la acción",
    },
    [47621] = {
        name = "Un festín digno de un loa",
    },
    [47622] = {
        name = "Un fulgor mágico",
    },
    [47623] = {
        name = "El último médico brujo de Krag'wa",
    },
    [47631] = {
        name = "Reunión con la Libación",
    },
    [47638] = {
        name = "Poderosos espíritus",
    },
    [47647] = {
        name = "Monstruos de Zem'lan",
    },
    [47659] = {
        name = "Cazar al cazador",
    },
    [47660] = {
        name = "Ídolos caídos",
    },
    [47695] = {
        name = "Dar la alarma",
    },
    [47696] = {
        name = "Krag'wa el Terrible",
    },
    [47697] = {
        name = "La ayuda de Krag'wa",
    },
    [47706] = {
        name = "La caza del rey Ka'tal",
    },
    [47711] = {
        name = "La cabeza de la víbora",
    },
    [47716] = {
        name = "Explorar las ruinas",
    },
    [47733] = {
        name = "La traición de la portavoz de los loa",
    },
    [47734] = {
        name = "Compañeros de herejía",
    },
    [47735] = {
        name = "Remedios tortolianos antiguos",
    },
    [47736] = {
        name = "Rodarán cabezas",
    },
    [47737] = {
        name = "El Templo de Rezan",
    },
    [47738] = {
        name = "La voluntad de los loa",
    },
    [47739] = {
        name = "El aroma de la venganza",
    },
    [47740] = {
        name = "La casa del rey",
    },
    [47741] = {
        name = "Sacrificar a un loa",
    },
    [47742] = {
        name = "El motín de Zul",
    },
    [47755] = {
        name = "Cautivos y cautivados",
    },
    [47756] = {
        name = "La liberación de la Libación",
    },
    [47797] = {
        name = "Gajes del oficio",
    },
    [47868] = {
        name = "La Necrópolis",
    },
    [47870] = {
        name = "Los muertos no hablan",
    },
    [47871] = {
        name = "Artículos imprescindibles para el mar",
    },
    [47873] = {
        name = "El alijo del capitán",
    },
    [47874] = {
        name = "Despejar la niebla",
    },
    [47880] = {
        name = "Un tributo a la muerte",
    },
    [47894] = {
        name = "Salta",
    },
    [47897] = {
        name = "Traidores Zanchuli",
    },
    [47915] = {
        name = "Rescata a los cautivos",
    },
    [47918] = {
        name = "Al servicio de Krag'wa",
    },
    [47919] = {
        name = "Di no al canibalismo",
    },
    [47924] = {
        name = "Filtro de profanidad",
    },
    [47925] = {
        name = "Shoak está en el menú",
    },
    [47928] = {
        name = "Ofrenda para el loa",
    },
    [47939] = {
        name = "Si la llave encaja...",
    },
    [47943] = {
        name = "A la caza del cangrejo",
    },
    [47945] = {
        name = "¡Al mercado!",
    },
    [47946] = {
        name = "Salvarles el beicon",
    },
    [47947] = {
        name = "Lobos feroces",
    },
    [47948] = {
        name = "Chuleta de cerdo",
    },
    [47949] = {
        name = "Ese no es mi fetiche",
    },
    [47950] = {
        name = "Jamón curado",
    },
    [47952] = {
        name = "La flota desaparecida",
    },
    [47959] = {
        name = "El rastro de la guardia bélica",
    },
    [47960] = {
        name = "Estrecho de Tiragarde",
    },
    [47962] = {
        name = "Valle Canto Tormenta",
    },
    [47963] = {
        name = "La antigua",
    },
    [47965] = {
        name = "El templo en ruinas",
    },
    [47968] = {
        name = "Señales y presagios",
    },
    [47969] = {
        name = "La maldición de Albergue del Ocaso",
    },
    [47978] = {
        name = "La vieja bruja díscola",
    },
    [47979] = {
        name = "Caza de brujas",
    },
    [47980] = {
        name = "Fauna furiosa",
    },
    [47981] = {
        name = "Romper el maleficio",
    },
    [47982] = {
        name = "La última efigie",
    },
    [47996] = {
        name = "Exterminación de faucemalignas",
    },
    [47998] = {
        name = "Matar caníbales",
    },
    [48003] = {
        name = "El mandato del señor",
    },
    [48004] = {
        name = "Equitación para principiantes",
    },
    [48005] = {
        name = "Déjanos invitarte",
    },
    [48008] = {
        name = "Cargamento peligroso",
    },
    [48009] = {
        name = "Traición del guardián",
    },
    [48014] = {
        name = "Chusma fuera",
    },
    [48015] = {
        name = "Los pergaminos de Gral",
    },
    [48025] = {
        name = "Guárdalas para luego",
    },
    [48026] = {
        name = "Bajo las olas",
    },
    [48070] = {
        name = "El festival de Norwington",
    },
    [48077] = {
        name = "La caza del armiño",
    },
    [48080] = {
        name = "La emoción de la caza",
    },
    [48087] = {
        name = "Recuperación equina",
    },
    [48088] = {
        name = "Nada como una fiesta con troggs",
    },
    [48089] = {
        name = "Sonidos de montaña",
    },
    [48090] = {
        name = "Los elegidos de Krag'wa",
    },
    [48092] = {
        name = "La venganza de las ranas",
    },
    [48093] = {
        name = "Nagar la amenaza",
    },
    [48104] = {
        name = "Un desafío aún mayor",
    },
    [48108] = {
        name = "La hija de los Crestavía",
    },
    [48109] = {
        name = "El bosque tiene ojos",
    },
    [48110] = {
        name = "En caso de emboscada",
    },
    [48111] = {
        name = "Juicio por superstición",
    },
    [48113] = {
        name = "Una acre solución",
    },
    [48165] = {
        name = "Ingesta nociva",
    },
    [48170] = {
        name = "Pica que te pica",
    },
    [48171] = {
        name = "La maldición de Cuenca del Flechero",
    },
    [48179] = {
        name = "Rescate de forestales",
    },
    [48180] = {
        name = "Todo un problemón",
    },
    [48181] = {
        name = "Naaaaaah",
    },
    [48182] = {
        name = "Del-hito grave",
    },
    [48183] = {
        name = "Las colinas están vivas",
    },
    [48184] = {
        name = "Fragmentos de historia",
    },
    [48195] = {
        name = "Trogloditas problemáticos",
    },
    [48196] = {
        name = "Tras la pista de Eddie",
    },
    [48198] = {
        name = "La verdad duele",
    },
    [48237] = {
        name = "Derrota a Nekthara",
    },
    [48283] = {
        name = "Acusación",
    },
    [48313] = {
        name = "Remedio de la naturaleza",
    },
    [48314] = {
        name = "Muerte acechante",
    },
    [48315] = {
        name = "Ojos huecos y vacíos",
    },
    [48317] = {
        name = "Olfato para la magia",
    },
    [48320] = {
        name = "Nunca se mata demasiado",
    },
    [48321] = {
        name = "Marketing creativo",
    },
    [48322] = {
        name = "Un recibimiento a lo Colmillo Dorado",
    },
    [48324] = {
        name = "Perdidos en Zem'lan",
    },
    [48326] = {
        name = "Esto es un motín",
    },
    [48327] = {
        name = "Una extraña entrega",
    },
    [48329] = {
        name = "Apaleado pero no sometido",
    },
    [48330] = {
        name = "Tesoro Zandalari",
    },
    [48331] = {
        name = "Succionando almas",
    },
    [48332] = {
        name = "Los ranishus son recursos",
    },
    [48334] = {
        name = "Tienen gólems",
    },
    [48335] = {
        name = "La cuerda más fuerte de Vol'dun",
    },
    [48347] = {
        name = "Embarcadero Puntamuelle",
    },
    [48348] = {
        name = "Aguijones punzantes",
    },
    [48352] = {
        name = "Una cura del mar",
    },
    [48353] = {
        name = "El cotarro del muelle",
    },
    [48354] = {
        name = "Envíos corruptos",
    },
    [48355] = {
        name = "Evacuar las instalaciones",
    },
    [48356] = {
        name = "Casco posesivo",
    },
    [48365] = {
        name = "El joven señor Canto Tormenta",
    },
    [48366] = {
        name = "Remar a lugar seguro",
    },
    [48367] = {
        name = "Eso no son huevos de pez",
    },
    [48368] = {
        name = "Profanación del fondo del mar",
    },
    [48369] = {
        name = "Estrategia emergente",
    },
    [48370] = {
        name = "Muerte en las profundidades",
    },
    [48372] = {
        name = "Invocaciones sobrenaturales",
    },
    [48399] = {
        name = "Una marea de Hierro Negro",
    },
    [48400] = {
        name = "Hurto mayor de telemancia",
    },
    [48402] = {
        name = "Un toque ponzoñoso",
    },
    [48404] = {
        name = "Los Malandrines",
    },
    [48405] = {
        name = "Don Amable",
    },
    [48419] = {
        name = "Atraídos y fascinados",
    },
    [48421] = {
        name = "Sangre en las mareas",
    },
    [48452] = {
        name = "El Mercado Rojo",
    },
    [48454] = {
        name = "Las pruebas de la corrupción",
    },
    [48456] = {
        name = "Médica bruja Jala",
    },
    [48468] = {
        name = "La liberación de Bwonsamdi",
    },
    [48473] = {
        name = "Respetar los ritos",
    },
    [48474] = {
        name = "Guardianes de la cripta",
    },
    [48475] = {
        name = "Ver espíritus",
    },
    [48476] = {
        name = "Grupo dividido",
    },
    [48477] = {
        name = "Buscar una más",
    },
    [48478] = {
        name = "El hogar de Kel'vax",
    },
    [48479] = {
        name = "Huesos protectores",
    },
    [48480] = {
        name = "La caída de Kel'vax",
    },
    [48492] = {
        name = "A piernas sueltas",
    },
    [48496] = {
        name = "Reunificar la compañía",
    },
    [48497] = {
        name = "Demostración de fuerza",
    },
    [48498] = {
        name = "No hay piedad para Sithis",
    },
    [48499] = {
        name = "Polvo eres y polvo serás",
    },
    [48504] = {
        name = "Por los viejos caminos",
    },
    [48505] = {
        name = "Perdido y con mal de amores",
    },
    [48515] = {
        name = "Hojas de plata",
    },
    [48516] = {
        name = "Comunidad tóxica",
    },
    [48517] = {
        name = "Despedida con honores",
    },
    [48518] = {
        name = "Salvar a los que podamos",
    },
    [48519] = {
        name = "Ojalá no sepan nadar",
    },
    [48520] = {
        name = "Las tres hermanas",
    },
    [48521] = {
        name = "El talismán de los inertes",
    },
    [48522] = {
        name = "Una misiva reveladora",
    },
    [48523] = {
        name = "La matriarca asesina",
    },
    [48524] = {
        name = "La matanza del aquelarre",
    },
    [48525] = {
        name = "Hacerlos astillas",
    },
    [48527] = {
        name = "Tiburones de tierra voraces",
    },
    [48529] = {
        name = "Bocas hambrientas que alimentar",
    },
    [48530] = {
        name = "Manada extraviada",
    },
    [48531] = {
        name = "Carne misteriosa",
    },
    [48532] = {
        name = "Alpacas enloquecidas",
    },
    [48533] = {
        name = "Pollo frito de Vol'dun",
    },
    [48534] = {
        name = "La última carcajada de Morrogruñe",
    },
    [48535] = {
        name = "Nazmir, el pantano prohibido",
    },
    [48538] = {
        name = "Una coartada impecable",
    },
    [48539] = {
        name = "Fuerte Libre",
    },
    [48540] = {
        name = "Ayuda para el Embarcadero",
    },
    [48549] = {
        name = "Grozztok Corazón Negro",
    },
    [48550] = {
        name = "Bolsas robadas",
    },
    [48551] = {
        name = "Mucho marchito",
    },
    [48553] = {
        name = "Que fluya",
    },
    [48554] = {
        name = "El origen del problema",
    },
    [48555] = {
        name = "Podemos salvar las semillas",
    },
    [48557] = {
        name = "Sembrar retoños",
    },
    [48558] = {
        name = "La banda Marea de Hierro",
    },
    [48573] = {
        name = "Vida de crocolisco",
    },
    [48574] = {
        name = "Colmillos fuera",
    },
    [48576] = {
        name = "Volar seguro",
    },
    [48577] = {
        name = "Aterrar sus huevos",
    },
    [48578] = {
        name = "Desojar al aterracielos",
    },
    [48581] = {
        name = "Una buena azotaina",
    },
    [48584] = {
        name = "La sangre de mis enemigos",
    },
    [48585] = {
        name = "Superviviente del páramo",
    },
    [48588] = {
        name = "Purgar la infección",
    },
    [48590] = {
        name = "Mi cabeza y mis hombros",
    },
    [48591] = {
        name = "La verdadera muerte de Urok",
    },
    [48597] = {
        name = "Escape saurolisco",
    },
    [48606] = {
        name = "Cargado y listo",
    },
    [48616] = {
        name = "Boleadoras y aves voladoras",
    },
    [48622] = {
        name = "El señor evanescente",
    },
    [48655] = {
        name = "El aprendiz del chef",
    },
    [48656] = {
        name = "Sauroliscos ariscos",
    },
    [48657] = {
        name = "Podrían ser deliciosos",
    },
    [48669] = {
        name = "Urok, terror de Los Humedales",
    },
    [48670] = {
        name = "Jinete a la fuga",
    },
    [48677] = {
        name = "Culto del mimbre",
    },
    [48678] = {
        name = "Ofrendas cuestionables",
    },
    [48679] = {
        name = "Cuidado con las colmenas",
    },
    [48680] = {
        name = "¡Las abejas no!",
    },
    [48682] = {
        name = "Un simple sacrificio",
    },
    [48683] = {
        name = "Cambios estacionales",
    },
    [48684] = {
        name = "En marcha",
    },
    [48699] = {
        name = "Infiltración en Zalamar",
    },
    [48715] = {
        name = "Akunda espera",
    },
    [48773] = {
        name = "Documentación, por favor",
    },
    [48774] = {
        name = "Las palizas no paran",
    },
    [48776] = {
        name = "Jalando jarcias",
    },
    [48778] = {
        name = "Sopa de piedras",
    },
    [48790] = {
        name = "Suministros robados",
    },
    [48792] = {
        name = "Amenaza para la sociedad",
    },
    [48793] = {
        name = "La Sociedad de Aventureros",
    },
    [48800] = {
        name = "La marca del murciélago",
    },
    [48801] = {
        name = "Aislar Zalamar",
    },
    [48804] = {
        name = "Los errores cometidos",
    },
    [48805] = {
        name = "Recuperar lo investigado",
    },
    [48823] = {
        name = "Destrucción de proyección",
    },
    [48825] = {
        name = "Poder denegado",
    },
    [48840] = {
        name = "Marketing en las ruinas",
    },
    [48846] = {
        name = "Motivación líquida",
    },
    [48847] = {
        name = "Armas para la tribu",
    },
    [48852] = {
        name = "Detener a Zardrax",
    },
    [48853] = {
        name = "Grado terminal",
    },
    [48854] = {
        name = "Oferta de poder",
    },
    [48855] = {
        name = "Cura de humildad a los terrores",
    },
    [48856] = {
        name = "Interrupción de conductos",
    },
    [48857] = {
        name = "No hay esperanza",
    },
    [48869] = {
        name = "La venganza del exánime",
    },
    [48871] = {
        name = "Rescatar las reliquias",
    },
    [48872] = {
        name = "Acelerar la excavación",
    },
    [48873] = {
        name = "Sin pardón",
    },
    [48874] = {
        name = "Óxido traidor",
    },
    [48879] = {
        name = "A la caza de huevos de halcón",
    },
    [48880] = {
        name = "Gaviotas chungas",
    },
    [48881] = {
        name = "Qué caña de cañas",
    },
    [48882] = {
        name = "Vivan las vísceras de pez",
    },
    [48883] = {
        name = "Las gaviotas grandes no mueren",
    },
    [48887] = {
        name = "Purificar la mente",
    },
    [48888] = {
        name = "Es eterna",
    },
    [48889] = {
        name = "Reparar el pasado",
    },
    [48890] = {
        name = "Cómo ser un trol de sangre",
    },
    [48894] = {
        name = "Prueba de verdad",
    },
    [48895] = {
        name = "La ofrenda perfecta",
    },
    [48896] = {
        name = "Sabiduría del pasado",
    },
    [48898] = {
        name = "Talismán de la suerte",
    },
    [48899] = {
        name = "La seguridad ante todo",
    },
    [48902] = {
        name = "Energía monstruosa",
    },
    [48903] = {
        name = "El caballo perfecto, cómo no",
    },
    [48904] = {
        name = "Buen cebo",
    },
    [48905] = {
        name = "Pergaminos minusvalorados",
    },
    [48909] = {
        name = "Nobles responsabilidades",
    },
    [48934] = {
        name = "La marca de los Malditos",
    },
    [48939] = {
        name = "Veamos de qué eres capaz",
    },
    [48941] = {
        name = "Un ligero desvío",
    },
    [48942] = {
        name = "Yetis peleones",
    },
    [48943] = {
        name = "Derecho de saqueo",
    },
    [48944] = {
        name = "Desvelar la historia",
    },
    [48945] = {
        name = "Las ruinas de Gol Var",
    },
    [48946] = {
        name = "La Orden de Ascuas",
    },
    [48948] = {
        name = "Las Cavernas del Paso del Norte",
    },
    [48963] = {
        name = "Tácticas de distracción",
    },
    [48965] = {
        name = "Ajuste de cuentas",
    },
    [48986] = {
        name = "Por el paso alto",
    },
    [48987] = {
        name = "Valle de la Desdicha",
    },
    [48988] = {
        name = "Incursión en la memoria",
    },
    [48991] = {
        name = "Infestación vil",
    },
    [48992] = {
        name = "Restos sagrados",
    },
    [48993] = {
        name = "Poderosos conductores",
    },
    [48996] = {
        name = "Acabar con la locura",
    },
    [49001] = {
        name = "Espíritus inoportunos",
    },
    [49002] = {
        name = "Aterrizaje forzoso",
    },
    [49003] = {
        name = "Venganza desde el cielo",
    },
    [49005] = {
        name = "Destrozados y rotos",
    },
    [49028] = {
        name = "Un suéter para Rupert",
    },
    [49036] = {
        name = "Lo mejor del certamen",
    },
    [49039] = {
        name = "El principio de una caza de monstruos",
    },
    [49040] = {
        name = "Despedidas sentidas",
    },
    [49059] = {
        name = "Los huesos de Xibala",
    },
    [49060] = {
        name = "Ecología de Xibala",
    },
    [49064] = {
        name = "Torga, el loa tortuga",
    },
    [49066] = {
        name = "Revestimiento frío",
    },
    [49067] = {
        name = "Suplicar a Bwonsamdi",
    },
    [49069] = {
        name = "SE BUSCA: Viejo Garrascarcha",
    },
    [49070] = {
        name = "Almas para el loa de muerte",
    },
    [49071] = {
        name = "Combustión de garrapaterrores",
    },
    [49072] = {
        name = "Noble a occidente",
    },
    [49078] = {
        name = "Envenenar a la camada",
    },
    [49079] = {
        name = "Hir'eek, el loa murciélago",
    },
    [49080] = {
        name = "Detener toda invocación",
    },
    [49081] = {
        name = "Matar a un loa",
    },
    [49082] = {
        name = "Arriba y adelante",
    },
    [49120] = {
        name = "Comunicación de ultratumba",
    },
    [49122] = {
        name = "Un puerto en peligro",
    },
    [49125] = {
        name = "Sangre negativa",
    },
    [49126] = {
        name = "Forzar la mano del destino",
    },
    [49130] = {
        name = "Dieta baja en loa",
    },
    [49131] = {
        name = "Terreno de santificación",
    },
    [49132] = {
        name = "Triturar a los trituracráneos",
    },
    [49136] = {
        name = "Jungo, heraldo de G'huun",
    },
    [49138] = {
        name = "El tesoro del capitán Gulnaku",
    },
    [49139] = {
        name = "El arsenal de un ejército",
    },
    [49141] = {
        name = "Diplomacia y dominancia",
    },
    [49144] = {
        name = "Cólera de los Zandalari",
    },
    [49145] = {
        name = "Ningún trol se quedará atrás",
    },
    [49146] = {
        name = "Pertenencias de los espíritus",
    },
    [49147] = {
        name = "Demostración de fuerza",
    },
    [49148] = {
        name = "Desmoronamiento",
    },
    [49149] = {
        name = "Entrégate al vudú",
    },
    [49160] = {
        name = "El retorno eterno de Torga",
    },
    [49178] = {
        name = "Mis cosas favoritas",
    },
    [49181] = {
        name = "Guardapelo reluciente",
    },
    [49185] = {
        name = "Ponerse al día",
    },
    [49218] = {
        name = "Los náufragos",
    },
    [49223] = {
        name = "El gran engaño",
    },
    [49225] = {
        name = "Tras la jefa",
    },
    [49226] = {
        name = "Silenciar a las hermanas",
    },
    [49227] = {
        name = "La llave maestra",
    },
    [49229] = {
        name = "El contraataque de las ruinas",
    },
    [49230] = {
        name = "Sabor local",
    },
    [49232] = {
        name = "Recuperarse de un desastre",
    },
    [49233] = {
        name = "Soy druida, no sacerdote",
    },
    [49234] = {
        name = "Como marino fuera del agua",
    },
    [49239] = {
        name = "Vístete para impresionar",
    },
    [49242] = {
        name = "Mala espina",
    },
    [49259] = {
        name = "Y justicia para todos",
    },
    [49260] = {
        name = "Ojo mientras recojo",
    },
    [49261] = {
        name = "Estofado para una tripulación malhumorada",
    },
    [49262] = {
        name = "Bandas no",
    },
    [49268] = {
        name = "Tiburones en el agua",
    },
    [49274] = {
        name = "La inspección de Morgrum",
    },
    [49276] = {
        name = "La emoción de la exploración",
    },
    [49278] = {
        name = "Restauración espiritual",
    },
    [49282] = {
        name = "La prolongada inspección de Morgrum",
    },
    [49283] = {
        name = "¿Quién busca a los buscadores?",
    },
    [49284] = {
        name = "En el momento oportuno",
    },
    [49285] = {
        name = "Minitesoros",
    },
    [49286] = {
        name = "Confinamiento con fin",
    },
    [49287] = {
        name = "Quelonios perdidos",
    },
    [49288] = {
        name = "Cazadores de pergaminos",
    },
    [49289] = {
        name = "Una piedra especial",
    },
    [49290] = {
        name = "Añejado a la perfección",
    },
    [49292] = {
        name = "Batidos de algas",
    },
    [49295] = {
        name = "Cortes limpios",
    },
    [49299] = {
        name = "Enemigo interno",
    },
    [49300] = {
        name = "Corrupción de criaturas",
    },
    [49302] = {
        name = "La presa más mortífera",
    },
    [49309] = {
        name = "La caída del Trueno",
    },
    [49310] = {
        name = "El complot del profeta",
    },
    [49314] = {
        name = "A por Zardrax",
    },
    [49315] = {
        name = "Conspiración Perlatriste",
    },
    [49327] = {
        name = "¡Hacedlos retroceder!",
    },
    [49333] = {
        name = "Aumentar nuestro arsenal",
    },
    [49334] = {
        name = "Un poderoso prisionero",
    },
    [49335] = {
        name = "Matanza de clamacielos",
    },
    [49340] = {
        name = "Las llaves de los guardianes",
    },
    [49348] = {
        name = "Un templo profanado",
    },
    [49366] = {
        name = "Ayudar a los heridos",
    },
    [49370] = {
        name = "Rescata al cronista",
    },
    [49375] = {
        name = "[LARRY TEST QUEST]",
    },
    [49377] = {
        name = "¡Que le corten la cabeza!",
    },
    [49378] = {
        name = "Gánate su confianza",
    },
    [49379] = {
        name = "Zona libre de tragadones",
    },
    [49380] = {
        name = "Mal yuyu",
    },
    [49382] = {
        name = "Parece que has hecho un amigo",
    },
    [49393] = {
        name = "Los Bellacos",
    },
    [49394] = {
        name = "No te muevas",
    },
    [49395] = {
        name = "Código panal",
    },
    [49398] = {
        name = "¡Arriba ese vaso!",
    },
    [49399] = {
        name = "El gran trabajo",
    },
    [49400] = {
        name = "Trabajo de reclutamiento",
    },
    [49401] = {
        name = "El nidal de Rodrigo",
    },
    [49402] = {
        name = "Aves a la fuga",
    },
    [49403] = {
        name = "La venganza de Rodrigo",
    },
    [49404] = {
        name = "Los \"amigos\" de Vientopropicio",
    },
    [49405] = {
        name = "Los defensores de la Puerta de Daelin",
    },
    [49406] = {
        name = "Matanza de Zalamar",
    },
    [49407] = {
        name = "Lo de Trixie",
    },
    [49408] = {
        name = "Dado pirata",
    },
    [49409] = {
        name = "¡Tesoro desaparecido!",
    },
    [49411] = {
        name = "Construir cuartel",
    },
    [49412] = {
        name = "Ayudar a Henry",
    },
    [49417] = {
        name = "Jinetes Bellacos",
    },
    [49418] = {
        name = "Gran jefe",
    },
    [49419] = {
        name = "Congelado",
    },
    [49421] = {
        name = "Caza a Zul",
    },
    [49422] = {
        name = "Herejes",
    },
    [49424] = {
        name = "La profecía completa",
    },
    [49425] = {
        name = "La ciudad de oro",
    },
    [49426] = {
        name = "La táctica del rey",
    },
    [49427] = {
        name = "No son nuestros elfos púrpura",
    },
    [49428] = {
        name = "Hurto mayor de telemancia",
    },
    [49431] = {
        name = "Cálido y acogedor",
    },
    [49432] = {
        name = "El alma melancólica",
    },
    [49433] = {
        name = "Wendis",
    },
    [49435] = {
        name = "¿Adónde han ido?",
    },
    [49437] = {
        name = "Nota ajada",
    },
    [49439] = {
        name = "Venganza de jefe",
    },
    [49440] = {
        name = "Trol de sangre por fuera",
    },
    [49443] = {
        name = "Una lección sobre la caza de brujas",
    },
    [49450] = {
        name = "Informes de incidentes",
    },
    [49451] = {
        name = "Peticiones de días libres",
    },
    [49452] = {
        name = "Déficit de inventario",
    },
    [49453] = {
        name = "Buena presa",
    },
    [49454] = {
        name = "Prevención de la peste",
    },
    [49464] = {
        name = "Colas de saurolisco",
    },
    [49465] = {
        name = "Maximizar recursos",
    },
    [49467] = {
        name = "Bruja del Bosque",
    },
    [49468] = {
        name = "Asistencia obligatoria",
    },
    [49477] = {
        name = "Refuerzos sorpresa",
    },
    [49479] = {
        name = "No se pararon a pensar si debían",
    },
    [49489] = {
        name = "Necesita algo de cuerpo",
    },
    [49490] = {
        name = "La urna de voces",
    },
    [49491] = {
        name = "Combustible para el vudú",
    },
    [49492] = {
        name = "La arrogancia de Vol'jamba",
    },
    [49493] = {
        name = "El dilema ético de Zul",
    },
    [49494] = {
        name = "Brebaje zuvembi",
    },
    [49495] = {
        name = "Forzar el destino",
    },
    [49522] = {
        name = "El pago de Carentan",
    },
    [49523] = {
        name = "Un mal trato",
    },
    [49529] = {
        name = "Limpieza general",
    },
    [49531] = {
        name = "La belleza del marketing",
    },
    [49569] = {
        name = "Junto al río",
    },
    [49570] = {
        name = "Un comienzo pedregoso",
    },
    [49571] = {
        name = "Escarbar en el pasado",
    },
    [49572] = {
        name = "El altar del mar",
    },
    [49573] = {
        name = "El altar del manto nocturno",
    },
    [49574] = {
        name = "El altar de las tormentas",
    },
    [49575] = {
        name = "Tol Dagor: Joya de las mareas",
    },
    [49576] = {
        name = "Grandes posibilidades",
    },
    [49577] = {
        name = "Rajar la superficie",
    },
    [49581] = {
        name = "Dunas moteadas de sol",
    },
    [49582] = {
        name = "Atal'Dazar: No todo lo que reluce...",
    },
    [49583] = {
        name = "Fuera lo viejo",
    },
    [49584] = {
        name = "El capítulo perdido",
    },
    [49585] = {
        name = "Un comienzo pedregoso",
    },
    [49586] = {
        name = "Escarbar en el pasado",
    },
    [49587] = {
        name = "El altar de la naturaleza",
    },
    [49588] = {
        name = "El altar de las arenas",
    },
    [49589] = {
        name = "El altar del amanecer",
    },
    [49599] = {
        name = "El capítulo perdido",
    },
    [49615] = {
        name = "La confianza de un rey",
    },
    [49661] = {
        name = "Huevos de cercanía",
    },
    [49662] = {
        name = "La llave desaparecida",
    },
    [49663] = {
        name = "Falsas profecías",
    },
    [49664] = {
        name = "Aliados en la anarquía",
    },
    [49665] = {
        name = "Listos para los disturbios",
    },
    [49666] = {
        name = "Que nos teman",
    },
    [49667] = {
        name = "Los pequeñines",
    },
    [49668] = {
        name = "Iluminar el barranco",
    },
    [49669] = {
        name = "Soltar a las bestias",
    },
    [49676] = {
        name = "Vestida para la batalla",
    },
    [49677] = {
        name = "Planes de ataque",
    },
    [49678] = {
        name = "Estruja la aguja",
    },
    [49679] = {
        name = "La incursión sethrak",
    },
    [49680] = {
        name = "Clamacielos Soltok",
    },
    [49681] = {
        name = "Pequeña Tika",
    },
    [49694] = {
        name = "Giro a Drust",
    },
    [49703] = {
        name = "La casa Canto Tormenta",
    },
    [49704] = {
        name = "Cosechadores fuera de control",
    },
    [49705] = {
        name = "Fuerza innecesaria",
    },
    [49706] = {
        name = "Investigación de las proclamas",
    },
    [49710] = {
        name = "Oferta de huevos",
    },
    [49715] = {
        name = "Problemas en la Fortaleza Petragrís",
    },
    [49716] = {
        name = "Lección de confianza",
    },
    [49719] = {
        name = "Hora de cobrar",
    },
    [49720] = {
        name = "Pájaro libre",
    },
    [49725] = {
        name = "Una estratagema arriesgada",
    },
    [49730] = {
        name = "SE BUSCA: Hocicotrueno",
    },
    [49731] = {
        name = "Despedidas sentidas",
    },
    [49733] = {
        name = "De remiendos",
    },
    [49734] = {
        name = "A por un traidor",
    },
    [49735] = {
        name = "Protección para los nidos",
    },
    [49736] = {
        name = "¡Por Kul Tiras!",
    },
    [49737] = {
        name = "Asalto aéreo",
    },
    [49738] = {
        name = "¡Mi botín no se toca!",
    },
    [49739] = {
        name = "Enemigos a las puertas",
    },
    [49740] = {
        name = "¡Alto el fuego!",
    },
    [49741] = {
        name = "Castigo merecido",
    },
    [49744] = {
        name = "Bombas fuera",
    },
    [49745] = {
        name = "Tienes sus órdenes",
    },
    [49746] = {
        name = "Sofocar las llamas",
    },
    [49753] = {
        name = "Arsenal de ensamblajes",
    },
    [49754] = {
        name = "No \"solo Zul\"",
    },
    [49755] = {
        name = "Artillería pesada",
    },
    [49757] = {
        name = "La gata sobre el tejado de cobre",
    },
    [49758] = {
        name = "¡Envía la señal!",
    },
    [49759] = {
        name = "Taller de ensamblajes",
    },
    [49766] = {
        name = "Tu siguiente paso",
    },
    [49767] = {
        name = "Tu siguiente paso",
    },
    [49768] = {
        name = "Travesía de Nesingwary",
    },
    [49769] = {
        name = "Restos del Cataclismo",
    },
    [49774] = {
        name = "No dejaré que muera",
    },
    [49775] = {
        name = "La llave del calabozo",
    },
    [49776] = {
        name = "El alquitrán lo arregla todo",
    },
    [49777] = {
        name = "La fuga",
    },
    [49778] = {
        name = "No vayas hacia la luz",
    },
    [49779] = {
        name = "Malo hasta la médula",
    },
    [49780] = {
        name = "Recuperar el fuego antiguo",
    },
    [49781] = {
        name = "Atrápame si puedes",
    },
    [49785] = {
        name = "Destruye el arma",
    },
    [49791] = {
        name = "Perdidos, pero no olvidados",
    },
    [49792] = {
        name = "Anclados y oprimidos",
    },
    [49793] = {
        name = "Medios para un fin",
    },
    [49794] = {
        name = "La marea creciente",
    },
    [49801] = {
        name = "Estrategia de apareamiento agresiva",
    },
    [49803] = {
        name = "Cambio de guardia",
    },
    [49804] = {
        name = "Ingenio afilado",
    },
    [49805] = {
        name = "Útiles de viles intenciones",
    },
    [49806] = {
        name = "Tratos ocultos",
    },
    [49807] = {
        name = "Una nueva orden",
    },
    [49810] = {
        name = "Alcahueta de monstruos",
    },
    [49814] = {
        name = "Aroma para un brutosaurio",
    },
    [49818] = {
        name = "Problemas en el Fuerte Daelin",
    },
    [49831] = {
        name = "De las profundidades",
    },
    [49832] = {
        name = "Un pergamino ilegible",
    },
    [49869] = {
        name = "Una defensa desesperada",
    },
    [49870] = {
        name = "El tamaño importa",
    },
    [49871] = {
        name = "Contra la marea",
    },
    [49873] = {
        name = "Escritos de sacrificio",
    },
    [49874] = {
        name = "Según las normas",
    },
    [49876] = {
        name = "Líneas en la arena",
    },
    [49877] = {
        name = "Templo de Sethraliss: cobrar un favor",
    },
    [49878] = {
        name = "Cerco de protección",
    },
    [49879] = {
        name = "Roce con la muerte",
    },
    [49881] = {
        name = "El último verso",
    },
    [49882] = {
        name = "Una prueba de plumas",
    },
    [49884] = {
        name = "La luz azul de la esperanza",
    },
    [49886] = {
        name = "Haz caso a tu olfato",
    },
    [49887] = {
        name = "Trabajos forzados",
    },
    [49890] = {
        name = "Ocaso Drust",
    },
    [49896] = {
        name = "¡A Médano del Halcón!",
    },
    [49897] = {
        name = "Crear misterio",
    },
    [49898] = {
        name = "Victoria clara",
    },
    [49901] = {
        name = "Atal'Dazar: Yazma, la sacerdotisa caída",
    },
    [49902] = {
        name = "Rumbo a la Cuenca Tenebrosa",
    },
    [49905] = {
        name = "Giro argumental",
    },
    [49908] = {
        name = "Regreso a Brennadam",
    },
    [49917] = {
        name = "¿Kaja'mita? ¡Venga!",
    },
    [49918] = {
        name = "Desfiladero de los Gorilas",
    },
    [49919] = {
        name = "A por la mena de kaja'mita",
    },
    [49920] = {
        name = "Guerra de gorilas",
    },
    [49922] = {
        name = "Rey Da'ka",
    },
    [49926] = {
        name = "El camino a Corlain",
    },
    [49932] = {
        name = "Fin de la hibernación",
    },
    [49935] = {
        name = "Cómo reparar un guardián de los titanes",
    },
    [49937] = {
        name = "Recuperar restos",
    },
    [49938] = {
        name = "Tierra corrupta",
    },
    [49939] = {
        name = "Adiós, hermana",
    },
    [49940] = {
        name = "Brecha Tajoarena",
    },
    [49941] = {
        name = "Procesamiento de huesos",
    },
    [49943] = {
        name = "Sacar sangre",
    },
    [49944] = {
        name = "Giro a Drust",
    },
    [49946] = {
        name = "Líneas en la arena",
    },
    [49949] = {
        name = "No-muertos no deseados",
    },
    [49950] = {
        name = "Purificación de sangre",
    },
    [49955] = {
        name = "No aptos para este plano",
    },
    [49956] = {
        name = "Vacío prohibido",
    },
    [49957] = {
        name = "Recuperación del protocolo",
    },
    [49960] = {
        name = "¡Ataca!",
    },
    [49965] = {
        name = "La manada de guerra",
    },
    [49969] = {
        name = "Despertar a un dios",
    },
    [49975] = {
        name = "Descanso en las profundidades",
    },
    [49980] = {
        name = "Procedimiento de contención",
    },
    [49985] = {
        name = "Regreso a la Cuenca Tenebrosa",
    },
    [49995] = {
        name = "Invenciones inventadas",
    },
    [49996] = {
        name = "Rearme",
    },
    [49997] = {
        name = "Sentencia de la tormenta",
    },
    [49998] = {
        name = "Las voces de las profundidades",
    },
    [50001] = {
        name = "Fin de la fada",
    },
    [50002] = {
        name = "Un cargamento precioso",
    },
    [50003] = {
        name = "La primera guardia",
    },
    [50005] = {
        name = "Cógeme de la mano",
    },
    [50009] = {
        name = "Cuadrilla de recuperación de naufragios",
    },
    [50026] = {
        name = "Salvar a los compañeros",
    },
    [50036] = {
        name = "Un arma de antaño",
    },
    [50041] = {
        name = "Un puñado de cartuchos",
    },
    [50043] = {
        name = "Eficiencia arqueológica",
    },
    [50044] = {
        name = "Eficiencia arqueológica",
    },
    [50058] = {
        name = "La mascota de la bruja",
    },
    [50059] = {
        name = "No oigo nada",
    },
    [50063] = {
        name = "Luchar con fuego",
    },
    [50064] = {
        name = "No bajes al sótano",
    },
    [50065] = {
        name = "Un motivo para quedarse",
    },
    [50069] = {
        name = "Guerra de Campodorado",
    },
    [50074] = {
        name = "Subidón brutal",
    },
    [50076] = {
        name = "Reúne a los guerreros",
    },
    [50078] = {
        name = "Tótems inmortales",
    },
    [50079] = {
        name = "La bomba que va a estallar",
    },
    [50080] = {
        name = "Asaltar a los asaltantes",
    },
    [50081] = {
        name = "La senda del dolor",
    },
    [50082] = {
        name = "Objetivo a tiro",
    },
    [50083] = {
        name = "La Madre de Tragadones",
    },
    [50085] = {
        name = "Un mensaje de sangre y fuego",
    },
    [50087] = {
        name = "La caída de Ateena",
    },
    [50088] = {
        name = "Eternos campos dorados",
    },
    [50090] = {
        name = "Levantar defensas",
    },
    [50091] = {
        name = "Obras de reparación",
    },
    [50092] = {
        name = "Curiosamente fuerte",
    },
    [50110] = {
        name = "Portadores de malas noticias",
    },
    [50111] = {
        name = "¡Tótems, tótems, tótems!",
    },
    [50112] = {
        name = "Lanzar la primera piedra",
    },
    [50113] = {
        name = "Extractos oculares",
    },
    [50114] = {
        name = "Interrogando a martillazos",
    },
    [50115] = {
        name = "Cambio de ambiente",
    },
    [50116] = {
        name = "Intercambio equivalente",
    },
    [50117] = {
        name = "Un jarabe letal",
    },
    [50118] = {
        name = "A un tiro de piedra",
    },
    [50119] = {
        name = "Agravamiento químico",
    },
    [50120] = {
        name = "La receta del éxito",
    },
    [50121] = {
        name = "Lanzar la primera piedra",
    },
    [50122] = {
        name = "Extractos oculares",
    },
    [50123] = {
        name = "Una receta imperecedera",
    },
    [50124] = {
        name = "Cambio de ambiente",
    },
    [50125] = {
        name = "Intercambio equivalente",
    },
    [50126] = {
        name = "Un jarabe letal",
    },
    [50127] = {
        name = "A un tiro de piedra",
    },
    [50128] = {
        name = "Agravamiento químico",
    },
    [50129] = {
        name = "La receta del éxito",
    },
    [50133] = {
        name = "Desbrozo",
    },
    [50134] = {
        name = "Artilugios y cacharros a tutiplén",
    },
    [50135] = {
        name = "¡Parra ya!",
    },
    [50136] = {
        name = "Estimulación agrícola",
    },
    [50138] = {
        name = "La batalla del Barranco Fuegosangre",
    },
    [50139] = {
        name = "El eslabón perdido",
    },
    [50149] = {
        name = "Ojo avizor",
    },
    [50150] = {
        name = "Preparar el ambiente",
    },
    [50151] = {
        name = "Un lastre estable",
    },
    [50152] = {
        name = "Escarbar en busca de restos",
    },
    [50154] = {
        name = "Dicen que es un manjar",
    },
    [50157] = {
        name = "Hay oro en esos campos",
    },
    [50158] = {
        name = "Un vistazo al hundimiento",
    },
    [50161] = {
        name = "Recuperar a Raimond",
    },
    [50162] = {
        name = "Situación peliaguda",
    },
    [50165] = {
        name = "El equipo B",
    },
    [50168] = {
        name = "Sucesión real",
    },
    [50172] = {
        name = "Hacia Floracarmesí",
    },
    [50173] = {
        name = "Metales preciosos",
    },
    [50174] = {
        name = "Todo envuelto",
    },
    [50175] = {
        name = "Una maldición de ocho patas",
    },
    [50177] = {
        name = "¡Aguanta en la barricada!",
    },
    [50178] = {
        name = "Problemas en Sendarraíz",
    },
    [50195] = {
        name = "Brigada de Batequilla",
    },
    [50206] = {
        name = "Contraataca",
    },
    [50235] = {
        name = "Sin refugio seguro",
    },
    [50238] = {
        name = "Gujaespino",
    },
    [50240] = {
        name = "Lapsus",
    },
    [50249] = {
        name = "Triple amenaza para Boralus",
    },
    [50251] = {
        name = "Vinculados",
    },
    [50252] = {
        name = "Descanso en la temporada de apareamiento",
    },
    [50253] = {
        name = "Un arsenal improvisado",
    },
    [50264] = {
        name = "Liberar a los mozos de labranza",
    },
    [50265] = {
        name = "Salvar al maestro Ashton",
    },
    [50266] = {
        name = "Agridulce",
    },
    [50268] = {
        name = "Darle sustancia",
    },
    [50270] = {
        name = "En lo más hondo del núcleo",
    },
    [50271] = {
        name = "Pega y pilla",
    },
    [50272] = {
        name = "Misión arrastrada",
    },
    [50274] = {
        name = "Forja titánica",
    },
    [50275] = {
        name = "Yunque va",
    },
    [50276] = {
        name = "Una receta imperecedera",
    },
    [50277] = {
        name = "Interrogando a martillazos",
    },
    [50278] = {
        name = "En lo más hondo del núcleo",
    },
    [50279] = {
        name = "Yunque va",
    },
    [50288] = {
        name = "Elección de Therazane",
    },
    [50297] = {
        name = "La cabeza de su enemigo",
    },
    [50306] = {
        name = "Cachivaches",
    },
    [50325] = {
        name = "Detener el gran ritual",
    },
    [50327] = {
        name = "Un pequeño \"reconstituyente\"",
    },
    [50328] = {
        name = "Aromas poco convencionales",
    },
    [50329] = {
        name = "Matriarcas Floracarmesí",
    },
    [50331] = {
        name = "Un resultado distinto",
    },
    [50332] = {
        name = "El Gran Cazador",
    },
    [50340] = {
        name = "Robarles a ellos",
    },
    [50343] = {
        name = "Caos en la Granja de Hidromiel Mildenhall",
    },
    [50349] = {
        name = "Una mina invadida",
    },
    [50350] = {
        name = "Necesitamos un químico",
    },
    [50351] = {
        name = "Operación de minería",
    },
    [50352] = {
        name = "Una pizca de azerita",
    },
    [50353] = {
        name = "Compañía jabalina",
    },
    [50354] = {
        name = "¡Ojo!",
    },
    [50356] = {
        name = "Piedra, papel o dinamita",
    },
    [50359] = {
        name = "Servicio de limpieza",
    },
    [50363] = {
        name = "Cerdos de guerra",
    },
    [50365] = {
        name = "Huyamos a las montañas",
    },
    [50367] = {
        name = "Rabia embotellada",
    },
    [50368] = {
        name = "Terror del Horado",
    },
    [50370] = {
        name = "En lo profundo del bosque",
    },
    [50376] = {
        name = "Alijo mortal: pez gordo",
    },
    [50381] = {
        name = "El gran robo del sombrero",
    },
    [50385] = {
        name = "Resolución incansable",
    },
    [50386] = {
        name = "Échalos",
    },
    [50387] = {
        name = "Abalorios y adornos",
    },
    [50388] = {
        name = "El peso de mi ambición",
    },
    [50389] = {
        name = "Inspiración maligna",
    },
    [50391] = {
        name = "Alijo mortal: pescando a cañonazos",
    },
    [50393] = {
        name = "Un vástago de Pa'ku",
    },
    [50394] = {
        name = "Ahora es tu problema",
    },
    [50395] = {
        name = "La llamada de los cielos",
    },
    [50396] = {
        name = "Un destino pterrible",
    },
    [50397] = {
        name = "Aspiraciones aéreas",
    },
    [50401] = {
        name = "Miedo a caer",
    },
    [50402] = {
        name = "¡PRIIII!",
    },
    [50412] = {
        name = "De vuelta al nido",
    },
    [50417] = {
        name = "La hora de la perdición",
    },
    [50418] = {
        name = "Alijo mortal: hundirse y nadar",
    },
    [50433] = {
        name = "La disolución de los Zanchuli",
    },
    [50444] = {
        name = "Por el camino de los loa",
    },
    [50445] = {
        name = "El control de la situación",
    },
    [50446] = {
        name = "Desgarrabrujas",
    },
    [50447] = {
        name = "Recordando a los caídos",
    },
    [50448] = {
        name = "Reclamar Corlain",
    },
    [50449] = {
        name = "Refugio hediondo",
    },
    [50450] = {
        name = "Una cosecha ofensiva",
    },
    [50451] = {
        name = "Comerse las defensas",
    },
    [50452] = {
        name = "Protección potente",
    },
    [50453] = {
        name = "Destructor de barreras",
    },
    [50454] = {
        name = "La muerte de un traidor",
    },
    [50455] = {
        name = "Abandonar el nido",
    },
    [50456] = {
        name = "Crías malditas",
    },
    [50457] = {
        name = "Abrirse paso",
    },
    [50466] = {
        name = "¡Se ha vuelto loco!",
    },
    [50481] = {
        name = "En el salón del rey Drust",
    },
    [50493] = {
        name = "Buscar a Wrex",
    },
    [50504] = {
        name = "Sam caramelizado",
    },
    [50520] = {
        name = "¿Dónde está Sam?",
    },
    [50530] = {
        name = "Fuera, bruja",
    },
    [50531] = {
        name = "Delante de sus narices",
    },
    [50533] = {
        name = "¡Dales duro!",
    },
    [50534] = {
        name = "Fuera wendigos",
    },
    [50535] = {
        name = "El poder de la sobrestante",
    },
    [50536] = {
        name = "Dispositivo decodificador mágico",
    },
    [50538] = {
        name = "El cuidador desaparecido",
    },
    [50539] = {
        name = "Los secretos de Zul'Ahjin",
    },
    [50542] = {
        name = "Una oportunidad explosiva",
    },
    [50544] = {
        name = "Los cazadores de la Residencia Kennings",
    },
    [50550] = {
        name = "La caída del emperador Korthek",
    },
    [50551] = {
        name = "Templo de Sethraliss: Avatar de los Loa",
    },
    [50553] = {
        name = "De vuelta al laboratorio",
    },
    [50561] = {
        name = "La piedra de Sulthis",
    },
    [50573] = {
        name = "Un mensaje de la dirección",
    },
    [50583] = {
        name = "Al otro lado",
    },
    [50584] = {
        name = "Rituales ruinosos",
    },
    [50585] = {
        name = "Brujicidio",
    },
    [50586] = {
        name = "La caída de Corlain",
    },
    [50588] = {
        name = "Asaltar la mansión",
    },
    [50593] = {
        name = "El sanguinariamiento",
    },
    [50594] = {
        name = "Bajo el velo",
    },
    [50595] = {
        name = "Sin cuartel",
    },
    [50596] = {
        name = "Exterminar a las alimañas",
    },
    [50598] = {
        name = "Imperio Zandalari",
    },
    [50599] = {
        name = "Almirantazgo de la Casa Valiente",
    },
    [50600] = {
        name = "Orden de Ascuas",
    },
    [50601] = {
        name = "El Despertar de la Tormenta",
    },
    [50602] = {
        name = "La Expedición de Talanji",
    },
    [50605] = {
        name = "Campaña bélica de la Alianza",
    },
    [50606] = {
        name = "Campaña bélica de la Horda",
    },
    [50608] = {
        name = "Ritos prohibidos",
    },
    [50609] = {
        name = "Desde las Fauces de la Locura",
    },
    [50610] = {
        name = "Tormenta inminente",
    },
    [50611] = {
        name = "La venganza de la tormenta",
    },
    [50612] = {
        name = "Una casa dividida",
    },
    [50614] = {
        name = "Libertad para el mar",
    },
    [50616] = {
        name = "Un pequeño aprieto",
    },
    [50621] = {
        name = "Atrapados en la red",
    },
    [50622] = {
        name = "Deal se ha ido",
    },
    [50635] = {
        name = "Las mareas cambiantes",
    },
    [50639] = {
        name = "Mansión Crestavía: La madre caída",
    },
    [50640] = {
        name = "Jabaquerer es jabapoder",
    },
    [50641] = {
        name = "Romper sus filas",
    },
    [50644] = {
        name = "Enfrentarse a los invasores",
    },
    [50645] = {
        name = "Caza mayor de anguilas",
    },
    [50649] = {
        name = "El que roba a un ladrón...",
    },
    [50653] = {
        name = "Retomando las defensas",
    },
    [50656] = {
        name = "Rescate arriesgado",
    },
    [50672] = {
        name = "Cualquier tipo de munición servirá",
    },
    [50674] = {
        name = "Escoria pirata por las dos caras",
    },
    [50675] = {
        name = "La caza del tesoro",
    },
    [50679] = {
        name = "Perforar el escudo",
    },
    [50690] = {
        name = "Con Moxie",
    },
    [50691] = {
        name = "Fuera de nómina",
    },
    [50696] = {
        name = "Diversión magnética",
    },
    [50697] = {
        name = "Bomba gana a roca",
    },
    [50698] = {
        name = "Pólvora para resolver problemas",
    },
    [50699] = {
        name = "Los derechos de los trabajadores",
    },
    [50700] = {
        name = "Drusto a tiempo",
    },
    [50702] = {
        name = "Derrotar a Jakra'zet",
    },
    [50703] = {
        name = "Informar a la Horda",
    },
    [50704] = {
        name = "Intentando levar anclas",
    },
    [50705] = {
        name = "Una serpiente de tres cabezas",
    },
    [50706] = {
        name = "Despejar el delta",
    },
    [50733] = {
        name = "Un nuevo amanecer",
    },
    [50739] = {
        name = "Asuntos perdidos",
    },
    [50741] = {
        name = "Tortugas no",
    },
    [50742] = {
        name = "Todo preparado",
    },
    [50743] = {
        name = "El problema inmediato",
    },
    [50745] = {
        name = "Infiltración en el imperio",
    },
    [50746] = {
        name = "Cráter conquistado",
    },
    [50748] = {
        name = "No la sueltes... aún",
    },
    [50749] = {
        name = "Viaje gratis",
    },
    [50750] = {
        name = "Enfurecer al emperador",
    },
    [50751] = {
        name = "Santuario bajo asedio",
    },
    [50752] = {
        name = "Reliquias de Sethraliss",
    },
    [50753] = {
        name = "Matar el gusanillo de Gual-I",
    },
    [50754] = {
        name = "Haber amado y perdido",
    },
    [50755] = {
        name = "Una festín para los pájaros",
    },
    [50757] = {
        name = "Matanza sin domesticar",
    },
    [50758] = {
        name = "Recuerdos dolorosos",
    },
    [50759] = {
        name = "Con demora",
    },
    [50760] = {
        name = "De hoy en adelante",
    },
    [50761] = {
        name = "Sangre en la capilla",
    },
    [50762] = {
        name = "El destino de la dama",
    },
    [50763] = {
        name = "Una última petición",
    },
    [50769] = {
        name = "Extracción en Ventormenta",
    },
    [50770] = {
        name = "Antídoto eficaz",
    },
    [50771] = {
        name = "Invocación: limpiador",
    },
    [50773] = {
        name = "Eres un tiburón",
    },
    [50774] = {
        name = "Ningún robot se queda atrás",
    },
    [50775] = {
        name = "A por una playa",
    },
    [50777] = {
        name = "La tormenta despierta",
    },
    [50778] = {
        name = "Intenciones retorcidas",
    },
    [50779] = {
        name = "Borrón y cuenta nueva",
    },
    [50780] = {
        name = "Leal al juramento",
    },
    [50781] = {
        name = "Un puente muy lejano",
    },
    [50783] = {
        name = "El Consejo Abisal",
    },
    [50784] = {
        name = "El ojo de la tormenta",
    },
    [50787] = {
        name = "Exponer nuestros argumentos",
    },
    [50788] = {
        name = "Enemigos dentro",
    },
    [50789] = {
        name = "Purificar el aire",
    },
    [50790] = {
        name = "Caza sin cuartel",
    },
    [50791] = {
        name = "Prrii...",
    },
    [50793] = {
        name = "Alboroto en la cueva",
    },
    [50794] = {
        name = "En busca de refugio",
    },
    [50795] = {
        name = "Prepararse para los problemas",
    },
    [50796] = {
        name = "¡PRIIII!",
    },
    [50797] = {
        name = "Invitación de una tortuga",
    },
    [50798] = {
        name = "A jugársela",
    },
    [50801] = {
        name = "Olfato para los pterrorblemas",
    },
    [50802] = {
        name = "Marea de Hierro baja",
    },
    [50803] = {
        name = "Lo quiero todo ahora",
    },
    [50805] = {
        name = "Desactivación de clamacielos",
    },
    [50808] = {
        name = "Detener la caída del imperio",
    },
    [50810] = {
        name = "Libéralos",
    },
    [50812] = {
        name = "Elementos despiertos",
    },
    [50814] = {
        name = "Un lugar horrible",
    },
    [50817] = {
        name = "Una cola encantadora",
    },
    [50818] = {
        name = "Una flauta perdida",
    },
    [50824] = {
        name = "Fin Tormentoso",
    },
    [50825] = {
        name = "Altar de la Tormenta: Susurros en las profundidades",
    },
    [50834] = {
        name = "¡Ese ruido!",
    },
    [50835] = {
        name = "El puerto de Zandalar",
    },
    [50838] = {
        name = "Olfato para los pterroblemas",
    },
    [50839] = {
        name = "¡PRIIII!",
    },
    [50841] = {
        name = "¡PRIIII!",
    },
    [50842] = {
        name = "Efecto de mástil",
    },
    [50860] = {
        name = "Olfato para los pterroblemas",
    },
    [50881] = {
        name = "Informe real",
    },
    [50886] = {
        name = "Alas postizas",
    },
    [50887] = {
        name = "Pérdida de confianza",
    },
    [50897] = {
        name = "Volver las tornas",
    },
    [50900] = {
        name = "Tal vez cuando seas mayor",
    },
    [50901] = {
        name = "Sorpresa de sáurido",
    },
    [50903] = {
        name = "Un maestro desaparecido",
    },
    [50904] = {
        name = "El Pasaje Abandonado",
    },
    [50908] = {
        name = "Huele a problemas",
    },
    [50909] = {
        name = "Que por armas no sea",
    },
    [50910] = {
        name = "Juego peligroso",
    },
    [50911] = {
        name = "Un hombre contra la Horda",
    },
    [50912] = {
        name = "Remezcla con ignición",
    },
    [50913] = {
        name = "Bendición de Akunda",
    },
    [50929] = {
        name = "La pólvora para el pueblo",
    },
    [50930] = {
        name = "Caer con estilo",
    },
    [50933] = {
        name = "Un evento desafortunado",
    },
    [50934] = {
        name = "Avistamiento fortuito",
    },
    [50940] = {
        name = "Sabiduría de los sin alas",
    },
    [50942] = {
        name = "Vestido para la ocasión correcta",
    },
    [50943] = {
        name = "La alegría de volar",
    },
    [50944] = {
        name = "Derribado pero no acabado",
    },
    [50953] = {
        name = "Acechaverde",
    },
    [50954] = {
        name = "¡Zandalar eterno!",
    },
    [50955] = {
        name = "No somos amigos",
    },
    [50956] = {
        name = "Dinero ambulante",
    },
    [50959] = {
        name = "Piratas desvalijadores",
    },
    [50960] = {
        name = "Órdenes de Sweete",
    },
    [50963] = {
        name = "De actos oscuros y días oscuros",
    },
    [50965] = {
        name = "Las que quedan",
    },
    [50967] = {
        name = "Perdida en el bosque",
    },
    [50970] = {
        name = "El destino de un granjero",
    },
    [50972] = {
        name = "Negociación de la casa Valiente",
    },
    [50976] = {
        name = "Una maldición ancestral",
    },
    [50978] = {
        name = "Fuera el viejo jefe",
    },
    [50979] = {
        name = "Solo un pellizquito",
    },
    [50980] = {
        name = "Mi hambrienta vecina",
    },
    [50988] = {
        name = "Una oportunidad económica",
    },
    [50990] = {
        name = "Avicultura de vanguardia",
    },
    [51001] = {
        name = "Contrabando, que es gerundio",
    },
    [51018] = {
        name = "Es para un amigo",
    },
    [51019] = {
        name = "Cuando más se necesita",
    },
    [51020] = {
        name = "Prácticas comerciales agresivas",
    },
    [51052] = {
        name = "¡Azerita para la Alianza!",
    },
    [51053] = {
        name = "El día en que cayó el puerto",
    },
    [51054] = {
        name = "Un motín que ya tardaba",
    },
    [51055] = {
        name = "El penol de la ley",
    },
    [51056] = {
        name = "Mi último día con vida",
    },
    [51057] = {
        name = "Náufragos por fuego",
    },
    [51059] = {
        name = "La Isla Dorada",
    },
    [51060] = {
        name = "Nuestra parte del saqueo",
    },
    [51061] = {
        name = "La primera vez que fallecí",
    },
    [51062] = {
        name = "Fuga de Zem'lan",
    },
    [51069] = {
        name = "SE BUSCA: hablaoscuro Jo'la",
    },
    [51071] = {
        name = "SE BUSCA: emperatriz colmisable",
    },
    [51072] = {
        name = "SE BUSCA: goricate primigenio",
    },
    [51085] = {
        name = "SE BUSCA: Cronista oscuro",
    },
    [51087] = {
        name = "SE BUSCA: Cronista oscuro",
    },
    [51088] = {
        name = "Corazón de la Oscuridad",
    },
    [51089] = {
        name = "SE BUSCA: Tojek",
    },
    [51091] = {
        name = "SE BUSCA: Ten'gor y Nol'ixwan",
    },
    [51101] = {
        name = "El Rey herido",
    },
    [51111] = {
        name = "Rey o presa",
    },
    [51129] = {
        name = "Ofrenda dudosa",
    },
    [51134] = {
        name = "Si los huesos hablaran",
    },
    [51139] = {
        name = "SE BUSCA: Tojek",
    },
    [51140] = {
        name = "Las riquezas compartidas",
    },
    [51142] = {
        name = "Plagas",
    },
    [51144] = {
        name = "Un fardo de pelajes",
    },
    [51145] = {
        name = "Maldición de Jani",
    },
    [51146] = {
        name = "El día libre de Kua'fon",
    },
    [51147] = {
        name = "El día libre de Kua'fon",
    },
    [51149] = {
        name = "Olvidada en el puerto",
    },
    [51150] = {
        name = "En honor a los caídos",
    },
    [51151] = {
        name = "Una carta para la Liga",
    },
    [51159] = {
        name = "Hay que sacar el cañón gordo",
    },
    [51161] = {
        name = "SE BUSCA: Za'roco",
    },
    [51162] = {
        name = "SE BUSCA: Taz'raka el Traidor",
    },
    [51164] = {
        name = "Se buscan: participantes de la expedición Cobra",
    },
    [51165] = {
        name = "SE BUSCA: exploraarena Vesarik",
    },
    [51167] = {
        name = "Sangre de Hir'eek",
    },
    [51168] = {
        name = "Fanáticas de Zalamar",
    },
    [51169] = {
        name = "Vuelo desde La caída",
    },
    [51170] = {
        name = "¡Ooostras!",
    },
    [51177] = {
        name = "Lecciones de los Malditos",
    },
    [51190] = {
        name = "Indulto concedido",
    },
    [51191] = {
        name = "Sálvalos a todos",
    },
    [51192] = {
        name = "Con el género justito",
    },
    [51193] = {
        name = "Eso es mío",
    },
    [51199] = {
        name = "La gloria de la caza",
    },
    [51200] = {
        name = "La oveja negra",
    },
    [51201] = {
        name = "El relato del trol",
    },
    [51203] = {
        name = "Que viene el lobo",
    },
    [51204] = {
        name = "SE BUSCA: zarpador alfa",
    },
    [51205] = {
        name = "¡Oh, puñetas!",
    },
    [51207] = {
        name = "Cosas de ettins",
    },
    [51208] = {
        name = "Amigo del trigo",
    },
    [51209] = {
        name = "Poderoso Puñogrokk",
    },
    [51211] = {
        name = "El Corazón de Azeroth",
    },
    [51214] = {
        name = "Haz el favor",
    },
    [51215] = {
        name = "Ordeñar cabras",
    },
    [51217] = {
        name = "SE BUSCA: Yarsel'ghun",
    },
    [51218] = {
        name = "Paquete pendiente de entrega",
    },
    [51220] = {
        name = "Incursión en las profundidades",
    },
    [51221] = {
        name = "Respuesta requerida",
    },
    [51222] = {
        name = "Lo tuyo es mío",
    },
    [51224] = {
        name = "Beneficios y reconocimiento",
    },
    [51226] = {
        name = "Muerte a dos bandas",
    },
    [51229] = {
        name = "Estableciendo una cabeza de playa",
    },
    [51231] = {
        name = "Vicafobia",
    },
    [51233] = {
        name = "Espero que no haya brujas en las montañas",
    },
    [51234] = {
        name = "La Avanzada Pernochispa",
    },
    [51240] = {
        name = "SE BUSCA: Caraancla",
    },
    [51244] = {
        name = "Lo que se pudre debajo",
    },
    [51246] = {
        name = "El destrozo final",
    },
    [51247] = {
        name = "Las cosas que llevaban",
    },
    [51248] = {
        name = "Plagas útiles",
    },
    [51249] = {
        name = "Festín cangrejil",
    },
    [51251] = {
        name = "Habitantes del sótano",
    },
    [51278] = {
        name = "Perdidos y olvidados",
    },
    [51279] = {
        name = "Cultores Nazmani",
    },
    [51280] = {
        name = "Ofrendas a G'huun",
    },
    [51282] = {
        name = "Capitana Conrad",
    },
    [51283] = {
        name = "Viaje al oeste",
    },
    [51286] = {
        name = "Fin a la evacuación",
    },
    [51302] = {
        name = "Catacumbas Putrefactas: Sellar la corrupción de G'huun",
    },
    [51308] = {
        name = "Posición de Zuldazar",
    },
    [51309] = {
        name = "Rocas de Ragnaros",
    },
    [51310] = {
        name = "En busca de la cosecha perdida",
    },
    [51314] = {
        name = "Sangría de grano",
    },
    [51319] = {
        name = "El ascenso final",
    },
    [51320] = {
        name = "Destino sellado",
    },
    [51331] = {
        name = "Maquinaciones subterráneas",
    },
    [51332] = {
        name = "Un viaje a través del océano",
    },
    [51335] = {
        name = "Galletas con leche",
    },
    [51339] = {
        name = "Facturas de limpieza",
    },
    [51340] = {
        name = "¡Drustvar a la vista!",
    },
    [51341] = {
        name = "La hija del mar",
    },
    [51342] = {
        name = "Batalla por Stromgarde",
    },
    [51343] = {
        name = "Lecciones de natación",
    },
    [51349] = {
        name = "Moralmente obligado",
    },
    [51350] = {
        name = "Ayuda inesperada",
    },
    [51351] = {
        name = "Púas envenenadas",
    },
    [51352] = {
        name = "Con cerillas no se juega",
    },
    [51353] = {
        name = "Cueva de Ai'twen",
    },
    [51354] = {
        name = "Rabia embotellada",
    },
    [51356] = {
        name = "SE BUSCA: hermana Lilias",
    },
    [51357] = {
        name = "Armada y lista",
    },
    [51358] = {
        name = "SE BUSCA: ladrones de grifos",
    },
    [51359] = {
        name = "Fragmento de las Tierras de Fuego",
    },
    [51364] = {
        name = "Una huida explosiva",
    },
    [51366] = {
        name = "Aplicación del antídoto",
    },
    [51367] = {
        name = "SE BUSCA: guardián de tierra furioso",
    },
    [51368] = {
        name = "SE BUSCA: el Avispón",
    },
    [51369] = {
        name = "Amigos en lugares extraños",
    },
    [51370] = {
        name = "Recompensa de escasez de suministros",
    },
    [51371] = {
        name = "Ofrenda sabrosa",
    },
    [51384] = {
        name = "SE BUSCA: intendente Ssylis",
    },
    [51386] = {
        name = "Batalla victoriosa",
    },
    [51389] = {
        name = "Liberación",
    },
    [51390] = {
        name = "SE BUSCA: los Rebanacabezas Carmesís",
    },
    [51391] = {
        name = "Despojando a los infieles",
    },
    [51394] = {
        name = "A romper el asedio",
    },
    [51395] = {
        name = "Las llaves de los guardianes",
    },
    [51401] = {
        name = "Continúa",
    },
    [51402] = {
        name = "A la orden",
    },
    [51403] = {
        name = "El imperativo del portavoz",
    },
    [51407] = {
        name = "Busca sus palabras",
    },
    [51421] = {
        name = "Que me parta un rayo",
    },
    [51425] = {
        name = "Hogar, dulce hogar",
    },
    [51426] = {
        name = "Artilugio de inspección",
    },
    [51427] = {
        name = "Me gustan las tortugas",
    },
    [51430] = {
        name = "Trasteo inverso",
    },
    [51435] = {
        name = "Aventuras con estilo",
    },
    [51436] = {
        name = "Negociaciones con piratas",
    },
    [51437] = {
        name = "Un ponche saboteado",
    },
    [51438] = {
        name = "Marcar nuestro territorio",
    },
    [51439] = {
        name = "Colección de balas de cañón",
    },
    [51440] = {
        name = "Cambio de dirección",
    },
    [51441] = {
        name = "¡Por allí revienta!",
    },
    [51442] = {
        name = "Ahora soy yo el capitán",
    },
    [51443] = {
        name = "El objetivo de la misión",
    },
    [51445] = {
        name = "Thros, las Tierras Contagiadas",
    },
    [51465] = {
        name = "Un montón de chatarra",
    },
    [51472] = {
        name = "Conservadora de vida",
    },
    [51474] = {
        name = "Forjado con fuego y llama",
    },
    [51479] = {
        name = "Los incorruptos",
    },
    [51483] = {
        name = "Legado de los Hierro Negro",
    },
    [51484] = {
        name = "Legado de los Mag'har",
    },
    [51485] = {
        name = "Por la Horda",
    },
    [51486] = {
        name = "Por la Alianza",
    },
    [51487] = {
        name = "En busca de respuestas",
    },
    [51488] = {
        name = "Conocimientos archivados",
    },
    [51489] = {
        name = "Hora de irse",
    },
    [51490] = {
        name = "Problemas fronterizos",
    },
    [51492] = {
        name = "Conspiración de la pólvora",
    },
    [51504] = {
        name = "Entrega de galletas",
    },
    [51513] = {
        name = "El retorno de Zalazane",
    },
    [51514] = {
        name = "Trato roto",
    },
    [51515] = {
        name = "Venganza para Vol'jin",
    },
    [51516] = {
        name = "Atal'Dazar: Cenizas de un Jefe de Guerra",
    },
    [51517] = {
        name = "Ese es el espíritu",
    },
    [51518] = {
        name = "El espíritu perdido",
    },
    [51519] = {
        name = "Llamada del espíritu",
    },
    [51520] = {
        name = "Justicia para los caídos",
    },
    [51521] = {
        name = "La auténtica líder de Zandalar",
    },
    [51526] = {
        name = "La llamada del Señor de la Guerra",
    },
    [51532] = {
        name = "Asalto",
    },
    [51533] = {
        name = "Guja de Vol'jin",
    },
    [51534] = {
        name = "La Batalla por Brennadam",
    },
    [51536] = {
        name = "A la caza",
    },
    [51538] = {
        name = "Mensaje de las profundidades",
    },
    [51539] = {
        name = "¡Informa a la Horda!",
    },
    [51540] = {
        name = "Situación explosiva",
    },
    [51543] = {
        name = "Pimpollos en la nieve",
    },
    [51544] = {
        name = "Desarmar los cañones",
    },
    [51545] = {
        name = "Destruyendo que es gerundio",
    },
    [51547] = {
        name = "SE BUSCA: Azotecorteza",
    },
    [51552] = {
        name = "El día no tiene suficientes horas",
    },
    [51554] = {
        name = "Recargando",
    },
    [51555] = {
        name = "Mantenerlos centrados",
    },
    [51557] = {
        name = "Alerta de la Marea de Hierro",
    },
    [51569] = {
        name = "La campaña de Zandalar",
    },
    [51573] = {
        name = "Yo te cubro",
    },
    [51574] = {
        name = "Recién exprimido",
    },
    [51582] = {
        name = "Que sea Mildenhall",
    },
    [51587] = {
        name = "¡Adelante!",
    },
    [51589] = {
        name = "Quebrar la voluntad de Kul Tiras",
    },
    [51590] = {
        name = "Hacia el corazón de Tiragarde",
    },
    [51591] = {
        name = "Ahora es nuestra montaña",
    },
    [51592] = {
        name = "Estamos en nuestra casa",
    },
    [51593] = {
        name = "Investigación Puertopuente",
    },
    [51594] = {
        name = "Explosivos en la Fundición",
    },
    [51595] = {
        name = "Explosividad",
    },
    [51596] = {
        name = "Adquisición de munición",
    },
    [51597] = {
        name = "Investigación de la pólvora",
    },
    [51598] = {
        name = "Un poco de caos",
    },
    [51599] = {
        name = "Trampa mortal",
    },
    [51601] = {
        name = "Paseo por Puertopuente",
    },
    [51602] = {
        name = "Hojas de bandido",
    },
    [51643] = {
        name = "Un muro de hierro",
    },
    [51663] = {
        name = "Preparativos para la caída",
    },
    [51674] = {
        name = "Apagar las llamas",
    },
    [51675] = {
        name = "Hay que cazarlos",
    },
    [51677] = {
        name = "Reparación en cuerpo y alma",
    },
    [51678] = {
        name = "Dominio de Rastakhan",
    },
    [51679] = {
        name = "Extraño puerto de escala",
    },
    [51680] = {
        name = "A la sombra de Bwonsamdi",
    },
    [51689] = {
        name = "Rescate tortoliano",
    },
    [51691] = {
        name = "Casi dignos de salvar",
    },
    [51696] = {
        name = "Reclamamos lo que es nuestro",
    },
    [51711] = {
        name = "Me lo estoy pasando bomba",
    },
    [51712] = {
        name = "Ojo por ojo",
    },
    [51714] = {
        name = "Misión real",
    },
    [51715] = {
        name = "Guerra de Sombras",
    },
    [51717] = {
        name = "La mejor miel de Vol'dun",
    },
    [51718] = {
        name = "Recolección de \"miel\"",
    },
    [51720] = {
        name = "Triturado",
    },
    [51723] = {
        name = "Con serrín",
    },
    [51726] = {
        name = "Fuera de aquí",
    },
    [51728] = {
        name = "A quemarlo todo",
    },
    [51752] = {
        name = "Grizz no va más",
    },
    [51753] = {
        name = "Campeón: Rexxar",
    },
    [51770] = {
        name = "Misión de la jefa de guerra",
    },
    [51771] = {
        name = "Guerra en las sombras",
    },
    [51772] = {
        name = "La tribu Tortuka",
    },
    [51773] = {
        name = "La amenaza de Gobernalle",
    },
    [51775] = {
        name = "Campamento Última Brisa",
    },
    [51784] = {
        name = "Un paseo por un cementerio",
    },
    [51785] = {
        name = "Revisión de los epitafios",
    },
    [51786] = {
        name = "Sin descansar en paz",
    },
    [51787] = {
        name = "Lo que nos toca en la vida",
    },
    [51788] = {
        name = "El guardián de la cripta",
    },
    [51789] = {
        name = "Lo que queda del mariscal M. Valentine",
    },
    [51795] = {
        name = "La batalla por Lordaeron",
    },
    [51796] = {
        name = "La batalla por Lordaeron",
    },
    [51797] = {
        name = "En busca de Sabiomar",
    },
    [51798] = {
        name = "No hay precio excesivo",
    },
    [51803] = {
        name = "La campaña de Kul Tiras",
    },
    [51805] = {
        name = "Sabrán lo que es el miedo",
    },
    [51810] = {
        name = "Capitán Hartford",
    },
    [51813] = {
        name = "Profundidades de Roca Negra",
    },
    [51818] = {
        name = "Comandante y capitán",
    },
    [51819] = {
        name = "Dispersar al enemigo",
    },
    [51829] = {
        name = "Llave de Rinah",
    },
    [51830] = {
        name = "Potencial de Zelling",
    },
    [51837] = {
        name = "Lo que sea, será",
    },
    [51870] = {
        name = "Expedición insular",
    },
    [51881] = {
        name = "El barredor de minas",
    },
    [51888] = {
        name = "Expedición insular",
    },
    [51903] = {
        name = "Expedición insular",
    },
    [51904] = {
        name = "Expedición insular",
    },
    [51916] = {
        name = "La unión de Zandalar",
    },
    [51918] = {
        name = "La unión de Kul Tiras",
    },
    [51961] = {
        name = "La campaña en curso",
    },
    [51967] = {
        name = "Regreso a Boralus",
    },
    [51968] = {
        name = "Regreso a Boralus",
    },
    [51969] = {
        name = "Regreso a Boralus",
    },
    [51975] = {
        name = "Campeón: Cazador de las Sombras Ty'jin",
    },
    [51979] = {
        name = "La campaña en curso",
    },
    [51980] = {
        name = "SE BUSCA: Jabra'kan",
    },
    [51984] = {
        name = "Regreso a Zuldazar",
    },
    [51985] = {
        name = "Regreso a Zuldazar",
    },
    [51986] = {
        name = "Regreso a Zuldazar",
    },
    [51987] = {
        name = "Campeón: Hobart Martillazos",
    },
    [51990] = {
        name = "Alas para el redil",
    },
    [51991] = {
        name = "Cargando las baterías",
    },
    [51998] = {
        name = "HCC: ahora con cuernoatroz auténtico",
    },
    [52003] = {
        name = "Campeona: Kelsey Chispacero",
    },
    [52008] = {
        name = "Campeón: Magister Umbric",
    },
    [52013] = {
        name = "Campeón: John J. Keeshan",
    },
    [52026] = {
        name = "Asesinato en ultramar",
    },
    [52027] = {
        name = "El plan de Vol'dun",
    },
    [52028] = {
        name = "Peinando el desierto",
    },
    [52029] = {
        name = "Trabajo sucio",
    },
    [52030] = {
        name = "Sigue peinando",
    },
    [52031] = {
        name = "Relicario clásico",
    },
    [52032] = {
        name = "Peinar sin parar",
    },
    [52033] = {
        name = "SE BUSCA: Cazahelada",
    },
    [52034] = {
        name = "Un mensaje para los Zandalari",
    },
    [52035] = {
        name = "Supervivencia improvisada",
    },
    [52036] = {
        name = "Aquí tienen alpacas",
    },
    [52038] = {
        name = "La división",
    },
    [52039] = {
        name = "Mortificación retardada",
    },
    [52040] = {
        name = "Lleno de flechas",
    },
    [52041] = {
        name = "A las órdenes de Aterravermis",
    },
    [52042] = {
        name = "La gran explosión",
    },
    [52061] = {
        name = "¡Taptaf el cerdo!",
    },
    [52065] = {
        name = "Peor de lo que parece",
    },
    [52067] = {
        name = "Supervivientes",
    },
    [52068] = {
        name = "La ayuda en otra parte",
    },
    [52069] = {
        name = "Más carne de cañón",
    },
    [52070] = {
        name = "Apoyo de Bauer",
    },
    [52073] = {
        name = "Petición a Krag'wa",
    },
    [52074] = {
        name = "La entrega",
    },
    [52075] = {
        name = "Deshuesado",
    },
    [52113] = {
        name = "Vol'jin, hijo de Sen'jin",
    },
    [52114] = {
        name = "En honor a un auténtico líder",
    },
    [52122] = {
        name = "Cómo ser renegado",
    },
    [52127] = {
        name = "Guarida del Lobo",
    },
    [52128] = {
        name = "Pase de ferri",
    },
    [52129] = {
        name = "Problemas de carga",
    },
    [52130] = {
        name = "Alijo mortal: Carpe Diem",
    },
    [52131] = {
        name = "Nos necesitamos mutuamente",
    },
    [52132] = {
        name = "La prueba de piratería",
    },
    [52139] = {
        name = "Asuntos candentes",
    },
    [52146] = {
        name = "Sangre en la arena",
    },
    [52147] = {
        name = "Neutralizar a la Horda",
    },
    [52149] = {
        name = "Llama perpetua",
    },
    [52150] = {
        name = "Cómo matar a una forestal oscura",
    },
    [52151] = {
        name = "Una nación unida",
    },
    [52153] = {
        name = "Asedio de Boralus: El retorno de lady Gobernalle",
    },
    [52154] = {
        name = "Nuestro siguiente objetivo",
    },
    [52156] = {
        name = "Tortolianos en apuros",
    },
    [52158] = {
        name = "Caza salvaje",
    },
    [52170] = {
        name = "Acabar con Areiel",
    },
    [52171] = {
        name = "Una opción: fuego",
    },
    [52172] = {
        name = "No pueden quedarse aquí",
    },
    [52173] = {
        name = "Los elfos del Vacío están listos",
    },
    [52183] = {
        name = "Cuando los planes salen bien",
    },
    [52184] = {
        name = "Reliquias rituales",
    },
    [52185] = {
        name = "Un portal bien situado",
    },
    [52186] = {
        name = "El grueso de la guardia",
    },
    [52187] = {
        name = "Antiguos colegas",
    },
    [52188] = {
        name = "Enseñanzas Sabiomar",
    },
    [52189] = {
        name = "Almas confiscadas",
    },
    [52190] = {
        name = "Sacar ventaja",
    },
    [52191] = {
        name = "Vida secuestrada",
    },
    [52192] = {
        name = "La ayuda de las mareas",
    },
    [52194] = {
        name = "Lo que tal vez lamentes",
    },
    [52203] = {
        name = "Encuentra el rastro de papel",
    },
    [52204] = {
        name = "La solución del Vacío",
    },
    [52205] = {
        name = "El bum de la bonanza Pantoque",
    },
    [52208] = {
        name = "Encuentro en la cumbre",
    },
    [52210] = {
        name = "Enviar una llamada de socorro",
    },
    [52212] = {
        name = "Batalla por Stromgarde",
    },
    [52219] = {
        name = "Objetivo: Príncipe de sangre Dreven",
    },
    [52241] = {
        name = "Paraíso de codicia goblin",
    },
    [52246] = {
        name = "Envío perdido",
    },
    [52247] = {
        name = "Perseguir a Gallywix",
    },
    [52252] = {
        name = "Una entrada explosiva",
    },
    [52253] = {
        name = "La clave del éxito está en Fuerte Libre",
    },
    [52258] = {
        name = "A la rica concha",
    },
    [52259] = {
        name = "No disfruto con esto",
    },
    [52260] = {
        name = "Lo tenemos acorralado",
    },
    [52261] = {
        name = "Gallywix ha huido",
    },
    [52281] = {
        name = "En la protección de Alapresta",
    },
    [52282] = {
        name = "Cómo hundir un buque de combate Zandalari",
    },
    [52283] = {
        name = "Sabotear el Brisa de Pa'ku",
    },
    [52284] = {
        name = "Cuadernos de bitácora",
    },
    [52285] = {
        name = "El submarino miniaturizado agrandado",
    },
    [52286] = {
        name = "En sus propias narices",
    },
    [52287] = {
        name = "Información denegada",
    },
    [52288] = {
        name = "Vacaciones en el Vacío",
    },
    [52289] = {
        name = "La victoria está asegurada",
    },
    [52290] = {
        name = "El disfraz del enemigo de mi enemigo",
    },
    [52291] = {
        name = "La victoria estaba asegurada",
    },
    [52294] = {
        name = "Ídolos caídos",
    },
    [52305] = {
        name = "Naturaleza frente a nutrición",
    },
    [52308] = {
        name = "Órdenes interceptadas",
    },
    [52311] = {
        name = "El arcón de Sweete",
    },
    [52317] = {
        name = "No ptomar, solo lanzar",
    },
    [52428] = {
        name = "Imbuir el corazón",
    },
    [52431] = {
        name = "Zona de no-desembarco",
    },
    [52443] = {
        name = "La posición final",
    },
    [52444] = {
        name = "La posición final",
    },
    [52445] = {
        name = "Tol Dagor: la cuarta llave",
    },
    [52447] = {
        name = "Mucho que aprender",
    },
    [52449] = {
        name = "La isla misteriosa",
    },
    [52450] = {
        name = "La unión de Kul Tiras",
    },
    [52453] = {
        name = "La esperanza abandonada",
    },
    [52472] = {
        name = "De Loh Coh",
    },
    [52473] = {
        name = "Acabar con la flota",
    },
    [52477] = {
        name = "SE BUSCA: Ayame",
    },
    [52480] = {
        name = "SE BUSCA: Ayame",
    },
    [52481] = {
        name = "De mitos y fábulas",
    },
    [52482] = {
        name = "El viejo oso",
    },
    [52483] = {
        name = "Atrapapesadillas",
    },
    [52484] = {
        name = "Poder enterrado",
    },
    [52485] = {
        name = "Enfoque del odio",
    },
    [52486] = {
        name = "Mansión Crestavía: Drenar a los Aterracorazón",
    },
    [52487] = {
        name = "Hacia la oscuridad",
    },
    [52488] = {
        name = "Resistencia rúnica",
    },
    [52489] = {
        name = "Caza al príncipe de sangre Dreven",
    },
    [52490] = {
        name = "Tras los barcos enemigos",
    },
    [52491] = {
        name = "Estruendo de andanadas",
    },
    [52492] = {
        name = "La especialidad de los Martillo Salvaje",
    },
    [52493] = {
        name = "Una tripulación antinatural",
    },
    [52494] = {
        name = "Cristales repugnantes para gente repugnante",
    },
    [52495] = {
        name = "El final de la amenaza San'layn",
    },
    [52496] = {
        name = "Una huida impecable",
    },
    [52508] = {
        name = "Los efectos del ritual",
    },
    [52509] = {
        name = "La fuerza de la tormenta",
    },
    [52510] = {
        name = "Altar de la Tormenta: El ritual perdido",
    },
    [52511] = {
        name = "Abrir el camino",
    },
    [52512] = {
        name = "Fin del Destino",
    },
    [52513] = {
        name = "Perdida en la oscuridad",
    },
    [52544] = {
        name = "El alijo bélico",
    },
    [52654] = {
        name = "La campaña de guerra",
    },
    [52746] = {
        name = "El alijo bélico",
    },
    [52748] = {
        name = "Ojos en los cielos",
    },
    [52749] = {
        name = "La campaña de guerra",
    },
    [52750] = {
        name = "Granjeros luchadores",
    },
    [52762] = {
        name = "Guía local",
    },
    [52764] = {
        name = "Viaje al centro de ninguna parte",
    },
    [52765] = {
        name = "Inmersión profunda",
    },
    [52766] = {
        name = "Naufragio en el lecho marino",
    },
    [52767] = {
        name = "Comprobar placas",
    },
    [52768] = {
        name = "El cementerio hundido",
    },
    [52769] = {
        name = "Capitán por capitán",
    },
    [52770] = {
        name = "Molestia biolumínica",
    },
    [52772] = {
        name = "La cornisa submarina",
    },
    [52773] = {
        name = "Dragón acuático",
    },
    [52774] = {
        name = "Listo para llevar",
    },
    [52782] = {
        name = "Llamamiento a las armas: Valle Canto Tormenta",
    },
    [52787] = {
        name = "Adormecer el dolor",
    },
    [52788] = {
        name = "No dejes a nadie con vida",
    },
    [52789] = {
        name = "Silenciar a la consejera",
    },
    [52790] = {
        name = "Fin a la matanza",
    },
    [52793] = {
        name = "A rodear los carros",
    },
    [52795] = {
        name = "Un asunto sáurdido",
    },
    [52796] = {
        name = "A veces menos es más",
    },
    [52800] = {
        name = "Tol Dagor: Sobrestante de los Gobernalle",
    },
    [52855] = {
        name = "La alquimia es una ciencia inexacta",
    },
    [52857] = {
        name = "En observación",
    },
    [52861] = {
        name = "Campeona: Lilian Voss",
    },
    [52876] = {
        name = "SE BUSCA: Guerrasangre",
    },
    [52942] = {
        name = "Recuperando viejos lazos",
    },
    [52943] = {
        name = "Convocar a los clanes",
    },
    [52944] = {
        name = "Llamamiento a las armas: Drustvar",
    },
    [52945] = {
        name = "Lazos forjados en la batalla",
    },
    [52946] = {
        name = "Un mundo agonizante",
    },
    [52948] = {
        name = "Llamamiento a las armas: Estrecho de Tiragarde",
    },
    [52949] = {
        name = "Llamamiento a las armas: Nazmir",
    },
    [52950] = {
        name = "Llamamiento a las armas: Vol'dun",
    },
    [52953] = {
        name = "Llamamiento a las armas: Vol'dun",
    },
    [52954] = {
        name = "Llamamiento a las armas: Nazmir",
    },
    [52955] = {
        name = "La tiranía de la Luz",
    },
    [52956] = {
        name = "Llamamiento a las armas: Estrecho de Tiragarde",
    },
    [52958] = {
        name = "Llamamiento a las armas: Drustvar",
    },
    [52965] = {
        name = "Un obsequio del Festival de Invierno",
    },
    [52978] = {
        name = "Con el príncipe a cuestas",
    },
    [52990] = {
        name = "Volver al puerto",
    },
    [53003] = {
        name = "Un ciclo de odio",
    },
    [53011] = {
        name = "Un obsequio ligeramente agitado",
    },
    [53028] = {
        name = "Un mundo agonizante",
    },
    [53031] = {
        name = "El imperativo del portavoz",
    },
    [53041] = {
        name = "Probar la mercancía",
    },
    [53045] = {
        name = "Examinando el muelle",
    },
    [53050] = {
        name = "En las profundidades de Kul Tiras",
    },
    [53052] = {
        name = "En las profundidades de Zandalar",
    },
    [53055] = {
        name = "Aumentar nuestra influencia",
    },
    [53056] = {
        name = "Aumentar nuestra influencia",
    },
    [53061] = {
        name = "La baza de la azerita",
    },
    [53062] = {
        name = "La baza de la azerita",
    },
    [53063] = {
        name = "Una misión de unidad",
    },
    [53065] = {
        name = "Operación: Sepulturero",
    },
    [53066] = {
        name = "Operación: Agua aprovechada",
    },
    [53067] = {
        name = "Operación: Limpiafondos",
    },
    [53068] = {
        name = "Operación: Anzuelo y sedal",
    },
    [53069] = {
        name = "Operación: Flecha de sangre",
    },
    [53070] = {
        name = "Operación: Ratero",
    },
    [53071] = {
        name = "Operación: Garra de grifo",
    },
    [53072] = {
        name = "Operación: Golpe en el corazón",
    },
    [53074] = {
        name = "Refuerzos",
    },
    [53079] = {
        name = "Refuerzos",
    },
    [53096] = {
        name = "Recompensa de escasez de suministros",
    },
    [53097] = {
        name = "Abluciones decaídas",
    },
    [53098] = {
        name = "Campeona: Shandris Plumaluna",
    },
    [53099] = {
        name = "Una mota de verdad cósmica",
    },
    [53105] = {
        name = "Fe inmerecida",
    },
    [53109] = {
        name = "Casa Crestavía",
    },
    [53110] = {
        name = "El Alto Hablaespinas",
    },
    [53121] = {
        name = "Asedio de Boralus",
    },
    [53128] = {
        name = "El lamento del lord almirante",
    },
    [53131] = {
        name = "Reposo de los Reyes",
    },
    [53185] = {
        name = "Contribución al frente de guerra",
    },
    [53194] = {
        name = "Al frente",
    },
    [53197] = {
        name = "Una visita al frente",
    },
    [53198] = {
        name = "Regreso a Boralus",
    },
    [53208] = {
        name = "Al frente",
    },
    [53209] = {
        name = "Contribución al frente de guerra",
    },
    [53210] = {
        name = "Una visita al frente",
    },
    [53212] = {
        name = "Regreso a Zuldazar",
    },
    [53330] = {
        name = "SE BUSCA: zarpador alfa",
    },
    [53332] = {
        name = "La hora de la guerra",
    },
    [53333] = {
        name = "La hora de la guerra",
    },
    [53336] = {
        name = "SE BUSCA: emperatriz colmisable",
    },
    [53337] = {
        name = "SE BUSCA: goricate primigenio",
    },
    [53342] = {
        name = "Núcleo de Magma",
    },
    [53347] = {
        name = "Beja la abeja",
    },
    [53348] = {
        name = "SE BUSCA: Hocicotrueno",
    },
    [53351] = {
        name = "LA VETA MADRE: Ferromazo",
    },
    [53352] = {
        name = "Tierras de Fuego",
    },
    [53353] = {
        name = "Eco de la señora de la guerra Zaela",
    },
    [53354] = {
        name = "Eco de Gul'dan",
    },
    [53355] = {
        name = "Eco de Garrosh Grito Infernal",
    },
    [53369] = {
        name = "De Loh Coh",
    },
    [53370] = {
        name = "La hora de la verdad",
    },
    [53371] = {
        name = "Abeja mía",
    },
    [53372] = {
        name = "La hora de la verdad",
    },
    [53406] = {
        name = "La Cámara del Corazón",
    },
    [53430] = {
        name = "Ballesta de la Orden de Ascuas",
    },
    [53431] = {
        name = "Frasco de la Orden de Ascuas",
    },
    [53432] = {
        name = "Cuchillo de la Orden de Ascuas",
    },
    [53433] = {
        name = "Sombrero de la Orden de Ascuas",
    },
    [53438] = {
        name = "SE BUSCAN: furtivos de dracoleones",
    },
    [53440] = {
        name = "SE BUSCA: el Avispón",
    },
    [53449] = {
        name = "La guerra de los simios",
    },
    [53450] = {
        name = "Rey Da'ka",
    },
    [53451] = {
        name = "SE BUSCA: guardián de tierra furioso",
    },
    [53452] = {
        name = "Guerra de gorilas",
    },
    [53453] = {
        name = "Machacar o no machacar",
    },
    [53454] = {
        name = "SE BUSCA: intendente Ssylis",
    },
    [53455] = {
        name = "SE BUSCA: los Rebanacabezas Carmesís",
    },
    [53456] = {
        name = "SE BUSCA: Cazahelada",
    },
    [53458] = {
        name = "SE BUSCA: Azotecorteza",
    },
    [53459] = {
        name = "SE BUSCA: hermana Lilias",
    },
    [53461] = {
        name = "Metales preciosos",
    },
    [53462] = {
        name = "Todo envuelto",
    },
    [53463] = {
        name = "Una maldición de ocho patas",
    },
    [53464] = {
        name = "La aldea de Valarroyo",
    },
    [53465] = {
        name = "Tomar el té",
    },
    [53466] = {
        name = "Visión en el tiempo",
    },
    [53467] = {
        name = "Las Cavernas del Tiempo",
    },
    [53566] = {
        name = "Enanos Hierro Negro",
    },
    [53583] = {
        name = "Adaptando nuestras tácticas",
    },
    [53602] = {
        name = "Adaptando nuestras tácticas",
    },
    [53719] = {
        name = "La lealtad de los Zandalari",
    },
    [53720] = {
        name = "La lealtad de Kul Tiras",
    },
    [53725] = {
        name = "Un pueblo destrozado",
    },
    [53734] = {
        name = "Caminar entre fantasmas",
    },
    [53735] = {
        name = "Los primeros en caer",
    },
    [53736] = {
        name = "El lamento de los Altonato",
    },
    [53737] = {
        name = "El día que murió la esperanza",
    },
    [53738] = {
        name = "Defensa de Quel'Danas",
    },
    [53760] = {
        name = "Consecuencias no deseadas",
    },
    [53761] = {
        name = "El tesoro de la pirata",
    },
    [53762] = {
        name = "La corona de la tempestad",
    },
    [53763] = {
        name = "Hurgar en la herida",
    },
    [53765] = {
        name = "Te ha echado el ojo",
    },
    [53766] = {
        name = "Te ha echado el ojo",
    },
    [53774] = {
        name = "Sabiduría del jefe de guerra",
    },
    [53775] = {
        name = "Sombras perturbadoras",
    },
    [53776] = {
        name = "A la Costa Abrupta",
    },
    [53777] = {
        name = "Donde pereció",
    },
    [53778] = {
        name = "Donde cayó",
    },
    [53779] = {
        name = "Las mentiras de un loa",
    },
    [53780] = {
        name = "Carcelero de los malditos",
    },
    [53782] = {
        name = "Misterios mortales",
    },
    [53783] = {
        name = "En las dunas",
    },
    [53791] = {
        name = "El orgullo de los sin'dorei",
    },
    [53802] = {
        name = "Persuasión sethrak",
    },
    [53805] = {
        name = "Un amigo en tiempo de necesidad",
    },
    [53806] = {
        name = "Cabeza pensante",
    },
    [53807] = {
        name = "Una puntada a tiempo",
    },
    [53810] = {
        name = "El hilo cortado",
    },
    [53813] = {
        name = "Hora de arremangarse",
    },
    [53815] = {
        name = "¿Qué ha sido de Saffy Tartanas?",
    },
    [53816] = {
        name = "Requiere reensamblaje",
    },
    [53817] = {
        name = "¿Qué ha sido de Grizzek Silballave?",
    },
    [53818] = {
        name = "Programación a vuelapluma",
    },
    [53819] = {
        name = "Regresa al nido",
    },
    [53820] = {
        name = "Está en un lugar mejor",
    },
    [53821] = {
        name = "Está muerto, Jastor",
    },
    [53823] = {
        name = "El séquito de una reina",
    },
    [53824] = {
        name = "El rito de reyes y reinas",
    },
    [53825] = {
        name = "El nuevo Consejo Zanchuli",
    },
    [53826] = {
        name = "La instigadora entre nosotros",
    },
    [53827] = {
        name = "El Consejo ha hablado",
    },
    [53828] = {
        name = "La mirada de los loa",
    },
    [53830] = {
        name = "Reina de los Zandalari",
    },
    [53831] = {
        name = "Un acontecimiento real",
    },
    [53833] = {
        name = "Ventura vengativa",
    },
    [53835] = {
        name = "¿Algo valioso, quizás?",
    },
    [53836] = {
        name = "Armadura antigua, misterio antiguo",
    },
    [53837] = {
        name = "Ándate con ojo",
    },
    [53838] = {
        name = "Con los pies en el suelo",
    },
    [53840] = {
        name = "¿Te hace una cerveza?",
    },
    [53841] = {
        name = "Fragmentos del pasado",
    },
    [53842] = {
        name = "Bendición terránea",
    },
    [53844] = {
        name = "En busca del Maestro de la Caldera",
    },
    [53845] = {
        name = "Forjar la armadura",
    },
    [53846] = {
        name = "El legado de los Barbabronce",
    },
    [53847] = {
        name = "Con vientos susurrantes",
    },
    [53848] = {
        name = "Herramientas perdidas por Vol'dun",
    },
    [53849] = {
        name = "Esperanza menguante",
    },
    [53851] = {
        name = "Nuestra guerra continúa",
    },
    [53852] = {
        name = "Negación de azerita",
    },
    [53853] = {
        name = "La caída del sol",
    },
    [53856] = {
        name = "La furia de la Horda",
    },
    [53858] = {
        name = "Ponte en su lugar",
    },
    [53866] = {
        name = "Matar en tiempos revueltos",
    },
    [53868] = {
        name = "Salvar el tiempo",
    },
    [53869] = {
        name = "Hora de matar",
    },
    [53870] = {
        name = "Visita en el Fuerte Grommash",
    },
    [53879] = {
        name = "Limpiar la hacienda",
    },
    [53880] = {
        name = "Máquinas de guerra y azerita",
    },
    [53881] = {
        name = "Cortadas por el mismo patrón",
    },
    [53882] = {
        name = "Escrito en el muro",
    },
    [53887] = {
        name = "La guerra continúa",
    },
    [53888] = {
        name = "A Puntamuelle",
    },
    [53889] = {
        name = "Una declaración de intenciones",
    },
    [53890] = {
        name = "Nuevos aliados, nuevos problemas",
    },
    [53891] = {
        name = "No hay problema pequeño",
    },
    [53892] = {
        name = "¿Dónde están los trabajadores?",
    },
    [53893] = {
        name = "Un poco de buena voluntad",
    },
    [53894] = {
        name = "Reparaciones útiles",
    },
    [53895] = {
        name = "¡Ascensos para peones!",
    },
    [53896] = {
        name = "Resiste",
    },
    [53897] = {
        name = "Una fiesta en vuestro honor",
    },
    [53898] = {
        name = "Fuerza y honor",
    },
    [53899] = {
        name = "En las afueras",
    },
    [53900] = {
        name = "Usaremos sus armas",
    },
    [53901] = {
        name = "Las explosiones nunca fallan",
    },
    [53902] = {
        name = "Eliminar a la clamamareas",
    },
    [53903] = {
        name = "Encuentro con Meerah",
    },
    [53904] = {
        name = "Los ayudantes del vinatero",
    },
    [53905] = {
        name = "Sacar partido a sus capacidades",
    },
    [53906] = {
        name = "Fermentado por la Horda",
    },
    [53907] = {
        name = "Sorber y saborear",
    },
    [53908] = {
        name = "Espera nuestra llegada",
    },
    [53909] = {
        name = "Aliados asediados",
    },
    [53910] = {
        name = "¡Rechaza a la Horda!",
    },
    [53912] = {
        name = "La cacería nunca acaba",
    },
    [53913] = {
        name = "Con honor",
    },
    [53916] = {
        name = "Proveedores de vinta",
    },
    [53919] = {
        name = "Tocado y hundido",
    },
    [53936] = {
        name = "Detener a los zapadores",
    },
    [53937] = {
        name = "Sup3rllave",
    },
    [53938] = {
        name = "Un amigo en tiempo de necesidad",
    },
    [53940] = {
        name = "Una puntada a tiempo",
    },
    [53941] = {
        name = "Un meca para un goblin",
    },
    [53942] = {
        name = "El meca adecuado",
    },
    [53947] = {
        name = "En las dunas",
    },
    [53948] = {
        name = "Ventura vengativa",
    },
    [53949] = {
        name = "Sup3rllave",
    },
    [53962] = {
        name = "Cortadas por el mismo patrón",
    },
    [53973] = {
        name = "Sal y plántales cara",
    },
    [53978] = {
        name = "Conspiraciones de la pólvora",
    },
    [53981] = {
        name = "La victoria es nuestra",
    },
    [53986] = {
        name = "La calma previa",
    },
    [53988] = {
        name = "Costas del destino",
    },
    [53989] = {
        name = "Esperanza",
    },
    [53990] = {
        name = "En la noche más oscura",
    },
    [53993] = {
        name = "Una voz en el viento",
    },
    [53995] = {
        name = "El peletero tauren",
    },
    [53996] = {
        name = "A recoger palos",
    },
    [53997] = {
        name = "El sexto sentido",
    },
    [53998] = {
        name = "Exhumación",
    },
    [53999] = {
        name = "Los hilos que unen",
    },
    [54000] = {
        name = "Los latidos del corazón",
    },
    [54001] = {
        name = "¡Allá que vamos!",
    },
    [54002] = {
        name = "Juntar las piezas",
    },
    [54004] = {
        name = "Ensayo n.º 1: meca contra Mekkatorque",
    },
    [54005] = {
        name = "Lo que sabían los Drust",
    },
    [54007] = {
        name = "Póliza de seguro",
    },
    [54008] = {
        name = "Renovación de póliza",
    },
    [54009] = {
        name = "Muertes adicionales",
    },
    [54012] = {
        name = "Almas afortunadas",
    },
    [54015] = {
        name = "A fondo",
    },
    [54018] = {
        name = "Descenso",
    },
    [54021] = {
        name = "La primera arcanista",
    },
    [54022] = {
        name = "Los planes de batalla de Mekkatorque",
    },
    [54026] = {
        name = "Pues esto ya está",
    },
    [54027] = {
        name = "Amenaza contenida",
    },
    [54028] = {
        name = "Meca contra nave",
    },
    [54031] = {
        name = "La mirada de los loa: Krag'wa",
    },
    [54032] = {
        name = "La mirada de los loa: Pa'ku",
    },
    [54033] = {
        name = "La mirada de los loa: Gonk",
    },
    [54034] = {
        name = "La mirada de los loa: Bwonsamdi",
    },
    [54036] = {
        name = "Un proceso especial",
    },
    [54041] = {
        name = "Nada de supervivientes",
    },
    [54042] = {
        name = "Problemas en Costa Oscura",
    },
    [54043] = {
        name = "Reunión de forestales oscuros",
    },
    [54044] = {
        name = "Se alza la luna negra",
    },
    [54045] = {
        name = "¡Parra ya!",
    },
    [54046] = {
        name = "Esto aún no ha terminado",
    },
    [54047] = {
        name = "Donde muere la esperanza",
    },
    [54049] = {
        name = "Noche mortal",
    },
    [54050] = {
        name = "Secuelas",
    },
    [54058] = {
        name = "Consecuencias no deseadas",
    },
    [54059] = {
        name = "La Guerrera Nocturna",
    },
    [54083] = {
        name = "Engrasando las ruedas",
    },
    [54086] = {
        name = "El robot adecuado",
    },
    [54087] = {
        name = "Tienes que tener esta altura",
    },
    [54088] = {
        name = "La leyenda de Mecandria",
    },
    [54094] = {
        name = "La idea del éxito de un goblin",
    },
    [54096] = {
        name = "Caída de La Fuente del Sol",
    },
    [54097] = {
        name = "La Dama Oscura te llama",
    },
    [54099] = {
        name = "El alto señor supremo",
    },
    [54100] = {
        name = "Una salida",
    },
    [54101] = {
        name = "Tras la pista",
    },
    [54102] = {
        name = "Huida hacia el este",
    },
    [54103] = {
        name = "Cruce de caminos",
    },
    [54104] = {
        name = "Rastros de Colmillosauro",
    },
    [54105] = {
        name = "Siempre hacia el este",
    },
    [54106] = {
        name = "Soplo de rastreo",
    },
    [54107] = {
        name = "Noticias macabras",
    },
    [54108] = {
        name = "La muerte de un guerrero",
    },
    [54109] = {
        name = "Favor de la reina",
    },
    [54113] = {
        name = "No hay muerte inútil",
    },
    [54114] = {
        name = "No hay muerte inútil",
    },
    [54117] = {
        name = "No hay muerte inútil",
    },
    [54118] = {
        name = "No hay muerte inútil",
    },
    [54120] = {
        name = "A Orgrimmar",
    },
    [54121] = {
        name = "La liberación de Gobernalle",
    },
    [54123] = {
        name = "¡Esto para mi meca!",
    },
    [54124] = {
        name = "Cómo evitar pleitos",
    },
    [54126] = {
        name = "Hurgar en la herida",
    },
    [54128] = {
        name = "Precauciones necesarias",
    },
    [54139] = {
        name = "La guerra está aquí",
    },
    [54140] = {
        name = "La marcha de los Zandalari",
    },
    [54141] = {
        name = "El medallón de Azshara",
    },
    [54144] = {
        name = "Órdenes de Azshara",
    },
    [54145] = {
        name = "El loa de la muerte",
    },
    [54147] = {
        name = "Enfrentarse a la Val'kyr",
    },
    [54156] = {
        name = "Un camino sangriento",
    },
    [54157] = {
        name = "No dejaremos a nadie atrás",
    },
    [54161] = {
        name = "Lo que sabían los Drust",
    },
    [54163] = {
        name = "La cosa se tranquiliza",
    },
    [54164] = {
        name = "La muerte del rey",
    },
    [54165] = {
        name = "El retorno de Derek Valiente",
    },
    [54169] = {
        name = "Atraco a la cámara del tesoro",
    },
    [54171] = {
        name = "El cetro abisal",
    },
    [54174] = {
        name = "Órdenes de Azshara",
    },
    [54175] = {
        name = "Enfréntate a tu enemigo",
    },
    [54176] = {
        name = "Sé más uniforme",
    },
    [54177] = {
        name = "Una distracción brillante",
    },
    [54178] = {
        name = "Al pasar la barca",
    },
    [54179] = {
        name = "Por la entrada principal",
    },
    [54183] = {
        name = "Toma de decisiones",
    },
    [54191] = {
        name = "Cambio de rumbo",
    },
    [54192] = {
        name = "Información confidencial",
    },
    [54193] = {
        name = "¡Es enorme!",
    },
    [54194] = {
        name = "Un poder grande de verdad",
    },
    [54195] = {
        name = "Una bestia con entendederas",
    },
    [54196] = {
        name = "Sin opciones",
    },
    [54197] = {
        name = "Libertad para los Da'kani",
    },
    [54198] = {
        name = "Despedidas agridulces",
    },
    [54199] = {
        name = "Las necesidades de muchos",
    },
    [54200] = {
        name = "Con lo básico",
    },
    [54201] = {
        name = "A la medida de Grong",
    },
    [54202] = {
        name = "Calibra el núcleo",
    },
    [54203] = {
        name = "El agrandamiento",
    },
    [54204] = {
        name = "Destrucción total del templo",
    },
    [54205] = {
        name = "Una buena siesta",
    },
    [54206] = {
        name = "El agente durmiente",
    },
    [54207] = {
        name = "Recuperar la avanzada",
    },
    [54208] = {
        name = "Buscaminas",
    },
    [54211] = {
        name = "Sin goblins, no hay escuadrón",
    },
    [54212] = {
        name = "Segunda reconstrucción del MEMOV",
    },
    [54213] = {
        name = "¡Está vivo!",
    },
    [54224] = {
        name = "La batalla de las Ruinas de Zul'jan",
    },
    [54244] = {
        name = "Los tenemos acorralados",
    },
    [54249] = {
        name = "Justicia Zandalari",
    },
    [54265] = {
        name = "Órdenes de Azshara",
    },
    [54269] = {
        name = "Nadie escapará",
    },
    [54270] = {
        name = "Reflejos que se rompen",
    },
    [54271] = {
        name = "La purga de Telaamon",
    },
    [54275] = {
        name = "Nieblas dispersas",
    },
    [54280] = {
        name = "Sal a plantarles cara",
    },
    [54282] = {
        name = "Batalla de Dazar'alor",
    },
    [54300] = {
        name = "Romper la fe",
    },
    [54301] = {
        name = "La piedad de Talanji",
    },
    [54302] = {
        name = "La caída de Zuldazar",
    },
    [54303] = {
        name = "La marcha hacia Nazmir",
    },
    [54310] = {
        name = "Un uso nuevo para su aldea",
    },
    [54312] = {
        name = "Niebla de guerra",
    },
    [54402] = {
        name = "Engranajes cambiantes",
    },
    [54404] = {
        name = "Maquinaciones Hierro Negro",
    },
    [54407] = {
        name = "Al acecho en el pantano",
    },
    [54412] = {
        name = "Aluvión en Zul'jan",
    },
    [54416] = {
        name = "Preparativos para el frente",
    },
    [54417] = {
        name = "Demostración de poder",
    },
    [54418] = {
        name = "Meca mortal",
    },
    [54419] = {
        name = "Calmando a las masas",
    },
    [54421] = {
        name = "Fierecillas domadas",
    },
    [54433] = {
        name = "Órdenes de Azshara",
    },
    [54438] = {
        name = "Crisol de Tormentas: reliquias de las sombras",
    },
    [54439] = {
        name = "Crisol de Tormentas: reliquias de las sombras",
    },
    [54441] = {
        name = "Tomar la Puerta de Sangre",
    },
    [54459] = {
        name = "El que sigue el camino de la Luz",
    },
    [54485] = {
        name = "Batalla de Dazar'alor",
    },
    [54510] = {
        name = "Fechoría resuelta",
    },
    [54518] = {
        name = "Cero zepelines",
    },
    [54519] = {
        name = "Objetivos de escuadrón",
    },
    [54559] = {
        name = "¡Liberad a Plumeria!",
    },
    [54576] = {
        name = "Lo mejor de Gnomeregan",
    },
    [54577] = {
        name = "Cámaras sombrías y engranajes polvorientos",
    },
    [54580] = {
        name = "Enigma en la tundra",
    },
    [54581] = {
        name = "Ahora con más aves mecánicas",
    },
    [54582] = {
        name = "Más listo que el trogg medio",
    },
    [54639] = {
        name = "Una señal en Las Cumbres Tormentosas",
    },
    [54640] = {
        name = "¡Gnomisericordia!",
    },
    [54641] = {
        name = "¡Por Gnomeregan!",
    },
    [54642] = {
        name = "Ases de los GASES",
    },
    [54703] = {
        name = "Entrega exprés",
    },
    [54706] = {
        name = "Hecho en Kul Tiras",
    },
    [54708] = {
        name = "La casa de la pradera",
    },
    [54721] = {
        name = "Ya soy vieja para esto",
    },
    [54723] = {
        name = "Cubrir los mástiles",
    },
    [54725] = {
        name = "Los de las profundidades",
    },
    [54726] = {
        name = "El armazón",
    },
    [54727] = {
        name = "Equipo de carga",
    },
    [54728] = {
        name = "Esta madera está encantada",
    },
    [54729] = {
        name = "Las Colinas Sombrías",
    },
    [54730] = {
        name = "Influencia de Gorak Tul",
    },
    [54731] = {
        name = "Equilibrio en todas las cosas",
    },
    [54732] = {
        name = "¡Suelta!",
    },
    [54733] = {
        name = "Gratitud minera",
    },
    [54734] = {
        name = "El reencuentro con Dorian",
    },
    [54735] = {
        name = "Una buena tripulación",
    },
    [54754] = {
        name = "Por la reina",
    },
    [54759] = {
        name = "Cuando los espíritus susurran",
    },
    [54760] = {
        name = "Los caminaespíritus",
    },
    [54761] = {
        name = "Espíritu guía",
    },
    [54762] = {
        name = "Una ligera retirada",
    },
    [54763] = {
        name = "Cruzando",
    },
    [54764] = {
        name = "Tormenta en Pezuña de Sangre",
    },
    [54765] = {
        name = "Una muestra de agradecimiento para tu guía",
    },
    [54766] = {
        name = "Acudir a la llamada",
    },
    [54787] = {
        name = "Máscara que espalda",
    },
    [54850] = {
        name = "Operación: Troggagedón",
    },
    [54851] = {
        name = "La bendición de las Mareas",
    },
    [54871] = {
        name = "Estamos en camino",
    },
    [54913] = {
        name = "Una chispa de genialidad",
    },
    [54915] = {
        name = "Telemetría activa",
    },
    [54916] = {
        name = "El credo del cazador",
    },
    [54917] = {
        name = "Pago con sangre",
    },
    [54918] = {
        name = "La chispa de la imaginación",
    },
    [54919] = {
        name = "Vínculos de trueno",
    },
    [54920] = {
        name = "Hacia el hogar",
    },
    [54922] = {
        name = "Sus tuercas y tornillos",
    },
    [54925] = {
        name = "¡Herejía!",
    },
    [54929] = {
        name = "Que empiece lo bueno",
    },
    [54930] = {
        name = "Liberación mecánica",
    },
    [54938] = {
        name = "La ayuda de un hermano",
    },
    [54939] = {
        name = "Cabezota como un Barbabronce",
    },
    [54940] = {
        name = "El consejo de una MADRE",
    },
    [54945] = {
        name = "Arranquen motores",
    },
    [54946] = {
        name = "Preséntate ante Gila",
    },
    [54947] = {
        name = "Un equipo reducido",
    },
    [54958] = {
        name = "Barcos en la noche",
    },
    [54959] = {
        name = "Bajo triple llave",
    },
    [54960] = {
        name = "Una reunión amarga",
    },
    [54961] = {
        name = "Desfaciendo entuertos",
    },
    [54964] = {
        name = "Un billete de ida al corazón",
    },
    [54965] = {
        name = "Robots desguazados",
    },
    [54969] = {
        name = "Descenso",
    },
    [54972] = {
        name = "Un camino a casa",
    },
    [54975] = {
        name = "Un breve alivio",
    },
    [54976] = {
        name = "La sombra de Gilneas",
    },
    [54977] = {
        name = "Hacia el Bosque del Ocaso",
    },
    [54980] = {
        name = "Azote de los Penumbría",
    },
    [54981] = {
        name = "Aullar a la luna",
    },
    [54982] = {
        name = "El espíritu del cazador",
    },
    [54983] = {
        name = "Despertar a un soñador",
    },
    [54984] = {
        name = "Que los lobos sigan durmiendo",
    },
    [54990] = {
        name = "La nueva guardia",
    },
    [54992] = {
        name = "El principio de algo más grande",
    },
    [54997] = {
        name = "Sangre en las aguas",
    },
    [54999] = {
        name = "Falsas pistas",
    },
    [55028] = {
        name = "Cuánta chatarra",
    },
    [55031] = {
        name = "Cuánta chatarra",
    },
    [55033] = {
        name = "Ingobernalles",
    },
    [55034] = {
        name = "Falsas pistas",
    },
    [55039] = {
        name = "El maestro constructor de barcos",
    },
    [55040] = {
        name = "Mirar dentro",
    },
    [55043] = {
        name = "Anécdotas pesqueras y velas lejanas",
    },
    [55044] = {
        name = "No hay que matar al mensajero",
    },
    [55045] = {
        name = "El guardián de mi hermano",
    },
    [55047] = {
        name = "Asegurando Fuerte Guerracolmillo",
    },
    [55048] = {
        name = "Juego de espías",
    },
    [55049] = {
        name = "Interrumpiendo la comunicación",
    },
    [55050] = {
        name = "¿Su entrada, por favor?",
    },
    [55051] = {
        name = "Una demostración de poder",
    },
    [55052] = {
        name = "Asegurando Fuerte Guerracolmillo",
    },
    [55053] = {
        name = "Un camino a casa",
    },
    [55054] = {
        name = "Agitación",
    },
    [55055] = {
        name = "Construir una trampa para peces más grande",
    },
    [55087] = {
        name = "La tormenta que se avecina",
    },
    [55088] = {
        name = "Perdidos en el campo",
    },
    [55089] = {
        name = "Salvar al soldado Shank",
    },
    [55090] = {
        name = "Una reunión de enemigos",
    },
    [55092] = {
        name = "Perturbación en la energía",
    },
    [55094] = {
        name = "¡Cautela y rapidez!",
    },
    [55095] = {
        name = "Agitación",
    },
    [55096] = {
        name = "Enviarle un mensaje a mi padre",
    },
    [55101] = {
        name = "El trabajo en el desguace y tú",
    },
    [55103] = {
        name = "Las ideas pueden surgir en cualquier parte",
    },
    [55116] = {
        name = "La clave de todo",
    },
    [55117] = {
        name = "Correspondencia enigmática",
    },
    [55118] = {
        name = "Cabos sueltos",
    },
    [55119] = {
        name = "¡A la orden!",
    },
    [55121] = {
        name = "El laboratorio de Mardivas",
    },
    [55124] = {
        name = "Desfaciendo entuertos",
    },
    [55136] = {
        name = "Ha tenido un día de perros",
    },
    [55153] = {
        name = "Construcción colaborativa",
    },
    [55171] = {
        name = "Batalla de espías",
    },
    [55175] = {
        name = "Adonde el camino lleve",
    },
    [55177] = {
        name = "Rompiendo las costuras",
    },
    [55179] = {
        name = "Represalias coordinadas",
    },
    [55182] = {
        name = "Reconstrucción necesaria",
    },
    [55183] = {
        name = "Terreno elevado",
    },
    [55185] = {
        name = "¡Atención!",
    },
    [55188] = {
        name = "Rompiendo las costuras",
    },
    [55195] = {
        name = "Reverberación",
    },
    [55210] = {
        name = "Pilas no incluidas",
    },
    [55211] = {
        name = "Recarga de Pernoóxido",
    },
    [55214] = {
        name = "Estrés costural",
    },
    [55216] = {
        name = "La audición",
    },
    [55217] = {
        name = "Saldar la deuda de vida",
    },
    [55218] = {
        name = "El preciado cuero de Sheza",
    },
    [55219] = {
        name = "De visita por la base",
    },
    [55220] = {
        name = "Pesca mayor",
    },
    [55221] = {
        name = "A otro con ese hueso",
    },
    [55222] = {
        name = "Que truenen los tambores",
    },
    [55223] = {
        name = "Instrumentos de destrucción",
    },
    [55227] = {
        name = "La artesana eterna",
    },
    [55228] = {
        name = "La audición",
    },
    [55229] = {
        name = "Saldar la deuda",
    },
    [55230] = {
        name = "El preciado cuero de Telonis",
    },
    [55231] = {
        name = "El otro Danzafantasma",
    },
    [55232] = {
        name = "La amenaza de Mevris",
    },
    [55233] = {
        name = "A otro con ese hueso",
    },
    [55234] = {
        name = "Que truenen los tambores",
    },
    [55235] = {
        name = "Instrumentos de destrucción",
    },
    [55247] = {
        name = "La confianza ganada",
    },
    [55252] = {
        name = "Una loa sin templo",
    },
    [55253] = {
        name = "Una prueba de fe",
    },
    [55254] = {
        name = "Un sueño eterno",
    },
    [55258] = {
        name = "Comer y dormir",
    },
    [55298] = {
        name = "En busca de algo más grande",
    },
    [55339] = {
        name = "¡De limpieza!",
    },
    [55361] = {
        name = "El chamán perdido",
    },
    [55362] = {
        name = "Furia elemental",
    },
    [55363] = {
        name = "Rescatar al clarividente",
    },
    [55373] = {
        name = "Quien roba a un ladrón...",
    },
    [55374] = {
        name = "Una perturbación bajo tierra",
    },
    [55384] = {
        name = "Instalarse",
    },
    [55385] = {
        name = "Explorar el cercado",
    },
    [55390] = {
        name = "En la oscuridad, sueño",
    },
    [55392] = {
        name = "Entrar en el Camino del Sueño",
    },
    [55393] = {
        name = "Anular el Vacío",
    },
    [55394] = {
        name = "Fragmentos de esmeralda",
    },
    [55395] = {
        name = "No cierres los ojos",
    },
    [55396] = {
        name = "El material del que están hechos los sueños",
    },
    [55397] = {
        name = "Antes de despertar",
    },
    [55398] = {
        name = "El largo despertar",
    },
    [55400] = {
        name = "Coge mi mano",
    },
    [55407] = {
        name = "Apaciguar el espinazo",
    },
    [55425] = {
        name = "Dominar al Indómito",
    },
    [55462] = {
        name = "La llamada de la Errante",
    },
    [55465] = {
        name = "Hay que adentrarse más",
    },
    [55469] = {
        name = "A Zin-Azshari",
    },
    [55481] = {
        name = "Explorando el palacio",
    },
    [55482] = {
        name = "Establecer la conexión",
    },
    [55485] = {
        name = "Horrores en las profundidades",
    },
    [55486] = {
        name = "Los secretos de la telemancia",
    },
    [55488] = {
        name = "Hablar con los muertos",
    },
    [55489] = {
        name = "El cuento de la fámula",
    },
    [55490] = {
        name = "Les sacaremos el ojo",
    },
    [55497] = {
        name = "Una cara conocida",
    },
    [55500] = {
        name = "Salvar a un amigo",
    },
    [55503] = {
        name = "La cuernoatroz y el sáurido",
    },
    [55504] = {
        name = "Santuarios de Zuldazar",
    },
    [55505] = {
        name = "El recuerdo de Roo'li",
    },
    [55506] = {
        name = "El final de un camino",
    },
    [55507] = {
        name = "Bendición de Torcali",
    },
    [55519] = {
        name = "Un trauma reciente",
    },
    [55520] = {
        name = "Curar a Nordrassil",
    },
    [55521] = {
        name = "Al estilo de la azerita",
    },
    [55529] = {
        name = "No vale echarse atrás",
    },
    [55530] = {
        name = "Un lugar más seguro",
    },
    [55533] = {
        name = "MADRE sabe lo que conviene",
    },
    [55558] = {
        name = "Un refugio",
    },
    [55560] = {
        name = "La venganza de Utama",
    },
    [55561] = {
        name = "Lo que queda de Zin-Azshari",
    },
    [55565] = {
        name = "Reforzar las reservas de maná",
    },
    [55569] = {
        name = "Ecos de dolor",
    },
    [55570] = {
        name = "Secretos en las ruinas",
    },
    [55571] = {
        name = "Ayúdalos a ver la verdad",
    },
    [55573] = {
        name = "La erradicación de los profanadores",
    },
    [55574] = {
        name = "Las jabalinas de Azshara",
    },
    [55585] = {
        name = "Un inicio prometedor",
    },
    [55586] = {
        name = "Pulido",
    },
    [55590] = {
        name = "Arreglando las cosas",
    },
    [55592] = {
        name = "Un inicio prometedor",
    },
    [55593] = {
        name = "Información sobre nuestros enemigos",
    },
    [55594] = {
        name = "Pulido",
    },
    [55595] = {
        name = "Conocimiento en decadencia",
    },
    [55596] = {
        name = "Arreglando las cosas",
    },
    [55597] = {
        name = "Atados por el honor",
    },
    [55598] = {
        name = "Lo que sabemos de los nagas",
    },
    [55599] = {
        name = "Exploración de incógnito",
    },
    [55600] = {
        name = "Saciar a los bocadragones",
    },
    [55601] = {
        name = "Cristales codiciados",
    },
    [55608] = {
        name = "Proyecto de taller",
    },
    [55618] = {
        name = "La forja del Corazón",
    },
    [55622] = {
        name = "Llévatelo a casa hoy mismo",
    },
    [55630] = {
        name = "Arranquen motores",
    },
    [55632] = {
        name = "Tienes que tener esta altura",
    },
    [55635] = {
        name = "Una voz en el viento",
    },
    [55645] = {
        name = "Visita principesca",
    },
    [55646] = {
        name = "La leyenda de Mecandria",
    },
    [55647] = {
        name = "A la escucha",
    },
    [55648] = {
        name = "Ahora esta cámara es nuestra",
    },
    [55649] = {
        name = "Maquinaciones para Mecandria",
    },
    [55650] = {
        name = "Lo mejor de lo mejor",
    },
    [55651] = {
        name = "¡A Mecandria!",
    },
    [55652] = {
        name = "Bahía de Prospección",
    },
    [55657] = {
        name = "A la sombra de alas carmesíes",
    },
    [55685] = {
        name = "Venimos en son de paz... y con ánimo de lucro",
    },
    [55694] = {
        name = "Hay algo en el agua",
    },
    [55696] = {
        name = "Prácticas de conducción",
    },
    [55697] = {
        name = "Sacar la patita",
    },
    [55707] = {
        name = "La primera es gratis",
    },
    [55708] = {
        name = "Mejorado",
    },
    [55729] = {
        name = "¡La Resistencia te necesita!",
    },
    [55730] = {
        name = "Rescatar a la Resistencia",
    },
    [55731] = {
        name = "Los ejércitos de mi padre",
    },
    [55732] = {
        name = "Una vieja cicatriz",
    },
    [55734] = {
        name = "Construcción de equipo de excavación",
    },
    [55735] = {
        name = "Defender La Vorágine",
    },
    [55736] = {
        name = "Bienvenidos a la Resistencia",
    },
    [55737] = {
        name = "Es la hora de la azerita",
    },
    [55752] = {
        name = "Unidos resistiremos",
    },
    [55753] = {
        name = "Derribar a su robot",
    },
    [55778] = {
        name = "Visiones de peligro",
    },
    [55779] = {
        name = "Ejecución pospuesta",
    },
    [55780] = {
        name = "Viejos aliados",
    },
    [55781] = {
        name = "Viejos aliados",
    },
    [55782] = {
        name = "Ejecución pospuesta",
    },
    [55783] = {
        name = "Ejecución pospuesta",
    },
    [55784] = {
        name = "Un pago adecuado",
    },
    [55795] = {
        name = "La montaña en marcha",
    },
    [55796] = {
        name = "Herejía en el cruce",
    },
    [55797] = {
        name = "Furia de la madre cuernoatroz",
    },
    [55798] = {
        name = "Errante, pero en compañía",
    },
    [55799] = {
        name = "Cambia la marea",
    },
    [55860] = {
        name = "Liquidación de babosas marinas",
    },
    [55861] = {
        name = "Que el residuo te guíe",
    },
    [55862] = {
        name = "Información sobre nuestros enemigos",
    },
    [55863] = {
        name = "Conocimiento en decadencia",
    },
    [55864] = {
        name = "El precio es la muerte",
    },
    [55865] = {
        name = "Lo que sabemos de los nagas",
    },
    [55866] = {
        name = "Exploración de incógnito",
    },
    [55867] = {
        name = "Cristales codiciados",
    },
    [55868] = {
        name = "Que el residuo te guíe",
    },
    [55869] = {
        name = "El desvalijo del alijo",
    },
    [55870] = {
        name = "Liquidación de babosas marinas",
    },
    [55937] = {
        name = "El desvalijo del alijo",
    },
    [55967] = {
        name = "Saciar a los bocadragones",
    },
    [55983] = {
        name = "Un lugar más seguro",
    },
    [55995] = {
        name = "Podemos arreglarlo",
    },
    [56030] = {
        name = "La orden de la jefa de guerra",
    },
    [56031] = {
        name = "La ofensiva del lobo",
    },
    [56037] = {
        name = "Robar los secretos de los nagas",
    },
    [56038] = {
        name = "Trabajar con un propósito",
    },
    [56039] = {
        name = "No nos valen malas armas",
    },
    [56043] = {
        name = "Enviar la flota",
    },
    [56044] = {
        name = "Enviar la flota",
    },
    [56045] = {
        name = "Robar los secretos de los nagas",
    },
    [56046] = {
        name = "Trabajar con un propósito",
    },
    [56047] = {
        name = "No nos valen malas armas",
    },
    [56063] = {
        name = "Mareas oscuras",
    },
    [56095] = {
        name = "Legado de Nar'anan",
    },
    [56118] = {
        name = "Contraataque",
    },
    [56143] = {
        name = "Qué fue de la profesora Elryna",
    },
    [56156] = {
        name = "Una hoja templada",
    },
    [56167] = {
        name = "Investigar las Tierras Altas",
    },
    [56168] = {
        name = "Fábrica reformada",
    },
    [56175] = {
        name = "Libre de emisiones",
    },
    [56181] = {
        name = "¡Yo invito!",
    },
    [56209] = {
        name = "Las Cámaras de los Orígenes",
    },
    [56210] = {
        name = "Piedras de visión",
    },
    [56211] = {
        name = "Piedras de visión",
    },
    [56234] = {
        name = "Amigos en apuros",
    },
    [56235] = {
        name = "Hacia el interior de Nazjatar",
    },
    [56236] = {
        name = "Golpeados, pero no acabados",
    },
    [56239] = {
        name = "Extraño cuchillo de plata",
    },
    [56240] = {
        name = "Extraño cuchillo de plata",
    },
    [56241] = {
        name = "Pistas conservadas",
    },
    [56242] = {
        name = "Pistas conservadas",
    },
    [56243] = {
        name = "Diarios de los muertos",
    },
    [56244] = {
        name = "Diarios de los muertos",
    },
    [56245] = {
        name = "Cerrojo encantado",
    },
    [56246] = {
        name = "Cerrojo encantado",
    },
    [56247] = {
        name = "La historia del tesoro",
    },
    [56248] = {
        name = "La historia del tesoro",
    },
    [56304] = {
        name = "La gran vida",
    },
    [56305] = {
        name = "¡A pescar!",
    },
    [56309] = {
        name = "La ciudad de los amigos ahogados",
    },
    [56310] = {
        name = "La ciudad de los amigos ahogados",
    },
    [56311] = {
        name = "El ahogo perpetuo",
    },
    [56312] = {
        name = "El ahogo perpetuo",
    },
    [56313] = {
        name = "Líder de guerra",
    },
    [56314] = {
        name = "Líder de guerra",
    },
    [56315] = {
        name = "Fue elección suya",
    },
    [56316] = {
        name = "Fue elección suya",
    },
    [56319] = {
        name = "El contrato de los Cargaveloz",
    },
    [56320] = {
        name = "¡La primera carga es gratis!",
    },
    [56321] = {
        name = "Salvar a Corin",
    },
    [56325] = {
        name = "Mareas cambiantes",
    },
    [56346] = {
        name = "Tecnología antigua",
    },
    [56347] = {
        name = "Una oportunidad abisal",
    },
    [56348] = {
        name = "El Palacio Eterno: Podemos hacer que sea más fuerte...",
    },
    [56349] = {
        name = "El Palacio Eterno: Ampliar los límites",
    },
    [56350] = {
        name = "Explorando el palacio",
    },
    [56351] = {
        name = "El Palacio Eterno: Ampliar los límites",
    },
    [56352] = {
        name = "El Palacio Eterno: Podemos hacer que sea más fuerte...",
    },
    [56353] = {
        name = "Una oportunidad abisal",
    },
    [56354] = {
        name = "Tecnología antigua",
    },
    [56356] = {
        name = "El Palacio Eterno: La estratagema de la reina",
    },
    [56358] = {
        name = "El Palacio Eterno: La estratagema de la reina",
    },
    [56374] = {
        name = "Un problema titánico",
    },
    [56375] = {
        name = "Hacia Ramkahen",
    },
    [56376] = {
        name = "Amenazas incipientes",
    },
    [56377] = {
        name = "A forjar",
    },
    [56378] = {
        name = "La tripulación desaparecida",
    },
    [56379] = {
        name = "La tripulación desaparecida",
    },
    [56401] = {
        name = "Una descarga azul",
    },
    [56422] = {
        name = "Con alas fantasmales",
    },
    [56429] = {
        name = "Contra las cuerdas",
    },
    [56472] = {
        name = "El acuerdo de Uldum",
    },
    [56494] = {
        name = "El preludio de la batalla",
    },
    [56495] = {
        name = "Van a por nosotros",
    },
    [56496] = {
        name = "El preludio de la batalla",
    },
    [56536] = {
        name = "Nunca resulta fácil",
    },
    [56537] = {
        name = "El sigilo misterioso",
    },
    [56538] = {
        name = "Clanes de los mogu",
    },
    [56539] = {
        name = "Localizar a los rajani",
    },
    [56540] = {
        name = "Muestra de tenacidad",
    },
    [56541] = {
        name = "El Motor de Nalak'sha",
    },
    [56542] = {
        name = "Esperanza restaurada",
    },
    [56560] = {
        name = "Un descubrimiento curioso",
    },
    [56561] = {
        name = "Un descubrimiento curioso",
    },
    [56574] = {
        name = "Reflejos en el ámbar",
    },
    [56575] = {
        name = "Una vez más en Kor'vess",
    },
    [56576] = {
        name = "Exterminación de aqir",
    },
    [56577] = {
        name = "Entorpecer al enjambre",
    },
    [56578] = {
        name = "Podredumbre arraigada",
    },
    [56580] = {
        name = "Secretos de ámbar",
    },
    [56616] = {
        name = "Caras conocidas, problemas nuevos",
    },
    [56617] = {
        name = "Un enjambre unido",
    },
    [56640] = {
        name = "Almas afortunadas",
    },
    [56641] = {
        name = "Perturbación en la energía",
    },
    [56642] = {
        name = "Mareas oscuras",
    },
    [56643] = {
        name = "A fondo",
    },
    [56644] = {
        name = "Contra las cuerdas",
    },
    [56645] = {
        name = "Corazón del enjambre",
    },
    [56647] = {
        name = "La amenaza mántide",
    },
    [56719] = {
        name = "Abrirse paso",
    },
    [56739] = {
        name = "El poder de la veneración",
    },
    [56741] = {
        name = "La lanza del destino",
    },
    [56771] = {
        name = "Guerreros perdidos en el tiempo",
    },
    [56833] = {
        name = "Líderes de la Horda",
    },
    [56979] = {
        name = "Salvar el asedio",
    },
    [56980] = {
        name = "Ya están entre nosotros",
    },
    [56981] = {
        name = "Despliegue estratégico",
    },
    [56982] = {
        name = "Ante las Puertas de Orgrimmar",
    },
    [56993] = {
        name = "El precio de la victoria",
    },
    [57002] = {
        name = "Viejo soldado",
    },
    [57005] = {
        name = "Elección de amistad",
    },
    [57006] = {
        name = "Una alianza digna",
    },
    [57010] = {
        name = "Dominar el poder",
    },
    [57043] = {
        name = "Viejos amigos, nuevas oportunidades",
    },
    [57045] = {
        name = "Una entrega especial",
    },
    [57047] = {
        name = "Un sencillo experimento",
    },
    [57048] = {
        name = "Comprar piezas",
    },
    [57051] = {
        name = "¡Cobro de deudas!",
    },
    [57052] = {
        name = "Tengo lo que necesitas",
    },
    [57053] = {
        name = "Prueba de fuerza contundente",
    },
    [57058] = {
        name = "Diversión con minas",
    },
    [57059] = {
        name = "¡A pelear!",
    },
    [57067] = {
        name = "Mogu a las puertas",
    },
    [57068] = {
        name = "Reconocimiento en cometa",
    },
    [57069] = {
        name = "Cortar cabezas",
    },
    [57070] = {
        name = "Masacre mogu",
    },
    [57071] = {
        name = "No dejaremos cerveza atrás",
    },
    [57072] = {
        name = "Yaktótum",
    },
    [57074] = {
        name = "Regreso a la puerta",
    },
    [57075] = {
        name = "Coraje líquido",
    },
    [57076] = {
        name = "Volver a Bruma Otoñal",
    },
    [57077] = {
        name = "¡Se buscan compradores!",
    },
    [57078] = {
        name = "La lista vip",
    },
    [57079] = {
        name = "¡Dale para el pelo!",
    },
    [57080] = {
        name = "Una recompensa apropiada",
    },
    [57088] = {
        name = "Abrirse paso",
    },
    [57090] = {
        name = "Salvar el asedio",
    },
    [57091] = {
        name = "Ya están entre nosotros",
    },
    [57092] = {
        name = "Despliegue estratégico",
    },
    [57093] = {
        name = "Ante las Puertas de Orgrimmar",
    },
    [57094] = {
        name = "El precio de la victoria",
    },
    [57095] = {
        name = "Viejo soldado",
    },
    [57126] = {
        name = "... Y buena mar",
    },
    [57130] = {
        name = "Traidores entre nosotros",
    },
    [57147] = {
        name = "No es mi jefa de guerra",
    },
    [57148] = {
        name = "Rompedores de asedio",
    },
    [57149] = {
        name = "Fin de la propaganda",
    },
    [57150] = {
        name = "Milicia",
    },
    [57151] = {
        name = "Una línea en la arena",
    },
    [57152] = {
        name = "Lealtad máxima",
    },
    [57198] = {
        name = "Sentido del deber",
    },
    [57220] = {
        name = "Inicio del protocolo de activación",
    },
    [57221] = {
        name = "Reoriginación",
    },
    [57222] = {
        name = "Investigar las cámaras",
    },
    [57290] = {
        name = "Iniciar el descenso",
    },
    [57324] = {
        name = "Zarpar con la marea",
    },
    [57362] = {
        name = "Adentrarse en la oscuridad",
    },
    [57373] = {
        name = "Descender a la locura",
    },
    [57374] = {
        name = "Hacia las profundidades más oscuras",
    },
    [57376] = {
        name = "La necesidad oculta",
    },
    [57378] = {
        name = "Restos de un mundo destrozado",
    },
    [57448] = {
        name = "Nuevos aliados entre nosotros",
    },
    [57486] = {
        name = "Energía menguante",
    },
    [57487] = {
        name = "Alguien capaz de ayudar",
    },
    [57488] = {
        name = "El esquema actual",
    },
    [57490] = {
        name = "Viajar a un lugar seguro",
    },
    [57491] = {
        name = "Mejores... Más fuertes... Menos muertos",
    },
    [57492] = {
        name = "¿Él?",
    },
    [57493] = {
        name = "Armonización mental",
    },
    [57494] = {
        name = "Un corazón fuerte",
    },
    [57495] = {
        name = "El futuro de Mecandria",
    },
    [57496] = {
        name = "Ascensión",
    },
    [57497] = {
        name = "Difundir la noticia",
    },
    [57524] = {
        name = "Acceder a los archivos",
    },
    [57873] = {
        name = "Noticias de Orsis",
    },
    [57915] = {
        name = "Busca supervivientes",
    },
    [57954] = {
        name = "Quema los cuerpos",
    },
    [57955] = {
        name = "Al Puerto de Ankhaten",
    },
    [57956] = {
        name = "Huéspedes Vagayermos",
    },
    [57969] = {
        name = "Atender a los heridos",
    },
    [57970] = {
        name = "Devastador Xok'nixx",
    },
    [57971] = {
        name = "Ruinas de Ammon",
    },
    [57990] = {
        name = "Obelisco del Sol",
    },
    [58008] = {
        name = "Combustible a tope",
    },
    [58009] = {
        name = "A la luna",
    },
    [58087] = {
        name = "Destruir la fuente",
    },
    [58214] = {
        name = "Atención urgente",
    },
    [58496] = {
        name = "Un consejero poco grato",
    },
    [58498] = {
        name = "El regreso del rey guerrero",
    },
    [58502] = {
        name = "Donde está el corazón",
    },
    [58506] = {
        name = "Diagnóstico de red",
    },
    [58582] = {
        name = "El regreso del Príncipe Negro",
    },
    [58583] = {
        name = "Donde está el corazón",
    },
    [58606] = {
        name = "Un trozo de investigación",
    },
    [58615] = {
        name = "Susurros en la oscuridad",
    },
    [58631] = {
        name = "En sueños",
    },
    [58632] = {
        name = "Ny'alotha, Ciudad del Despertar: El fin del Corruptor",
    },
    [58634] = {
        name = "Abrir el portal",
    },
    [58636] = {
        name = "Atención a los amathet",
    },
    [58638] = {
        name = "Una incursión más profunda",
    },
    [58639] = {
        name = "Historia enterrada",
    },
    [58640] = {
        name = "Una rendija en la armadura",
    },
    [58641] = {
        name = "Buscadores de corrupción",
    },
    [58642] = {
        name = "Objetivos compartidos",
    },
    [58643] = {
        name = "Destrucción mutua asegurada",
    },
    [58645] = {
        name = "Un mundo digno de salvar",
    },
    [58646] = {
        name = "¡Cómete esto!",
    },
    [58737] = {
        name = "Descubrimientos de Magni",
    },
})
]])()
