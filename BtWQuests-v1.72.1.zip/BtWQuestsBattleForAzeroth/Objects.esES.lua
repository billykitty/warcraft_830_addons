----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "esES" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateObjectsTable({
    [244983] = {
        name = "Reloj de bolsillo sucio",
    },
    [270917] = {
        name = "Registro de Valarroyo",
    },
    [271706] = {
        name = "Tablero de cazadores",
    },
    [272179] = {
        name = "Comunicado del alcalde",
    },
    [272422] = {
        name = "Libro de hechizos de Gentle",
    },
    [273814] = {
        name = "Talismán afilado",
    },
    [273854] = {
        name = "Mochila",
    },
    [276251] = {
        name = "Inventario de excavación",
    },
    [276488] = {
        name = "Bala de cañón de azerita",
    },
    [276513] = {
        name = "Pezfango intacto",
    },
    [276515] = {
        name = "Caña de pescar",
    },
    [276837] = {
        name = "Roca de recetas",
    },
    [277199] = {
        name = "Lista de encargos deteriorada",
    },
    [277373] = {
        name = "Algas de luz trémula",
    },
    [277459] = {
        name = "Efigie de cerdo",
    },
    [278197] = {
        name = "Vial de antídoto",
    },
    [278252] = {
        name = "Folleto de oferta de trabajo",
    },
    [278313] = {
        name = "Carta seria",
    },
    [278368] = {
        name = "Nota ajada",
    },
    [278447] = {
        name = "Lanza de trampero infiel",
    },
    [278570] = {
        name = "Diario antiguo",
    },
    [278577] = {
        name = "Misiva de la Horda rota",
    },
    [278669] = {
        name = "Libro de contabilidad de Albergue del Ocaso",
    },
    [278675] = {
        name = "Efigie maldita",
    },
    [279337] = {
        name = "Grimorio Aterracorazón",
    },
    [279646] = {
        name = "Crónicas de guardia de sangre",
    },
    [279647] = {
        name = "Tomo del sacrificio",
    },
    [280576] = {
        name = "Pergamino encerrado",
    },
    [280727] = {
        name = "Nota carbonizada",
    },
    [280755] = {
        name = "Bolsa de Quintin",
    },
    [281230] = {
        name = "Invitación formal",
    },
    [281348] = {
        name = "Carta deshecha",
    },
    [281551] = {
        name = "Póster de Se busca ayudante",
    },
    [281583] = {
        name = "Relicario antiguo",
    },
    [281639] = {
        name = "Estatua desmoronada",
    },
    [281647] = {
        name = "Aviso colgado",
    },
    [281673] = {
        name = "Diario de ciudadano de Corlain",
    },
    [281718] = {
        name = "SE BUSCA AYUDANTE",
    },
    [282457] = {
        name = "Tótem de guardazarzas",
    },
    [282478] = {
        name = "Cajón vacío",
    },
    [282498] = {
        name = "Flauta del desierto",
    },
    [284426] = {
        name = "Máquina minera enterrada",
    },
    [286016] = {
        name = "Cuaderno de bitácora",
    },
    [287081] = {
        name = "Tablilla antigua",
    },
    [287185] = {
        name = "Se busca: hablaoscuro Jo'la",
    },
    [287189] = {
        name = "Se buscan: bestias peligrosas",
    },
    [287228] = {
        name = "Se busca: Cronista oscuro",
    },
    [287229] = {
        name = "Se busca: Cronista oscuro",
    },
    [287232] = {
        name = "Informe de exploración",
    },
    [287327] = {
        name = "Informe de exploración",
    },
    [287398] = {
        name = "Se busca: Za'roco",
    },
    [287440] = {
        name = "Se busca: Taz'raka",
    },
    [287441] = {
        name = "Se busca: exploraarena Vesarik",
    },
    [287442] = {
        name = "Se buscan: participantes de la expedición Cobra",
    },
    [287958] = {
        name = "Tablón de anuncios",
    },
    [288157] = {
        name = "Se busca: Yarsel'ghun",
    },
    [288167] = {
        name = "Paquete de Marie",
    },
    [288214] = {
        name = "Cartel de Se busca",
    },
    [288622] = {
        name = "Cartel de Se busca",
    },
    [288641] = {
        name = "SE BUSCA: ladrones de grifos",
    },
    [289310] = {
        name = "SE BUSCA: guardián de tierra furioso",
    },
    [289313] = {
        name = "SE BUSCA: el Avispón",
    },
    [289361] = {
        name = "SE BUSCA: intendente Ssylis",
    },
    [289365] = {
        name = "Cartel de Se busca",
    },
    [289728] = {
        name = "Mapa del tesoro del capitán Gulnaku",
    },
    [290138] = {
        name = "Bomba destruyerrobots",
    },
    [290419] = {
        name = "Cartel de Se busca",
    },
    [290537] = {
        name = "Se busca ayudante",
    },
    [290750] = {
        name = "Reservas Jambani",
    },
    [290765] = {
        name = "Montón de oro enorme",
    },
    [290993] = {
        name = "Botín de Marea de Hierro",
    },
    [291143] = {
        name = "Llave de Rinah",
    },
    [291291] = {
        name = "Se busca: furtivo",
    },
    [292523] = {
        name = "Cartel de Se busca",
    },
    [293567] = {
        name = "Cartel de Se busca",
    },
    [293568] = {
        name = "Cartel de Se busca",
    },
    [293985] = {
        name = "Se busca: Guerrasangre",
    },
    [297492] = {
        name = "Tablón de anuncios",
    },
    [298778] = {
        name = "Cartel de Se busca",
    },
    [298849] = {
        name = "Cartel de Se busca",
    },
    [298858] = {
        name = "Cartel de Se busca",
    },
    [307748] = {
        name = "Carta de Ventura y Cía.",
    },
    [309498] = {
        name = "Portaarmaduras",
    },
    [311155] = {
        name = "Tablilla antigua",
    },
    [311218] = {
        name = "Xal'atath, Daga del Imperio Negro",
    },
    [311885] = {
        name = "Xal'atath, Daga del Imperio Negro",
    },
    [322533] = {
        name = "Escrito de los elementos de Mardivas",
    },
    [326393] = {
        name = "Alijo de armas de azerita",
    },
    [326418] = {
        name = "Cofre Arcano",
    },
    [326588] = {
        name = "Alijo de armas de azerita",
    },
    [327170] = {
        name = "Expositor de armas",
    },
    [327591] = {
        name = "Diario conservado",
    },
    [327592] = {
        name = "Cerrojo encantado",
    },
    [327596] = {
        name = "Enfoque abisal roto",
    },
    [329805] = {
        name = "Cristal extraño",
    },
})
]])()
