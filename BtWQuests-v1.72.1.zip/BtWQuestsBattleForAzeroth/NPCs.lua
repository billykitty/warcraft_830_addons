----- AUTO GENERATED - DO NOT EDIT

BtWQuestsDatabase:AddNPCsTable({
    [3037] = {
        name = "Sheza Wildmane",
        locations = {
            [88] = {
                {
                    x = 0.697252,
                    y = 0.267331,
                },
            },
        },
    },
    [5164] = {
        name = "Grumnus Steelshaper",
        locations = {
            [87] = {
                {
                    x = 0.487777,
                    y = 0.45771,
                },
            },
        },
    },
    [14720] = {
        name = "High Overlord Saurfang",
    },
    [15192] = {
        name = "Anachronos",
        locations = {
            [75] = {
                {
                    x = 0.417583,
                    y = 0.498922,
                },
            },
        },
    },
    [16802] = {
        name = "Lor'themar Theron",
        locations = {
            [110] = {
                {
                    x = 0.54,
                    y = 0.204,
                },
                {
                    x = 0.54,
                    y = 0.206,
                },
            },
        },
    },
    [29445] = {
        name = "Thorim",
        locations = {
            [120] = {
                {
                    x = 0.33416,
                    y = 0.579557,
                },
            },
        },
    },
    [36648] = {
        name = "Baine Bloodhoof",
        locations = {
            [88] = {
                {
                    x = 0.602924,
                    y = 0.516756,
                },
            },
        },
    },
    [107574] = {
        name = "Anduin Wrynn",
        locations = {
            [84] = {
                {
                    x = 0.859159,
                    y = 0.315612,
                },
            },
        },
    },
    [108017] = {
        name = "Torv Dubstomp",
        locations = {
            [652] = {
                {
                    x = 0.549054,
                    y = 0.78,
                },
            },
        },
    },
    [120168] = {
        name = "Chronicler To'kini",
        locations = {
            [1165] = {
                {
                    x = 6964,
                    y = 0.4745,
                },
            },
        },
    },
    [120170] = {
        name = "Nathanos Blightcaller",
        locations = {
            [1165] = {
                {
                    x = 0.484,
                    y = 0.374,
                },
            },
        },
    },
    [120171] = {
        name = "Rokhan",
        locations = {
            [1165] = {
                {
                    x = 0.4033,
                    y = 0.6933,
                },
            },
        },
    },
    [120173] = {
        name = "Zen'tabra",
        locations = {
            [463] = {
                {
                    x = 0.594,
                    y = 0.518,
                },
            },
        },
    },
    [120551] = {
        name = "Krag'wa the Huge",
        locations = {
            [863] = {
                {
                    x = 0.754,
                    y = 0.566,
                },
            },
        },
    },
    [120740] = {
        name = "King Rastakhan",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.464,
                },
            },
        },
    },
    [120756] = {
        name = "Anduin Wrynn",
        locations = {
            [84] = {
                {
                    x = 0.852,
                    y = 0.325,
                },
            },
        },
    },
    [120788] = {
        name = "Genn Greymane",
        locations = {
            [1161] = {
                {
                    x = 0.68,
                    y = 0.22,
                },
            },
        },
    },
    [120904] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.43,
                    y = 0.86,
                },
            },
        },
    },
    [120922] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1161] = {
                {
                    x = 0.656,
                    y = 0.506,
                },
            },
        },
    },
    [121144] = {
        name = "Katherine Proudmoore",
        locations = {
            [1161] = {
                {
                    x = 0.482,
                    y = 0.808,
                },
            },
        },
    },
    [121235] = {
        name = "Taelia",
        locations = {
            [1161] = {
                {
                    x = 0.758,
                    y = 0.234,
                },
            },
        },
    },
    [121239] = {
        name = "Flynn Fairwind",
        locations = {
            [974] = {
                {
                    x = 0.472,
                    y = 0.462,
                },
            },
        },
    },
    [121241] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.456,
                    y = 0.748,
                },
            },
        },
    },
    [121288] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.394,
                    y = 0.78,
                },
            },
        },
    },
    [121599] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.604,
                    y = 0.22,
                },
            },
        },
    },
    [121601] = {
        name = "Rokhan",
        locations = {
            [862] = {
                {
                    x = 0.568,
                    y = 0.19,
                },
            },
        },
    },
    [121603] = {
        name = "Abby Lewis",
        locations = {
            [896] = {
                {
                    x = 0.545,
                    y = 0.392,
                },
            },
        },
    },
    [121706] = {
        name = "Beastlord L'kala",
        locations = {
            [862] = {
                {
                    x = 0.668073,
                    y = 0.4251,
                },
            },
        },
    },
    [122009] = {
        name = "Kraal Master B'khor",
        locations = {
            [862] = {
                {
                    x = 0.675,
                    y = 0.434,
                },
            },
        },
    },
    [122102] = {
        name = "Hanzabu",
        locations = {
            [863] = {
                {
                    x = 0.366,
                    y = 0.54,
                },
            },
        },
    },
    [122129] = {
        name = "Trader Alexxi Cruzpot",
        locations = {
            [862] = {
                {
                    x = 0.668,
                    y = 0.425,
                },
            },
        },
    },
    [122289] = {
        name = "Bladeguard Kaja",
        locations = {
            [864] = {
                {
                    x = 0.532,
                    y = 0.66,
                },
            },
        },
    },
    [122320] = {
        name = "Bladeguard Kaja",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.314,
                },
            },
        },
    },
    [122370] = {
        name = "Cyrus Crestfall",
        locations = {
            [1161] = {
                {
                    x = 0.68,
                    y = 0.22,
                },
            },
        },
    },
    [122493] = {
        name = "Annie Warren",
        locations = {
            [896] = {
                {
                    x = 0.546,
                    y = 0.49,
                },
            },
        },
    },
    [122583] = {
        name = "Meerah",
        locations = {
            [864] = {
                {
                    x = 0.568,
                    y = 0.504,
                },
            },
        },
    },
    [122641] = {
        name = "Yazma",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.464,
                },
            },
        },
    },
    [122661] = {
        name = "General Jakra'zet",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.825,
                },
            },
        },
    },
    [122671] = {
        name = "Cagney",
        locations = {
            [895] = {
                {
                    x = 0.768,
                    y = 0.434,
                },
            },
        },
    },
    [122672] = {
        name = "Olive",
        locations = {
            [895] = {
                {
                    x = 0.768,
                    y = 0.435,
                },
            },
        },
    },
    [122688] = {
        name = "Bwonsamdi",
        locations = {
            [863] = {
                {
                    x = 0.395,
                    y = 0.246,
                },
            },
        },
    },
    [122695] = {
        name = "Seshuli",
        locations = {
            [1165] = {
                {
                    x = 0.470546,
                    y = 0.379259,
                },
            },
        },
    },
    [122698] = {
        name = "Xanjo",
        locations = {
            [1165] = {
                {
                    x = 0.440702,
                    y = 0.346348,
                },
            },
        },
    },
    [122702] = {
        name = "Enchantress Quinni",
        locations = {
            [1165] = {
                {
                    x = 0.470894,
                    y = 0.356819,
                },
            },
        },
    },
    [122703] = {
        name = "Clever Kumali",
        locations = {
            [1165] = {
                {
                    x = 0.42221,
                    y = 0.37961,
                },
            },
        },
    },
    [122706] = {
        name = "Theurgist Salazae",
        locations = {
            [863] = {
                {
                    x = 0.366,
                    y = 0.275,
                },
            },
        },
    },
    [122723] = {
        name = "Rhan'ka",
        locations = {
            [864] = {
                {
                    x = 0.435,
                    y = 0.602,
                },
            },
        },
    },
    [122725] = {
        name = "Zulsan",
        locations = {
            [864] = {
                {
                    x = 0.436,
                    y = 0.602,
                },
            },
        },
    },
    [122760] = {
        name = "Wardruid Loti",
        locations = {
            [862] = {
                {
                    x = 0.485,
                    y = 0.268,
                },
            },
        },
    },
    [122766] = {
        name = "Bwonsamdi",
        locations = {
            [863] = {
                {
                    x = 0.395,
                    y = 0.302,
                },
            },
        },
    },
    [122795] = {
        name = "Witch Doctor Kejabu",
        locations = {
            [863] = {
                {
                    x = 0.396,
                    y = 0.438,
                },
            },
        },
    },
    [122817] = {
        name = "Bladeguard Kaja",
        locations = {
            [1165] = {
                {
                    x = 0.515,
                    y = 0.318,
                },
            },
        },
    },
    [122915] = {
        name = "Zolani",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.464,
                },
            },
        },
    },
    [122939] = {
        name = "Direhorn Hatchling",
        locations = {
            [862] = {
                {
                    x = 0.642,
                    y = 0.446,
                },
                {
                    x = 0.656,
                    y = 0.412,
                },
                {
                    x = 0.68,
                    y = 0.382,
                },
            },
        },
    },
    [122991] = {
        name = "Shadow Hunter Mutumba",
        locations = {
            [863] = {
                {
                    x = 0.674,
                    y = 0.42,
                },
            },
        },
    },
    [123000] = {
        name = "Captain Rez'okun",
        locations = {
            [1165] = {
                {
                    x = 0.445,
                    y = 0.954,
                },
            },
        },
    },
    [123005] = {
        name = "Hemet Nesingwary",
        locations = {
            [862] = {
                {
                    x = 0.675044,
                    y = 0.177072,
                },
            },
        },
    },
    [123019] = {
        name = "Huntmaster Vol'ka",
        locations = {
            [862] = {
                {
                    x = 0.674,
                    y = 0.176,
                },
            },
        },
    },
    [123022] = {
        name = "Tracker Burke",
        locations = {
            [862] = {
                {
                    x = 0.675,
                    y = 0.176,
                },
            },
        },
    },
    [123026] = {
        name = "Erak the Aloof",
        locations = {
            [862] = {
                {
                    x = 0.674,
                    y = 0.176,
                },
            },
        },
    },
    [123052] = {
        name = "Kimbul",
        locations = {
            [864] = {
                {
                    x = 0.566,
                    y = 0.104,
                },
            },
        },
    },
    [123063] = {
        name = "Elder Kuppaka",
        locations = {
            [864] = {
                {
                    x = 0.616,
                    y = 0.205,
                },
            },
        },
    },
    [123118] = {
        name = "Trapper Custer",
        locations = {
            [862] = {
                {
                    x = 0.688,
                    y = 0.194,
                },
            },
        },
    },
    [123178] = {
        name = "Patch",
        locations = {
            [863] = {
                {
                    x = 0.746,
                    y = 0.388,
                },
            },
        },
    },
    [123335] = {
        name = "Wardruid Loti",
        locations = {
            [1165] = {
                {
                    x = 0.394,
                    y = 0.138,
                },
            },
        },
    },
    [123415] = {
        name = "Henry Hardwick",
        locations = {
            [895] = {
                {
                    x = 0.502,
                    y = 0.372,
                },
            },
        },
    },
    [123526] = {
        name = "Ticker",
        locations = {
            [863] = {
                {
                    x = 0.746,
                    y = 0.39,
                },
            },
        },
    },
    [123544] = {
        name = "Patch",
        locations = {
            [863] = {
                {
                    x = 0.822,
                    y = 0.272,
                },
            },
        },
    },
    [123545] = {
        name = "Newt",
        locations = {
            [863] = {
                {
                    x = 0.822,
                    y = 0.272,
                },
            },
        },
    },
    [123548] = {
        name = "Ticker",
        locations = {
            [863] = {
                {
                    x = 0.822,
                    y = 0.272,
                },
            },
        },
    },
    [123586] = {
        name = "Kiro",
        locations = {
            [864] = {
                {
                    x = 0.568,
                    y = 0.504,
                },
            },
        },
    },
    [123729] = {
        name = "Volni",
        locations = {
            [864] = {
                {
                    x = 0.428,
                    y = 0.61,
                },
            },
        },
    },
    [123730] = {
        name = "Man'zul",
        locations = {
            [864] = {
                {
                    x = 0.433,
                    y = 0.608,
                },
            },
        },
    },
    [123878] = {
        name = "Patch",
        locations = {
            [863] = {
                {
                    x = 0.814,
                    y = 0.26,
                },
            },
        },
    },
    [124062] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.766,
                    y = 0.16,
                },
            },
        },
    },
    [124063] = {
        name = "Jol the Ancient",
        locations = {
            [862] = {
                {
                    x = 0.764,
                    y = 0.16,
                },
            },
        },
    },
    [124083] = {
        name = "Zolani",
        locations = {
            [862] = {
                {
                    x = 0.766,
                    y = 0.162,
                },
            },
        },
    },
    [124289] = {
        name = "\"Risky\" Liz Seminario",
        locations = {
            [1161] = {
                {
                    x = 0.722,
                    y = 0.16,
                },
            },
        },
    },
    [124376] = {
        name = "Witch Doctor Zentimo",
        locations = {
            [863] = {
                {
                    x = 0.686,
                    y = 0.466,
                },
            },
        },
    },
    [124417] = {
        name = "Cyril White",
        locations = {
            [896] = {
                {
                    x = 0.558,
                    y = 0.35,
                },
            },
        },
    },
    [124428] = {
        name = "Hanzabu",
        locations = {
            [863] = {
                {
                    x = 0.395,
                    y = 0.438,
                },
            },
        },
    },
    [124468] = {
        name = "Randall Redmond",
        locations = {
            [864] = {
                {
                    x = 0.456,
                    y = 0.824,
                },
            },
        },
    },
    [124513] = {
        name = "Hanzabu",
        locations = {
            [863] = {
                {
                    x = 0.395,
                    y = 0.325,
                },
            },
        },
    },
    [124629] = {
        name = "Kaza'jin the Wavebinder",
        locations = {
            [1165] = {
                {
                    x = 0.426,
                    y = 0.215,
                },
            },
        },
    },
    [124630] = {
        name = "Taelia",
    },
    [124641] = {
        name = "Shadow Hunter Mutumba",
        locations = {
            [863] = {
                {
                    x = 0.752,
                    y = 0.565,
                },
            },
        },
    },
    [124655] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.72,
                    y = 0.21,
                },
            },
        },
    },
    [124656] = {
        name = "Zolani",
        locations = {
            [862] = {
                {
                    x = 0.72,
                    y = 0.212,
                },
            },
        },
    },
    [124666] = {
        name = "Kajosh",
        locations = {
            [863] = {
                {
                    x = 0.552,
                    y = 0.366,
                },
            },
        },
    },
    [124786] = {
        name = "Thomas Staughton",
        locations = {
            [896] = {
                {
                    x = 0.632,
                    y = 0.27,
                },
            },
        },
    },
    [124802] = {
        name = "Lord Aldrius Norwington",
        locations = {
            [895] = {
                {
                    x = 0.516,
                    y = 0.272,
                },
            },
        },
    },
    [124915] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.71,
                    y = 0.298,
                },
            },
        },
    },
    [124922] = {
        name = "Helena Gentle",
        locations = {
            [896] = {
                {
                    x = 0.605,
                    y = 0.316,
                },
            },
        },
    },
    [124933] = {
        name = "Kajosh",
        locations = {
            [863] = {
                {
                    x = 0.518,
                    y = 0.332,
                },
            },
        },
    },
    [125039] = {
        name = "Trader Kro",
        locations = {
            [862] = {
                {
                    x = 0.792,
                    y = 0.422,
                },
            },
        },
    },
    [125041] = {
        name = "Scrollsage Goji",
        locations = {
            [862] = {
                {
                    x = 0.792,
                    y = 0.42,
                },
            },
        },
    },
    [125042] = {
        name = "Gora Layton",
        locations = {
            [895] = {
                {
                    x = 0.524,
                    y = 0.284,
                },
            },
        },
    },
    [125047] = {
        name = "Rokor",
        locations = {
            [862] = {
                {
                    x = 0.814,
                    y = 0.458,
                },
            },
        },
    },
    [125093] = {
        name = "Fallhaven Villager",
        locations = {
            [896] = {
                {
                    x = 0.608,
                    y = 0.306,
                },
            },
        },
    },
    [125309] = {
        name = "Abbey Watkins",
        locations = {
            [895] = {
                {
                    x = 0.554,
                    y = 0.246,
                },
            },
        },
    },
    [125312] = {
        name = "Scrollsage Rooka",
        locations = {
            [1165] = {
                {
                    x = 0.56,
                    y = 0.888,
                },
            },
        },
    },
    [125317] = {
        name = "Shadow Hunter Narez",
        locations = {
            [863] = {
                {
                    x = 0.778,
                    y = 0.532,
                },
            },
        },
    },
    [125342] = {
        name = "Captain Keelson",
        locations = {
            [895] = {
                {
                    x = 0.862,
                    y = 0.798,
                },
            },
        },
    },
    [125380] = {
        name = "Lucille Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.7,
                    y = 0.428,
                },
            },
        },
    },
    [125385] = {
        name = "Marshal Everit Reade",
        locations = {
            [896] = {
                {
                    x = 0.696,
                    y = 0.432,
                },
            },
        },
    },
    [125394] = {
        name = "Constable Henry Framer",
        locations = {
            [896] = {
                {
                    x = 0.7,
                    y = 0.428,
                },
            },
        },
    },
    [125398] = {
        name = "Harold Beckett",
        locations = {
            [895] = {
                {
                    x = 0.555,
                    y = 0.246,
                },
            },
        },
    },
    [125457] = {
        name = "Rebecca Hale",
        locations = {
            [896] = {
                {
                    x = 0.646,
                    y = 0.548,
                },
            },
        },
    },
    [125486] = {
        name = "Wingrider Nivek",
        locations = {
            [862] = {
                {
                    x = 0.69,
                    y = 0.406,
                },
            },
        },
    },
    [125862] = {
        name = "Zauljin",
        locations = {
            [864] = {
                {
                    x = 0.432,
                    y = 0.77,
                },
            },
        },
    },
    [125904] = {
        name = "Norah",
        locations = {
            [864] = {
                {
                    x = 0.388,
                    y = 0.772,
                },
            },
        },
    },
    [125922] = {
        name = "Brother Therold",
        locations = {
            [895] = {
                {
                    x = 0.412,
                    y = 0.27,
                },
            },
        },
    },
    [125962] = {
        name = "Manager Yerold",
        locations = {
            [895] = {
                {
                    x = 0.376,
                    y = 0.296,
                },
            },
        },
    },
    [126039] = {
        name = "Mag'ash the Poisonous",
        locations = {
            [863] = {
                {
                    x = 0.69,
                    y = 0.504,
                },
            },
        },
    },
    [126066] = {
        name = "Eitrigg",
        locations = {
            [85] = {
                {
                    x = 0.378,
                    y = 0.806,
                },
            },
        },
    },
    [126079] = {
        name = "Kol'jun Deathwalker",
        locations = {
            [863] = {
                {
                    x = 0.39,
                    y = 0.6,
                },
            },
        },
    },
    [126080] = {
        name = "Shinga Deathwalker",
        locations = {
            [863] = {
                {
                    x = 0.39,
                    y = 0.6,
                },
            },
        },
    },
    [126085] = {
        name = "Mugjabu",
        locations = {
            [864] = {
                {
                    x = 0.422,
                    y = 0.762,
                },
            },
        },
    },
    [126108] = {
        name = "Sezahjin",
        locations = {
            [864] = {
                {
                    x = 0.436,
                    y = 0.768,
                },
            },
        },
    },
    [126148] = {
        name = "Witch Doctor Jala",
        locations = {
            [1165] = {
                {
                    x = 0.442,
                    y = 0.82,
                },
            },
        },
    },
    [126158] = {
        name = "Flynn Fairwind",
        locations = {
            [895] = {
                {
                    x = 0.848,
                    y = 0.76,
                },
            },
        },
    },
    [126210] = {
        name = "Caretaker Allen",
        locations = {
            [896] = {
                {
                    x = 0.625,
                    y = 0.43,
                },
            },
        },
    },
    [126213] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.674,
                    y = 0.422,
                },
            },
        },
    },
    [126225] = {
        name = "Aaron Cresterly",
        locations = {
            [896] = {
                {
                    x = 0.606,
                    y = 0.465,
                },
            },
        },
    },
    [126240] = {
        name = "Bridget Fairwater",
        locations = {
            [896] = {
                {
                    x = 0.598,
                    y = 0.49,
                },
            },
        },
    },
    [126289] = {
        name = "Chadwick Paxton",
        locations = {
            [863] = {
                {
                    x = 0.286,
                    y = 0.438,
                },
            },
        },
    },
    [126298] = {
        name = "Brannon Stormsong",
        locations = {
            [895] = {
                {
                    x = 0.395,
                    y = 0.266,
                },
            },
        },
    },
    [126308] = {
        name = "Keegan Alby",
        locations = {
            [895] = {
                {
                    x = 0.395,
                    y = 0.266,
                },
            },
        },
    },
    [126310] = {
        name = "Evelyn Pare",
        locations = {
            [896] = {
                {
                    x = 0.7,
                    y = 0.602,
                },
            },
        },
    },
    [126334] = {
        name = "Jani",
        locations = {
            [1165] = {
                {
                    x = 0.354,
                    y = 0.078,
                },
            },
        },
    },
    [126346] = {
        name = "Chadwick Paxton",
        locations = {
            [863] = {
                {
                    x = 0.258,
                    y = 0.36,
                },
            },
        },
    },
    [126377] = {
        name = "Ingrid Bellix",
        locations = {
            [863] = {
                {
                    x = 0.266,
                    y = 0.38,
                },
            },
        },
    },
    [126511] = {
        name = "Skinner MacGuff",
        locations = {
            [895] = {
                {
                    x = 0.828,
                    y = 0.728,
                },
            },
        },
    },
    [126549] = {
        name = "Rokhan",
        locations = {
            [1165] = {
                {
                    x = 0.515,
                    y = 0.412,
                },
            },
        },
    },
    [126560] = {
        name = "Wardruid Loti",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.464,
                },
            },
        },
    },
    [126564] = {
        name = "Hexlord Raal",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.464,
                },
            },
        },
    },
    [126576] = {
        name = "Razgaji",
        locations = {
            [864] = {
                {
                    x = 0.434,
                    y = 0.754,
                },
            },
        },
    },
    [126588] = {
        name = "Keula",
        locations = {
            [863] = {
                {
                    x = 0.425,
                    y = 0.314,
                },
            },
        },
    },
    [126620] = {
        name = "Flynn Fairwind",
        locations = {
            [895] = {
                {
                    x = 0.802,
                    y = 0.752,
                },
            },
        },
    },
    [126684] = {
        name = "Yazma",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.848,
                },
            },
        },
    },
    [126696] = {
        name = "Jorak",
        locations = {
            [864] = {
                {
                    x = 0.528,
                    y = 0.892,
                },
            },
        },
    },
    [126713] = {
        name = "Sur'jan",
        locations = {
            [863] = {
                {
                    x = 0.388,
                    y = 0.778,
                },
            },
        },
    },
    [126804] = {
        name = "Trapped Saurolisk",
        locations = {
            [895] = {
                {
                    x = 0.56,
                    y = 0.175,
                },
            },
        },
    },
    [126814] = {
        name = "Ranah",
        locations = {
            [864] = {
                {
                    x = 0.538,
                    y = 0.694,
                },
            },
        },
    },
    [127006] = {
        name = "Melissa Kenny",
        locations = {
            [895] = {
                {
                    x = 0.556,
                    y = 0.246,
                },
            },
        },
    },
    [127015] = {
        name = "Thaddeus \"Gramps\" Rifthold",
        locations = {
            [896] = {
                {
                    x = 0.506,
                    y = 0.244,
                },
            },
        },
    },
    [127080] = {
        name = "Lord Autumnvale",
        locations = {
            [896] = {
                {
                    x = 0.595,
                    y = 0.22,
                },
            },
        },
    },
    [127112] = {
        name = "Forgemaster Zak'aal",
        locations = {
            [1165] = {
                {
                    x = 0.436523,
                    y = 0.38295,
                },
            },
        },
    },
    [127144] = {
        name = "Melissa Kenny",
        locations = {
            [895] = {
                {
                    x = 0.544,
                    y = 0.194,
                },
            },
        },
    },
    [127157] = {
        name = "Marcus Howlingdale",
        locations = {
            [896] = {
                {
                    x = 0.506,
                    y = 0.242,
                },
            },
        },
    },
    [127161] = {
        name = "Alanna Holton",
        locations = {
            [895] = {
                {
                    x = 0.758,
                    y = 0.658,
                },
            },
        },
    },
    [127212] = {
        name = "Kal'dran",
        locations = {
            [863] = {
                {
                    x = 0.31,
                    y = 0.52,
                },
            },
        },
    },
    [127215] = {
        name = "Shadow Hunter Da'jul",
        locations = {
            [863] = {
                {
                    x = 0.31,
                    y = 0.52,
                },
            },
        },
    },
    [127216] = {
        name = "Zardrax the Empowerer",
        locations = {
            [863] = {
                {
                    x = 0.31,
                    y = 0.52,
                },
            },
        },
    },
    [127296] = {
        name = "David Maldus",
        locations = {
            [896] = {
                {
                    x = 0.626,
                    y = 0.238,
                },
            },
        },
    },
    [127377] = {
        name = "Pa'ku",
        locations = {
            [862] = {
                {
                    x = 0.714,
                    y = 0.492,
                },
            },
        },
    },
    [127391] = {
        name = "Bloodseeker Jo'chunga",
        locations = {
            [863] = {
                {
                    x = 0.334,
                    y = 0.458,
                },
            },
        },
    },
    [127396] = {
        name = "Initiate Peony",
        locations = {
            [896] = {
                {
                    x = 0.59,
                    y = 0.224,
                },
            },
        },
    },
    [127418] = {
        name = "Edwin Maldus",
        locations = {
            [896] = {
                {
                    x = 0.565,
                    y = 0.24,
                },
            },
        },
    },
    [127481] = {
        name = "Lord Kennings",
        locations = {
            [895] = {
                {
                    x = 0.708,
                    y = 0.62,
                },
            },
        },
    },
    [127489] = {
        name = "Hexlord Raal",
        locations = {
            [1165] = {
                {
                    x = 0.498,
                    y = 0.335,
                },
            },
        },
    },
    [127492] = {
        name = "Majo",
        locations = {
            [895] = {
                {
                    x = 0.512,
                    y = 0.258,
                },
            },
        },
    },
    [127537] = {
        name = "Geraldine",
        locations = {
            [895] = {
                {
                    x = 0.792,
                    y = 0.764,
                },
            },
        },
    },
    [127558] = {
        name = "Art Hughie",
        locations = {
            [896] = {
                {
                    x = 0.718,
                    y = 0.504,
                },
            },
        },
    },
    [127559] = {
        name = "Lord Aldrius Norwington",
        locations = {
            [895] = {
                {
                    x = 0.525,
                    y = 0.285,
                },
            },
        },
    },
    [127570] = {
        name = "Bladeguard Kaja",
        locations = {
            [864] = {
                {
                    x = 0.532,
                    y = 0.902,
                },
            },
        },
    },
    [127586] = {
        name = "Joma",
        locations = {
            [895] = {
                {
                    x = 0.512,
                    y = 0.258,
                },
            },
        },
    },
    [127646] = {
        name = "Lord Kennings",
        locations = {
            [895] = {
                {
                    x = 0.758,
                    y = 0.658,
                },
            },
        },
    },
    [127665] = {
        name = "Nokano",
        locations = {
            [1165] = {
                {
                    x = 0.402,
                    y = 0.192,
                },
            },
        },
    },
    [127691] = {
        name = "Jorak",
        locations = {
            [864] = {
                {
                    x = 0.528,
                    y = 0.892,
                },
            },
        },
    },
    [127715] = {
        name = "Lucille Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.46,
                    y = 0.334,
                },
            },
        },
    },
    [127743] = {
        name = "Auntie Amanda Hale",
        locations = {
            [896] = {
                {
                    x = 0.694,
                    y = 0.436,
                },
            },
        },
    },
    [127803] = {
        name = "Caleb Batharen",
        locations = {
            [895] = {
                {
                    x = 0.582,
                    y = 0.254,
                },
            },
        },
    },
    [127814] = {
        name = "Habutu",
        locations = {
            [862] = {
                {
                    x = 0.478,
                    y = 0.604,
                },
            },
        },
    },
    [127815] = {
        name = "Zolani",
        locations = {
            [862] = {
                {
                    x = 0.478,
                    y = 0.604,
                },
            },
        },
    },
    [127837] = {
        name = "Kaza'jin the Wavebinder",
        locations = {
            [862] = {
                {
                    x = 0.48,
                    y = 0.604,
                },
            },
        },
    },
    [127958] = {
        name = "Kisha",
        locations = {
            [863] = {
                {
                    x = 0.565,
                    y = 0.266,
                },
            },
        },
    },
    [127960] = {
        name = "Lashk",
        locations = {
            [863] = {
                {
                    x = 0.565,
                    y = 0.266,
                },
            },
        },
    },
    [127961] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.565,
                    y = 0.266,
                },
            },
        },
    },
    [127980] = {
        name = "Akunda the Sensible",
        locations = {
            [864] = {
                {
                    x = 0.536,
                    y = 0.914,
                },
            },
        },
    },
    [127989] = {
        name = "Meijani",
        locations = {
            [864] = {
                {
                    x = 0.522,
                    y = 0.796,
                },
            },
        },
    },
    [127992] = {
        name = "Akunda the Exalted",
        locations = {
            [864] = {
                {
                    x = 0.532,
                    y = 0.902,
                },
            },
        },
    },
    [128096] = {
        name = "Bwonsamdi",
        locations = {
            [863] = {
                {
                    x = 0.565,
                    y = 0.266,
                },
            },
        },
    },
    [128152] = {
        name = "Akunda",
        locations = {
            [864] = {
                {
                    x = 0.532,
                    y = 0.915,
                },
            },
        },
    },
    [128228] = {
        name = "Hungry Sam",
        locations = {
            [895] = {
                {
                    x = 0.854,
                    y = 0.808,
                },
            },
        },
    },
    [128229] = {
        name = "Stabby Jane",
        locations = {
            [895] = {
                {
                    x = 0.854,
                    y = 0.808,
                },
            },
        },
    },
    [128261] = {
        name = "First Mate Jamboya",
        locations = {
            [864] = {
                {
                    x = 0.354,
                    y = 0.838,
                },
            },
        },
    },
    [128276] = {
        name = "Jo'chunga",
        locations = {
            [863] = {
                {
                    x = 0.312,
                    y = 0.468,
                },
            },
        },
    },
    [128339] = {
        name = "Jorak",
        locations = {
            [864] = {
                {
                    x = 0.528,
                    y = 0.892,
                },
            },
        },
    },
    [128349] = {
        name = "Hilde Firebreaker",
        locations = {
            [1171] = {
                {
                    x = 0.597,
                    y = 0.405,
                },
            },
        },
    },
    [128353] = {
        name = "Pendi Cranklefuse",
        locations = {
            [1171] = {
                {
                    x = 0.504,
                    y = 0.696,
                },
            },
        },
    },
    [128354] = {
        name = "Birch Tomlin",
        locations = {
            [1171] = {
                {
                    x = 0.506,
                    y = 0.695,
                },
            },
        },
    },
    [128377] = {
        name = "Beachcomber Bob",
        locations = {
            [895] = {
                {
                    x = 0.855,
                    y = 0.835,
                },
            },
        },
    },
    [128381] = {
        name = "Drogrin Alewhisker",
        locations = {
            [895] = {
                {
                    x = 0.626,
                    y = 0.298,
                },
            },
        },
    },
    [128422] = {
        name = "Keerin",
        locations = {
            [864] = {
                {
                    x = 0.476,
                    y = 0.862,
                },
            },
        },
    },
    [128457] = {
        name = "Maude Rifthold",
        locations = {
            [896] = {
                {
                    x = 0.552,
                    y = 0.35,
                },
            },
        },
    },
    [128467] = {
        name = "Elijah Eggleton",
        locations = {
            [896] = {
                {
                    x = 0.555,
                    y = 0.348,
                },
            },
        },
    },
    [128494] = {
        name = "Adela Hawthorne",
        locations = {
            [896] = {
                {
                    x = 0.668,
                    y = 0.42,
                },
            },
        },
    },
    [128618] = {
        name = "Dockmaster Herrington",
        locations = {
            [864] = {
                {
                    x = 0.445,
                    y = 0.882,
                },
            },
        },
    },
    [128679] = {
        name = "Rosaline Madison",
        locations = {
            [895] = {
                {
                    x = 0.35,
                    y = 0.242,
                },
            },
        },
    },
    [128680] = {
        name = "Okri Putterwrench",
        locations = {
            [895] = {
                {
                    x = 0.352,
                    y = 0.245,
                },
            },
        },
    },
    [128687] = {
        name = "Serrik",
        locations = {
            [864] = {
                {
                    x = 0.272,
                    y = 0.54,
                },
            },
        },
    },
    [128691] = {
        name = "Izarn",
        locations = {
            [864] = {
                {
                    x = 0.322,
                    y = 0.482,
                },
            },
        },
    },
    [128694] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.271,
                    y = 0.525,
                },
            },
        },
    },
    [128696] = {
        name = "Zissiah",
        locations = {
            [864] = {
                {
                    x = 0.272,
                    y = 0.538,
                },
            },
        },
    },
    [128702] = {
        name = "Roko",
        locations = {
            [895] = {
                {
                    x = 0.796,
                    y = 0.818,
                },
            },
        },
    },
    [128888] = {
        name = "Koba",
        locations = {
            [862] = {
                {
                    x = 0.702,
                    y = 0.65,
                },
            },
        },
    },
    [128889] = {
        name = "Deyon",
        locations = {
            [862] = {
                {
                    x = 0.736,
                    y = 0.61,
                },
            },
        },
    },
    [128903] = {
        name = "Carentan",
        locations = {
            [895] = {
                {
                    x = 0.768,
                    y = 0.86,
                },
            },
        },
    },
    [128909] = {
        name = "Shalo",
        locations = {
            [1165] = {
                {
                    x = 0.576,
                    y = 0.924,
                },
            },
        },
    },
    [128925] = {
        name = "Deyon",
        locations = {
            [862] = {
                {
                    x = 0.752,
                    y = 0.614,
                },
            },
        },
    },
    [128927] = {
        name = "Venrik",
        locations = {
            [895] = {
                {
                    x = 0.772,
                    y = 0.84,
                },
            },
        },
    },
    [129003] = {
        name = "Tagart",
        locations = {
            [895] = {
                {
                    x = 0.424,
                    y = 0.222,
                },
            },
        },
    },
    [129098] = {
        name = "Rodrigo",
        locations = {
            [895] = {
                {
                    x = 0.77,
                    y = 0.828,
                },
            },
        },
    },
    [129164] = {
        name = "Chronicler Jabari",
        locations = {
            [863] = {
                {
                    x = 0.626,
                    y = 0.536,
                },
            },
        },
    },
    [129165] = {
        name = "Guard Satao",
        locations = {
            [863] = {
                {
                    x = 0.632,
                    y = 0.528,
                },
            },
        },
    },
    [129170] = {
        name = "Rulf",
        locations = {
            [895] = {
                {
                    x = 0.424,
                    y = 0.226,
                },
            },
        },
    },
    [129291] = {
        name = "Boss Tak",
        locations = {
            [895] = {
                {
                    x = 0.42,
                    y = 0.168,
                },
            },
        },
    },
    [129354] = {
        name = "Rhan'ka",
        locations = {
            [864] = {
                {
                    x = 0.434,
                    y = 0.602,
                },
            },
        },
    },
    [129378] = {
        name = "Jo'chunga",
        locations = {
            [863] = {
                {
                    x = 0.332,
                    y = 0.458,
                },
            },
        },
    },
    [129392] = {
        name = "\"Helpless\" Henry",
        locations = {
            [895] = {
                {
                    x = 0.476,
                    y = 0.176,
                },
            },
        },
    },
    [129450] = {
        name = "Tacha",
        locations = {
            [864] = {
                {
                    x = 0.454,
                    y = 0.462,
                },
            },
        },
    },
    [129451] = {
        name = "Omi",
        locations = {
            [864] = {
                {
                    x = 0.454,
                    y = 0.462,
                },
            },
        },
    },
    [129453] = {
        name = "Kenzou",
        locations = {
            [864] = {
                {
                    x = 0.454,
                    y = 0.462,
                },
            },
        },
    },
    [129491] = {
        name = "King Rastakhan",
        locations = {
            [1165] = {
                {
                    x = 0.39,
                    y = 0.27,
                },
            },
        },
    },
    [129519] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.2761,
                    y = 0.5257,
                },
            },
        },
    },
    [129561] = {
        name = "Wardruid Loti",
        locations = {
            [862] = {
                {
                    x = 0.492,
                    y = 0.444,
                },
            },
        },
    },
    [129578] = {
        name = "Shawn McClinter",
        locations = {
            [895] = {
                {
                    x = 0.478,
                    y = 0.164,
                },
            },
        },
    },
    [129586] = {
        name = "Batu",
        locations = {
            [862] = {
                {
                    x = 0.705,
                    y = 0.651,
                },
            },
        },
    },
    [129588] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.27,
                    y = 0.525,
                },
            },
        },
    },
    [129613] = {
        name = "Maynard Algerson",
        locations = {
            [895] = {
                {
                    x = 0.69,
                    y = 0.205,
                },
            },
        },
    },
    [129642] = {
        name = "Lucille Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.368,
                    y = 0.5,
                },
            },
        },
    },
    [129643] = {
        name = "Marshal Everit Reade",
        locations = {
            [896] = {
                {
                    x = 0.368,
                    y = 0.5,
                },
            },
        },
    },
    [129669] = {
        name = "Benjamin Algerson",
        locations = {
            [895] = {
                {
                    x = 0.688,
                    y = 0.198,
                },
            },
        },
    },
    [129670] = {
        name = "Lyssa Treewarden",
        locations = {
            [895] = {
                {
                    x = 0.666,
                    y = 0.172,
                },
            },
        },
    },
    [129703] = {
        name = "Hexlord Raal",
        locations = {
            [862] = {
                {
                    x = 0.496,
                    y = 0.38,
                },
            },
        },
    },
    [129717] = {
        name = "Akru",
        locations = {
            [862] = {
                {
                    x = 0.705,
                    y = 0.648,
                },
            },
        },
    },
    [129740] = {
        name = "Gonk",
        locations = {
            [862] = {
                {
                    x = 0.492,
                    y = 0.444,
                },
            },
        },
    },
    [129757] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.426,
                    y = 0.376,
                },
            },
        },
    },
    [129808] = {
        name = "Farmer Goldfield",
        locations = {
            [942] = {
                {
                    x = 0.508,
                    y = 0.73,
                },
            },
        },
    },
    [129858] = {
        name = "Wulferd Fizzbracket",
        locations = {
            [895] = {
                {
                    x = 0.675,
                    y = 0.558,
                },
            },
        },
    },
    [129907] = {
        name = "Zul the Prophet",
        locations = {
            [862] = {
                {
                    x = 0.628,
                    y = 0.324,
                },
            },
        },
    },
    [129940] = {
        name = "Roko",
        locations = {
            [1161] = {
                {
                    x = 0.702,
                    y = 0.086,
                },
            },
        },
    },
    [129956] = {
        name = "Dockmaster Tyndall",
        locations = {
            [895] = {
                {
                    x = 0.658,
                    y = 0.5,
                },
            },
        },
    },
    [129983] = {
        name = "Inquisitor Cleardawn",
        locations = {
            [896] = {
                {
                    x = 0.402,
                    y = 0.565,
                },
            },
        },
    },
    [129999] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.592,
                    y = 0.695,
                },
            },
        },
    },
    [130101] = {
        name = "Recruit Brutis",
        locations = {
            [895] = {
                {
                    x = 0.628,
                    y = 0.298,
                },
            },
        },
    },
    [130159] = {
        name = "Taelia",
        locations = {
            [895] = {
                {
                    x = 0.77,
                    y = 0.828,
                },
            },
        },
    },
    [130190] = {
        name = "Sergeant Calvin",
        locations = {
            [942] = {
                {
                    x = 0.576,
                    y = 0.664,
                },
            },
        },
    },
    [130216] = {
        name = "Magni Bronzebeard",
        locations = {
            [81] = {
                {
                    x = 0.422,
                    y = 0.442,
                },
            },
        },
    },
    [130341] = {
        name = "Bladeguard Kaja",
        locations = {
            [864] = {
                {
                    x = 0.568,
                    y = 0.504,
                },
            },
        },
    },
    [130368] = {
        name = "Samuel D. Colton III",
        locations = {
            [1161] = {
                {
                    x = 0.752013,
                    y = 0.098893,
                },
            },
        },
    },
    [130375] = {
        name = "Tallis Skyheart",
        locations = {
            [895] = {
                {
                    x = 0.81,
                    y = 0.424,
                },
            },
        },
    },
    [130377] = {
        name = "Courier Gerald",
        locations = {
            [1161] = {
                {
                    x = 0.694,
                    y = 0.11,
                },
            },
        },
    },
    [130399] = {
        name = "Zooey Inksprocket",
        locations = {
            [1161] = {
                {
                    x = 0.733924,
                    y = 0.063415,
                },
            },
        },
    },
    [130424] = {
        name = "\"Helpless\" Henry",
        locations = {
            [895] = {
                {
                    x = 0.436,
                    y = 0.152,
                },
            },
        },
    },
    [130450] = {
        name = "Bladeguard Sonji",
        locations = {
            [862] = {
                {
                    x = 0.472,
                    y = 0.25,
                },
            },
        },
    },
    [130455] = {
        name = "Nisha",
        locations = {
            [864] = {
                {
                    x = 0.66,
                    y = 0.365,
                },
            },
        },
    },
    [130468] = {
        name = "Lil' Tika",
        locations = {
            [862] = {
                {
                    x = 0.462,
                    y = 0.234,
                },
            },
        },
    },
    [130478] = {
        name = "Griddon",
        locations = {
            [895] = {
                {
                    x = 0.448,
                    y = 0.154,
                },
            },
        },
    },
    [130481] = {
        name = "Shinga Deathwalker",
        locations = {
            [863] = {
                {
                    x = 0.39,
                    y = 0.606,
                },
            },
        },
    },
    [130576] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.592,
                    y = 0.686,
                },
            },
        },
    },
    [130603] = {
        name = "Beastbreaker Hakid",
    },
    [130660] = {
        name = "Warguard Rakera",
        locations = {
            [864] = {
                {
                    x = 0.535,
                    y = 0.916,
                },
            },
        },
    },
    [130667] = {
        name = "Warguard Rakera",
        locations = {
            [864] = {
                {
                    x = 0.528,
                    y = 0.892,
                },
            },
        },
    },
    [130694] = {
        name = "Mayor Roz",
        locations = {
            [942] = {
                {
                    x = 0.576,
                    y = 0.665,
                },
            },
        },
    },
    [130697] = {
        name = "Fire Marshal Jill",
        locations = {
            [895] = {
                {
                    x = 0.585,
                    y = 0.605,
                },
            },
        },
    },
    [130706] = {
        name = "Izita's Spirit",
        locations = {
            [862] = {
                {
                    x = 0.636,
                    y = 0.318,
                },
            },
        },
    },
    [130714] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.634,
                    y = 0.648,
                },
            },
        },
    },
    [130715] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.634,
                    y = 0.648,
                },
            },
        },
    },
    [130750] = {
        name = "Captain Grez'ko",
        locations = {
            [862] = {
                {
                    x = 0.546,
                    y = 0.898,
                },
            },
        },
    },
    [130785] = {
        name = "Huntmaster Kil'ja",
        locations = {
            [1165] = {
                {
                    x = 0.518,
                    y = 0.414,
                },
            },
        },
    },
    [130786] = {
        name = "Hobbs",
        locations = {
            [942] = {
                {
                    x = 0.586,
                    y = 0.704,
                },
            },
        },
    },
    [130821] = {
        name = "Wavemaster Lanfa",
        locations = {
            [862] = {
                {
                    x = 0.544,
                    y = 0.87,
                },
            },
        },
    },
    [130833] = {
        name = "Captain Grez'ko",
        locations = {
            [862] = {
                {
                    x = 0.578,
                    y = 0.766,
                },
            },
        },
    },
    [130844] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.452,
                    y = 0.71,
                },
            },
        },
    },
    [130901] = {
        name = "Chronicler Grazzul",
        locations = {
            [1165] = {
                {
                    x = 0.423294,
                    y = 0.397227,
                },
            },
        },
    },
    [130904] = {
        name = "Samuel Williams",
        locations = {
            [942] = {
                {
                    x = 0.646,
                    y = 0.622,
                },
            },
        },
    },
    [130905] = {
        name = "Cala Cruzpot",
        locations = {
            [862] = {
                {
                    x = 0.64,
                    y = 0.354,
                },
            },
        },
    },
    [130929] = {
        name = "Witch Doctor Jangalar",
        locations = {
            [862] = {
                {
                    x = 0.64,
                    y = 0.354,
                },
            },
        },
    },
    [130930] = {
        name = "Zaluto",
        locations = {
            [863] = {
                {
                    x = 0.242,
                    y = 0.532,
                },
            },
        },
    },
    [130932] = {
        name = "Nok'tal",
        locations = {
            [1165] = {
                {
                    x = 0.6725,
                    y = 0.8377,
                },
            },
        },
    },
    [130947] = {
        name = "Tsunga",
        locations = {
            [862] = {
                {
                    x = 0.502,
                    y = 0.545,
                },
            },
        },
    },
    [131000] = {
        name = "Commander Kellam",
        locations = {
            [942] = {
                {
                    x = 0.34,
                    y = 0.548,
                },
            },
        },
    },
    [131001] = {
        name = "Lieutenant Harris",
        locations = {
            [942] = {
                {
                    x = 0.346,
                    y = 0.475,
                },
            },
        },
    },
    [131002] = {
        name = "Lieutenant Bauer",
        locations = {
            [942] = {
                {
                    x = 0.302,
                    y = 0.592,
                },
            },
        },
    },
    [131003] = {
        name = "Specialist Wembley",
        locations = {
            [942] = {
                {
                    x = 0.345,
                    y = 0.472,
                },
            },
        },
    },
    [131004] = {
        name = "Squire Augustus III",
        locations = {
            [942] = {
                {
                    x = 0.594,
                    y = 0.7,
                },
            },
        },
    },
    [131014] = {
        name = "Rikal",
        locations = {
            [942] = {
                {
                    x = 0.35,
                    y = 0.476,
                },
            },
        },
    },
    [131048] = {
        name = "Lieutenant Tarenfold",
        locations = {
            [895] = {
                {
                    x = 0.566,
                    y = 0.612,
                },
            },
        },
    },
    [131049] = {
        name = "Rezan",
        locations = {
            [862] = {
                {
                    x = 0.436,
                    y = 0.392,
                },
            },
        },
    },
    [131213] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.674,
                    y = 0.422,
                },
            },
        },
    },
    [131231] = {
        name = "Jin'Tiki",
        locations = {
            [863] = {
                {
                    x = 0.242,
                    y = 0.532,
                },
            },
        },
    },
    [131248] = {
        name = "Samuel Williams",
        locations = {
            [942] = {
                {
                    x = 0.664,
                    y = 0.564,
                },
            },
        },
    },
    [131249] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.664,
                    y = 0.565,
                },
            },
        },
    },
    [131253] = {
        name = "Titan Keeper Hezrel",
        locations = {
            [863] = {
                {
                    x = 0.67,
                    y = 0.388,
                },
            },
        },
    },
    [131287] = {
        name = "Natal'hakata",
        locations = {
            [1165] = {
                {
                    x = 0.666,
                    y = 0.714,
                },
            },
        },
    },
    [131290] = {
        name = "Flynn Fairwind",
        locations = {
            [1161] = {
                {
                    x = 0.668,
                    y = 0.33,
                },
            },
        },
    },
    [131354] = {
        name = "Beastmother Jabati",
        locations = {
            [862] = {
                {
                    x = 0.472,
                    y = 0.25,
                },
            },
        },
    },
    [131386] = {
        name = "Kronah",
        locations = {
            [896] = {
                {
                    x = 0.206609,
                    y = 0.440871,
                },
            },
        },
    },
    [131397] = {
        name = "Miju",
        locations = {
            [862] = {
                {
                    x = 0.326204,
                    y = 0.860396,
                },
            },
        },
    },
    [131442] = {
        name = "Leandro Royston",
        locations = {
            [896] = {
                {
                    x = 0.255,
                    y = 0.7,
                },
            },
        },
    },
    [131443] = {
        name = "Chief Telemancer Oculeth",
        locations = {
            [1163] = {
                {
                    x = 0.67028,
                    y = 0.736312,
                },
            },
        },
    },
    [131448] = {
        name = "Warren Ashton",
        locations = {
            [896] = {
                {
                    x = 0.252,
                    y = 0.672,
                },
            },
        },
    },
    [131469] = {
        name = "Marten Webb",
        locations = {
            [896] = {
                {
                    x = 0.25,
                    y = 0.674,
                },
            },
        },
    },
    [131579] = {
        name = "Captive Villager",
        locations = {
            [896] = {
                {
                    x = 0.252,
                    y = 0.676,
                },
                {
                    x = 0.252,
                    y = 0.686,
                },
                {
                    x = 0.262,
                    y = 0.664,
                },
                {
                    x = 0.264,
                    y = 0.68,
                },
            },
        },
    },
    [131580] = {
        name = "Apprentice Telemancer Astrandis",
        locations = {
            [862] = {
                {
                    x = 0.44,
                    y = 0.72,
                },
            },
        },
    },
    [131582] = {
        name = "Examiner Tae'shara Bloodwatcher",
        locations = {
            [862] = {
                {
                    x = 0.44,
                    y = 0.72,
                },
            },
        },
    },
    [131627] = {
        name = "Thomas Pinker",
        locations = {
            [895] = {
                {
                    x = 0.494,
                    y = 0.312,
                },
            },
        },
    },
    [131636] = {
        name = "Marshal Everit Reade",
        locations = {
            [896] = {
                {
                    x = 0.32,
                    y = 0.31,
                },
            },
        },
    },
    [131638] = {
        name = "Lucille Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.314,
                    y = 0.302,
                },
            },
        },
    },
    [131639] = {
        name = "Inquisitor Mace",
        locations = {
            [896] = {
                {
                    x = 0.285,
                    y = 0.256,
                },
            },
        },
    },
    [131640] = {
        name = "Inquisitor Notley",
        locations = {
            [896] = {
                {
                    x = 0.308,
                    y = 0.295,
                },
            },
        },
    },
    [131641] = {
        name = "Inquisitor Yorrick",
        locations = {
            [896] = {
                {
                    x = 0.262,
                    y = 0.36,
                },
            },
        },
    },
    [131642] = {
        name = "Inquisitor Sterntide",
        locations = {
            [896] = {
                {
                    x = 0.306,
                    y = 0.215,
                },
            },
        },
    },
    [131654] = {
        name = "Meredith",
        locations = {
            [895] = {
                {
                    x = 0.586,
                    y = 0.615,
                },
            },
        },
    },
    [131656] = {
        name = "Houndmaster Archibald",
        locations = {
            [942] = {
                {
                    x = 0.51,
                    y = 0.7,
                },
            },
        },
    },
    [131657] = {
        name = "Bloodshed Compendium",
        locations = {
            [896] = {
                {
                    x = 0.20725,
                    y = 0.441046,
                },
            },
        },
    },
    [131684] = {
        name = "Penny \"Precious\" Hardwick",
        locations = {
            [895] = {
                {
                    x = 0.554,
                    y = 0.358,
                },
            },
        },
    },
    [131763] = {
        name = "Excavator Morgrum Emberflint",
        locations = {
            [862] = {
                {
                    x = 0.414,
                    y = 0.714,
                },
            },
        },
    },
    [131775] = {
        name = "Earless Joe",
        locations = {
            [895] = {
                {
                    x = 0.51,
                    y = 0.358,
                },
            },
        },
    },
    [131777] = {
        name = "Acadia Chistlestone",
        locations = {
            [862] = {
                {
                    x = 0.412,
                    y = 0.714,
                },
            },
        },
    },
    [131793] = {
        name = "Ancel Mildenhall",
        locations = {
            [942] = {
                {
                    x = 0.688,
                    y = 0.652,
                },
            },
        },
    },
    [131840] = {
        name = "Shuga Blastcaps",
        locations = {
            [1165] = {
                {
                    x = 0.451343,
                    y = 0.405857,
                },
            },
        },
    },
    [131872] = {
        name = "Sur'jan",
        locations = {
            [863] = {
                {
                    x = 0.288,
                    y = 0.726,
                },
            },
        },
    },
    [131879] = {
        name = "Inquisitor Cleardawn",
        locations = {
            [896] = {
                {
                    x = 0.25,
                    y = 0.674,
                },
            },
        },
    },
    [131978] = {
        name = "Lashk",
        locations = {
            [863] = {
                {
                    x = 0.674,
                    y = 0.42,
                },
            },
        },
    },
    [131993] = {
        name = "Yash",
        locations = {
            [863] = {
                {
                    x = 0.668,
                    y = 0.42,
                },
            },
        },
    },
    [132118] = {
        name = "Farmer Burton",
        locations = {
            [942] = {
                {
                    x = 0.516,
                    y = 0.66,
                },
            },
        },
    },
    [132193] = {
        name = "Angus Ballaster",
        locations = {
            [896] = {
                {
                    x = 0.316,
                    y = 0.296,
                },
            },
        },
    },
    [132228] = {
        name = "Elric Whalgrene",
        locations = {
            [1161] = {
                {
                    x = 0.742082,
                    y = 0.065512,
                },
            },
        },
    },
    [132292] = {
        name = "Raimond Mildenhall",
        locations = {
            [942] = {
                {
                    x = 0.74,
                    y = 0.726,
                },
            },
        },
    },
    [132332] = {
        name = "Princess Talanji",
        locations = {
            [862] = {
                {
                    x = 0.58,
                    y = 0.624,
                },
            },
        },
    },
    [132333] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.448,
                    y = 0.685,
                },
            },
        },
    },
    [132347] = {
        name = "Quintin Whalgrene",
        locations = {
            [896] = {
                {
                    x = 0.307513,
                    y = 0.497147,
                },
            },
        },
    },
    [132374] = {
        name = "Elsie Wright",
        locations = {
            [896] = {
                {
                    x = 0.345,
                    y = 0.306,
                },
            },
        },
    },
    [132617] = {
        name = "Bently Greaseflare",
        locations = {
            [862] = {
                {
                    x = 0.516,
                    y = 0.505,
                },
            },
        },
    },
    [132637] = {
        name = "Jamil Abul'housin",
        locations = {
            [862] = {
                {
                    x = 0.764,
                    y = 0.16,
                },
            },
        },
    },
    [132647] = {
        name = "Ancel Mildenhall",
        locations = {
            [942] = {
                {
                    x = 0.71,
                    y = 0.692,
                },
            },
        },
    },
    [132680] = {
        name = "Zukashi",
        locations = {
            [863] = {
                {
                    x = 0.651472,
                    y = 0.368739,
                },
            },
        },
    },
    [132720] = {
        name = "Hawkmaster Lloyd",
        locations = {
            [895] = {
                {
                    x = 0.806,
                    y = 0.42,
                },
            },
        },
    },
    [132966] = {
        name = "Lynn Sweet",
        locations = {
            [896] = {
                {
                    x = 0.27,
                    y = 0.712,
                },
            },
        },
    },
    [132988] = {
        name = "Patch",
        locations = {
            [863] = {
                {
                    x = 0.448,
                    y = 0.684,
                },
            },
        },
    },
    [132994] = {
        name = "Lord Arthur Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.242,
                    y = 0.15,
                },
            },
        },
    },
    [133035] = {
        name = "Officer Jovan",
        locations = {
            [895] = {
                {
                    x = 0.81,
                    y = 0.424,
                },
            },
        },
    },
    [133050] = {
        name = "Princess Talanji",
        locations = {
            [1164] = {
                {
                    x = 0.412776,
                    y = 0.66737,
                },
            },
        },
    },
    [133098] = {
        name = "Inquisitor Cleardawn",
        locations = {
            [896] = {
                {
                    x = 0.206,
                    y = 0.574,
                },
            },
        },
    },
    [133101] = {
        name = "Samantha Sweet",
        locations = {
            [896] = {
                {
                    x = 0.212,
                    y = 0.552,
                },
            },
        },
    },
    [133105] = {
        name = "Warren Ashton",
        locations = {
            [896] = {
                {
                    x = 0.21,
                    y = 0.552,
                },
            },
        },
    },
    [133125] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.452,
                    y = 0.605,
                },
            },
        },
    },
    [133126] = {
        name = "Marten Webb",
        locations = {
            [896] = {
                {
                    x = 0.206,
                    y = 0.575,
                },
            },
        },
    },
    [133324] = {
        name = "Hexlord Raal",
        locations = {
            [1165] = {
                {
                    x = 0.425,
                    y = 0.094,
                },
            },
        },
    },
    [133338] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.482,
                    y = 0.535,
                },
            },
        },
    },
    [133471] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.454,
                    y = 0.586,
                },
            },
        },
    },
    [133476] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.494,
                    y = 0.57,
                },
            },
        },
    },
    [133489] = {
        name = "Ormhun Stonehammer",
        locations = {
            [207] = {
                {
                    x = 0.53978,
                    y = 0.500902,
                },
            },
        },
    },
    [133490] = {
        name = "Jani",
        locations = {
            [862] = {
                {
                    x = 0.662,
                    y = 0.166,
                },
            },
        },
    },
    [133519] = {
        name = "Rokhan",
        locations = {
            [85] = {
                {
                    x = 0.381562,
                    y = 0.813515,
                },
            },
        },
    },
    [133523] = {
        name = "Ji Firepaw",
        locations = {
            [85] = {
                {
                    x = 0.377747,
                    y = 0.811661,
                },
            },
        },
    },
    [133536] = {
        name = "Grix \"Ironfists\" Barlow",
        locations = {
            [1161] = {
                {
                    x = 0.734526,
                    y = 0.084842,
                },
            },
        },
    },
    [133550] = {
        name = "Junior Miner Joe",
        locations = {
            [895] = {
                {
                    x = 0.756,
                    y = 0.506,
                },
            },
        },
    },
    [133551] = {
        name = "Chief Miner Theock",
        locations = {
            [895] = {
                {
                    x = 0.78,
                    y = 0.56,
                },
            },
        },
    },
    [133552] = {
        name = "Head Chemist Walters",
        locations = {
            [895] = {
                {
                    x = 0.78,
                    y = 0.56,
                },
            },
        },
    },
    [133576] = {
        name = "Coxswain Hook",
        locations = {
            [942] = {
                {
                    x = 0.26,
                    y = 0.552,
                },
            },
        },
    },
    [133577] = {
        name = "Master Gunner Line",
        locations = {
            [942] = {
                {
                    x = 0.258,
                    y = 0.552,
                },
            },
        },
    },
    [133578] = {
        name = "\"Sinker\"",
        locations = {
            [942] = {
                {
                    x = 0.258,
                    y = 0.552,
                },
            },
        },
    },
    [133612] = {
        name = "Jani",
        locations = {
            [862] = {
                {
                    x = 0.618,
                    y = 0.468,
                },
            },
        },
    },
    [133640] = {
        name = "Wayne the Ancestral",
        locations = {
            [942] = {
                {
                    x = 0.788,
                    y = 0.544,
                },
            },
        },
    },
    [133653] = {
        name = "Hexlord Raal",
        locations = {
            [862] = {
                {
                    x = 0.506,
                    y = 0.296,
                },
            },
        },
    },
    [133678] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.508,
                },
                {
                    x = 0.744,
                    y = 0.518,
                },
            },
        },
    },
    [133679] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.706,
                    y = 0.51,
                },
            },
        },
    },
    [133682] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.508,
                },
                {
                    x = 0.748,
                    y = 0.496,
                },
                {
                    x = 0.752,
                    y = 0.494,
                },
            },
        },
    },
    [133796] = {
        name = "Therazane",
        locations = {
            [207] = {
                {
                    x = 0.275631,
                    y = 0.509177,
                },
            },
        },
    },
    [133833] = {
        name = "Rikati",
        locations = {
            [864] = {
                {
                    x = 0.404,
                    y = 0.554,
                },
            },
        },
    },
    [133839] = {
        name = "Harris Hocking",
        locations = {
            [896] = {
                {
                    x = 0.27,
                    y = 0.252,
                },
            },
        },
    },
    [133859] = {
        name = "Jani",
        locations = {
            [864] = {
                {
                    x = 0.422,
                    y = 0.72,
                },
            },
        },
    },
    [133953] = {
        name = "Sergeant Calvin",
        locations = {
            [942] = {
                {
                    x = 0.448,
                    y = 0.645,
                },
            },
        },
    },
    [134009] = {
        name = "Corlain Townsperson",
        locations = {
            [896] = {
                {
                    x = 0.292,
                    y = 0.298,
                },
            },
        },
    },
    [134028] = {
        name = "Sam Robinson",
        locations = {
            [942] = {
                {
                    x = 0.728,
                    y = 0.722,
                },
            },
        },
    },
    [134098] = {
        name = "Torka",
        locations = {
            [864] = {
                {
                    x = 0.62,
                    y = 0.222,
                },
            },
        },
    },
    [134128] = {
        name = "Churka",
        locations = {
            [864] = {
                {
                    x = 0.62,
                    y = 0.222,
                },
            },
        },
    },
    [134133] = {
        name = "Teekcha",
        locations = {
            [864] = {
                {
                    x = 0.585,
                    y = 0.118,
                },
            },
        },
    },
    [134134] = {
        name = "Tulu",
        locations = {
            [864] = {
                {
                    x = 0.584,
                    y = 0.118,
                },
            },
        },
    },
    [134148] = {
        name = "Maaz",
        locations = {
            [864] = {
                {
                    x = 0.472,
                    y = 0.728,
                },
            },
        },
    },
    [134162] = {
        name = "Julwaba",
        locations = {
            [864] = {
                {
                    x = 0.47,
                    y = 0.756,
                },
            },
        },
    },
    [134164] = {
        name = "Amre",
        locations = {
            [864] = {
                {
                    x = 0.474,
                    y = 0.728,
                },
            },
        },
    },
    [134166] = {
        name = "Flynn Fairwind",
        locations = {
            [895] = {
                {
                    x = 0.758,
                    y = 0.49,
                },
            },
        },
    },
    [134325] = {
        name = "Terrence Foster",
        locations = {
            [895] = {
                {
                    x = 0.728,
                    y = 0.175,
                },
            },
        },
    },
    [134345] = {
        name = "Collector Kojo",
        locations = {
            [862] = {
                {
                    x = 0.714988,
                    y = 0.303476,
                },
            },
        },
    },
    [134346] = {
        name = "Toki",
        locations = {
            [1165] = {
                {
                    x = 0.562,
                    y = 0.915,
                },
            },
        },
    },
    [134408] = {
        name = "Foreman Jethek",
        locations = {
            [864] = {
                {
                    x = 0.496,
                    y = 0.762,
                },
            },
        },
    },
    [134509] = {
        name = "Lead Guide Zipwrench",
        locations = {
            [895] = {
                {
                    x = 0.666,
                    y = 0.5,
                },
            },
        },
    },
    [134533] = {
        name = "Serrik",
        locations = {
            [864] = {
                {
                    x = 0.47,
                    y = 0.756,
                },
            },
        },
    },
    [134611] = {
        name = "Seriah",
        locations = {
            [864] = {
                {
                    x = 0.326,
                    y = 0.484,
                },
            },
        },
    },
    [134623] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.662,
                    y = 0.47,
                },
            },
        },
    },
    [134628] = {
        name = "Civil Technician Alena",
        locations = {
            [895] = {
                {
                    x = 0.755,
                    y = 0.592,
                },
            },
        },
    },
    [134639] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.662,
                    y = 0.474,
                },
            },
        },
    },
    [134702] = {
        name = "Nedly Grinner",
        locations = {
            [942] = {
                {
                    x = 0.444,
                    y = 0.555,
                },
            },
        },
    },
    [134720] = {
        name = "Leo Shealds",
        locations = {
            [942] = {
                {
                    x = 0.43,
                    y = 0.566,
                },
            },
        },
    },
    [134752] = {
        name = "Mayor Roz",
        locations = {
            [942] = {
                {
                    x = 0.586,
                    y = 0.704,
                },
            },
        },
    },
    [134776] = {
        name = "Davey Brindle",
        locations = {
            [895] = {
                {
                    x = 0.674,
                    y = 0.24,
                },
            },
        },
    },
    [134953] = {
        name = "Alexander Treadward",
        locations = {
            [896] = {
                {
                    x = 0.232,
                    y = 0.126,
                },
            },
        },
    },
    [135012] = {
        name = "Vivi",
        locations = {
            [864] = {
                {
                    x = 0.552,
                    y = 0.484,
                },
            },
        },
    },
    [135021] = {
        name = "Inquisitor Cleardawn",
        locations = {
            [896] = {
                {
                    x = 0.372,
                    y = 0.502,
                },
            },
        },
    },
    [135033] = {
        name = "Maokka",
        locations = {
            [942] = {
                {
                    x = 0.426,
                    y = 0.544,
                },
            },
        },
    },
    [135067] = {
        name = "Moxie Lockspinner",
        locations = {
            [942] = {
                {
                    x = 0.426,
                    y = 0.542,
                },
            },
        },
    },
    [135085] = {
        name = "Captain Lilian Nottley",
        locations = {
            [896] = {
                {
                    x = 0.396,
                    y = 0.58,
                },
            },
        },
    },
    [135090] = {
        name = "Nisha",
        locations = {
            [864] = {
                {
                    x = 0.462,
                    y = 0.332,
                },
            },
        },
    },
    [135099] = {
        name = "Kiro",
        locations = {
            [864] = {
                {
                    x = 0.554,
                    y = 0.35,
                },
            },
        },
    },
    [135110] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.48,
                    y = 0.364,
                },
            },
        },
    },
    [135111] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.52,
                    y = 0.288,
                },
            },
        },
    },
    [135133] = {
        name = "Warguard Rakera",
        locations = {
            [864] = {
                {
                    x = 0.27,
                    y = 0.526,
                },
            },
        },
    },
    [135154] = {
        name = "Kiro",
        locations = {
            [864] = {
                {
                    x = 0.47,
                    y = 0.756,
                },
            },
        },
    },
    [135172] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.428,
                    y = 0.358,
                },
            },
        },
    },
    [135179] = {
        name = "Merd Archfeld",
        locations = {
            [864] = {
                {
                    x = 0.262,
                    y = 0.736,
                },
            },
        },
    },
    [135180] = {
        name = "Nerin Solvis",
        locations = {
            [864] = {
                {
                    x = 0.262,
                    y = 0.736,
                },
            },
        },
    },
    [135200] = {
        name = "Alexander Treadward",
        locations = {
            [896] = {
                {
                    x = 0.232,
                    y = 0.174,
                },
            },
        },
    },
    [135205] = {
        name = "Nathanos Blightcaller",
        locations = {
            [85] = {
                {
                    x = 0.545,
                    y = 0.785,
                },
            },
        },
    },
    [135259] = {
        name = "Taelia",
        locations = {
            [1161] = {
                {
                    x = 0.5,
                    y = 0.874,
                },
            },
        },
    },
    [135272] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.508,
                },
            },
        },
    },
    [135308] = {
        name = "Wingminder Goja",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.51,
                },
            },
        },
    },
    [135330] = {
        name = "Nedly Grinner",
        locations = {
            [942] = {
                {
                    x = 0.412,
                    y = 0.54,
                },
            },
        },
    },
    [135355] = {
        name = "Meerah",
        locations = {
            [864] = {
                {
                    x = 0.48,
                    y = 0.364,
                },
            },
        },
    },
    [135367] = {
        name = "Grettle Haribull",
        locations = {
            [942] = {
                {
                    x = 0.442,
                    y = 0.54,
                },
            },
        },
    },
    [135390] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.52,
                    y = 0.276,
                },
            },
        },
    },
    [135400] = {
        name = "Jenoh",
        locations = {
            [864] = {
                {
                    x = 0.295,
                    y = 0.593,
                },
            },
        },
    },
    [135441] = {
        name = "Zolani",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.85,
                },
            },
        },
    },
    [135455] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.706,
                    y = 0.51,
                },
            },
        },
    },
    [135502] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.506,
                },
            },
        },
    },
    [135517] = {
        name = "Tideguard Victoria",
        locations = {
            [942] = {
                {
                    x = 0.608,
                    y = 0.412,
                },
            },
        },
    },
    [135534] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.632,
                    y = 0.432,
                },
            },
        },
    },
    [135541] = {
        name = "Bilgewater Incinerator",
        locations = {
            [896] = {
                {
                    x = 0.362,
                    y = 0.346,
                },
                {
                    x = 0.362,
                    y = 0.366,
                },
                {
                    x = 0.364,
                    y = 0.344,
                },
                {
                    x = 0.364,
                    y = 0.364,
                },
                {
                    x = 0.366,
                    y = 0.342,
                },
                {
                    x = 0.372,
                    y = 0.352,
                },
                {
                    x = 0.374,
                    y = 0.358,
                },
                {
                    x = 0.376,
                    y = 0.352,
                },
                {
                    x = 0.384,
                    y = 0.36,
                },
                {
                    x = 0.384,
                    y = 0.366,
                },
                {
                    x = 0.386,
                    y = 0.354,
                },
                {
                    x = 0.386,
                    y = 0.356,
                },
                {
                    x = 0.39,
                    y = 0.376,
                },
                {
                    x = 0.392,
                    y = 0.374,
                },
                {
                    x = 0.396,
                    y = 0.374,
                },
            },
        },
    },
    [135576] = {
        name = "Bo'tzun Maset",
        locations = {
            [862] = {
                {
                    x = 0.544,
                    y = 0.87,
                },
            },
        },
    },
    [135595] = {
        name = "Pa'ku",
        locations = {
            [862] = {
                {
                    x = 0.724,
                    y = 0.57,
                },
            },
        },
    },
    [135612] = {
        name = "Halford Wyrmbane",
        locations = {
            [1161] = {
                {
                    x = 0.692717,
                    y = 0.269957,
                },
            },
        },
    },
    [135614] = {
        name = "Master Mathias Shaw",
        locations = {
            [1161] = {
                {
                    x = 0.704,
                    y = 0.27,
                },
            },
        },
    },
    [135618] = {
        name = "Falstad Wildhammer",
        locations = {
            [1161] = {
                {
                    x = 0.696,
                    y = 0.276,
                },
            },
        },
    },
    [135620] = {
        name = "Kelsey Steelspark",
        locations = {
            [862] = {
                {
                    x = 0.4076,
                    y = 0.7067,
                },
            },
        },
    },
    [135625] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.43,
                    y = 0.682,
                },
            },
        },
    },
    [135673] = {
        name = "Scout McKellis",
        locations = {
            [896] = {
                {
                    x = 0.346,
                    y = 0.398,
                },
            },
        },
    },
    [135681] = {
        name = "Grand Admiral Jes-Tereth",
        locations = {
            [1161] = {
                {
                    x = 0.679495,
                    y = 0.266862,
                },
            },
        },
    },
    [135682] = {
        name = "Patrick Eckhart",
        locations = {
            [942] = {
                {
                    x = 0.578,
                    y = 0.554,
                },
            },
        },
    },
    [135690] = {
        name = "Dread-Admiral Tattersail",
        locations = {
            [862] = {
                {
                    x = 0.584592,
                    y = 0.629857,
                },
            },
        },
    },
    [135691] = {
        name = "Nathanos Blightcaller",
        locations = {
            [862] = {
                {
                    x = 0.584,
                    y = 0.626,
                },
            },
        },
    },
    [135744] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.706,
                    y = 0.506,
                },
            },
        },
    },
    [135784] = {
        name = "Imperial Guard",
        locations = {
            [863] = {
                {
                    x = 0.292,
                    y = 0.52,
                },
            },
        },
    },
    [135793] = {
        name = "Collector Kojo",
        locations = {
            [942] = {
                {
                    x = 0.4054,
                    y = 0.364078,
                },
            },
        },
    },
    [135794] = {
        name = "Scrollsage Nola",
        locations = {
            [942] = {
                {
                    x = 0.406,
                    y = 0.456,
                },
            },
        },
    },
    [135795] = {
        name = "Toki",
        locations = {
            [942] = {
                {
                    x = 0.406,
                    y = 0.455,
                },
            },
        },
    },
    [135801] = {
        name = "Hexlord Raal",
        locations = {
            [862] = {
                {
                    x = 0.706,
                    y = 0.506,
                },
                {
                    x = 0.752,
                    y = 0.494,
                },
            },
        },
    },
    [135803] = {
        name = "J'eebi",
        locations = {
            [862] = {
                {
                    x = 0.764,
                    y = 0.488,
                },
            },
        },
    },
    [135855] = {
        name = "Teekay Treadlebobbin",
        locations = {
            [862] = {
                {
                    x = 0.764,
                    y = 0.488,
                },
            },
        },
    },
    [135861] = {
        name = "Adalyn Forestwatcher",
        locations = {
            [896] = {
                {
                    x = 0.334,
                    y = 0.65,
                },
            },
        },
    },
    [135874] = {
        name = "Lea Martinel",
        locations = {
            [942] = {
                {
                    x = 0.578,
                    y = 0.555,
                },
            },
        },
    },
    [135890] = {
        name = "King Rastakhan",
        locations = {
            [862] = {
                {
                    x = 0.600533,
                    y = 0.222359,
                },
            },
        },
    },
    [135901] = {
        name = "Bloodbough Funggarian",
    },
    [135976] = {
        name = "Morwin Gladeheart",
        locations = {
            [896] = {
                {
                    x = 0.3,
                    y = 0.404,
                },
            },
        },
    },
    [136041] = {
        name = "Emily Fairweather",
        locations = {
            [1161] = {
                {
                    x = 0.740291,
                    y = 0.115558,
                },
            },
        },
    },
    [136053] = {
        name = "Samuel Williams",
        locations = {
            [942] = {
                {
                    x = 0.632,
                    y = 0.432,
                },
            },
        },
    },
    [136059] = {
        name = "Layla Evenkeel",
        locations = {
            [1161] = {
                {
                    x = 0.77627,
                    y = 0.143328,
                },
            },
        },
    },
    [136063] = {
        name = "Cassandra Brennor",
        locations = {
            [1161] = {
                {
                    x = 0.754688,
                    y = 0.126023,
                },
            },
        },
    },
    [136140] = {
        name = "Clonk Greaseybit",
        locations = {
            [896] = {
                {
                    x = 0.208,
                    y = 0.436,
                },
            },
        },
    },
    [136184] = {
        name = "Kane Carlyle",
        locations = {
            [896] = {
                {
                    x = 0.208,
                    y = 0.46,
                },
            },
        },
    },
    [136192] = {
        name = "Degdod",
        locations = {
            [862] = {
                {
                    x = 0.7713,
                    y = 0.5559,
                },
            },
        },
    },
    [136195] = {
        name = "Medic Feorea",
        locations = {
            [862] = {
                {
                    x = 0.7712,
                    y = 0.5554,
                },
            },
        },
    },
    [136197] = {
        name = "Brigadier Thom",
        locations = {
            [862] = {
                {
                    x = 0.7754,
                    y = 0.5458,
                },
            },
        },
    },
    [136227] = {
        name = "Fixi Slyshiv",
        locations = {
            [896] = {
                {
                    x = 0.208,
                    y = 0.462,
                },
            },
        },
    },
    [136233] = {
        name = "Klause Fairwind",
        locations = {
            [896] = {
                {
                    x = 0.198,
                    y = 0.442,
                },
            },
        },
    },
    [136234] = {
        name = "Cesi Loosecannon",
        locations = {
            [896] = {
                {
                    x = 0.192,
                    y = 0.434,
                },
            },
        },
    },
    [136309] = {
        name = "First Mate Jamboya",
        locations = {
            [864] = {
                {
                    x = 0.354,
                    y = 0.832,
                },
            },
        },
    },
    [136310] = {
        name = "First Mate Jamboya",
        locations = {
            [864] = {
                {
                    x = 0.352,
                    y = 0.832,
                },
            },
        },
    },
    [136414] = {
        name = "Shepherd Milbrooke",
        locations = {
            [942] = {
                {
                    x = 0.318,
                    y = 0.695,
                },
            },
        },
    },
    [136432] = {
        name = "Brann Bronzebeard",
        locations = {
            [863] = {
                {
                    x = 0.6202,
                    y = 0.416,
                },
            },
        },
    },
    [136458] = {
        name = "Cesi Loosecannon",
        locations = {
            [896] = {
                {
                    x = 0.228,
                    y = 0.462,
                },
            },
        },
    },
    [136497] = {
        name = "Tideguard Victoria",
        locations = {
            [942] = {
                {
                    x = 0.618,
                    y = 0.362,
                },
            },
        },
    },
    [136498] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.6,
                    y = 0.378,
                },
            },
        },
    },
    [136562] = {
        name = "Quartermaster Alfin",
        locations = {
            [864] = {
                {
                    x = 0.366,
                    y = 0.324,
                },
            },
        },
    },
    [136568] = {
        name = "Captain Conrad",
        locations = {
            [863] = {
                {
                    x = 0.4501,
                    y = 0.5714,
                },
            },
        },
    },
    [136574] = {
        name = "Charles Davenport",
        locations = {
            [942] = {
                {
                    x = 0.304,
                    y = 0.668,
                },
            },
        },
    },
    [136576] = {
        name = "Dockmaster Leighton",
        locations = {
            [895] = {
                {
                    x = 0.75,
                    y = 0.496,
                },
            },
        },
    },
    [136641] = {
        name = "Brann Bronzebeard",
        locations = {
            [863] = {
                {
                    x = 0.3117,
                    y = 0.4672,
                },
            },
        },
    },
    [136645] = {
        name = "Brann Bronzebeard",
    },
    [136658] = {
        name = "Marie Davenport",
        locations = {
            [942] = {
                {
                    x = 0.304,
                    y = 0.668,
                },
            },
        },
    },
    [136675] = {
        name = "Brann Bronzebeard",
        locations = {
            [863] = {
                {
                    x = 0.4998,
                    y = 0.5094,
                },
            },
        },
    },
    [136683] = {
        name = "Trade Prince Gallywix",
        locations = {
            [862] = {
                {
                    x = 0.584,
                    y = 0.626,
                },
            },
        },
    },
    [136725] = {
        name = "Eitrigg",
        locations = {
            [896] = {
                {
                    x = 0.208,
                    y = 0.438,
                },
            },
        },
    },
    [136779] = {
        name = "First Mate Jamboya",
        locations = {
            [864] = {
                {
                    x = 0.332,
                    y = 0.818,
                },
            },
        },
    },
    [136907] = {
        name = "Magni Bronzebeard",
        locations = {
            [1021] = {
                {
                    x = 0.496,
                    y = 0.542,
                },
            },
        },
    },
    [136933] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.7,
                    y = 0.36,
                },
            },
        },
    },
    [137008] = {
        name = "Sergeant Ermey",
        locations = {
            [864] = {
                {
                    x = 0.396,
                    y = 0.356,
                },
            },
        },
    },
    [137075] = {
        name = "Lieutenant Dennis Grimtale",
        locations = {
            [862] = {
                {
                    x = 0.766,
                    y = 0.486,
                },
            },
        },
    },
    [137094] = {
        name = "Farmer Max",
        locations = {
            [942] = {
                {
                    x = 0.55,
                    y = 0.68,
                },
            },
        },
    },
    [137112] = {
        name = "Titan Keeper Hezrel",
        locations = {
            [863] = {
                {
                    x = 0.518,
                    y = 0.658,
                },
            },
        },
    },
    [137113] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.518,
                    y = 0.656,
                },
            },
        },
    },
    [137213] = {
        name = "Halford Wyrmbane",
        locations = {
            [864] = {
                {
                    x = 0.377,
                    y = 0.3583,
                },
            },
        },
    },
    [137337] = {
        name = "Sergeant Ermey",
        locations = {
            [864] = {
                {
                    x = 0.3897,
                    y = 0.4292,
                },
            },
        },
    },
    [137401] = {
        name = "Anvil-Thane Thurgaden",
        locations = {
            [862] = {
                {
                    x = 0.4075,
                    y = 0.7083,
                },
            },
        },
    },
    [137434] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.3897,
                    y = 0.4292,
                },
            },
        },
    },
    [137453] = {
        name = "Loroja",
        locations = {
            [942] = {
                {
                    x = 0.356,
                    y = 0.312,
                },
            },
        },
    },
    [137506] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.756,
                    y = 0.27,
                },
            },
        },
    },
    [137537] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.2722,
                    y = 0.5393,
                },
            },
        },
    },
    [137543] = {
        name = "Sergeant Ermey",
        locations = {
            [864] = {
                {
                    x = 0.2718,
                    y = 0.5391,
                },
            },
        },
    },
    [137554] = {
        name = "Toki",
        locations = {
            [942] = {
                {
                    x = 0.344,
                    y = 0.262,
                },
            },
        },
    },
    [137613] = {
        name = "Hobart Grapplehammer",
        locations = {
            [896] = {
                {
                    x = 0.335,
                    y = 0.378,
                },
            },
        },
    },
    [137629] = {
        name = "Mekaru",
        locations = {
            [864] = {
                {
                    x = 0.548,
                    y = 0.424,
                },
            },
        },
    },
    [137631] = {
        name = "Neri",
        locations = {
            [864] = {
                {
                    x = 0.546,
                    y = 0.425,
                },
            },
        },
    },
    [137675] = {
        name = "Shadow Hunter Ty'jin",
        locations = {
            [895] = {
                {
                    x = 0.894,
                    y = 0.534,
                },
            },
        },
    },
    [137677] = {
        name = "Toki",
        locations = {
            [942] = {
                {
                    x = 0.356,
                    y = 0.312,
                },
            },
        },
    },
    [137691] = {
        name = "Brother Pike",
        locations = {
            [942] = {
                {
                    x = 0.782,
                    y = 0.288,
                },
            },
        },
    },
    [137692] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.782,
                    y = 0.288,
                },
            },
        },
    },
    [137694] = {
        name = "Parin Tinklocket",
        locations = {
            [895] = {
                {
                    x = 0.65,
                    y = 0.606,
                },
            },
        },
    },
    [137727] = {
        name = "First Mate Owings",
        locations = {
            [895] = {
                {
                    x = 0.872,
                    y = 0.5,
                },
            },
        },
    },
    [137732] = {
        name = "Zallestrasza",
        locations = {
            [896] = {
                {
                    x = 0.334,
                    y = 0.652,
                },
            },
        },
    },
    [137742] = {
        name = "Shadow Hunter Ty'jin",
        locations = {
            [895] = {
                {
                    x = 0.872,
                    y = 0.5,
                },
            },
        },
    },
    [137818] = {
        name = "Myxle \"The Searat\" Gutwrench",
        locations = {
            [1165] = {
                {
                    x = 0.45,
                    y = 0.396,
                },
            },
        },
    },
    [137837] = {
        name = "Overlord Geya'rah",
        locations = {
            [1170] = {
                {
                    x = 0.363651,
                    y = 0.697067,
                },
            },
        },
    },
    [137866] = {
        name = "Taelia",
        locations = {
            [942] = {
                {
                    x = 0.578,
                    y = 0.858,
                },
            },
            [1161] = {
                {
                    x = 0.652,
                    y = 0.688,
                },
            },
        },
    },
    [137867] = {
        name = "Halford Wyrmbane",
        locations = {
            [864] = {
                {
                    x = 0.328,
                    y = 0.348,
                },
            },
        },
    },
    [137878] = {
        name = "Master Gadrin",
        locations = {
            [463] = {
                {
                    x = 0.595,
                    y = 0.515,
                },
            },
        },
    },
    [137970] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.428,
                    y = 0.358,
                },
            },
        },
    },
    [137981] = {
        name = "Kiro",
        locations = {
            [864] = {
                {
                    x = 0.46,
                    y = 0.332,
                },
            },
        },
    },
    [138131] = {
        name = "Rexxar",
        locations = {
            [942] = {
                {
                    x = 0.504,
                    y = 0.262,
                },
            },
        },
    },
    [138138] = {
        name = "Princess Talanji",
        locations = {
            [862] = {
                {
                    x = 0.438,
                    y = 0.394,
                },
            },
        },
    },
    [138148] = {
        name = "Bwonsamdi",
        locations = {
            [934] = {
                {
                    x = 0.4319,
                    y = 0.2561,
                },
            },
        },
    },
    [138285] = {
        name = "Nathanos Blightcaller",
        locations = {
            [895] = {
                {
                    x = 0.873716,
                    y = 0.50516,
                },
            },
        },
    },
    [138287] = {
        name = "Lilian Voss",
        locations = {
            [895] = {
                {
                    x = 0.77,
                    y = 0.492,
                },
            },
        },
    },
    [138352] = {
        name = "High Warlord Cromush",
        locations = {
            [862] = {
                {
                    x = 0.584,
                    y = 0.625,
                },
            },
        },
    },
    [138365] = {
        name = "High Warlord Cromush",
        locations = {
            [942] = {
                {
                    x = 0.51,
                    y = 0.21,
                },
            },
        },
    },
    [138382] = {
        name = "Akunda",
        locations = {
            [864] = {
                {
                    x = 0.522,
                    y = 0.798,
                },
            },
        },
    },
    [138411] = {
        name = "Vorrik",
        locations = {
            [864] = {
                {
                    x = 0.518,
                    y = 0.286,
                },
            },
        },
    },
    [138520] = {
        name = "Zeb'ahari Villager",
        locations = {
            [862] = {
                {
                    x = 0.794,
                    y = 0.166,
                },
            },
        },
    },
    [138521] = {
        name = "Mine Technician",
    },
    [138669] = {
        name = "Hemet Nesingwary",
        locations = {
            [862] = {
                {
                    x = 0.634,
                    y = 0.16,
                },
            },
        },
    },
    [138677] = {
        name = "Rexxar",
        locations = {
            [942] = {
                {
                    x = 0.516,
                    y = 0.298,
                },
            },
        },
    },
    [138688] = {
        name = "Centurion Kaga Warmstone",
        locations = {
            [942] = {
                {
                    x = 0.516,
                    y = 0.298,
                },
            },
        },
    },
    [138708] = {
        name = "Garona Halforcen",
        locations = {
            [1165] = {
                {
                    x = 0.516,
                    y = 0.994,
                },
            },
        },
    },
    [138735] = {
        name = "Felecia Gladstone",
        locations = {
            [942] = {
                {
                    x = 0.468,
                    y = 0.478,
                },
            },
        },
    },
    [138749] = {
        name = "Rhan'ka",
        locations = {
            [864] = {
                {
                    x = 0.374,
                    y = 0.51,
                },
            },
        },
    },
    [138867] = {
        name = "Rexxar",
        locations = {
            [942] = {
                {
                    x = 0.492,
                    y = 0.342,
                },
            },
        },
    },
    [138876] = {
        name = "Rexxar",
        locations = {
            [942] = {
                {
                    x = 0.521276,
                    y = 0.336598,
                },
            },
        },
    },
    [138924] = {
        name = "Holger Nash",
        locations = {
            [1182] = {
                {
                    x = 0.672,
                    y = 0.384,
                },
            },
        },
    },
    [138949] = {
        name = "Throk",
        locations = {
            [1165] = {
                x = 0.52953433990479,
                y = 0.9448184967041,
            },
        },
    },
    [139061] = {
        name = "Nathanos Blightcaller",
        locations = {
            [896] = {
                {
                    x = 0.613679,
                    y = 0.510941,
                },
            },
        },
    },
    [139062] = {
        name = "Lilian Voss",
        locations = {
            [896] = {
                {
                    x = 0.613121,
                    y = 0.510314,
                },
            },
        },
    },
    [139069] = {
        name = "First Mate Redmond",
        locations = {
            [864] = {
                {
                    x = 0.446,
                    y = 0.868,
                },
            },
        },
    },
    [139070] = {
        name = "Captain Redmond",
        locations = {
            [864] = {
                {
                    x = 0.432,
                    y = 0.908,
                },
            },
        },
    },
    [139089] = {
        name = "Hatherford Guard",
        locations = {
            [895] = {
                {
                    x = 0.664,
                    y = 0.248,
                },
            },
        },
    },
    [139098] = {
        name = "Thomas Zelling",
        locations = {
            [942] = {
                {
                    x = 0.626442,
                    y = 0.318756,
                },
            },
        },
    },
    [139101] = {
        name = "Lilian Voss",
        locations = {
            [942] = {
                {
                    x = 0.626487,
                    y = 0.319449,
                },
            },
        },
    },
    [139102] = {
        name = "Rexxar",
        locations = {
            [942] = {
                {
                    x = 0.626882,
                    y = 0.31815,
                },
            },
        },
    },
    [139568] = {
        name = "Magister Umbric",
        locations = {
            [864] = {
                {
                    x = 0.3747,
                    y = 0.3583,
                },
            },
        },
    },
    [139609] = {
        name = "John J. Keeshan",
        locations = {
            [863] = {
                {
                    x = 0.512,
                    y = 0.218,
                },
            },
        },
    },
    [139705] = {
        name = "Halford Wyrmbane",
        locations = {
            [864] = {
                {
                    x = 0.376,
                    y = 0.358,
                },
            },
        },
    },
    [139719] = {
        name = "Shandris Feathermoon",
        locations = {
            [864] = {
                {
                    x = 0.376,
                    y = 0.358,
                },
            },
        },
    },
    [139722] = {
        name = "Explosioneer Zoidfuse",
        locations = {
            [864] = {
                {
                    x = 0.412,
                    y = 0.724,
                },
            },
        },
    },
    [139912] = {
        name = "Ranger Wons",
        locations = {
            [896] = {
                {
                    x = 0.618,
                    y = 0.592,
                },
            },
        },
    },
    [139926] = {
        name = "Thornspeaker Birchgrove",
        locations = {
            [896] = {
                {
                    x = 0.618,
                    y = 0.594,
                },
            },
        },
    },
    [139928] = {
        name = "Master Gadrin",
        locations = {
            [862] = {
                {
                    x = 0.455283,
                    y = 0.358065,
                },
            },
        },
    },
    [140046] = {
        name = "Rozzy",
        locations = {
            [864] = {
                {
                    x = 0.285,
                    y = 0.686,
                },
            },
        },
    },
    [140048] = {
        name = "Arthur Tradewind",
        locations = {
            [896] = {
                {
                    x = 0.584,
                    y = 0.632,
                },
            },
        },
    },
    [140105] = {
        name = "Nathanos Blightcaller",
    },
    [140176] = {
        name = "Nathanos Blightcaller",
        locations = {
            [85] = {
                {
                    x = 0.49,
                    y = 0.915,
                },
            },
        },
    },
    [140258] = {
        name = "Shandris Feathermoon",
        locations = {
            [863] = {
                {
                    x = 0.62,
                    y = 0.412,
                },
            },
        },
    },
    [140484] = {
        name = "Captain Amalia Stone",
        locations = {
            [895] = {
                {
                    x = 0.869661,
                    y = 0.531253,
                },
            },
        },
    },
    [140485] = {
        name = "Nathanos Blightcaller",
        locations = {
            [895] = {
                {
                    x = 0.869119,
                    y = 0.531448,
                },
            },
        },
    },
    [140487] = {
        name = "Thomas Zelling",
        locations = {
            [1161] = {
                {
                    x = 0.711922,
                    y = 0.847725,
                },
            },
        },
    },
    [140495] = {
        name = "Katherine Proudmoore",
    },
    [140590] = {
        name = "Captain Grez'ko",
        locations = {
            [1165] = {
                {
                    x = 0.461302,
                    y = 0.945733,
                },
            },
        },
    },
    [140656] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.53,
                    y = 0.692,
                },
            },
        },
    },
    [140724] = {
        name = "Princess Talanji",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.398,
                },
            },
        },
    },
    [140725] = {
        name = "Spirit of Vol'jin",
        locations = {
            [1165] = {
                {
                    x = 0.499,
                    y = 0.395,
                },
            },
        },
    },
    [140752] = {
        name = "Jenny Swiftbrook",
        locations = {
            [895] = {
                {
                    x = 0.61,
                    y = 0.308,
                },
            },
        },
    },
    [140907] = {
        name = "Bwonsamdi",
        locations = {
            [1165] = {
                {
                    x = 0.45,
                    y = 0.2,
                },
            },
        },
    },
    [141026] = {
        name = "Kua'fon",
        locations = {
            [862] = {
                {
                    x = 0.708,
                    y = 0.506,
                },
            },
        },
    },
    [141078] = {
        name = "Vigil Hill Refugee",
        locations = {
            [895] = {
                {
                    x = 0.608,
                    y = 0.592,
                },
            },
        },
    },
    [141555] = {
        name = "Baine Bloodhoof",
        locations = {
            [1164] = {
                {
                    x = 0.413835,
                    y = 0.724098,
                },
            },
        },
    },
    [141602] = {
        name = "Thomas Zelling",
        locations = {
            [1161] = {
                {
                    x = 0.711525,
                    y = 0.822497,
                },
            },
        },
    },
    [141603] = {
        name = "Mallory Hood",
        locations = {
            [942] = {
                {
                    x = 0.648,
                    y = 0.768,
                },
            },
        },
    },
    [141643] = {
        name = "Seafloor Shambleclaw",
    },
    [141644] = {
        name = "Nathanos Blightcaller",
        locations = {
            [1157] = {
                {
                    x = 0.402961,
                    y = 0.672602,
                },
            },
        },
    },
    [141672] = {
        name = "Drowned Sailor",
    },
    [141769] = {
        name = "Marilyn Hood",
        locations = {
            [942] = {
                {
                    x = 0.602,
                    y = 0.704,
                },
            },
        },
    },
    [141815] = {
        name = "Drowned Sailor",
    },
    [141952] = {
        name = "Direhorn Juvenile",
        locations = {
            [862] = {
                {
                    x = 0.682,
                    y = 0.418,
                },
            },
        },
    },
    [141961] = {
        name = "Lilian Voss",
        locations = {
            [1165] = {
                {
                    x = 0.515428,
                    y = 0.994192,
                },
            },
        },
    },
    [142275] = {
        name = "Grommash Hellscream",
        locations = {
            [1170] = {
                {
                    x = 0.452656,
                    y = 0.520904,
                },
            },
        },
    },
    [142393] = {
        name = "Taelia",
        locations = {
            [895] = {
                {
                    x = 0.564,
                    y = 0.615,
                },
            },
        },
    },
    [142422] = {
        name = "Eitrigg",
        locations = {
            [1170] = {
                {
                    x = 0.449965,
                    y = 0.532265,
                },
            },
        },
    },
    [142651] = {
        name = "Lucille Waycrest",
        locations = {
            [896] = {
                {
                    x = 0.36,
                    y = 0.512,
                },
            },
        },
    },
    [142721] = {
        name = "Ralston Karn",
    },
    [142930] = {
        name = "Halford Wyrmbane",
        locations = {
            [84] = {
                {
                    x = 0.276,
                    y = 0.215,
                },
            },
        },
    },
    [143536] = {
        name = "High Warlord Volrath",
        locations = {
            [862] = {
                {
                    x = 0.514,
                    y = 0.582,
                },
                {
                    x = 0.516,
                    y = 0.582,
                },
            },
        },
    },
    [143559] = {
        name = "Grand Marshal Tremblade",
        locations = {
            [1161] = {
                {
                    x = 0.564,
                    y = 0.26,
                },
            },
        },
    },
    [143565] = {
        name = "Wayne the Ancestral",
        locations = {
            [942] = {
                {
                    x = 0.786,
                    y = 0.548,
                },
            },
        },
    },
    [143692] = {
        name = "Anachronos",
        locations = {
            [379] = {
                {
                    x = 0.689028,
                    y = 0.439682,
                },
            },
        },
    },
    [143777] = {
        name = "Tall Hasani",
        locations = {
            [895] = {
                {
                    x = 0.852,
                    y = 0.805,
                },
            },
        },
    },
    [143787] = {
        name = "Flap-Flap",
        locations = {
            [862] = {
                {
                    x = 0.515,
                    y = 0.53,
                },
            },
        },
    },
    [143792] = {
        name = "Tsunga",
        locations = {
            [862] = {
                {
                    x = 0.501707,
                    y = 0.54574,
                },
            },
        },
    },
    [143845] = {
        name = "Overlord Geya'rah",
        locations = {
            [85] = {
                {
                    x = 0.38,
                    y = 0.808,
                },
                {
                    x = 0.704,
                    y = 0.446,
                },
                {
                    x = 0.706,
                    y = 0.444,
                },
                {
                    x = 0.706,
                    y = 0.446,
                },
            },
        },
    },
    [143846] = {
        name = "Alleria Windrunner",
        locations = {
            [1161] = {
                {
                    x = 0.704,
                    y = 0.272,
                },
            },
        },
    },
    [143851] = {
        name = "Kelsey Steelspark",
        locations = {
            [1161] = {
                {
                    x = 0.6801,
                    y = 0.263,
                },
            },
        },
    },
    [143871] = {
        name = "Foreman Cogbutton",
        locations = {
            [896] = {
                {
                    x = 0.345,
                    y = 0.306,
                },
            },
        },
    },
    [143878] = {
        name = "Reez Grimelock",
        locations = {
            [896] = {
                {
                    x = 0.363495,
                    y = 0.258431,
                },
            },
        },
    },
    [143908] = {
        name = "Mangled Body",
        locations = {
            [896] = {
                {
                    x = 0.546,
                    y = 0.49,
                },
            },
        },
    },
    [143913] = {
        name = "Eitrigg",
        locations = {
            [862] = {
                {
                    x = 0.584,
                    y = 0.626,
                },
            },
        },
    },
    [144095] = {
        name = "Master Mathias Shaw",
        locations = {
            [84] = {
                {
                    x = 0.225,
                    y = 0.326,
                },
            },
        },
    },
    [144152] = {
        name = "Moira Thaurissan",
        locations = {
            [1186] = {
                {
                    x = 0.562,
                    y = 0.32,
                },
                {
                    x = 0.566,
                    y = 0.318,
                },
            },
        },
    },
    [144773] = {
        name = "Xal'atath",
        locations = {
            [896] = {
                {
                    x = 0.19916,
                    y = 0.362433,
                },
            },
        },
    },
    [145005] = {
        name = "Farstrider Elite",
        locations = {
            [95] = {
                {
                    x = 0.474759,
                    y = 0.840655,
                },
            },
        },
    },
    [145015] = {
        name = "Lor'themar Theron",
        locations = {
            [95] = {
                {
                    x = 0.462967,
                    y = 0.319787,
                },
            },
        },
    },
    [145022] = {
        name = "Timeweaver Delormi",
        locations = {
            [1165] = {
                {
                    x = 0.435104,
                    y = 0.347621,
                },
            },
        },
    },
    [145131] = {
        name = "Dataguru Gryzix",
        locations = {
            [864] = {
                {
                    x = 0.262654,
                    y = 0.473523,
                },
            },
        },
    },
    [145190] = {
        name = "Princess Talanji",
        locations = {
            [1167] = {
                {
                    x = 0.667774,
                    y = 0.713598,
                },
            },
        },
    },
    [145225] = {
        name = "Spirit of Vol'jin",
        locations = {
            [1167] = {
                {
                    x = 0.679436,
                    y = 0.730454,
                },
            },
        },
    },
    [145359] = {
        name = "Princess Talanji",
        locations = {
            [1165] = {
                {
                    x = 0.40524,
                    y = 0.118909,
                },
            },
        },
    },
    [145360] = {
        name = "Zolani",
        locations = {
            [1165] = {
                {
                    x = 0.402758,
                    y = 0.124533,
                },
            },
        },
    },
    [145396] = {
        name = "Xal'atath",
        locations = {
            [895] = {
                {
                    x = 0.750368,
                    y = 0.776703,
                },
            },
        },
    },
    [145411] = {
        name = "Lady Sylvanas Windrunner",
        locations = {
            [1165] = {
                {
                    x = 0.499839,
                    y = 0.388858,
                },
            },
        },
    },
    [145414] = {
        name = "Natal'hakata",
        locations = {
            [1163] = {
                {
                    x = 0.486514,
                    y = 0.219611,
                },
            },
        },
    },
    [145416] = {
        name = "Kiro",
        locations = {
            [85] = {
                {
                    x = 0.488908,
                    y = 0.72749,
                },
            },
        },
    },
    [145422] = {
        name = "Rexxar",
        locations = {
            [895] = {
                {
                    x = 0.475147,
                    y = 0.217621,
                },
            },
        },
    },
    [145423] = {
        name = "Thomas Zelling",
        locations = {
            [895] = {
                {
                    x = 0.488627,
                    y = 0.250326,
                },
            },
        },
    },
    [145424] = {
        name = "Baine Bloodhoof",
        locations = {
            [85] = {
                {
                    x = 0.483009,
                    y = 0.710423,
                },
            },
        },
    },
    [145462] = {
        name = "Brann Bronzebeard",
        locations = {
            [87] = {
                {
                    x = 0.774302,
                    y = 0.095088,
                },
            },
        },
    },
    [145464] = {
        name = "Advisor Belgrum",
        locations = {
            [87] = {
                {
                    x = 0.39883,
                    y = 0.465634,
                },
            },
        },
    },
    [145580] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [895] = {
                {
                    x = 0.421639,
                    y = 0.298501,
                },
            },
        },
    },
    [145593] = {
        name = "Rosaline Madison",
        locations = {
            [895] = {
                {
                    x = 0.415231,
                    y = 0.270314,
                },
            },
        },
    },
    [145632] = {
        name = "Okri Putterwrench",
        locations = {
            [895] = {
                {
                    x = 0.415337,
                    y = 0.270812,
                },
            },
        },
    },
    [145641] = {
        name = "Kiro",
        locations = {
            [241] = {
                {
                    x = 0.4681,
                    y = 0.662277,
                },
            },
        },
    },
    [145751] = {
        name = "Trade Prince Gallywix",
        locations = {
            [862] = {
                {
                    x = 0.36313,
                    y = 0.720224,
                },
            },
        },
    },
    [145793] = {
        name = "Lady Liadrin",
        locations = {
            [122] = {
                {
                    x = 0.483595,
                    y = 0.360023,
                },
            },
        },
    },
    [145816] = {
        name = "G.M.O.D",
        locations = {
            [896] = {
                {
                    x = 0.373178,
                    y = 0.260129,
                },
            },
        },
    },
    [145965] = {
        name = "Spirit of Vol'jin",
        locations = {
            [646] = {
                {
                    x = 0.632196,
                    y = 0.333921,
                },
            },
        },
    },
    [145980] = {
        name = "Nisha",
        locations = {
            [862] = {
                {
                    x = 0.748591,
                    y = 0.630293,
                },
            },
        },
    },
    [145981] = {
        name = "Spirit of Vol'jin",
        locations = {
            [646] = {
                {
                    x = 0.623324,
                    y = 0.306669,
                },
            },
        },
    },
    [146010] = {
        name = "Dark Ranger Lyana",
        locations = {
            [37] = {
                {
                    x = 0.305501,
                    y = 0.576623,
                },
            },
        },
    },
    [146011] = {
        name = "Varok Saurfang",
        locations = {
            [51] = {
                {
                    x = 0.807928,
                    y = 0.787161,
                },
            },
        },
    },
    [146012] = {
        name = "Zekhan",
        locations = {
            [49] = {
                {
                    x = 0.8092,
                    y = 0.511474,
                },
            },
        },
    },
    [146013] = {
        name = "Dark Ranger Alina",
        locations = {
            [862] = {
                {
                    x = 0.583967,
                    y = 0.627216,
                },
            },
        },
    },
    [146050] = {
        name = "Maiev Shadowsong",
        locations = {
            [84] = {
                {
                    x = 0.866479,
                    y = 0.357489,
                },
            },
        },
    },
    [146053] = {
        name = "Sef Iwen",
        locations = {
            [896] = {
                {
                    x = 0.533888,
                    y = 0.401357,
                },
            },
        },
    },
    [146073] = {
        name = "Trade Prince Gallywix",
        locations = {
            [895] = {
                {
                    x = 0.546051,
                    y = 0.645856,
                },
            },
        },
    },
    [146091] = {
        name = "Sef Iwen",
        locations = {
            [896] = {
                {
                    x = 0.553347,
                    y = 0.460532,
                },
            },
        },
    },
    [146093] = {
        name = "Sef Iwen",
        locations = {
            [896] = {
                {
                    x = 0.629644,
                    y = 0.594402,
                },
            },
        },
    },
    [146094] = {
        name = "Sef Iwen",
        locations = {
            [896] = {
                {
                    x = 0.589329,
                    y = 0.628745,
                },
            },
        },
    },
    [146208] = {
        name = "Krag'wa the Huge",
        locations = {
            [1165] = {
                {
                    x = 0.441908,
                    y = 0.149368,
                },
            },
        },
    },
    [146209] = {
        name = "Pa'ku",
        locations = {
            [1165] = {
                {
                    x = 0.44535,
                    y = 0.08808,
                },
            },
        },
    },
    [146214] = {
        name = "Gonk",
        locations = {
            [1165] = {
                {
                    x = 0.465338,
                    y = 0.120059,
                },
            },
        },
    },
    [146261] = {
        name = "Kiro",
        locations = {
            [85] = {
                {
                    x = 0.490194,
                    y = 0.73687,
                },
            },
        },
    },
    [146264] = {
        name = "Meerah",
        locations = {
            [680] = {
                {
                    x = 0.589345,
                    y = 0.550811,
                },
            },
        },
    },
    [146290] = {
        name = "Spirit of Vol'jin",
        locations = {
            {
                {
                    x = 0.459875,
                    y = 0.159819,
                },
            },
        },
    },
    [146301] = {
        name = "Nomi",
        locations = {
            [680] = {
                {
                    x = 0.605917,
                    y = 0.562196,
                },
            },
        },
    },
    [146323] = {
        name = "Nathanos Blightcaller",
        locations = {
            [1333] = {
                {
                    x = 0.5363,
                    y = 0.204108,
                },
            },
        },
    },
    [146325] = {
        name = "Shredmaster Blix",
        locations = {
            [1333] = {
                {
                    x = 0.547069,
                    y = 0.219751,
                },
            },
        },
    },
    [146335] = {
        name = "Queen Talanji",
        locations = {
            [1165] = {
                {
                    x = 0.424179,
                    y = 0.092116,
                },
            },
        },
    },
    [146373] = {
        name = "Maiev Shadowsong",
        locations = {
            [62] = {
                {
                    x = 0.306215,
                    y = 0.981569,
                },
            },
        },
    },
    [146374] = {
        name = "Shandris Feathermoon",
        locations = {
            [62] = {
                {
                    x = 0.30671,
                    y = 0.981258,
                },
            },
        },
    },
    [146375] = {
        name = "Sira Moonwarden",
        locations = {
            [62] = {
                {
                    x = 0.306005,
                    y = 0.982317,
                },
            },
        },
    },
    [146384] = {
        name = "Xal'atath",
        locations = {
            [864] = {
                {
                    x = 0.530276,
                    y = 0.136688,
                },
            },
        },
    },
    [146462] = {
        name = "Rexxar",
        locations = {
            [895] = {
                {
                    x = 0.50835,
                    y = 0.268444,
                },
            },
        },
    },
    [146536] = {
        name = "Lost Wisp",
    },
    [146601] = {
        name = "Sira Moonwarden",
        locations = {
            [1333] = {
                {
                    x = 0.546482,
                    y = 0.206345,
                },
            },
        },
    },
    [146623] = {
        name = "G.M.O.D",
        locations = {
            [895] = {
                {
                    x = 0.87638,
                    y = 0.534884,
                },
            },
        },
    },
    [146630] = {
        name = "Spirit of Vol'jin",
        locations = {
            [85] = {
                {
                    x = 0.484854,
                    y = 0.715024,
                },
            },
        },
    },
    [146654] = {
        name = "Lady Sylvanas Windrunner",
        locations = {
            [85] = {
                {
                    x = 0.483173,
                    y = 0.710891,
                },
            },
        },
    },
    [146791] = {
        name = "Dark Ranger Lyana",
        locations = {
            [37] = {
                {
                    x = 0.344098,
                    y = 0.629994,
                },
            },
        },
    },
    [146806] = {
        name = "Dark Ranger Lyana",
        locations = {
            [49] = {
                {
                    x = 0.113567,
                    y = 0.668283,
                },
            },
        },
    },
    [146824] = {
        name = "Princess Talanji",
        locations = {
            [863] = {
                {
                    x = 0.395748,
                    y = 0.270399,
                },
            },
        },
    },
    [146877] = {
        name = "Princess Talanji",
        locations = {
            [634] = {
                {
                    x = 0.612259,
                    y = 0.681019,
                },
            },
        },
    },
    [146902] = {
        name = "Brother Pike",
        locations = {
            [1161] = {
                {
                    x = 0.673688,
                    y = 0.209541,
                },
            },
        },
    },
    [146921] = {
        name = "Princess Talanji",
        locations = {
            [862] = {
                {
                    x = 0.579521,
                    y = 0.212603,
                },
            },
        },
    },
    [146931] = {
        name = "Rexxar",
        locations = {
            [895] = {
                {
                    x = 0.829939,
                    y = 0.496437,
                },
            },
        },
    },
    [146937] = {
        name = "Dark Ranger Lyana",
        locations = {
            [49] = {
                {
                    x = 0.258779,
                    y = 0.399649,
                },
            },
        },
    },
    [146939] = {
        name = "Ambassador Dawnsworn",
        locations = {
            [85] = {
                {
                    x = 0.391281,
                    y = 0.789986,
                },
            },
        },
    },
    [146982] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [862] = {
                {
                    x = 0.405582,
                    y = 0.706942,
                },
            },
        },
    },
    [146988] = {
        name = "Digger Golad",
        locations = {
            [84] = {
                {
                    x = 0.544729,
                    y = 0.183111,
                },
            },
        },
    },
    [147075] = {
        name = "General Rakera",
        locations = {
            [862] = {
                {
                    x = 0.579566,
                    y = 0.213059,
                },
            },
        },
    },
    [147088] = {
        name = "Arcanist Valtrois",
        locations = {
            [895] = {
                {
                    x = 0.829467,
                    y = 0.495391,
                },
            },
        },
    },
    [147135] = {
        name = "Nathanos Blightcaller",
        locations = {
            [895] = {
                {
                    x = 0.882067,
                    y = 0.507495,
                },
            },
        },
    },
    [147145] = {
        name = "Nathanos Blightcaller",
        locations = {
            [863] = {
                {
                    x = 0.503383,
                    y = 0.78408,
                },
            },
        },
    },
    [147148] = {
        name = "Megs",
        locations = {
            [862] = {
                {
                    x = 0.410977,
                    y = 0.706013,
                },
            },
        },
    },
    [147149] = {
        name = "Morton Cogswald",
        locations = {
            [862] = {
                {
                    x = 0.410713,
                    y = 0.706074,
                },
            },
        },
    },
    [147151] = {
        name = "Kelsey Steelspark",
        locations = {
            [862] = {
                {
                    x = 0.410797,
                    y = 0.70657,
                },
            },
        },
    },
    [147155] = {
        name = "Patch",
        locations = {
            [863] = {
                {
                    x = 0.502956,
                    y = 0.784093,
                },
            },
        },
    },
    [147210] = {
        name = "Dark Ranger Lyana",
        locations = {
            [49] = {
                {
                    x = 0.806472,
                    y = 0.46966,
                },
            },
        },
    },
    [147228] = {
        name = "Grong",
        locations = {
            [862] = {
                {
                    x = 0.467933,
                    y = 0.504835,
                },
            },
        },
    },
    [147233] = {
        name = "Rokhan",
        locations = {
            [863] = {
                {
                    x = 0.312554,
                    y = 0.468171,
                },
            },
        },
    },
    [147293] = {
        name = "Grong",
        locations = {
            [862] = {
                {
                    x = 0.495219,
                    y = 0.55162,
                },
            },
        },
    },
    [147297] = {
        name = "Zekhan",
        locations = {
            [51] = {
                {
                    x = 0.797927,
                    y = 0.747171,
                },
            },
        },
    },
    [147311] = {
        name = "Morton Cogswald",
        locations = {
            [862] = {
                {
                    x = 0.410707,
                    y = 0.706069,
                },
            },
        },
    },
    [147519] = {
        name = "Kelsey Steelspark",
        locations = {
            [862] = {
                {
                    x = 0.411468,
                    y = 0.706767,
                },
            },
        },
    },
    [147819] = {
        name = "Blademaster Telaamon",
        locations = {
            [1161] = {
                {
                    x = 0.38963,
                    y = 0.768991,
                },
            },
        },
    },
    [147842] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [863] = {
                {
                    x = 0.33645,
                    y = 0.476514,
                },
            },
        },
    },
    [147843] = {
        name = "Master Mathias Shaw",
        locations = {
            [863] = {
                {
                    x = 0.442183,
                    y = 0.786329,
                },
            },
        },
    },
    [147844] = {
        name = "Blademaster Telaamon",
        locations = {
            [863] = {
                {
                    x = 0.333639,
                    y = 0.459117,
                },
            },
        },
    },
    [147885] = {
        name = "Anduin Wrynn",
        locations = {
            [1161] = {
                {
                    x = 0.493425,
                    y = 0.855355,
                },
            },
        },
    },
    [147939] = {
        name = "Ace Pilot Stormcog",
        locations = {
            [84] = {
                {
                    x = 0.546672,
                    y = 0.185202,
                },
            },
        },
    },
    [147943] = {
        name = "Captain Tread Sparknozzle",
        locations = {
            [469] = {
                {
                    x = 0.417768,
                    y = 0.316318,
                },
            },
        },
    },
    [147950] = {
        name = "Cog Captain Winklespring",
        locations = {
            [114] = {
                {
                    x = 0.552779,
                    y = 0.189143,
                },
            },
        },
    },
    [147952] = {
        name = "Fizzi Tinkerbow",
        locations = {
            [114] = {
                {
                    x = 0.553056,
                    y = 0.189661,
                },
            },
        },
    },
    [148015] = {
        name = "Taelia Fordragon",
        locations = {
            [895] = {
                {
                    x = 0.421313,
                    y = 0.29873,
                },
            },
        },
    },
    [148096] = {
        name = "High Prelate Rata",
        locations = {
            [1165] = {
                {
                    x = 0.425834,
                    y = 0.225431,
                },
            },
        },
    },
    [148339] = {
        name = "Patch",
        locations = {
            [862] = {
                {
                    x = 0.362539,
                    y = 0.720238,
                },
            },
        },
    },
    [148798] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [84] = {
                {
                    x = 0.522849,
                    y = 0.13384,
                },
            },
        },
    },
    [148870] = {
        name = "Dorian Atwater",
        locations = {
            [942] = {
                {
                    x = 0.502275,
                    y = 0.498704,
                },
            },
        },
    },
    [149084] = {
        name = "Spiritwalker Ussoh",
        locations = {
            [462] = {
                {
                    x = 0.121667,
                    y = 0.312663,
                },
            },
        },
    },
    [149088] = {
        name = "Spiritwalker Isahi",
        locations = {
            [85] = {
                {
                    x = 0.391346,
                    y = 0.79014,
                },
            },
        },
    },
    [149143] = {
        name = "Nathanos Blightcaller",
    },
    [149252] = {
        name = "Bound Sky",
    },
    [149471] = {
        name = "Dark Ranger Velonara",
        locations = {
            [1165] = {
                {
                    x = 0.529794,
                    y = 0.943285,
                },
            },
        },
    },
    [149503] = {
        name = "Cog Captain Winklespring",
        locations = {
            [1375] = {
                {
                    x = 0.500569,
                    y = 0.126573,
                },
            },
        },
    },
    [149528] = {
        name = "Baine Bloodhoof",
        locations = {
            [88] = {
                {
                    x = 0.582277,
                    y = 0.518138,
                },
            },
        },
    },
    [149529] = {
        name = "Spiritwalker Ussoh",
        locations = {
            [65] = {
                {
                    x = 0.49175,
                    y = 0.609201,
                },
            },
        },
    },
    [149612] = {
        name = "Shandris Feathermoon",
        locations = {
            [1161] = {
                {
                    x = 0.695354,
                    y = 0.268382,
                },
            },
        },
    },
    [149736] = {
        name = "Image of Mimiron",
        locations = {
            [120] = {
                {
                    x = 0.375277,
                    y = 0.465178,
                },
            },
        },
    },
    [149809] = {
        name = "Gazlowe",
        locations = {
            [895] = {
                {
                    x = 0.658177,
                    y = 0.663483,
                },
            },
        },
    },
    [149815] = {
        name = "Grizzek Fizzwrench",
        locations = {
            [1462] = {
                {
                    x = 0.715588,
                    y = 0.387642,
                },
            },
        },
    },
    [149823] = {
        name = "Magni Bronzebeard",
        locations = {
            [1382] = {
                {
                    x = 0.522997,
                    y = 0.68758,
                },
            },
        },
    },
    [149842] = {
        name = "Baine Bloodhoof",
        locations = {
            [895] = {
                {
                    x = 0.858817,
                    y = 0.459009,
                },
            },
        },
    },
    [149864] = {
        name = "Tinkmaster Overspark",
        locations = {
            [895] = {
                {
                    x = 0.655917,
                    y = 0.650242,
                },
            },
        },
    },
    [149867] = {
        name = "Magni Bronzebeard",
        locations = {
            [863] = {
                {
                    x = 0.578895,
                    y = 0.504756,
                },
            },
        },
    },
    [149870] = {
        name = "Grif Wildheart",
        locations = {
            [120] = {
                {
                    x = 0.336291,
                    y = 0.585711,
                },
            },
        },
    },
    [149877] = {
        name = "Tinkmaster Overspark",
        locations = {
            [895] = {
                {
                    x = 0.658198,
                    y = 0.663654,
                },
            },
        },
    },
    [149904] = {
        name = "Neri Sharpfin",
        locations = {
            [1355] = {
                {
                    x = 0.497372,
                    y = 0.646511,
                },
            },
        },
    },
    [150086] = {
        name = "Bolten Springspark",
        locations = {
            [1462] = {
                {
                    x = 0.631551,
                    y = 0.392944,
                },
            },
        },
    },
    [150087] = {
        name = "Genn Greymane",
        locations = {
            [1355] = {
                {
                    x = 0.483282,
                    y = 0.926231,
                },
            },
        },
    },
    [150101] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1355] = {
                {
                    x = 0.403184,
                    y = 0.552403,
                },
            },
        },
    },
    [150106] = {
        name = "Goldrinn",
        locations = {
            [47] = {
                {
                    x = 0.465609,
                    y = 0.364926,
                },
            },
        },
    },
    [150115] = {
        name = "Princess Tess Greymane",
        locations = {
            [47] = {
                {
                    x = 0.463311,
                    y = 0.370708,
                },
            },
        },
    },
    [150145] = {
        name = "Gila Crosswires",
        locations = {
            [1161] = {
                {
                    x = 0.432245,
                    y = 0.320047,
                },
            },
        },
    },
    [150187] = {
        name = "Nathanos Blightcaller",
        locations = {
            [1355] = {
                {
                    x = 0.36795,
                    y = 0.9352,
                },
            },
        },
    },
    [150196] = {
        name = "First Arcanist Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.419691,
                    y = 0.806954,
                },
            },
        },
    },
    [150200] = {
        name = "Courier Claridge",
        locations = {
            [84] = {
                {
                    x = 0.54666,
                    y = 0.185368,
                },
            },
        },
    },
    [150206] = {
        name = "Chief Telemancer Oculeth",
        locations = {
            [1355] = {
                {
                    x = 0.36686,
                    y = 0.869361,
                },
            },
        },
    },
    [150207] = {
        name = "Lor'themar Theron",
        locations = {
            [1355] = {
                {
                    x = 0.363208,
                    y = 0.820978,
                },
            },
        },
    },
    [150208] = {
        name = "Tinkmaster Overspark",
        locations = {
            [1161] = {
                {
                    x = 0.672094,
                    y = 0.157649,
                },
            },
        },
    },
    [150209] = {
        name = "Neri Sharpfin",
        locations = {
            [1355] = {
                {
                    x = 0.372948,
                    y = 0.673558,
                },
            },
        },
    },
    [150309] = {
        name = "Baine Bloodhoof",
        locations = {
            [895] = {
                {
                    x = 0.873019,
                    y = 0.496269,
                },
            },
        },
    },
    [150311] = {
        name = "Thomas Zelling",
        locations = {
            [70] = {
                {
                    x = 0.763396,
                    y = 0.42754,
                },
            },
        },
    },
    [150318] = {
        name = "Veriss",
        locations = {
            [864] = {
                {
                    x = 0.27632,
                    y = 0.523365,
                },
            },
        },
    },
    [150391] = {
        name = "Image of Mimiron",
        locations = {
            [81] = {
                {
                    x = 0.393067,
                    y = 0.717137,
                },
            },
        },
    },
    [150433] = {
        name = "Bluffwatcher Proudscar",
        locations = {
            [1165] = {
                {
                    x = 0.498144,
                    y = 0.959921,
                },
            },
        },
    },
    [150515] = {
        name = "Cyrus Crestfall",
        locations = {
            [942] = {
                {
                    x = 0.593943,
                    y = 0.702751,
                },
            },
        },
    },
    [150555] = {
        name = "Waren Gearhart",
        locations = {
            [1462] = {
                {
                    x = 0.731339,
                    y = 0.333465,
                },
            },
        },
    },
    [150573] = {
        name = "Recycler Kerchunk",
        locations = {
            [1462] = {
                {
                    x = 0.714955,
                    y = 0.387791,
                },
            },
        },
    },
    [150574] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1161] = {
                {
                    x = 0.692676,
                    y = 0.271405,
                },
            },
        },
    },
    [150630] = {
        name = "Flip Quickcharge",
        locations = {
            [1462] = {
                {
                    x = 0.708297,
                    y = 0.3913,
                },
            },
        },
    },
    [150631] = {
        name = "Pristy Quickcharge",
        locations = {
            [1462] = {
                {
                    x = 0.707431,
                    y = 0.384181,
                },
            },
        },
    },
    [150633] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1161] = {
                {
                    x = 0.451975,
                    y = 0.626169,
                },
            },
        },
    },
    [150637] = {
        name = "Kelsey Steelspark",
        locations = {
            [942] = {
                {
                    x = 0.482837,
                    y = 0.414513,
                },
            },
        },
    },
    [150640] = {
        name = "Master Mathias Shaw",
        locations = {
            [942] = {
                {
                    x = 0.488346,
                    y = 0.327512,
                },
            },
        },
    },
    [150690] = {
        name = "Boss Mida",
        locations = {
            [942] = {
                {
                    x = 0.509774,
                    y = 0.328616,
                },
            },
        },
    },
    [150691] = {
        name = "Kazit",
        locations = {
            [942] = {
                {
                    x = 0.509698,
                    y = 0.32811,
                },
            },
        },
    },
    [150796] = {
        name = "Kelsey Steelspark",
        locations = {
            [895] = {
                {
                    x = 0.801136,
                    y = 0.75048,
                },
            },
        },
    },
    [150884] = {
        name = "Chelsea Wright",
        locations = {
            [896] = {
                {
                    x = 0.331694,
                    y = 0.303707,
                },
            },
        },
    },
    [150885] = {
        name = "Wicker Beast",
        locations = {
            [896] = {
                {
                    x = 0.366243,
                    y = 0.288244,
                },
            },
        },
    },
    [150893] = {
        name = "Shrine of the Sea",
        locations = {
            [895] = {
                {
                    x = 0.463486,
                    y = 0.234625,
                },
            },
        },
    },
    [150894] = {
        name = "Shrine of Nature",
        locations = {
            [862] = {
                {
                    x = 0.431479,
                    y = 0.643642,
                },
            },
        },
    },
    [150895] = {
        name = "Shrine of the Sands",
        locations = {
            [864] = {
                {
                    x = 0.441941,
                    y = 0.379982,
                },
            },
        },
    },
    [150896] = {
        name = "Shrine of the Eventide",
        locations = {
            [896] = {
                {
                    x = 0.340999,
                    y = 0.35353,
                },
            },
        },
    },
    [150897] = {
        name = "Shrine of the Dawning",
        locations = {
            [863] = {
                {
                    x = 0.613585,
                    y = 0.37282,
                },
            },
        },
    },
    [150898] = {
        name = "Shrine of Storms",
        locations = {
            [942] = {
                {
                    x = 0.606999,
                    y = 0.5851,
                },
            },
        },
    },
    [150956] = {
        name = "Broken Drill Rig",
        locations = {
            [1462] = {
                {
                    x = 0.567214,
                    y = 0.600215,
                },
            },
        },
    },
    [151000] = {
        name = "Blademaster Okani",
        locations = {
            [1355] = {
                {
                    x = 0.389911,
                    y = 0.546266,
                },
            },
        },
    },
    [151061] = {
        name = "Mimiron",
        locations = {
            [745] = {
                {
                    x = 0.432955,
                    y = 0.387904,
                },
            },
        },
    },
    [151100] = {
        name = "Gila Crosswires",
        locations = {
            [1161] = {
                {
                    x = 0.672255,
                    y = 0.159322,
                },
            },
        },
    },
    [151129] = {
        name = "Sapphronetta Flivvers",
        locations = {
            [71] = {
                {
                    x = 0.271289,
                    y = 0.600675,
                },
            },
        },
    },
    [151130] = {
        name = "Grizzek Fizzwrench",
        locations = {
            [71] = {
                {
                    x = 0.271637,
                    y = 0.60084,
                },
            },
        },
    },
    [151132] = {
        name = "Feathers",
        locations = {
            [71] = {
                {
                    x = 0.621866,
                    y = 0.453391,
                },
            },
        },
    },
    [151134] = {
        name = "Timeweaver Delormi",
        locations = {
            [1165] = {
                {
                    x = 0.435104,
                    y = 0.347621,
                },
            },
        },
    },
    [151137] = {
        name = "Timeweaver Delormi",
    },
    [151162] = {
        name = "Atikka \"Ace\" Moonchaser",
        locations = {
            [1165] = {
                {
                    x = 0.534075,
                    y = 0.925261,
                },
            },
        },
    },
    [151173] = {
        name = "Daniss Ghostdancer",
        locations = {
            [1161] = {
                {
                    x = 0.694371,
                    y = 0.299694,
                },
            },
        },
    },
    [151257] = {
        name = "Torcali",
        locations = {
            [862] = {
                {
                    x = 0.683886,
                    y = 0.293952,
                },
            },
        },
    },
    [151283] = {
        name = "Direhorn Hatchling",
        locations = {
            [862] = {
                {
                    x = 0.681747,
                    y = 0.417465,
                },
            },
        },
    },
    [151285] = {
        name = "Mevris Ghostdancer",
        locations = {
            [641] = {
                {
                    x = 0.535856,
                    y = 0.544027,
                },
            },
        },
    },
    [151286] = {
        name = "Child of Torcali",
        locations = {
            [862] = {
                {
                    x = 0.681741,
                    y = 0.417457,
                },
            },
        },
    },
    [151287] = {
        name = "Telonis",
        locations = {
            [84] = {
                {
                    x = 0.425887,
                    y = 0.60445,
                },
            },
        },
    },
    [151319] = {
        name = "Li'zal",
        locations = {
            [862] = {
                {
                    x = 0.682034,
                    y = 0.4175,
                },
            },
        },
    },
    [151462] = {
        name = "Danielle Anglers",
        locations = {
            [1462] = {
                {
                    x = 0.370348,
                    y = 0.471562,
                },
            },
        },
    },
    [151626] = {
        name = "Hunter Akana",
        locations = {
            [1355] = {
                {
                    x = 0.394078,
                    y = 0.534638,
                },
            },
        },
    },
    [151641] = {
        name = "Spiritwalker Ebonhorn",
        locations = {
            [650] = {
                {
                    x = 0.495325,
                    y = 0.683679,
                },
            },
        },
    },
    [151682] = {
        name = "Merithra of the Dream",
        locations = {
            [641] = {
                {
                    x = 0.51617,
                    y = 0.572165,
                },
            },
        },
    },
    [151693] = {
        name = "Merithra of the Dream",
        locations = {
            [1471] = {
                {
                    x = 0.440404,
                    y = 0.307039,
                },
            },
        },
    },
    [151695] = {
        name = "Spiritwalker Ebonhorn",
        locations = {
            [1472] = {
                {
                    x = 0.267234,
                    y = 0.461716,
                },
            },
        },
    },
    [151704] = {
        name = "Valithria Dreamwalker",
        locations = {
            [1471] = {
                {
                    x = 0.270678,
                    y = 0.558923,
                },
            },
        },
    },
    [151741] = {
        name = "Apprentice Odari",
        locations = {
            [1355] = {
                {
                    x = 0.435112,
                    y = 0.497838,
                },
            },
        },
    },
    [151761] = {
        name = "Vassandra Stormclaw",
        locations = {
            [47] = {
                {
                    x = 0.1809,
                    y = 0.572281,
                },
            },
        },
    },
    [151784] = {
        name = "Mia Greymane",
        locations = {
            [84] = {
                {
                    x = 0.823534,
                    y = 0.277641,
                },
            },
        },
    },
    [151825] = {
        name = "Merithra of the Dream",
        locations = {
            [1475] = {
                {
                    x = 0.465546,
                    y = 0.396812,
                },
            },
        },
    },
    [151848] = {
        name = "Lor'themar Theron",
        locations = {
            [1355] = {
                {
                    x = 0.485068,
                    y = 0.621787,
                },
            },
        },
    },
    [151851] = {
        name = "Chief Telemancer Oculeth",
        locations = {
            [1355] = {
                {
                    x = 0.485013,
                    y = 0.623712,
                },
            },
        },
    },
    [151887] = {
        name = "Merithra of the Dream",
        locations = {
            [1475] = {
                {
                    x = 0.467357,
                    y = 0.398248,
                },
            },
        },
    },
    [151947] = {
        name = "Prince Erazmin",
        locations = {
            [1462] = {
                {
                    x = 0.712779,
                    y = 0.358607,
                },
            },
        },
    },
    [151999] = {
        name = "Jo'nok, Bulwark of Torcali",
        locations = {
            [862] = {
                {
                    x = 0.682805,
                    y = 0.416892,
                },
            },
        },
    },
    [152000] = {
        name = "Dori'thur",
    },
    [152002] = {
        name = "Image of Mimiron",
        locations = {
            [1161] = {
                {
                    x = 0.728549,
                    y = 0.138058,
                },
            },
        },
    },
    [152047] = {
        name = "Poen Gillbrack",
        locations = {
            [1355] = {
                {
                    x = 0.388726,
                    y = 0.424145,
                },
            },
        },
    },
    [152066] = {
        name = "First Arcanist Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.642114,
                    y = 0.520993,
                },
            },
        },
    },
    [152084] = {
        name = "Mrrl",
        locations = {
            [1355] = {
                {
                    x = 0.481965,
                    y = 0.453502,
                },
            },
        },
    },
    [152095] = {
        name = "Magni Bronzebeard",
        locations = {
            [198] = {
                {
                    x = 0.620267,
                    y = 0.249188,
                },
            },
        },
    },
    [152108] = {
        name = "Neri Sharpfin",
        locations = {
            [1355] = {
                {
                    x = 0.497049,
                    y = 0.645367,
                },
            },
        },
    },
    [152115] = {
        name = "Koo'li",
        locations = {
            [862] = {
                {
                    x = 0.619293,
                    y = 0.496837,
                },
            },
        },
    },
    [152194] = {
        name = "MOTHER",
        locations = {
            [1473] = {
                {
                    x = 0.481751,
                    y = 0.724507,
                },
            },
        },
    },
    [152206] = {
        name = "Magni Bronzebeard",
        locations = {
            [1473] = {
                {
                    x = 0.501271,
                    y = 0.591606,
                },
            },
        },
    },
    [152238] = {
        name = "Riathia Silverstar",
        locations = {
            [1499] = {
                {
                    x = 0.537778,
                    y = 0.204904,
                },
            },
        },
    },
    [152255] = {
        name = "Sef Iwen",
        locations = {
            [896] = {
                {
                    x = 0.579984,
                    y = 0.809322,
                },
            },
        },
    },
    [152295] = {
        name = "Pascal",
        locations = {
            [1462] = {
                {
                    x = 0.712019,
                    y = 0.323041,
                },
            },
        },
    },
    [152316] = {
        name = "Image of Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.764737,
                    y = 0.298832,
                },
            },
        },
    },
    [152365] = {
        name = "Kalecgos",
        locations = {
            [1473] = {
                {
                    x = 0.525616,
                    y = 0.699304,
                },
            },
        },
    },
    [152385] = {
        name = "Spiritwalker Ebonhorn",
    },
    [152484] = {
        name = "Tinkmaster Overspark",
        locations = {
            [1462] = {
                {
                    x = 0.775735,
                    y = 0.404309,
                },
            },
        },
    },
    [152489] = {
        name = "Shrine of Storms",
        locations = {
            [942] = {
                {
                    x = 0.606556,
                    y = 0.584925,
                },
            },
        },
    },
    [152490] = {
        name = "Shrine of the Dawning",
        locations = {
            [863] = {
                {
                    x = 0.613598,
                    y = 0.372108,
                },
            },
        },
    },
    [152493] = {
        name = "Shrine of the Sands",
        locations = {
            [864] = {
                {
                    x = 0.44192,
                    y = 0.379983,
                },
            },
        },
    },
    [152495] = {
        name = "Shrine of the Sea",
        locations = {
            [895] = {
                {
                    x = 0.463791,
                    y = 0.234902,
                },
            },
        },
    },
    [152496] = {
        name = "Shrine of Nature",
        locations = {
            [862] = {
                {
                    x = 0.431701,
                    y = 0.643307,
                },
            },
        },
    },
    [152497] = {
        name = "Shrine of the Eventide",
        locations = {
            [896] = {
                {
                    x = 0.341132,
                    y = 0.354265,
                },
            },
        },
    },
    [152504] = {
        name = "Gazlowe",
        locations = {
            [1165] = {
                {
                    x = 0.420563,
                    y = 0.878395,
                },
            },
        },
    },
    [152505] = {
        name = "Skaggit",
        locations = {
            [1165] = {
                {
                    x = 0.42193,
                    y = 0.878373,
                },
            },
        },
    },
    [152522] = {
        name = "Gazlowe",
        locations = {
            [1165] = {
                {
                    x = 0.530826,
                    y = 0.432719,
                },
            },
        },
    },
    [152578] = {
        name = "Gazlowe",
        locations = {
            [895] = {
                {
                    x = 0.656295,
                    y = 0.646124,
                },
            },
        },
    },
    [152652] = {
        name = "Gazlowe",
        locations = {
            [895] = {
                {
                    x = 0.659009,
                    y = 0.664161,
                },
            },
        },
    },
    [152720] = {
        name = "Kalecgos",
        locations = {
            [241] = {
                {
                    x = 0.359531,
                    y = 0.504897,
                },
            },
        },
    },
    [152747] = {
        name = "Christy Punchcog",
        locations = {
            [1462] = {
                {
                    x = 0.697496,
                    y = 0.323345,
                },
            },
        },
    },
    [152783] = {
        name = "Gazlowe",
        locations = {
            [1462] = {
                {
                    x = 0.761654,
                    y = 0.153089,
                },
            },
        },
    },
    [152815] = {
        name = "Magni Bronzebeard",
        locations = {
            [1474] = {
                {
                    x = 0.337454,
                    y = 0.54551,
                },
            },
        },
    },
    [152820] = {
        name = "Prince Erazmin",
        locations = {
            [1462] = {
                {
                    x = 0.589794,
                    y = 0.548446,
                },
            },
        },
    },
    [152845] = {
        name = "Gazlowe",
        locations = {
            [1462] = {
                {
                    x = 0.736934,
                    y = 0.259431,
                },
            },
        },
    },
    [152851] = {
        name = "Prince Erazmin",
        locations = {
            [1462] = {
                {
                    x = 0.710925,
                    y = 0.383232,
                },
            },
        },
    },
    [152864] = {
        name = "Tinkmaster Overspark",
        locations = {
            [895] = {
                {
                    x = 0.658195,
                    y = 0.663651,
                },
            },
        },
    },
    [152977] = {
        name = "Thrall",
        locations = {
            [86] = {
                {
                    x = 0.561251,
                    y = 0.680566,
                },
            },
        },
    },
    [153251] = {
        name = "Lor'themar Theron",
        locations = {
            [1355] = {
                {
                    x = 0.506048,
                    y = 0.241556,
                },
            },
        },
    },
    [153253] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1355] = {
                {
                    x = 0.503851,
                    y = 0.240887,
                },
            },
        },
    },
    [153365] = {
        name = "Honeyback Hivemother",
        locations = {
            [942] = {
                {
                    x = 0.628966,
                    y = 0.265245,
                },
            },
        },
    },
    [153385] = {
        name = "Blademaster Okani",
        locations = {
            [1355] = {
                {
                    x = 0.389008,
                    y = 0.303783,
                },
            },
        },
    },
    [153393] = {
        name = "Barry",
        locations = {
            [942] = {
                {
                    x = 0.692491,
                    y = 0.641936,
                },
            },
        },
    },
    [153422] = {
        name = "Chief Telemancer Oculeth",
        locations = {
            [1355] = {
                {
                    x = 0.388626,
                    y = 0.304235,
                },
            },
        },
    },
    [153492] = {
        name = "Fenn",
        locations = {
            [1355] = {
                {
                    x = 0.389759,
                    y = 0.303879,
                },
            },
        },
    },
    [153496] = {
        name = "Adaru",
        locations = {
            [1355] = {
                {
                    x = 0.389967,
                    y = 0.30371,
                },
            },
        },
    },
    [153509] = {
        name = "Artisan Okata",
        locations = {
            [1355] = {
                {
                    x = 0.378179,
                    y = 0.555493,
                },
            },
        },
    },
    [153510] = {
        name = "Artisan Itanu",
        locations = {
            [1355] = {
                {
                    x = 0.378502,
                    y = 0.556939,
                },
            },
        },
    },
    [153512] = {
        name = "Finder Pruc",
        locations = {
            [1355] = {
                {
                    x = 0.490736,
                    y = 0.621935,
                },
            },
        },
    },
    [153514] = {
        name = "Finder Palta",
        locations = {
            [1355] = {
                {
                    x = 0.492288,
                    y = 0.620868,
                },
            },
        },
    },
    [153617] = {
        name = "Shandris Feathermoon",
        locations = {
            [1355] = {
                {
                    x = 0.402749,
                    y = 0.553848,
                },
            },
        },
    },
    [153670] = {
        name = "Prince Erazmin",
    },
    [153932] = {
        name = "Genn Greymane",
        locations = {
            [1161] = {
                {
                    x = 0.706674,
                    y = 0.271964,
                },
            },
        },
    },
    [153936] = {
        name = "Overseer Hajeer",
        locations = {
            [1355] = {
                {
                    x = 0.369741,
                    y = 0.270195,
                },
            },
        },
    },
    [154002] = {
        name = "Atolia Seapearl",
    },
    [154023] = {
        name = "Nascent Harvester",
        locations = {
            [942] = {
                {
                    x = 0.625215,
                    y = 0.264318,
                },
            },
        },
    },
    [154143] = {
        name = "Collector Kojo",
        locations = {
            [1355] = {
                {
                    x = 0.66471,
                    y = 0.473327,
                },
            },
        },
    },
    [154248] = {
        name = "Bladesman Inowari",
        locations = {
            [1355] = {
                {
                    x = 0.394629,
                    y = 0.534275,
                },
            },
        },
    },
    [154257] = {
        name = "Instructor Ulooaka",
        locations = {
            [1355] = {
                {
                    x = 0.379812,
                    y = 0.529097,
                },
            },
        },
    },
    [154408] = {
        name = "Rolm",
        locations = {
            [1355] = {
                {
                    x = 0.493002,
                    y = 0.618873,
                },
            },
        },
    },
    [154418] = {
        name = "Ra-den",
        locations = {
            [1530] = {
                {
                    x = 0.453301,
                    y = 0.743276,
                },
            },
        },
    },
    [154444] = {
        name = "Stormspeaker Qian",
        locations = {
            [1530] = {
                {
                    x = 0.447461,
                    y = 0.738917,
                },
            },
        },
    },
    [154514] = {
        name = "Kelya Moonfall",
        locations = {
            [1355] = {
                {
                    x = 0.800954,
                    y = 0.314315,
                },
            },
        },
    },
    [154520] = {
        name = "First Arcanist Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.734505,
                    y = 0.477901,
                },
            },
        },
    },
    [154522] = {
        name = "Shandris Feathermoon",
        locations = {
            [1355] = {
                {
                    x = 0.761511,
                    y = 0.457873,
                },
            },
        },
    },
    [154532] = {
        name = "Magni Bronzebeard",
        locations = {
            [1527] = {
                {
                    x = 0.698572,
                    y = 0.521884,
                },
            },
        },
    },
    [154533] = {
        name = "Magni Bronzebeard",
        locations = {
            [1542] = {
                {
                    x = 0.470989,
                    y = 0.444849,
                },
            },
        },
    },
    [154574] = {
        name = "Kelya Moonfall",
        locations = {
            [1355] = {
                {
                    x = 0.741541,
                    y = 0.249254,
                },
            },
        },
    },
    [154601] = {
        name = "Kelya Moonfall",
        locations = {
            [1355] = {
                {
                    x = 0.802087,
                    y = 0.318904,
                },
            },
        },
    },
    [154607] = {
        name = "Image of Torcali",
        locations = {
            [862] = {
                {
                    x = 0.523444,
                    y = 0.228893,
                },
            },
        },
    },
    [154640] = {
        name = "Grand Marshal Tremblade",
    },
    [154660] = {
        name = "Shandris Feathermoon",
        locations = {
            [1355] = {
                {
                    x = 0.739781,
                    y = 0.417481,
                },
            },
        },
    },
    [154661] = {
        name = "First Arcanist Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.739813,
                    y = 0.417478,
                },
            },
        },
    },
    [154673] = {
        name = "Li'zal",
        locations = {
            [862] = {
                {
                    x = 0.681988,
                    y = 0.418892,
                },
            },
        },
    },
    [154958] = {
        name = "Laborer Mitchell",
        locations = {
            [1527] = {
                {
                    x = 0.408074,
                    y = 0.385418,
                },
            },
        },
    },
    [155071] = {
        name = "Shandris Feathermoon",
        locations = {
            [1355] = {
                {
                    x = 0.797677,
                    y = 0.44935,
                },
            },
        },
    },
    [155095] = {
        name = "King Phaoris",
        locations = {
            [1527] = {
                {
                    x = 0.549027,
                    y = 0.327427,
                },
            },
        },
    },
    [155102] = {
        name = "High Explorer Dellorah",
        locations = {
            [1527] = {
                {
                    x = 0.549593,
                    y = 0.329562,
                },
            },
        },
    },
    [155325] = {
        name = "First Arcanist Thalyssra",
        locations = {
            [1355] = {
                {
                    x = 0.797645,
                    y = 0.449342,
                },
            },
        },
    },
    [155336] = {
        name = "Mogu Warrior",
        locations = {
            [379] = {
                {
                    x = 0.596127,
                    y = 0.391963,
                },
            },
        },
    },
    [155482] = {
        name = "Shandris Feathermoon",
        locations = {
            [1355] = {
                {
                    x = 0.489212,
                    y = 0.868744,
                },
            },
        },
    },
    [155487] = {
        name = "Taoshi",
        locations = {
            [390] = {
                {
                    x = 0.139049,
                    y = 0.772144,
                },
            },
        },
    },
    [155496] = {
        name = "Wrathion",
        locations = {
            [1473] = {
                {
                    x = 0.461386,
                    y = 0.640277,
                },
            },
        },
    },
    [155562] = {
        name = "Taoshi",
        locations = {
            [422] = {
                {
                    x = 0.454884,
                    y = 0.191821,
                },
            },
        },
    },
    [155582] = {
        name = "Taoshi",
        locations = {
            [422] = {
                {
                    x = 0.45389,
                    y = 0.164803,
                },
            },
        },
    },
    [155707] = {
        name = "Taoshi",
        locations = {
            [422] = {
                {
                    x = 0.532168,
                    y = 0.395887,
                },
            },
        },
    },
    [155784] = {
        name = "Anduin Wrynn",
        locations = {
            {
                {
                    x = 0.540589,
                    y = 0.425269,
                },
            },
        },
    },
    [155785] = {
        name = "Lady Jaina Proudmoore",
        locations = {
            [1535] = {
                {
                    x = 0.363759,
                    y = 0.640817,
                },
            },
        },
    },
    [155786] = {
        name = "Varok Saurfang",
        locations = {
            [1535] = {
                {
                    x = 0.416441,
                    y = 0.557289,
                },
            },
        },
    },
    [155789] = {
        name = "Lor'themar Theron",
        locations = {
            [1165] = {
                {
                    x = 0.5,
                    y = 0.96,
                },
            },
        },
    },
    [156003] = {
        name = "Lorewalker Cho",
        locations = {
            [1530] = {
                {
                    x = 0.838042,
                    y = 0.271636,
                },
            },
        },
    },
    [156124] = {
        name = "Eitrigg",
        locations = {
            [1534] = {
                {
                    x = 0.742087,
                    y = 0.460827,
                },
            },
        },
    },
    [156297] = {
        name = "Chen Stormstout",
        locations = {
            [1530] = {
                {
                    x = 0.439455,
                    y = 0.049852,
                },
            },
        },
    },
    [156358] = {
        name = "Izzy",
        locations = {
            [85] = {
                {
                    x = 0.395034,
                    y = 0.802805,
                },
            },
        },
    },
    [156390] = {
        name = "Chen Stormstout",
        locations = {
            [379] = {
                {
                    x = 0.599724,
                    y = 0.755713,
                },
            },
        },
    },
    [156391] = {
        name = "Li Li Stormstout",
        locations = {
            [379] = {
                {
                    x = 0.600347,
                    y = 0.756365,
                },
            },
        },
    },
    [156396] = {
        name = "Sassy Hardwrench",
        locations = {
            [210] = {
                {
                    x = 0.346117,
                    y = 0.285917,
                },
            },
        },
    },
    [156423] = {
        name = "Lady Sylvanas Windrunner",
        locations = {
            [1534] = {
                {
                    x = 0.485221,
                    y = 0.707927,
                },
            },
        },
    },
    [156425] = {
        name = "Dark Ranger Lenara",
        locations = {
            [1534] = {
                {
                    x = 0.499771,
                    y = 0.913318,
                },
            },
        },
    },
    [156440] = {
        name = "Nathanos Blightcaller",
        locations = {
            [1534] = {
                {
                    x = 0.504476,
                    y = 0.761981,
                },
            },
        },
    },
    [156520] = {
        name = "Hobart Grapplehammer",
        locations = {
            [1532] = {
                {
                    x = 0.535748,
                    y = 0.619633,
                },
            },
        },
    },
    [156542] = {
        name = "Crank Greasefuse",
        locations = {
            [1532] = {
                {
                    x = 0.560867,
                    y = 0.781979,
                },
            },
        },
    },
    [156937] = {
        name = "Chen Stormstout",
        locations = {
            [379] = {
                {
                    x = 0.554723,
                    y = 0.911066,
                },
            },
        },
    },
    [156938] = {
        name = "Li Li Stormstout",
        locations = {
            [379] = {
                {
                    x = 0.555377,
                    y = 0.911099,
                },
            },
        },
    },
    [157180] = {
        name = "Abandoned Stormstout Kegs",
        locations = {
            [379] = {
                {
                    x = 0.585258,
                    y = 0.839954,
                },
            },
        },
    },
    [157491] = {
        name = "Hobart Grapplehammer",
        locations = {
            [1531] = {
                {
                    x = 0.478496,
                    y = 0.505555,
                },
            },
        },
    },
    [157668] = {
        name = "Meerah",
        locations = {
            [680] = {
                {
                    x = 0.587951,
                    y = 0.555316,
                },
            },
        },
    },
    [157997] = {
        name = "Kelsey Steelspark",
        locations = {
            [1161] = {
                {
                    x = 0.36888,
                    y = 0.625543,
                },
            },
        },
    },
    [158145] = {
        name = "Prince Erazmin",
        locations = {
            [1462] = {
                {
                    x = 0.730334,
                    y = 0.334282,
                },
            },
        },
    },
    [158672] = {
        name = "Nisha",
        locations = {
            [862] = {
                {
                    x = 0.77185,
                    y = 0.653942,
                },
            },
        },
    },
    [159544] = {
        name = "Arik Scorpidsting",
        locations = {
            [1527] = {
                {
                    x = 0.401316,
                    y = 0.213163,
                },
            },
        },
    },
    [159560] = {
        name = "Outrider Lashan",
        locations = {
            [1527] = {
                {
                    x = 0.399917,
                    y = 0.452635,
                },
            },
        },
    },
    [159587] = {
        name = "Gelbin Mekkatorque",
        locations = {
            [1462] = {
                {
                    x = 0.730698,
                    y = 0.335949,
                },
            },
        },
    },
    [159682] = {
        name = "Tracker Samara",
        locations = {
            [1527] = {
                {
                    x = 0.24498,
                    y = 0.552829,
                },
            },
        },
    },
    [159820] = {
        name = "Mender Dyrin",
        locations = {
            [1527] = {
                {
                    x = 0.279474,
                    y = 0.634481,
                },
            },
        },
    },
    [159920] = {
        name = "Zahra Sandstalker",
        locations = {
            [1527] = {
                {
                    x = 0.424403,
                    y = 0.559451,
                },
            },
        },
    },
    [160101] = {
        name = "Kelsey Steelspark",
        locations = {
            [1161] = {
                {
                    x = 0.73132,
                    y = 0.169306,
                },
            },
        },
    },
    [160232] = {
        name = "Christy Punchcog",
        locations = {
            [1462] = {
                {
                    x = 0.732,
                    y = 0.334763,
                },
            },
        },
    },
    [161031] = {
        name = "Captain Hadan",
        locations = {
            [1527] = {
                {
                    x = 0.716553,
                    y = 0.520153,
                },
            },
        },
    },
    [161458] = {
        name = "Valeera Sanguinar",
        locations = {
            [862] = {
                {
                    x = 0.578649,
                    y = 0.64502,
                },
            },
        },
    },
    [161738] = {
        name = "H'partho Ardoros",
        locations = {
            [1527] = {
                {
                    x = 0.279891,
                    y = 0.633837,
                },
            },
        },
    },
    [161805] = {
        name = "Magni Bronzebeard",
    },
})
