----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "deDE" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateObjectsTable({
    [244983] = {
        name = "Schmutzige Taschenuhr",
    },
    [270917] = {
        name = "Verzeichnis von Schluchtbach",
    },
    [271706] = {
        name = "Jägertafel",
    },
    [272179] = {
        name = "Bekanntmachung des Bürgermeisters",
    },
    [272422] = {
        name = "Sanftmuts Zauberbuch",
    },
    [273814] = {
        name = "Klingenbewehrter Talisman",
    },
    [273854] = {
        name = "Rucksack",
    },
    [276251] = {
        name = "Ausgrabungsinventar",
    },
    [276488] = {
        name = "Azeritkanonenkugel",
    },
    [276513] = {
        name = "Intakter Matschflosser",
    },
    [276515] = {
        name = "Angelrute",
    },
    [276837] = {
        name = "Rezeptstein",
    },
    [277199] = {
        name = "Verwitterte Auftragsliste",
    },
    [277373] = {
        name = "Schimmernder Seetang",
    },
    [277459] = {
        name = "Schweinsbildnis",
    },
    [278197] = {
        name = "Phiole mit Gegengift",
    },
    [278252] = {
        name = "Auftragszettel",
    },
    [278313] = {
        name = "Scharf formulierter Brief",
    },
    [278368] = {
        name = "Zerfledderte Notiz",
    },
    [278447] = {
        name = "Speer des treulosen Fallenstellers",
    },
    [278570] = {
        name = "Uraltes Tagebuch",
    },
    [278577] = {
        name = "Zerrissenes Sendschreiben der Horde",
    },
    [278669] = {
        name = "Geschäftsbuch von Fallhafen",
    },
    [278675] = {
        name = "Verfluchtes Bildnis",
    },
    [279337] = {
        name = "Herzbannzauberfoliant",
    },
    [279646] = {
        name = "Blutwachenchronik",
    },
    [279647] = {
        name = "Foliant der Opferung",
    },
    [280576] = {
        name = "Eingeschlossene Schriftrolle",
    },
    [280727] = {
        name = "Verkohlte Nachricht",
    },
    [281230] = {
        name = "Förmliche Einladung",
    },
    [281348] = {
        name = "Auseinanderfallender Brief",
    },
    [281551] = {
        name = "Plakat: Hilfe gesucht",
    },
    [281583] = {
        name = "Uraltes Reliquiar",
    },
    [281639] = {
        name = "Zerbröckelnde Statue",
    },
    [281647] = {
        name = "Aushang",
    },
    [281673] = {
        name = "Tagebuch eines Bewohners von Korlach",
    },
    [281718] = {
        name = "AUSHILFE GESUCHT",
    },
    [282457] = {
        name = "Dornenwachentotem",
    },
    [282478] = {
        name = "Leere Kiste",
    },
    [282498] = {
        name = "Wüstenflöte",
    },
    [284426] = {
        name = "Vergrabene Abbaumaschine",
    },
    [286016] = {
        name = "Schiffslogbuch",
    },
    [287081] = {
        name = "Uralte Schrifttafel",
    },
    [287185] = {
        name = "Gesucht: Dunkelsprecher Jo'la",
    },
    [287189] = {
        name = "Gesucht: Gefährliche Bestien",
    },
    [287228] = {
        name = "Gesucht: Dunkler Chronist",
    },
    [287229] = {
        name = "Gesucht: Dunkler Chronist",
    },
    [287232] = {
        name = "Späherbericht",
    },
    [287327] = {
        name = "Späherbericht",
    },
    [287398] = {
        name = "Gesucht: Za'roco",
    },
    [287440] = {
        name = "Gesucht: Taz'raka",
    },
    [287441] = {
        name = "Gesucht: Sandspäher Vesarik",
    },
    [287442] = {
        name = "Gesucht: Teilnehmer für Kobraausflug",
    },
    [287958] = {
        name = "Anschlagbrett",
    },
    [288157] = {
        name = "Gesucht: Yarsel'ghun",
    },
    [288167] = {
        name = "Maries Paket",
    },
    [288214] = {
        name = "Steckbrief",
    },
    [288622] = {
        name = "Steckbrief",
    },
    [288641] = {
        name = "GESUCHT: Greifenentführer",
    },
    [289310] = {
        name = "GESUCHT: Tobender Erdwächter",
    },
    [289313] = {
        name = "GESUCHT: Die Hornisse",
    },
    [289361] = {
        name = "GESUCHT: Rüstmeister Ssylis",
    },
    [289365] = {
        name = "Steckbrief",
    },
    [289728] = {
        name = "Käpt'n Gulnakus Schatzkarte",
    },
    [290138] = {
        name = "Botbrecherbombe",
    },
    [290419] = {
        name = "Steckbrief",
    },
    [290537] = {
        name = "Hilfe gesucht",
    },
    [290750] = {
        name = "Vorräte der Jambani",
    },
    [290765] = {
        name = "Großer Haufen Gold",
    },
    [290993] = {
        name = "Beute der Eisenfluträuber",
    },
    [291143] = {
        name = "Ranahs Schraubenschlüssel",
    },
    [291291] = {
        name = "Gesucht: Wilderer",
    },
    [292523] = {
        name = "Steckbrief",
    },
    [293567] = {
        name = "Steckbrief",
    },
    [293568] = {
        name = "Steckbrief",
    },
    [293985] = {
        name = "Gesucht: Schlachtmetzler",
    },
    [297492] = {
        name = "Anschlagbrett",
    },
    [298778] = {
        name = "Steckbrief",
    },
    [298849] = {
        name = "Steckbrief",
    },
    [298858] = {
        name = "Steckbrief",
    },
    [307748] = {
        name = "Brief der Venture Co.",
    },
    [309498] = {
        name = "Rüstungsständer",
    },
    [311155] = {
        name = "Uralte Schrifttafel",
    },
    [311218] = {
        name = "Xal'atath, Klinge des Schwarzen Imperiums",
    },
    [311885] = {
        name = "Xal'atath, Klinge des Schwarzen Imperiums",
    },
    [322533] = {
        name = "Mardivas' Foliant der Elemente",
    },
    [326393] = {
        name = "Azeritwaffentruhe",
    },
    [326418] = {
        name = "Arkane Truhe",
    },
    [326588] = {
        name = "Azeritwaffentruhe",
    },
    [327170] = {
        name = "Waffenständer",
    },
    [327591] = {
        name = "Erhaltenes Tagebuch",
    },
    [327592] = {
        name = "Verzaubertes Schloss",
    },
    [327596] = {
        name = "Zerbrochener abyssischer Fokus",
    },
    [329805] = {
        name = "Merkwürdiger Kristall",
    },
})
]])()
