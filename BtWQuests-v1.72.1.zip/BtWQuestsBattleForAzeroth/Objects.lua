----- AUTO GENERATED - DO NOT EDIT

BtWQuestsDatabase:AddObjectsTable({
    [244983] = {
        name = "Dirty Pocketwatch",
        locations = {
            [942] = {
                {
                    x = 0.499,
                    y = 0.735,
                },
            },
        },
    },
    [270917] = {
        name = "Glenbrook Register",
        locations = {
            [896] = {
                {
                    x = 0.556,
                    y = 0.411,
                },
            },
        },
    },
    [271706] = {
        name = "Hunters' Board",
        locations = {
            [862] = {
                {
                    x = 0.6745,
                    y = 0.179,
                },
            },
        },
    },
    [272179] = {
        name = "Mayor's Bulletin",
        locations = {
            [896] = {
                {
                    x = 0.561,
                    y = 0.353,
                },
            },
        },
    },
    [272422] = {
        name = "Gentle's Spellbook",
        locations = {
            [896] = {
                {
                    x = 0.606,
                    y = 0.3145,
                },
            },
        },
    },
    [273814] = {
        name = "Bladed Charm",
        locations = {
            [896] = {
                {
                    x = 0.7,
                    y = 0.629,
                },
            },
        },
    },
    [273854] = {
        name = "Backpack",
        locations = {
            [864] = {
                {
                    x = 0.4045,
                    y = 0.7365,
                },
            },
        },
    },
    [276187] = {
        name = "Junji",
        locations = {
            [864] = {
                {
                    x = 0.4345,
                    y = 0.787,
                },
            },
        },
    },
    [276251] = {
        name = "Excavation Inventory",
        locations = {
            [896] = {
                {
                    x = 0.518,
                    y = 0.229,
                },
            },
        },
    },
    [276488] = {
        name = "Azerite Cannonball",
        locations = {
            [895] = {
                {
                    x = 0.776,
                    y = 0.763,
                },
                {
                    x = 0.786,
                    y = 0.778,
                },
            },
        },
    },
    [276513] = {
        name = "Intact Mudfish",
        locations = {
            [896] = {
                {
                    x = 0.708,
                    y = 0.508,
                },
            },
        },
    },
    [276515] = {
        name = "Fishing Rod",
        locations = {
            [896] = {
                {
                    x = 0.711,
                    y = 0.524,
                },
            },
        },
    },
    [276837] = {
        name = "Recipe Rock",
        locations = {
            [895] = {
                {
                    x = 0.561,
                    y = 0.179,
                },
            },
        },
    },
    [277199] = {
        name = "Weathered Job List",
        locations = {
            [895] = {
                {
                    x = 0.761,
                    y = 0.6545,
                },
            },
        },
    },
    [277373] = {
        name = "Glimmering Seaweed",
        locations = {
            [895] = {
                {
                    x = 0.88,
                    y = 0.75,
                },
            },
        },
    },
    [277459] = {
        name = "Pig Effigy",
        locations = {
            [896] = {
                {
                    x = 0.634,
                    y = 0.302,
                },
            },
        },
    },
    [278197] = {
        name = "Vial of Antidote",
        locations = {
            [863] = {
                {
                    x = 0.64,
                    y = 0.504,
                },
            },
        },
    },
    [278252] = {
        name = "Job Flyer",
        locations = {
            [895] = {
                {
                    x = 0.4245,
                    y = 0.272,
                },
                {
                    x = 0.516,
                    y = 0.297,
                },
                {
                    x = 0.531,
                    y = 0.284,
                },
            },
        },
    },
    [278313] = {
        name = "Sternly Worded Letter",
        locations = {
            [895] = {
                {
                    x = 0.772,
                    y = 0.848,
                },
            },
        },
    },
    [278368] = {
        name = "Tattered Note",
        locations = {
            [864] = {
                {
                    x = 0.5445,
                    y = 0.342,
                },
            },
        },
    },
    [278447] = {
        name = "Faithless Trapper's Spear",
        locations = {
            [864] = {
                {
                    x = 0.471,
                    y = 0.388,
                },
            },
        },
    },
    [278570] = {
        name = "Ancient Journal",
        locations = {
            [1161] = {
                {
                    x = 0.751496,
                    y = 0.100479,
                },
            },
        },
    },
    [278577] = {
        name = "Torn Horde Missive",
        locations = {
            [863] = {
                {
                    x = 0.292,
                    y = 0.466,
                },
                {
                    x = 0.34,
                    y = 0.397,
                },
            },
        },
    },
    [278669] = {
        name = "Fallhaven Ledger",
        locations = {
            [896] = {
                {
                    x = 0.556,
                    y = 0.357,
                },
            },
        },
    },
    [278675] = {
        name = "Cursed Effigy",
        locations = {
            [896] = {
                {
                    x = 0.559,
                    y = 0.351,
                },
            },
        },
    },
    [279337] = {
        name = "Heartsbane Grimoire",
        locations = {
            [896] = {
                {
                    x = 0.377,
                    y = 0.5045,
                },
            },
        },
    },
    [279645] = {
        name = "Tome of Oblivion",
        locations = {
            [864] = {
                {
                    x = 0.276035,
                    y = 0.523526,
                },
            },
        },
    },
    [279646] = {
        name = "Bloodguard Chronicles",
        locations = {
            [864] = {
                {
                    x = 0.276496,
                    y = 0.522866,
                },
            },
        },
    },
    [279647] = {
        name = "Tome of Sacrifice",
        locations = {
            [896] = {
                {
                    x = 0.206271,
                    y = 0.440969,
                },
            },
        },
    },
    [280576] = {
        name = "Encased Scroll",
        locations = {
            [942] = {
                {
                    x = 0.322,
                    y = 0.401,
                },
            },
        },
    },
    [280727] = {
        name = "Charred Note",
        locations = {
            [942] = {
                {
                    x = 0.678,
                    y = 0.529,
                },
                {
                    x = 0.687,
                    y = 0.544,
                },
                {
                    x = 0.687,
                    y = 0.545,
                },
            },
        },
    },
    [280755] = {
        name = "Quintin's Satchel",
        locations = {
            [896] = {
                {
                    x = 0.422504,
                    y = 0.366924,
                },
            },
        },
    },
    [280957] = {
        name = "Zukashi's Satchel",
        locations = {
            [863] = {
                {
                    x = 0.628965,
                    y = 0.288603,
                },
            },
        },
    },
    [281230] = {
        name = "Formal Invitation",
        locations = {
            [895] = {
                {
                    x = 0.661,
                    y = 0.504,
                },
                {
                    x = 0.671,
                    y = 0.248,
                },
            },
        },
    },
    [281348] = {
        name = "Crumbling Letter",
        locations = {
            [942] = {
                {
                    x = 0.5,
                    y = 0.318,
                },
                {
                    x = 0.595,
                    y = 0.684,
                },
            },
        },
    },
    [281551] = {
        name = "Help Wanted Poster",
        locations = {
            [895] = {
                {
                    x = 0.756,
                    y = 0.499,
                },
            },
        },
    },
    [281583] = {
        name = "Ancient Reliquary",
        locations = {
            [864] = {
                {
                    x = 0.489,
                    y = 0.743,
                },
            },
        },
    },
    [281639] = {
        name = "Crumbling Statue",
        locations = {
            [864] = {
                {
                    x = 0.489,
                    y = 0.7445,
                },
            },
        },
    },
    [281647] = {
        name = "Posted Notice",
        locations = {
            [895] = {
                {
                    x = 0.79,
                    y = 0.458,
                },
                {
                    x = 0.795,
                    y = 0.489,
                },
                {
                    x = 0.801,
                    y = 0.469,
                },
                {
                    x = 0.805,
                    y = 0.494,
                },
            },
        },
    },
    [281673] = {
        name = "Corlain Citizen's Journal",
        locations = {
            [896] = {
                {
                    x = 0.308,
                    y = 0.195,
                },
            },
        },
    },
    [281718] = {
        name = "HELP WANTED",
        locations = {
            [895] = {
                {
                    x = 0.531,
                    y = 0.284,
                },
            },
        },
    },
    [282457] = {
        name = "Brambleguard Totem",
        locations = {
            [942] = {
                {
                    x = 0.440473,
                    y = 0.7247,
                },
            },
        },
    },
    [282478] = {
        name = "Empty Crate",
        locations = {
            [942] = {
                {
                    x = 0.463,
                    y = 0.77,
                },
            },
        },
    },
    [282498] = {
        name = "Desert Flute",
        locations = {
            [864] = {
                {
                    x = 0.29,
                    y = 0.546,
                },
            },
        },
    },
    [284426] = {
        name = "Buried Mining Machine",
        locations = {
            [896] = {
                {
                    x = 0.348,
                    y = 0.4,
                },
            },
        },
    },
    [286016] = {
        name = "Ship's Log",
        locations = {
            [896] = {
                {
                    x = 0.2745,
                    y = 0.1155,
                },
            },
        },
    },
    [287081] = {
        name = "Ancient Tablet",
        locations = {
            [863] = {
                {
                    x = 0.529,
                    y = 0.759,
                },
            },
        },
    },
    [287185] = {
        name = "Wanted: Darkspeaker Jo'la",
        locations = {
            [862] = {
                {
                    x = 0.637,
                    y = 0.102,
                },
            },
        },
    },
    [287189] = {
        name = "Wanted: Dangerous Beasts",
        locations = {
            [862] = {
                {
                    x = 0.516,
                    y = 0.455,
                },
            },
        },
    },
    [287228] = {
        name = "Wanted: Dark Chronicler",
        locations = {
            [862] = {
                {
                    x = 0.408,
                    y = 0.711,
                },
            },
        },
    },
    [287229] = {
        name = "Wanted: Dark Chronicler",
        locations = {
            [862] = {
                {
                    x = 0.443,
                    y = 0.721,
                },
            },
        },
    },
    [287232] = {
        name = "Scouting Report",
        locations = {
            [863] = {
                {
                    x = 0.395,
                    y = 0.799,
                },
            },
        },
    },
    [287327] = {
        name = "Scouting Report",
        locations = {
            [863] = {
                {
                    x = 0.621,
                    y = 0.411,
                },
            },
        },
    },
    [287398] = {
        name = "Wanted: Za'roco",
        locations = {
            [864] = {
                {
                    x = 0.432,
                    y = 0.765,
                },
            },
        },
    },
    [287440] = {
        name = "Wanted: Taz'raka",
        locations = {
            [864] = {
                {
                    x = 0.388,
                    y = 0.77,
                },
            },
        },
    },
    [287441] = {
        name = "Wanted: Sandscout Vesarik",
        locations = {
            [864] = {
                {
                    x = 0.274,
                    y = 0.533,
                },
            },
        },
    },
    [287442] = {
        name = "Wanted: Cobra Excursion Participants",
        locations = {
            [864] = {
                {
                    x = 0.436,
                    y = 0.6,
                },
            },
        },
    },
    [287958] = {
        name = "Bulletin Board",
        locations = {
            [942] = {
                {
                    x = 0.307,
                    y = 0.681,
                },
            },
        },
    },
    [288157] = {
        name = "Wanted: Yarsel'ghun",
        locations = {
            [942] = {
                {
                    x = 0.578,
                    y = 0.558,
                },
            },
        },
    },
    [288167] = {
        name = "Marie's Package",
        locations = {
            [942] = {
                {
                    x = 0.338,
                    y = 0.5945,
                },
                {
                    x = 0.3845,
                    y = 0.6295,
                },
            },
        },
    },
    [288214] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.196,
                    y = 0.436,
                },
            },
        },
    },
    [288622] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.317,
                    y = 0.307,
                },
            },
        },
    },
    [288641] = {
        name = "WANTED: Gryphon 'Nappers",
        locations = {
            [895] = {
                {
                    x = 0.6685,
                    y = 0.2445,
                },
            },
        },
    },
    [289310] = {
        name = "WANTED: Raging Earthguard",
        locations = {
            [895] = {
                {
                    x = 0.531,
                    y = 0.2845,
                },
            },
        },
    },
    [289313] = {
        name = "WANTED: The Hornet",
        locations = {
            [895] = {
                {
                    x = 0.422,
                    y = 0.23,
                },
            },
        },
    },
    [289361] = {
        name = "WANTED: Quartermaster Ssylis",
        locations = {
            [895] = {
                {
                    x = 0.423,
                    y = 0.272,
                },
            },
        },
    },
    [289365] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.2645,
                    y = 0.722,
                },
            },
        },
    },
    [289728] = {
        name = "Captain Gulnaku's Treasure Map",
        locations = {
            [864] = {
                {
                    x = 0.351,
                    y = 0.8045,
                },
            },
        },
    },
    [290138] = {
        name = "Bot Buster Bomb",
        locations = {
            [942] = {
                {
                    x = 0.3785,
                    y = 0.2845,
                },
            },
        },
    },
    [290419] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.557,
                    y = 0.349,
                },
            },
        },
    },
    [290537] = {
        name = "Help Wanted",
        locations = {
            [942] = {
                {
                    x = 0.664,
                    y = 0.572,
                },
            },
        },
    },
    [290750] = {
        name = "Jambani Stockpile",
        locations = {
            [862] = {
                {
                    x = 0.653,
                    y = 0.283,
                },
            },
        },
    },
    [290765] = {
        name = "Large Pile of Gold",
        locations = {
            [942] = {
                {
                    x = 0.508,
                    y = 0.568,
                },
            },
        },
    },
    [290993] = {
        name = "Irontide Loot",
        locations = {
            [942] = {
                {
                    x = 0.359,
                    y = 0.56,
                },
            },
        },
    },
    [291143] = {
        name = "Ranah's Wrench",
        locations = {
            [864] = {
                {
                    x = 0.507,
                    y = 0.647,
                },
            },
        },
    },
    [291291] = {
        name = "Wanted: Poacher",
        locations = {
            [862] = {
                {
                    x = 0.69,
                    y = 0.408,
                },
            },
        },
    },
    [292523] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.413,
                    y = 0.41,
                },
            },
        },
    },
    [293567] = {
        name = "Wanted Poster",
        locations = {
            [863] = {
                {
                    x = 0.672,
                    y = 0.409,
                },
            },
        },
    },
    [293568] = {
        name = "Wanted Poster",
        locations = {
            [863] = {
                {
                    x = 0.624,
                    y = 0.413,
                },
            },
        },
    },
    [293985] = {
        name = "Wanted: War Gore",
        locations = {
            [942] = {
                {
                    x = 0.468,
                    y = 0.481,
                },
            },
        },
    },
    [297492] = {
        name = "Bulletin Board",
        locations = {
            [942] = {
                {
                    x = 0.51,
                    y = 0.336,
                },
            },
        },
    },
    [298778] = {
        name = "Wanted Poster",
        locations = {
            [895] = {
                {
                    x = 0.628,
                    y = 0.14,
                },
            },
        },
    },
    [298849] = {
        name = "Wanted Poster",
        locations = {
            [895] = {
                {
                    x = 0.397,
                    y = 0.179,
                },
            },
        },
    },
    [298858] = {
        name = "Wanted Poster",
        locations = {
            [896] = {
                {
                    x = 0.374,
                    y = 0.255,
                },
            },
        },
    },
    [307748] = {
        name = "Venture Co. Letter",
        locations = {
            [864] = {
                {
                    x = 0.262583,
                    y = 0.473013,
                },
            },
        },
    },
    [309498] = {
        name = "Armor Stand",
        locations = {
            [87] = {
                {
                    x = 0.194973,
                    y = 0.520509,
                },
            },
        },
    },
    [311155] = {
        name = "Ancient Tablet",
        locations = {
            [31] = {
                {
                    x = 0.327865,
                    y = 0.836447,
                },
            },
        },
    },
    [311218] = {
        name = "Xal'atath, Blade of the Black Empire",
        locations = {
            [942] = {
                {
                    x = 0.341377,
                    y = 0.317543,
                },
            },
        },
    },
    [311885] = {
        name = "Xal'atath, Blade of the Black Empire",
        locations = {
            [942] = {
                {
                    x = 0.341371,
                    y = 0.31754,
                },
            },
        },
    },
    [322533] = {
        name = "Mardivas's Tome of the Elements",
        locations = {
            [1355] = {
                {
                    x = 0.606581,
                    y = 0.332961,
                },
            },
        },
    },
    [326393] = {
        name = "Azerite Weapons Cache",
        locations = {
            [1355] = {
                {
                    x = 0.461173,
                    y = 0.520406,
                },
            },
        },
    },
    [326418] = {
        name = "Arcane Chest",
        locations = {
            [1355] = {
                {
                    x = 0.379572,
                    y = 0.605494,
                },
            },
        },
    },
    [326588] = {
        name = "Azerite Weapons Cache",
        locations = {
            [1355] = {
                {
                    x = 0.461162,
                    y = 0.520484,
                },
            },
        },
    },
    [327170] = {
        name = "Weapon Rack",
        locations = {
            [1355] = {
                {
                    x = 0.346451,
                    y = 0.211033,
                },
            },
        },
    },
    [327591] = {
        name = "Preserved Journal",
        locations = {
            [1355] = {
                {
                    x = 0.814449,
                    y = 0.454984,
                },
            },
        },
    },
    [327592] = {
        name = "Enchanted Lock",
        locations = {
            [1355] = {
                {
                    x = 0.789019,
                    y = 0.411355,
                },
            },
        },
    },
    [327596] = {
        name = "Broken Abyssal Focus",
        locations = {
            [1355] = {
                {
                    x = 0.381139,
                    y = 0.370025,
                },
            },
        },
    },
    [329805] = {
        name = "Strange Crystal",
        locations = {
            [1355] = {
                {
                    x = 0.328074,
                    y = 0.395909,
                },
            },
        },
    },
})
