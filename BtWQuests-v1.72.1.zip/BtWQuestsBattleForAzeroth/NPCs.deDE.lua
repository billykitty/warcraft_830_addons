----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "deDE" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateNPCsTable({
    [3037] = {
        name = "Sheza Wildmähne",
    },
    [5164] = {
        name = "Grumnus Scharfstahl",
    },
    [14720] = {
        name = "Hochfürst Saurfang",
    },
    [36648] = {
        name = "Baine Bluthuf",
    },
    [108017] = {
        name = "Torv Dubstampf",
    },
    [120168] = {
        name = "Chronist To'kini",
    },
    [120170] = {
        name = "Nathanos Pestrufer",
    },
    [120551] = {
        name = "Krag'wa der Riesige",
    },
    [120740] = {
        name = "König Rastakhan",
    },
    [120788] = {
        name = "Genn Graumähne",
    },
    [120904] = {
        name = "Prinzessin Talanji",
    },
    [120922] = {
        name = "Lady Jaina Prachtmeer",
    },
    [121144] = {
        name = "Katherine Prachtmeer",
    },
    [121239] = {
        name = "Finn Schönwind",
    },
    [121241] = {
        name = "Prinzessin Talanji",
    },
    [121288] = {
        name = "Prinzessin Talanji",
    },
    [121599] = {
        name = "König Rastakhan",
    },
    [121603] = {
        name = "Anneke Lehmann",
    },
    [121706] = {
        name = "Abrichterin L'kala",
    },
    [122009] = {
        name = "Kralmeister B'khor",
    },
    [122129] = {
        name = "Händler Alexxi Kruxtopf",
    },
    [122169] = {
        name = "Anneke Lehmann",
    },
    [122289] = {
        name = "Klingenwache Kaja",
    },
    [122320] = {
        name = "Klingenwache Kaja",
    },
    [122370] = {
        name = "Carsten Jammerthal",
    },
    [122493] = {
        name = "Annie Haag",
    },
    [122671] = {
        name = "Cassens",
    },
    [122672] = {
        name = "Olivia",
    },
    [122702] = {
        name = "Verzauberin Quinni",
    },
    [122703] = {
        name = "Kumali die Kluge",
    },
    [122706] = {
        name = "Magierin Salazae",
    },
    [122760] = {
        name = "Kriegsdruidin Loti",
    },
    [122795] = {
        name = "Hexendoktor Kejabu",
    },
    [122817] = {
        name = "Klingenwache Kaja",
    },
    [122939] = {
        name = "Terrorhornjungtier",
    },
    [122991] = {
        name = "Schattenjägerin Mutumba",
    },
    [123000] = {
        name = "Käpt'n Rez'okun",
    },
    [123019] = {
        name = "Jagdmeisterin Vol'ka",
    },
    [123022] = {
        name = "Fährtenleser Burke",
    },
    [123026] = {
        name = "Erak der Unnahbare",
    },
    [123063] = {
        name = "Ältester Kuppaka",
    },
    [123118] = {
        name = "Fallensteller Custer",
    },
    [123178] = {
        name = "Flick",
    },
    [123335] = {
        name = "Kriegsdruidin Loti",
    },
    [123415] = {
        name = "Henri Hartke",
    },
    [123544] = {
        name = "Flick",
    },
    [123545] = {
        name = "Molch",
    },
    [123878] = {
        name = "Flick",
    },
    [124062] = {
        name = "König Rastakhan",
    },
    [124063] = {
        name = "Jol der Uralte",
    },
    [124289] = {
        name = "\"Die gefährliche\" Liz Seminario",
    },
    [124376] = {
        name = "Hexendoktor Zentimo",
    },
    [124417] = {
        name = "Cyril Weiß",
    },
    [124468] = {
        name = "Randall Rotmond",
    },
    [124629] = {
        name = "Kaza'jin der Wellenbinder",
    },
    [124641] = {
        name = "Schattenjägerin Mutumba",
    },
    [124655] = {
        name = "König Rastakhan",
    },
    [124786] = {
        name = "Thomas Zwirbler",
    },
    [124802] = {
        name = "Lord Adrian Norwinsen",
    },
    [124915] = {
        name = "König Rastakhan",
    },
    [124922] = {
        name = "Helena Sanftmut",
    },
    [125039] = {
        name = "Händlerin Kro",
    },
    [125041] = {
        name = "Schriftrollengelehrter Goji",
    },
    [125042] = {
        name = "Georg Lauchner",
    },
    [125093] = {
        name = "Bewohner von Fallhafen",
    },
    [125309] = {
        name = "Anne Watteck",
    },
    [125312] = {
        name = "Schriftrollengelehrte Rooka",
    },
    [125317] = {
        name = "Schattenjägerin Narez",
    },
    [125342] = {
        name = "Käpt'n Kielson",
    },
    [125380] = {
        name = "Luzilla Kronsteig",
    },
    [125385] = {
        name = "Marschall Elkmar Lesner",
    },
    [125394] = {
        name = "Wachtmeister Henri Leumder",
    },
    [125398] = {
        name = "Harald Beckner",
    },
    [125457] = {
        name = "Rebecca Kernig",
    },
    [125486] = {
        name = "Schwingenreiter Nivek",
    },
    [125922] = {
        name = "Bruder Therold",
    },
    [125962] = {
        name = "Verwalter Jarold",
    },
    [126039] = {
        name = "Mag'ash der Giftige",
    },
    [126066] = {
        name = "Etrigg",
    },
    [126079] = {
        name = "Kol'jun Todeswandler",
    },
    [126080] = {
        name = "Shinga Todeswandler",
    },
    [126148] = {
        name = "Hexendoktorin Jala",
    },
    [126158] = {
        name = "Finn Schönwind",
    },
    [126210] = {
        name = "Verwalter Arndt",
    },
    [126213] = {
        name = "Prinzessin Talanji",
    },
    [126225] = {
        name = "Aaron Wappenstein",
    },
    [126240] = {
        name = "Brigitte Quellwasser",
    },
    [126298] = {
        name = "Brannon Sturmsang",
    },
    [126308] = {
        name = "Karsten Albers",
    },
    [126310] = {
        name = "Evelyn Minder",
    },
    [126511] = {
        name = "Sven Matjes",
    },
    [126560] = {
        name = "Kriegsdruidin Loti",
    },
    [126564] = {
        name = "Hexfürst Raal",
    },
    [126620] = {
        name = "Finn Schönwind",
    },
    [126804] = {
        name = "Eingefangener Saurolisk",
    },
    [127006] = {
        name = "Marina Kenner",
    },
    [127015] = {
        name = "Thaddäus \"Opi\" Risswalt",
    },
    [127080] = {
        name = "Lord Herbsttal",
    },
    [127112] = {
        name = "Schmiedemeister Zak'aal",
    },
    [127144] = {
        name = "Marina Kenner",
    },
    [127157] = {
        name = "Markus Sturmtal",
    },
    [127161] = {
        name = "Alina Holsten",
    },
    [127215] = {
        name = "Schattenjäger Da'jul",
    },
    [127216] = {
        name = "Zardrax der Ermächtiger",
    },
    [127391] = {
        name = "Blutsucher Jo'chunga",
    },
    [127396] = {
        name = "Initiandin Lilly",
    },
    [127481] = {
        name = "Lord Kenninger",
    },
    [127489] = {
        name = "Hexfürst Raal",
    },
    [127537] = {
        name = "Gertrude",
    },
    [127558] = {
        name = "Art Hugen",
    },
    [127559] = {
        name = "Lord Adrian Norwinsen",
    },
    [127570] = {
        name = "Klingenwache Kaja",
    },
    [127646] = {
        name = "Lord Kenninger",
    },
    [127715] = {
        name = "Luzilla Kronsteig",
    },
    [127743] = {
        name = "Tantchen Amanda Kernig",
    },
    [127803] = {
        name = "Karsten Bergmann",
    },
    [127837] = {
        name = "Kaza'jin der Wellenbinder",
    },
    [127961] = {
        name = "Prinzessin Talanji",
    },
    [127980] = {
        name = "Akunda der Verständige",
    },
    [127992] = {
        name = "Akunda der Erhabene",
    },
    [128228] = {
        name = "Kohldampfsören",
    },
    [128229] = {
        name = "Jette die Klinge",
    },
    [128261] = {
        name = "Erster Maat Jamboya",
    },
    [128349] = {
        name = "Hilde Feuerbruch",
    },
    [128353] = {
        name = "Pendi Krummelunte",
    },
    [128377] = {
        name = "Strandgutsammler Björn",
    },
    [128381] = {
        name = "Drogrin Backenbräu",
    },
    [128457] = {
        name = "Maude Risswalt",
    },
    [128467] = {
        name = "Elias Eimann",
    },
    [128494] = {
        name = "Adela Hagendorn",
    },
    [128618] = {
        name = "Dockmeister Heringsson",
    },
    [128679] = {
        name = "Rosalinde Mertens",
    },
    [128680] = {
        name = "Okri Werkelkant",
    },
    [128903] = {
        name = "Karl-Jan",
    },
    [129164] = {
        name = "Chronist Jabari",
    },
    [129165] = {
        name = "Wache Satao",
    },
    [129392] = {
        name = "Der \"hilflose\" Henri",
    },
    [129451] = {
        name = "Umi",
    },
    [129491] = {
        name = "König Rastakhan",
    },
    [129561] = {
        name = "Kriegsdruidin Loti",
    },
    [129578] = {
        name = "Sören Meiners",
    },
    [129613] = {
        name = "Mainhardt Algerson",
    },
    [129642] = {
        name = "Luzilla Kronsteig",
    },
    [129643] = {
        name = "Marschall Elkmar Lesner",
    },
    [129670] = {
        name = "Lotte Baumhüter",
    },
    [129703] = {
        name = "Hexfürst Raal",
    },
    [129757] = {
        name = "König Rastakhan",
    },
    [129808] = {
        name = "Bauer Goldfeld",
    },
    [129858] = {
        name = "Wulferd Zischkolben",
    },
    [129907] = {
        name = "Zul der Prophet",
    },
    [129956] = {
        name = "Dockmeister Tinsen",
    },
    [129983] = {
        name = "Inquisitorin Morgenlicht",
    },
    [130101] = {
        name = "Rekrut Brutis",
    },
    [130190] = {
        name = "Unteroffizier Calvin",
    },
    [130216] = {
        name = "Magni Bronzebart",
    },
    [130341] = {
        name = "Klingenwache Kaja",
    },
    [130368] = {
        name = "Samuel D. Kaltmann III.",
    },
    [130375] = {
        name = "Tallis Himmelsherz",
    },
    [130377] = {
        name = "Kurier Gerald",
    },
    [130399] = {
        name = "Zooey Tintenritzel",
    },
    [130424] = {
        name = "Der \"hilflose\" Henri",
    },
    [130450] = {
        name = "Klingenwache Sonji",
    },
    [130468] = {
        name = "Klein Tika",
    },
    [130481] = {
        name = "Shinga Todeswandler",
    },
    [130576] = {
        name = "Bruder Pike",
    },
    [130603] = {
        name = "Bestienbrecher Hakid",
    },
    [130660] = {
        name = "Kriegswache Rakera",
    },
    [130667] = {
        name = "Kriegswache Rakera",
    },
    [130694] = {
        name = "Bürgermeisterin Rosen",
    },
    [130697] = {
        name = "Brandmeisterin Jule",
    },
    [130706] = {
        name = "Izitas Geist",
    },
    [130714] = {
        name = "Bruder Pike",
    },
    [130750] = {
        name = "Käpt'n Grez'ko",
    },
    [130785] = {
        name = "Jagdmeisterin Kil'ja",
    },
    [130821] = {
        name = "Wellenbezwingerin Lanfa",
    },
    [130833] = {
        name = "Käpt'n Grez'ko",
    },
    [130844] = {
        name = "Prinzessin Talanji",
    },
    [130901] = {
        name = "Chronist Grazzul",
    },
    [130904] = {
        name = "Samuel Willem",
    },
    [130905] = {
        name = "Kala Kruxtopf",
    },
    [130929] = {
        name = "Hexendoktorin Jangalar",
    },
    [131000] = {
        name = "Kommandant Kellmann",
    },
    [131001] = {
        name = "Leutnant Harms",
    },
    [131002] = {
        name = "Leutnant Bauer",
    },
    [131003] = {
        name = "Spezialist Weneke",
    },
    [131004] = {
        name = "Knappe Augustus III.",
    },
    [131048] = {
        name = "Leutnant Tarenfeld",
    },
    [131248] = {
        name = "Samuel Willem",
    },
    [131253] = {
        name = "Titanenhüter Hezrel",
    },
    [131290] = {
        name = "Finn Schönwind",
    },
    [131354] = {
        name = "Bestienmutter Jabati",
    },
    [131442] = {
        name = "Leonhard Reinwald",
    },
    [131443] = {
        name = "Großtelemant Oculeth",
    },
    [131448] = {
        name = "Werner Eschtal",
    },
    [131469] = {
        name = "Martin Nezz",
    },
    [131579] = {
        name = "Gefangener Dorfbewohner",
    },
    [131580] = {
        name = "Telemantenlehrling Astrandis",
    },
    [131582] = {
        name = "Prüferin Tae'shara Blutwächter",
    },
    [131636] = {
        name = "Marschall Elkmar Lesner",
    },
    [131638] = {
        name = "Luzilla Kronsteig",
    },
    [131639] = {
        name = "Inquisitorin Knüpp",
    },
    [131640] = {
        name = "Inquisitor Nottlich",
    },
    [131642] = {
        name = "Inquisitor Hartwasser",
    },
    [131654] = {
        name = "Marie",
    },
    [131656] = {
        name = "Hundemeister Archibald",
    },
    [131657] = {
        name = "Kompendium des Blutvergießens",
    },
    [131684] = {
        name = "Petra \"Püppchen\" Hartke",
    },
    [131763] = {
        name = "Ausgräber Morgrum Glutstein",
    },
    [131775] = {
        name = "Der ohrlose Jens",
    },
    [131777] = {
        name = "Acadia Tistelstein",
    },
    [131793] = {
        name = "Anselm Mildenhall",
    },
    [131840] = {
        name = "Shuga Sprengkapp",
    },
    [131879] = {
        name = "Inquisitorin Morgenlicht",
    },
    [131993] = {
        name = "Yasch",
    },
    [132118] = {
        name = "Bauer Büttner",
    },
    [132193] = {
        name = "Arnold Ballaster",
    },
    [132228] = {
        name = "Elrick Pfitzer",
    },
    [132292] = {
        name = "Raimund Mildenhall",
    },
    [132332] = {
        name = "Prinzessin Talanji",
    },
    [132333] = {
        name = "Prinzessin Talanji",
    },
    [132347] = {
        name = "Quintin Pfitzer",
    },
    [132374] = {
        name = "Else Werker",
    },
    [132617] = {
        name = "Bently Schmierfleck",
    },
    [132647] = {
        name = "Anselm Mildenhall",
    },
    [132720] = {
        name = "Falkenmeister Lloyd",
    },
    [132966] = {
        name = "Linda Süß",
    },
    [132988] = {
        name = "Flick",
    },
    [132994] = {
        name = "Lord Arthur Kronsteig",
    },
    [133035] = {
        name = "Offizier Jovan",
    },
    [133050] = {
        name = "Prinzessin Talanji",
    },
    [133098] = {
        name = "Inquisitorin Morgenlicht",
    },
    [133101] = {
        name = "Samantha Süß",
    },
    [133105] = {
        name = "Werner Eschtal",
    },
    [133125] = {
        name = "Prinzessin Talanji",
    },
    [133126] = {
        name = "Martin Nezz",
    },
    [133324] = {
        name = "Hexfürst Raal",
    },
    [133476] = {
        name = "Prinzessin Talanji",
    },
    [133489] = {
        name = "Ormhun Steinhammer",
    },
    [133523] = {
        name = "Ji Feuerpfote",
    },
    [133536] = {
        name = "Grix \"Eisenfäuste\" Brennecke",
    },
    [133550] = {
        name = "Bergbaufrischling Hannes",
    },
    [133551] = {
        name = "Leitender Minenarbeiter Theock",
    },
    [133552] = {
        name = "Oberster Chemiker Walters",
    },
    [133576] = {
        name = "Steuerfrau Haken",
    },
    [133577] = {
        name = "Meisterkanonier Schnur",
    },
    [133578] = {
        name = "\"Senkblei\"",
    },
    [133640] = {
        name = "June der Vorfahre",
    },
    [133653] = {
        name = "Hexfürst Raal",
    },
    [133839] = {
        name = "Harri Hocke",
    },
    [133953] = {
        name = "Unteroffizier Calvin",
    },
    [134009] = {
        name = "Einwohnerin von Korlach",
    },
    [134028] = {
        name = "Sven Robertson",
    },
    [134166] = {
        name = "Finn Schönwind",
    },
    [134325] = {
        name = "Tillmann Pfleger",
    },
    [134345] = {
        name = "Sammler Kojo",
    },
    [134408] = {
        name = "Großknecht Jethek",
    },
    [134509] = {
        name = "Hauptführer Zugzange",
    },
    [134628] = {
        name = "Bautechnikerin Alena",
    },
    [134639] = {
        name = "Bruder Pike",
    },
    [134702] = {
        name = "Nante Grinser",
    },
    [134720] = {
        name = "Leo Schilders",
    },
    [134752] = {
        name = "Bürgermeisterin Rosen",
    },
    [134776] = {
        name = "David Brindel",
    },
    [134953] = {
        name = "Alexander Trittwart",
    },
    [135021] = {
        name = "Inquisitorin Morgenlicht",
    },
    [135067] = {
        name = "Moxie Schlossdreher",
    },
    [135085] = {
        name = "Hauptmann Linda Notlich",
    },
    [135133] = {
        name = "Kriegswache Rakera",
    },
    [135179] = {
        name = "Merd Erzfeld",
    },
    [135200] = {
        name = "Alexander Trittwart",
    },
    [135205] = {
        name = "Nathanos Pestrufer",
    },
    [135308] = {
        name = "Schwingenhalter Goja",
    },
    [135330] = {
        name = "Nante Grinser",
    },
    [135367] = {
        name = "Gretel Haribock",
    },
    [135517] = {
        name = "Gezeitenwächterin Wiebke",
    },
    [135534] = {
        name = "Bruder Pike",
    },
    [135541] = {
        name = "Bilgewasserverbrenner",
    },
    [135576] = {
        name = "Bo'tzfrau Maset",
    },
    [135612] = {
        name = "Halford Wyrmbann",
    },
    [135614] = {
        name = "Meister Mathias Shaw",
    },
    [135620] = {
        name = "Kelsey Stahlfunken",
    },
    [135673] = {
        name = "Späher Melzer",
    },
    [135681] = {
        name = "Großadmiralin Jes-Tereth",
    },
    [135690] = {
        name = "Schreckensadmiralin Segelriss",
    },
    [135691] = {
        name = "Nathanos Pestrufer",
    },
    [135784] = {
        name = "Kaiserliche Wache",
    },
    [135793] = {
        name = "Sammler Kojo",
    },
    [135794] = {
        name = "Schriftrollengelehrte Nola",
    },
    [135801] = {
        name = "Hexfürst Raal",
    },
    [135855] = {
        name = "Teekay Tretspule",
    },
    [135861] = {
        name = "Adelinde Waldschau",
    },
    [135874] = {
        name = "Leefke Martinek",
    },
    [135890] = {
        name = "König Rastakhan",
    },
    [135901] = {
        name = "Fungianer der Blutschwämme",
    },
    [135976] = {
        name = "Morwin Hainherz",
    },
    [136041] = {
        name = "Emilia Frohwetter",
    },
    [136053] = {
        name = "Samuel Willem",
    },
    [136059] = {
        name = "Lotte Ebenkiel",
    },
    [136063] = {
        name = "Kassandra Brenner",
    },
    [136140] = {
        name = "Klonk Schmierbit",
    },
    [136184] = {
        name = "Kai Karlson",
    },
    [136195] = {
        name = "Sanitäterin Feorea",
    },
    [136227] = {
        name = "Fixi Scharflist",
    },
    [136233] = {
        name = "Klaus Schönwind",
    },
    [136234] = {
        name = "Cesi Zündschnur",
    },
    [136309] = {
        name = "Erster Maat Jamboya",
    },
    [136310] = {
        name = "Erster Maat Jamboya",
    },
    [136414] = {
        name = "Hirtin Mühlbach",
    },
    [136432] = {
        name = "Brann Bronzebart",
    },
    [136458] = {
        name = "Cesi Zündschnur",
    },
    [136497] = {
        name = "Gezeitenwächterin Wiebke",
    },
    [136562] = {
        name = "Rüstmeister Alfin",
    },
    [136568] = {
        name = "Hauptmann Conrad",
    },
    [136574] = {
        name = "Karl Fürbittshafen",
    },
    [136576] = {
        name = "Dockmeisterin Lettmann",
    },
    [136641] = {
        name = "Brann Bronzebart",
    },
    [136645] = {
        name = "Brann Bronzebart",
    },
    [136658] = {
        name = "Marie Fürbittshafen",
    },
    [136675] = {
        name = "Brann Bronzebart",
    },
    [136683] = {
        name = "Handelsprinz Gallywix",
    },
    [136725] = {
        name = "Etrigg",
    },
    [136779] = {
        name = "Erster Maat Jamboya",
    },
    [136907] = {
        name = "Magni Bronzebart",
    },
    [136933] = {
        name = "Bruder Pike",
    },
    [137008] = {
        name = "Unteroffizier Elkmar",
    },
    [137075] = {
        name = "Leutnant Dennis Düstermär",
    },
    [137094] = {
        name = "Bauer Max",
    },
    [137112] = {
        name = "Titanenhüter Hezrel",
    },
    [137213] = {
        name = "Halford Wyrmbann",
    },
    [137337] = {
        name = "Unteroffizier Elkmar",
    },
    [137401] = {
        name = "Ambossthan Thurgaden",
    },
    [137506] = {
        name = "Bruder Pike",
    },
    [137543] = {
        name = "Unteroffizier Elkmar",
    },
    [137613] = {
        name = "Hobart Wurfhammer",
    },
    [137675] = {
        name = "Schattenjäger Ty'jin",
    },
    [137691] = {
        name = "Bruder Pike",
    },
    [137694] = {
        name = "Parin Tüfteldings",
    },
    [137727] = {
        name = "Erster Maat Ottkens",
    },
    [137742] = {
        name = "Schattenjäger Ty'jin",
    },
    [137818] = {
        name = "Myxle \"die Seeratte\" Schraubenruck",
    },
    [137837] = {
        name = "Oberanführerin Geya'rah",
    },
    [137867] = {
        name = "Halford Wyrmbann",
    },
    [137878] = {
        name = "Meister Gadrin",
    },
    [138138] = {
        name = "Prinzessin Talanji",
    },
    [138285] = {
        name = "Nathanos Pestrufer",
    },
    [138352] = {
        name = "Oberster Kriegsfürst Cromush",
    },
    [138365] = {
        name = "Oberster Kriegsfürst Cromush",
    },
    [138520] = {
        name = "Einwohnerin von Zeb'ahari",
    },
    [138521] = {
        name = "Minentechniker",
    },
    [138688] = {
        name = "Zenturio Kaga Warmstein",
    },
    [138708] = {
        name = "Garona die Halborcin",
    },
    [138735] = {
        name = "Frederike Götzstein",
    },
    [138924] = {
        name = "Holger Nielsen",
    },
    [139061] = {
        name = "Nathanos Pestrufer",
    },
    [139069] = {
        name = "Erster Maat Rotmond",
    },
    [139070] = {
        name = "Käpt'n Rotmond",
    },
    [139089] = {
        name = "Wache von Haderfurt",
    },
    [139705] = {
        name = "Halford Wyrmbann",
    },
    [139719] = {
        name = "Shandris Mondfeder",
    },
    [139722] = {
        name = "Explosionist Robolöt",
    },
    [139912] = {
        name = "Waldläuferin Wons",
    },
    [139926] = {
        name = "Dornsprecher Birkhain",
    },
    [139928] = {
        name = "Meister Gadrin",
    },
    [140048] = {
        name = "Arthur Handelswind",
    },
    [140105] = {
        name = "Nathanos Pestrufer",
    },
    [140176] = {
        name = "Nathanos Pestrufer",
    },
    [140258] = {
        name = "Shandris Mondfeder",
    },
    [140484] = {
        name = "Kapitänin Amalia Stein",
    },
    [140485] = {
        name = "Nathanos Pestrufer",
    },
    [140495] = {
        name = "Katherine Prachtmeer",
    },
    [140590] = {
        name = "Käpt'n Grez'ko",
    },
    [140724] = {
        name = "Prinzessin Talanji",
    },
    [140725] = {
        name = "Geist von Vol'jin",
    },
    [140752] = {
        name = "Jenny Flottbeek",
    },
    [141078] = {
        name = "Flüchtling der Wachkuppe",
    },
    [141555] = {
        name = "Baine Bluthuf",
    },
    [141603] = {
        name = "Mallorie Veddel",
    },
    [141643] = {
        name = "Meeresbodenwatschelklaue",
    },
    [141644] = {
        name = "Nathanos Pestrufer",
    },
    [141672] = {
        name = "Ertrunkener Matrose",
    },
    [141769] = {
        name = "Marleen Veddel",
    },
    [141815] = {
        name = "Ertrunkener Matrose",
    },
    [141952] = {
        name = "Junges Terrorhorn",
    },
    [142275] = {
        name = "Grommash Höllschrei",
    },
    [142422] = {
        name = "Etrigg",
    },
    [142651] = {
        name = "Luzilla Kronsteig",
    },
    [142930] = {
        name = "Halford Wyrmbann",
    },
    [143536] = {
        name = "Oberster Kriegsfürst Volrath",
    },
    [143559] = {
        name = "Großmarschall Tremblade",
    },
    [143565] = {
        name = "June der Vorfahre",
    },
    [143777] = {
        name = "Der große Hasani",
    },
    [143787] = {
        name = "Flapp-Flapp",
    },
    [143845] = {
        name = "Oberanführerin Geya'rah",
    },
    [143846] = {
        name = "Alleria Windläufer",
    },
    [143851] = {
        name = "Kelsey Stahlfunken",
    },
    [143871] = {
        name = "Vorarbeiterin Ritzelknopf",
    },
    [143878] = {
        name = "Ratz Riegelflöz",
    },
    [143908] = {
        name = "Geschundener Leichnam",
    },
    [143913] = {
        name = "Etrigg",
    },
    [144095] = {
        name = "Meister Mathias Shaw",
    },
    [145005] = {
        name = "Elitereiter der Weltenwanderer",
    },
    [145022] = {
        name = "Zeitweberin Delormi",
    },
    [145131] = {
        name = "Datenguru Gryzix",
    },
    [145190] = {
        name = "Prinzessin Talanji",
    },
    [145225] = {
        name = "Geist von Vol'jin",
    },
    [145359] = {
        name = "Prinzessin Talanji",
    },
    [145411] = {
        name = "Fürstin Sylvanas Windläufer",
    },
    [145424] = {
        name = "Baine Bluthuf",
    },
    [145462] = {
        name = "Brann Bronzebart",
    },
    [145464] = {
        name = "Berater Belgrum",
    },
    [145580] = {
        name = "Lady Jaina Prachtmeer",
    },
    [145593] = {
        name = "Rosalinde Mertens",
    },
    [145632] = {
        name = "Okri Werkelkant",
    },
    [145751] = {
        name = "Handelsprinz Gallywix",
    },
    [145816] = {
        name = "G.M.O.D.",
    },
    [145965] = {
        name = "Geist von Vol'jin",
    },
    [145981] = {
        name = "Geist von Vol'jin",
    },
    [146010] = {
        name = "Dunkle Waldläuferin Lyana",
    },
    [146013] = {
        name = "Dunkle Waldläuferin Alina",
    },
    [146050] = {
        name = "Maiev Schattensang",
    },
    [146073] = {
        name = "Handelsprinz Gallywix",
    },
    [146208] = {
        name = "Krag'wa der Riesige",
    },
    [146290] = {
        name = "Geist von Vol'jin",
    },
    [146323] = {
        name = "Nathanos Pestrufer",
    },
    [146325] = {
        name = "Schreddermeister Blix",
    },
    [146335] = {
        name = "Königin Talanji",
    },
    [146373] = {
        name = "Maiev Schattensang",
    },
    [146374] = {
        name = "Shandris Mondfeder",
    },
    [146375] = {
        name = "Sira Mondhüter",
    },
    [146536] = {
        name = "Verlorener Irrwisch",
    },
    [146601] = {
        name = "Sira Mondhüter",
    },
    [146623] = {
        name = "G.M.O.D.",
    },
    [146630] = {
        name = "Geist von Vol'jin",
    },
    [146654] = {
        name = "Fürstin Sylvanas Windläufer",
    },
    [146791] = {
        name = "Dunkle Waldläuferin Lyana",
    },
    [146806] = {
        name = "Dunkle Waldläuferin Lyana",
    },
    [146824] = {
        name = "Prinzessin Talanji",
    },
    [146877] = {
        name = "Prinzessin Talanji",
    },
    [146902] = {
        name = "Bruder Pike",
    },
    [146921] = {
        name = "Prinzessin Talanji",
    },
    [146937] = {
        name = "Dunkle Waldläuferin Lyana",
    },
    [146939] = {
        name = "Botschafterin Morgenschwur",
    },
    [146982] = {
        name = "Lady Jaina Prachtmeer",
    },
    [146988] = {
        name = "Ausgräber Golad",
    },
    [147075] = {
        name = "Generalin Rakera",
    },
    [147088] = {
        name = "Arkanistin Valtrois",
    },
    [147135] = {
        name = "Nathanos Pestrufer",
    },
    [147145] = {
        name = "Nathanos Pestrufer",
    },
    [147149] = {
        name = "Morten Ritzelwald",
    },
    [147151] = {
        name = "Kelsey Stahlfunken",
    },
    [147155] = {
        name = "Flick",
    },
    [147210] = {
        name = "Dunkle Waldläuferin Lyana",
    },
    [147311] = {
        name = "Morten Ritzelwald",
    },
    [147519] = {
        name = "Kelsey Stahlfunken",
    },
    [147819] = {
        name = "Klingenmeister Telaamon",
    },
    [147842] = {
        name = "Lady Jaina Prachtmeer",
    },
    [147843] = {
        name = "Meister Mathias Shaw",
    },
    [147844] = {
        name = "Klingenmeister Telaamon",
    },
    [147939] = {
        name = "Pilotenass Sturmrad",
    },
    [147943] = {
        name = "Hauptmann Tret Funkdüse",
    },
    [147950] = {
        name = "Getriebehauptmann Winkelfeder",
    },
    [147952] = {
        name = "Fizzi Tüftelbogen",
    },
    [148096] = {
        name = "Hochprälatin Rata",
    },
    [148339] = {
        name = "Flick",
    },
    [148798] = {
        name = "Lady Jaina Prachtmeer",
    },
    [148870] = {
        name = "Dorian Ebbwasser",
    },
    [149084] = {
        name = "Geistwandler Ussoh",
    },
    [149088] = {
        name = "Geistwandlerin Isahi",
    },
    [149143] = {
        name = "Nathanos Pestrufer",
    },
    [149252] = {
        name = "Gebundener Himmel",
    },
    [149471] = {
        name = "Dunkle Waldläuferin Velonara",
    },
    [149503] = {
        name = "Getriebehauptmann Winkelfeder",
    },
    [149528] = {
        name = "Baine Bluthuf",
    },
    [149529] = {
        name = "Geistwandler Ussoh",
    },
    [149612] = {
        name = "Shandris Mondfeder",
    },
    [149736] = {
        name = "Abbild von Mimiron",
    },
    [149815] = {
        name = "Grizzek Zischzang",
    },
    [149823] = {
        name = "Magni Bronzebart",
    },
    [149842] = {
        name = "Baine Bluthuf",
    },
    [149864] = {
        name = "Tüftlermeister Oberfunks",
    },
    [149867] = {
        name = "Magni Bronzebart",
    },
    [149870] = {
        name = "Grif Wildherz",
    },
    [149877] = {
        name = "Tüftlermeister Oberfunks",
    },
    [149904] = {
        name = "Neri Scharffinne",
    },
    [150086] = {
        name = "Fitz Funkenschlag",
    },
    [150087] = {
        name = "Genn Graumähne",
    },
    [150101] = {
        name = "Lady Jaina Prachtmeer",
    },
    [150115] = {
        name = "Prinzessin Tess Graumähne",
    },
    [150145] = {
        name = "Gila Kurzschluss",
    },
    [150187] = {
        name = "Nathanos Pestrufer",
    },
    [150196] = {
        name = "Erste Arkanistin Thalyssra",
    },
    [150200] = {
        name = "Kurierin Claridge",
    },
    [150206] = {
        name = "Großtelemant Oculeth",
    },
    [150208] = {
        name = "Tüftlermeister Oberfunks",
    },
    [150209] = {
        name = "Neri Scharffinne",
    },
    [150309] = {
        name = "Baine Bluthuf",
    },
    [150391] = {
        name = "Abbild von Mimiron",
    },
    [150433] = {
        name = "Donnerfelsbehüterin Prachtnarbe",
    },
    [150515] = {
        name = "Carsten Jammerthal",
    },
    [150555] = {
        name = "Waren Kolbenherz",
    },
    [150573] = {
        name = "Recycler Römms",
    },
    [150574] = {
        name = "Lady Jaina Prachtmeer",
    },
    [150630] = {
        name = "Flip Blitzlader",
    },
    [150631] = {
        name = "Pristy Blitzlader",
    },
    [150633] = {
        name = "Lady Jaina Prachtmeer",
    },
    [150637] = {
        name = "Kelsey Stahlfunken",
    },
    [150640] = {
        name = "Meister Mathias Shaw",
    },
    [150796] = {
        name = "Kelsey Stahlfunken",
    },
    [150884] = {
        name = "Klara Werth",
    },
    [150885] = {
        name = "Weidenbestie",
    },
    [150893] = {
        name = "Schrein der See",
    },
    [150894] = {
        name = "Schrein der Natur",
    },
    [150895] = {
        name = "Schrein der Sande",
    },
    [150896] = {
        name = "Schrein der Abendflut",
    },
    [150897] = {
        name = "Schrein der Dämmerung",
    },
    [150898] = {
        name = "Schrein der Stürme",
    },
    [150956] = {
        name = "Kaputte Bohrmaschine",
    },
    [151000] = {
        name = "Klingenmeister Okani",
    },
    [151100] = {
        name = "Gila Kurzschluss",
    },
    [151129] = {
        name = "Sapphronetta Chaise",
    },
    [151130] = {
        name = "Grizzek Zischzang",
    },
    [151132] = {
        name = "Feders",
    },
    [151134] = {
        name = "Zeitweberin Delormi",
    },
    [151137] = {
        name = "Synchronschneiderin",
    },
    [151162] = {
        name = "Atikka \"Ass\" Mondjäger",
    },
    [151173] = {
        name = "Daniss Geisttänzer",
    },
    [151283] = {
        name = "Terrorhornjungtier",
    },
    [151285] = {
        name = "Mevris Geisttänzer",
    },
    [151286] = {
        name = "Spross von Torcali",
    },
    [151626] = {
        name = "Jäger Akana",
    },
    [151641] = {
        name = "Geistwandler Ebenhorn",
    },
    [151682] = {
        name = "Merithra des Traums",
    },
    [151693] = {
        name = "Merithra des Traums",
    },
    [151695] = {
        name = "Geistwandler Ebenhorn",
    },
    [151704] = {
        name = "Valithria Traumwandler",
    },
    [151741] = {
        name = "Lehrling Odari",
    },
    [151761] = {
        name = "Vassandra Sturmklaue",
    },
    [151784] = {
        name = "Mia Graumähne",
    },
    [151825] = {
        name = "Merithra des Traums",
    },
    [151851] = {
        name = "Großtelemant Oculeth",
    },
    [151887] = {
        name = "Merithra des Traums",
    },
    [151947] = {
        name = "Prinz Erazmin",
    },
    [151999] = {
        name = "Jo'nok, Bollwerk von Torcali",
    },
    [152002] = {
        name = "Abbild von Mimiron",
    },
    [152047] = {
        name = "Poen Kiembrack",
    },
    [152066] = {
        name = "Erste Arkanistin Thalyssra",
    },
    [152095] = {
        name = "Magni Bronzebart",
    },
    [152108] = {
        name = "Neri Scharffinne",
    },
    [152194] = {
        name = "MUTTER",
    },
    [152206] = {
        name = "Magni Bronzebart",
    },
    [152238] = {
        name = "Riathia Silberstern",
    },
    [152316] = {
        name = "Abbild von Thalyssra",
    },
    [152385] = {
        name = "Geistwandler Ebenhorn",
    },
    [152484] = {
        name = "Tüftlermeister Oberfunks",
    },
    [152489] = {
        name = "Schrein der Stürme",
    },
    [152490] = {
        name = "Schrein der Dämmerung",
    },
    [152493] = {
        name = "Schrein der Sande",
    },
    [152495] = {
        name = "Schrein der See",
    },
    [152496] = {
        name = "Schrein der Natur",
    },
    [152497] = {
        name = "Schrein der Abendflut",
    },
    [152747] = {
        name = "Christy Schlagbolz",
    },
    [152815] = {
        name = "Magni Bronzebart",
    },
    [152820] = {
        name = "Prinz Erazmin",
    },
    [152851] = {
        name = "Prinz Erazmin",
    },
    [152864] = {
        name = "Tüftlermeister Oberfunks",
    },
    [153253] = {
        name = "Lady Jaina Prachtmeer",
    },
    [153365] = {
        name = "Honigrückenschwarmmutter",
    },
    [153385] = {
        name = "Klingenmeister Okani",
    },
    [153393] = {
        name = "Ingmar",
    },
    [153422] = {
        name = "Großtelemant Oculeth",
    },
    [153509] = {
        name = "Handwerker Okata",
    },
    [153510] = {
        name = "Handwerker Itanu",
    },
    [153514] = {
        name = "Finderin Palta",
    },
    [153617] = {
        name = "Shandris Mondfeder",
    },
    [153670] = {
        name = "Prinz Erazmin",
    },
    [153932] = {
        name = "Genn Graumähne",
    },
    [153936] = {
        name = "Aufseher Hajeer",
    },
    [154002] = {
        name = "Atolia Seeperl",
    },
    [154023] = {
        name = "Schlüpfende Ernterin",
    },
    [154143] = {
        name = "Sammler Kojo",
    },
    [154248] = {
        name = "Klingenkämpfer Inowari",
    },
    [154257] = {
        name = "Ausbilder Ulooaka",
    },
    [154444] = {
        name = "Sturmsprecher Qian",
    },
    [154514] = {
        name = "Kelya Mondsturz",
    },
    [154520] = {
        name = "Erste Arkanistin Thalyssra",
    },
    [154522] = {
        name = "Shandris Mondfeder",
    },
    [154532] = {
        name = "Magni Bronzebart",
    },
    [154533] = {
        name = "Magni Bronzebart",
    },
    [154574] = {
        name = "Kelya Mondsturz",
    },
    [154601] = {
        name = "Kelya Mondsturz",
    },
    [154607] = {
        name = "Abbild von Torcali",
    },
    [154640] = {
        name = "Großmarschall Tremblade",
    },
    [154660] = {
        name = "Shandris Mondfeder",
    },
    [154661] = {
        name = "Erste Arkanistin Thalyssra",
    },
    [154958] = {
        name = "Arbeiter Mitchell",
    },
    [155071] = {
        name = "Shandris Mondfeder",
    },
    [155095] = {
        name = "König Phaoris",
    },
    [155102] = {
        name = "Hochforscherin Dellorah",
    },
    [155325] = {
        name = "Erste Arkanistin Thalyssra",
    },
    [155336] = {
        name = "Mogukrieger",
    },
    [155482] = {
        name = "Shandris Mondfeder",
    },
    [155496] = {
        name = "Furorion",
    },
    [155562] = {
        name = "Meisterin der Shado-Pan",
    },
    [155785] = {
        name = "Lady Jaina Prachtmeer",
    },
    [156003] = {
        name = "Lehrensucher Cho",
    },
    [156124] = {
        name = "Etrigg",
    },
    [156297] = {
        name = "Chen Sturmbräu",
    },
    [156390] = {
        name = "Chen Sturmbräu",
    },
    [156391] = {
        name = "Li Li Sturmbräu",
    },
    [156396] = {
        name = "Sassy Hartzang",
    },
    [156423] = {
        name = "Fürstin Sylvanas Windläufer",
    },
    [156425] = {
        name = "Dunkle Waldläuferin Lenara",
    },
    [156440] = {
        name = "Nathanos Pestrufer",
    },
    [156520] = {
        name = "Hobart Wurfhammer",
    },
    [156542] = {
        name = "Kramp Schmierlunte",
    },
    [156937] = {
        name = "Chen Sturmbräu",
    },
    [156938] = {
        name = "Li Li Sturmbräu",
    },
    [157180] = {
        name = "Zurückgelassene Sturmbräufässchen",
    },
    [157491] = {
        name = "Hobart Wurfhammer",
    },
    [157997] = {
        name = "Kelsey Stahlfunken",
    },
    [158145] = {
        name = "Prinz Erazmin",
    },
    [159544] = {
        name = "Arik Skorpidstich",
    },
    [159560] = {
        name = "Vorhut Lashan",
    },
    [159587] = {
        name = "Gelbin Mekkadrill",
    },
    [159682] = {
        name = "Fährtenleserin Samara",
    },
    [159820] = {
        name = "Heiler Dyrin",
    },
    [159920] = {
        name = "Zahra Sandpirscher",
    },
    [160101] = {
        name = "Kelsey Stahlfunken",
    },
    [160232] = {
        name = "Christy Schlagbolz",
    },
    [161031] = {
        name = "Hauptmann Hadan",
    },
    [161805] = {
        name = "Magni Bronzebart",
    },
})
]])()
