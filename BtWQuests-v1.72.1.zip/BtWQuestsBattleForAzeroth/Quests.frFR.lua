----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "frFR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Juste un peu de sang",
    },
    [44785] = {
        name = "L’heure du goûter",
    },
    [45079] = {
        name = "Le village de Ruisseval",
    },
    [45972] = {
        name = "Le fourré maudit",
    },
    [46727] = {
        name = "Le déferlement",
    },
    [46728] = {
        name = "La nation de Kul Tiras",
    },
    [46729] = {
        name = "Le chevalier grisonnant",
    },
    [46846] = {
        name = "La parole de Zul",
    },
    [46926] = {
        name = "Ratissage",
    },
    [46927] = {
        name = "La punition de Tal’aman",
    },
    [46928] = {
        name = "La punition de Tal’farrak",
    },
    [46929] = {
        name = "Dissuasion",
    },
    [46931] = {
        name = "Porte-parole de la Horde",
    },
    [46957] = {
        name = "Bienvenue à Zuldazar",
    },
    [47098] = {
        name = "Bagnards en cavale",
    },
    [47099] = {
        name = "Repérage",
    },
    [47103] = {
        name = "En route pour Nazmir",
    },
    [47105] = {
        name = "Dans les ténèbres",
    },
    [47130] = {
        name = "Des funérailles peu orthodoxes",
    },
    [47181] = {
        name = "Situation explosive",
    },
    [47186] = {
        name = "Le sanctum des Sages",
    },
    [47188] = {
        name = "L’aide des Loas",
    },
    [47189] = {
        name = "Une nation divisée",
    },
    [47198] = {
        name = "Ils nous veulent vivants",
    },
    [47199] = {
        name = "La porte de Sang",
    },
    [47200] = {
        name = "Tiques ? Attaque, et toc !",
    },
    [47204] = {
        name = "Le nouveau front",
    },
    [47205] = {
        name = "La mère de la guerre",
    },
    [47226] = {
        name = "Un jeune orphelin",
    },
    [47228] = {
        name = "L’écosystème xibalani",
    },
    [47229] = {
        name = "Rempart de Torcali",
    },
    [47235] = {
        name = "À la recherche de l’Œil",
    },
    [47241] = {
        name = "L’ombre de la mort",
    },
    [47244] = {
        name = "Moisson d’âmes",
    },
    [47245] = {
        name = "Reçu cinq sur cinq",
    },
    [47247] = {
        name = "Ce qui hante les morts",
    },
    [47248] = {
        name = "Jusqu’à ce que la mort nous sépare",
    },
    [47249] = {
        name = "Lien d’âme",
    },
    [47250] = {
        name = "À la revoyure",
    },
    [47257] = {
        name = "Les os de Xibala",
    },
    [47258] = {
        name = "Les préparatifs de siège",
    },
    [47259] = {
        name = "Navriculture",
    },
    [47260] = {
        name = "Effets secondaires inattendus",
    },
    [47261] = {
        name = "L’art d’élever un navrecorne",
    },
    [47262] = {
        name = "À bas les Trolls de sang",
    },
    [47263] = {
        name = "La révélation",
    },
    [47264] = {
        name = "Pas de quartier",
    },
    [47272] = {
        name = "Hormone de croissance de navrecorne",
    },
    [47289] = {
        name = "Doudous et dînette",
    },
    [47310] = {
        name = "Un petit somme",
    },
    [47311] = {
        name = "Bourrage de crâne",
    },
    [47312] = {
        name = "Plumeréale",
    },
    [47313] = {
        name = "Une conversation en toute discrétion",
    },
    [47314] = {
        name = "Rumeurs d’exil",
    },
    [47315] = {
        name = "Expédition dans les dunes",
    },
    [47316] = {
        name = "Des secrets dans le sable",
    },
    [47317] = {
        name = "À la recherche de survivants",
    },
    [47319] = {
        name = "Venin curatif",
    },
    [47320] = {
        name = "Du baume sur la plaie",
    },
    [47321] = {
        name = "Gris-gris mal acquis ne profite jamais",
    },
    [47322] = {
        name = "Fuite assistée",
    },
    [47324] = {
        name = "Des alliés improbables",
    },
    [47327] = {
        name = "Action, réaction",
    },
    [47329] = {
        name = "L’héritage des Guette-le-sang",
    },
    [47332] = {
        name = "Un choix stratégique",
    },
    [47418] = {
        name = "Poussée de croissance",
    },
    [47422] = {
        name = "Redoutable problème",
    },
    [47423] = {
        name = "Pratiques interdites",
    },
    [47428] = {
        name = "Minou ?",
    },
    [47432] = {
        name = "Les jeux sont faits",
    },
    [47433] = {
        name = "Offensive de défense",
    },
    [47434] = {
        name = "La chasse est ouverte",
    },
    [47435] = {
        name = "Conflit pterreurtorial",
    },
    [47437] = {
        name = "Crise de foi",
    },
    [47438] = {
        name = "Choisir son camp",
    },
    [47439] = {
        name = "Gonk, le seigneur de la meute",
    },
    [47440] = {
        name = "Pa’ku, divinité des vents",
    },
    [47441] = {
        name = "Vermines",
    },
    [47442] = {
        name = "La malédiction de Jani",
    },
    [47445] = {
        name = "Le conseil zanchuli",
    },
    [47485] = {
        name = "La compagnie marchande Corsandre",
    },
    [47486] = {
        name = "Cargaisons suspectes",
    },
    [47487] = {
        name = "Grève générale",
    },
    [47488] = {
        name = "Petites mains",
    },
    [47489] = {
        name = "Passagers clandestins",
    },
    [47491] = {
        name = "Les vestiges des damnés",
    },
    [47497] = {
        name = "Rencontre avec la bande de la Défense d’or",
    },
    [47498] = {
        name = "L’ami perdu de Rhan’ka",
    },
    [47499] = {
        name = "Les idoles ricanantes",
    },
    [47501] = {
        name = "Sale boulot, sale bibine",
    },
    [47502] = {
        name = "Une idée de génie",
    },
    [47503] = {
        name = "Gozda’kun l’Esclavagiste",
    },
    [47509] = {
        name = "Terrasse de l’Élu",
    },
    [47513] = {
        name = "Vol’dun",
    },
    [47520] = {
        name = "Les murs ont des oreilles",
    },
    [47521] = {
        name = "Minuit dans le jardin des Loas",
    },
    [47522] = {
        name = "Le Chasseur",
    },
    [47525] = {
        name = "Filature",
    },
    [47527] = {
        name = "Rituels hérétiques",
    },
    [47528] = {
        name = "La maîtresse désespère",
    },
    [47540] = {
        name = "Restauration totémique",
    },
    [47564] = {
        name = "Le ravitaillement du buffet",
    },
    [47570] = {
        name = "Desseins cachés",
    },
    [47571] = {
        name = "La sagesse de l’ancien",
    },
    [47573] = {
        name = "Infestation de tissejungles",
    },
    [47574] = {
        name = "Entoilés jusqu’au cou",
    },
    [47576] = {
        name = "Le courroux du tigre",
    },
    [47577] = {
        name = "La menace venue des mers",
    },
    [47578] = {
        name = "La marque du Loa",
    },
    [47580] = {
        name = "La malédiction de Mepjila",
    },
    [47581] = {
        name = "La bénédiction de Kimbul",
    },
    [47583] = {
        name = "Dix meurtres en don",
    },
    [47584] = {
        name = "Une épine dans le flanc",
    },
    [47585] = {
        name = "Prédateurs",
    },
    [47586] = {
        name = "Le chasseur chassé",
    },
    [47587] = {
        name = "Chasseur de têtes Jo",
    },
    [47596] = {
        name = "Un plan B, quel plan B ?",
    },
    [47597] = {
        name = "On n’abandonne aucun gobelin",
    },
    [47598] = {
        name = "Racket organisé",
    },
    [47599] = {
        name = "La vengeance est un plat qui se mange chaud",
    },
    [47601] = {
        name = "M.E.C.H., vise-moi ça !",
    },
    [47602] = {
        name = "Parés à intervenir",
    },
    [47621] = {
        name = "Un festin de Loa",
    },
    [47622] = {
        name = "Une lueur magique",
    },
    [47623] = {
        name = "Le dernier féticheur de Krag’wa",
    },
    [47631] = {
        name = "Rendez-vous avec la Libation",
    },
    [47638] = {
        name = "De puissants esprits",
    },
    [47647] = {
        name = "Les monstres de Zem’lan",
    },
    [47659] = {
        name = "La chasseuse chassée",
    },
    [47660] = {
        name = "Idoles déchues",
    },
    [47695] = {
        name = "Sirènes, alarme !",
    },
    [47696] = {
        name = "Krag’wa le Terrible",
    },
    [47697] = {
        name = "L’aide de Krag’wa",
    },
    [47706] = {
        name = "La chasse au roi K’tal",
    },
    [47711] = {
        name = "La tête de la bête",
    },
    [47716] = {
        name = "Fouille des ruines",
    },
    [47733] = {
        name = "La trahison de la parle-Loa",
    },
    [47734] = {
        name = "Partenaires hérétiques",
    },
    [47735] = {
        name = "Remèdes tortollans ancestraux",
    },
    [47736] = {
        name = "Des têtes vont tomber !",
    },
    [47737] = {
        name = "Le temple de Rezan",
    },
    [47738] = {
        name = "La volonté du Loa",
    },
    [47739] = {
        name = "L’odeur de la vengeance",
    },
    [47740] = {
        name = "La maison du roi",
    },
    [47741] = {
        name = "Sacrifice de Loa",
    },
    [47742] = {
        name = "La mutinerie de Zul",
    },
    [47755] = {
        name = "Comme un charme",
    },
    [47756] = {
        name = "Libération de la Libation",
    },
    [47797] = {
        name = "Les dangers de l’occupation",
    },
    [47868] = {
        name = "La Nécropole",
    },
    [47870] = {
        name = "Les morts ne mentent pas",
    },
    [47871] = {
        name = "Le nécessaire de navigation",
    },
    [47873] = {
        name = "La cache du capitaine",
    },
    [47874] = {
        name = "La brume se dissipe",
    },
    [47880] = {
        name = "Une offrande à la mort",
    },
    [47894] = {
        name = "Sauts en série",
    },
    [47897] = {
        name = "Traîtres zanchuli",
    },
    [47915] = {
        name = "Secourir les captifs",
    },
    [47918] = {
        name = "Au service de Krag’wa",
    },
    [47919] = {
        name = "Dites NON au cannibalisme",
    },
    [47924] = {
        name = "Profane à tort",
    },
    [47925] = {
        name = "Shoak en pâte",
    },
    [47928] = {
        name = "L’offrande au Loa",
    },
    [47939] = {
        name = "La clé des marchands",
    },
    [47943] = {
        name = "La capture de crabes",
    },
    [47945] = {
        name = "Un petit cochon…",
    },
    [47946] = {
        name = "Leur sauver la couenne",
    },
    [47947] = {
        name = "Les grands méchants loups",
    },
    [47948] = {
        name = "Cochon à la broche",
    },
    [47949] = {
        name = "C’est le fétiche d’un ami",
    },
    [47950] = {
        name = "Tête de cochon",
    },
    [47952] = {
        name = "La flotte disparue",
    },
    [47959] = {
        name = "Sur la piste du garde de guerre",
    },
    [47960] = {
        name = "La rade de Tiragarde",
    },
    [47962] = {
        name = "La vallée Chantorage",
    },
    [47963] = {
        name = "L’Ancienne",
    },
    [47965] = {
        name = "Le temple en ruine",
    },
    [47968] = {
        name = "Signes et présages",
    },
    [47969] = {
        name = "La malédiction de Havrebrune",
    },
    [47978] = {
        name = "La mégère de passage",
    },
    [47979] = {
        name = "Chasse à la sorcière",
    },
    [47980] = {
        name = "Familiers furieux",
    },
    [47981] = {
        name = "Briser la malédiction",
    },
    [47982] = {
        name = "L’effigie finale",
    },
    [47996] = {
        name = "Extermination des gueules démoniaques",
    },
    [47998] = {
        name = "Cannibalicide",
    },
    [48003] = {
        name = "Demande seigneuriale",
    },
    [48004] = {
        name = "Les bases de l’équitation",
    },
    [48005] = {
        name = "Invité d’honneur",
    },
    [48008] = {
        name = "Une dangereuse cargaison",
    },
    [48009] = {
        name = "La trahison de la garde",
    },
    [48014] = {
        name = "Dehors la vermine",
    },
    [48015] = {
        name = "Les parchemins de Gral",
    },
    [48025] = {
        name = "Patience et longueur de temps",
    },
    [48026] = {
        name = "Sous les vagues",
    },
    [48070] = {
        name = "Le festival de Norwington",
    },
    [48077] = {
        name = "La chasse à l’hermine",
    },
    [48080] = {
        name = "Un soupçon de danger",
    },
    [48087] = {
        name = "Récupération hippique",
    },
    [48088] = {
        name = "Troggs en vogue",
    },
    [48089] = {
        name = "L’appel de la montagne",
    },
    [48090] = {
        name = "Les élus de Krag’wa",
    },
    [48092] = {
        name = "La vengeance des grenouilles",
    },
    [48093] = {
        name = "Nagaliser les chances",
    },
    [48104] = {
        name = "Un grand défi",
    },
    [48108] = {
        name = "La fille des Malvoie",
    },
    [48109] = {
        name = "Les bois ont des yeux",
    },
    [48110] = {
        name = "En cas d’embuscade…",
    },
    [48111] = {
        name = "À l’épreuve des superstitions",
    },
    [48113] = {
        name = "Une solution qui pique les yeux",
    },
    [48165] = {
        name = "Vomitif",
    },
    [48170] = {
        name = "Piqûre de rappel",
    },
    [48171] = {
        name = "La malédiction de Val-Archer",
    },
    [48179] = {
        name = "À la rescousse des forestiers",
    },
    [48180] = {
        name = "Un problème imposant",
    },
    [48181] = {
        name = "Pas moyen",
    },
    [48182] = {
        name = "Cairnage total",
    },
    [48183] = {
        name = "La colline a des yeux",
    },
    [48184] = {
        name = "Bribes de l’histoire",
    },
    [48195] = {
        name = "Troglodytes trop gloutons",
    },
    [48196] = {
        name = "Sur la piste d’Eddie Norwington",
    },
    [48198] = {
        name = "La charge de la preuve",
    },
    [48237] = {
        name = "Vaincre Nekthara",
    },
    [48283] = {
        name = "Accusée, levez-vous !",
    },
    [48313] = {
        name = "Nature salvatrice",
    },
    [48314] = {
        name = "La mort insidieuse",
    },
    [48315] = {
        name = "Les yeux caves",
    },
    [48317] = {
        name = "La source de magie",
    },
    [48320] = {
        name = "La chasse au gros, c’est rigolo",
    },
    [48321] = {
        name = "Coup de pub",
    },
    [48322] = {
        name = "Un accueil en or",
    },
    [48324] = {
        name = "Perdus à Zem’lan",
    },
    [48326] = {
        name = "C’est une mutinerie !",
    },
    [48327] = {
        name = "Une étrange livraison",
    },
    [48329] = {
        name = "Seconde chance",
    },
    [48330] = {
        name = "Le trésor zandalari",
    },
    [48331] = {
        name = "Siphonnage d’âmes",
    },
    [48332] = {
        name = "De précieux ranishu",
    },
    [48334] = {
        name = "Ils ont des golems",
    },
    [48335] = {
        name = "La corde la plus solide de Vol’dun",
    },
    [48347] = {
        name = "Le quai du Trident",
    },
    [48348] = {
        name = "Piquer des piquants",
    },
    [48352] = {
        name = "Un remède marin",
    },
    [48353] = {
        name = "Les ragots du port",
    },
    [48354] = {
        name = "Cargaisons contaminées",
    },
    [48355] = {
        name = "Évacuation d’urgence",
    },
    [48356] = {
        name = "Maux de tête",
    },
    [48365] = {
        name = "Le jeune seigneur Chantorage",
    },
    [48366] = {
        name = "Sauvetage à la rame",
    },
    [48367] = {
        name = "Sûrement pas des gâteaux secs",
    },
    [48368] = {
        name = "Profanation des abysses",
    },
    [48369] = {
        name = "Une stratégie improvisée",
    },
    [48370] = {
        name = "Mort abyssale",
    },
    [48372] = {
        name = "Indicibles invocations",
    },
    [48399] = {
        name = "Sombre mer",
    },
    [48400] = {
        name = "Vol par télémancie",
    },
    [48402] = {
        name = "Sang toxique",
    },
    [48404] = {
        name = "Les canailles",
    },
    [48405] = {
        name = "Le Bon Corleone",
    },
    [48419] = {
        name = "Piège enchanteur",
    },
    [48421] = {
        name = "Marées sanglantes",
    },
    [48452] = {
        name = "Le marché rouge",
    },
    [48454] = {
        name = "La piste du mal",
    },
    [48456] = {
        name = "Féticheuse Jala",
    },
    [48468] = {
        name = "La délivrance de Bwonsamdi",
    },
    [48473] = {
        name = "Les préceptes des rites",
    },
    [48474] = {
        name = "Gardiens des cryptes",
    },
    [48475] = {
        name = "Esprits révélés",
    },
    [48476] = {
        name = "Séparation forcée",
    },
    [48477] = {
        name = "Une dernière pour la route",
    },
    [48478] = {
        name = "Le repaire de Kel’vax",
    },
    [48479] = {
        name = "Ossements protecteurs",
    },
    [48480] = {
        name = "La chute de Kel’vax",
    },
    [48492] = {
        name = "Jeu de jambes",
    },
    [48496] = {
        name = "La compagnie réunie",
    },
    [48497] = {
        name = "Démonstration de force",
    },
    [48498] = {
        name = "Pas de pitié pour Siphis",
    },
    [48499] = {
        name = "Retour à la poussière",
    },
    [48504] = {
        name = "Sur les routes d’antan",
    },
    [48505] = {
        name = "À cœur perdu",
    },
    [48515] = {
        name = "Lames argentées",
    },
    [48516] = {
        name = "D’art toxique",
    },
    [48517] = {
        name = "Un repos bien mérité",
    },
    [48518] = {
        name = "Sauve-qui-peut",
    },
    [48519] = {
        name = "Des villageois sont sur un bateau…",
    },
    [48520] = {
        name = "Les trois sœurs",
    },
    [48521] = {
        name = "Charme d’osier",
    },
    [48522] = {
        name = "Une missive des plus révélatrices",
    },
    [48523] = {
        name = "La matrone meurtrière",
    },
    [48524] = {
        name = "Massacre à la mine",
    },
    [48525] = {
        name = "À réduire en copeaux",
    },
    [48527] = {
        name = "Les dents de la terre",
    },
    [48529] = {
        name = "Agir contre la faim",
    },
    [48530] = {
        name = "Le berger sans troupeau",
    },
    [48531] = {
        name = "De la viande mystère",
    },
    [48532] = {
        name = "Alpagas en cavale",
    },
    [48533] = {
        name = "Du poulet frit à la vol’duni",
    },
    [48534] = {
        name = "Le dernier rire de Gronde-Gueule",
    },
    [48535] = {
        name = "Nazmir, le marais interdit",
    },
    [48538] = {
        name = "Un alibi en béton",
    },
    [48539] = {
        name = "Port-Liberté",
    },
    [48540] = {
        name = "Au secours du quai",
    },
    [48549] = {
        name = "Grozztok le Cœur-Noir",
    },
    [48550] = {
        name = "Les sacoches volées",
    },
    [48551] = {
        name = "Des plantes assoiffées",
    },
    [48553] = {
        name = "Que l’eau coule à flots",
    },
    [48554] = {
        name = "La source du problème",
    },
    [48555] = {
        name = "Recyclage des graines",
    },
    [48557] = {
        name = "Plants de secours",
    },
    [48558] = {
        name = "L’équipage des Lamineurs",
    },
    [48573] = {
        name = "Larmes de crocilisque",
    },
    [48574] = {
        name = "Comme un arracheur de dents",
    },
    [48576] = {
        name = "Baptême de l’air",
    },
    [48577] = {
        name = "Omelette-du-ciel",
    },
    [48578] = {
        name = "Terreur aveugle",
    },
    [48581] = {
        name = "La grosse fessée",
    },
    [48584] = {
        name = "Le sang de mes ennemis",
    },
    [48585] = {
        name = "La survie en milieu désertique",
    },
    [48588] = {
        name = "Désinfection",
    },
    [48590] = {
        name = "La tête sur les épaules ?",
    },
    [48591] = {
        name = "La véritable mort d’Urok",
    },
    [48597] = {
        name = "Saurolisques en cavale",
    },
    [48606] = {
        name = "Chargé et prêt à tirer !",
    },
    [48616] = {
        name = "Chasse aux bolas",
    },
    [48622] = {
        name = "Le seigneur disparu",
    },
    [48655] = {
        name = "L’apprenti du chef",
    },
    [48656] = {
        name = "Les saurolisques sauvages",
    },
    [48657] = {
        name = "On en mangerait !",
    },
    [48669] = {
        name = "Urok, la Terreur de la mangrove",
    },
    [48670] = {
        name = "Cavalier égaré",
    },
    [48677] = {
        name = "Croyances païennes",
    },
    [48678] = {
        name = "Offrandes discutables",
    },
    [48679] = {
        name = "Gare aux ruches",
    },
    [48680] = {
        name = "Pas les abeilles !",
    },
    [48682] = {
        name = "Un simple sacrifice",
    },
    [48683] = {
        name = "Nouvelle saison",
    },
    [48684] = {
        name = "En route vers le temple",
    },
    [48699] = {
        name = "Infiltration de Zalamar",
    },
    [48715] = {
        name = "Akunda attend",
    },
    [48773] = {
        name = "Papiers, s’il vous plaît !",
    },
    [48774] = {
        name = "Une rossée bien méritée !",
    },
    [48776] = {
        name = "De grog ou de force",
    },
    [48778] = {
        name = "Soupe de cailloux",
    },
    [48790] = {
        name = "Marchandises volées",
    },
    [48792] = {
        name = "Une menace pour la société",
    },
    [48793] = {
        name = "Le Club des aventuriers",
    },
    [48800] = {
        name = "La marque de la chauve-souris",
    },
    [48801] = {
        name = "Le bouclage de Zalamar",
    },
    [48804] = {
        name = "Tout le monde commet des erreurs",
    },
    [48805] = {
        name = "Récupération de trouvailles",
    },
    [48823] = {
        name = "Crémation",
    },
    [48825] = {
        name = "Refus de pouvoir",
    },
    [48840] = {
        name = "Une campagne publicitaire ruineuse",
    },
    [48846] = {
        name = "Paiement en liquide",
    },
    [48847] = {
        name = "Armer la tribu",
    },
    [48852] = {
        name = "Arrêter Zardrax",
    },
    [48853] = {
        name = "Brevet des cavernes",
    },
    [48854] = {
        name = "Pouvoir à pourvoir",
    },
    [48855] = {
        name = "Terroriser les terreurs",
    },
    [48856] = {
        name = "Panne de liche",
    },
    [48857] = {
        name = "Tout espoir est perdu",
    },
    [48869] = {
        name = "Sus à la liche",
    },
    [48871] = {
        name = "Sauvetage de reliques",
    },
    [48872] = {
        name = "Des pillards à expédier",
    },
    [48873] = {
        name = "Sus aux grizzlys",
    },
    [48874] = {
        name = "Rouille ouille ouille",
    },
    [48879] = {
        name = "Chasse aux œufs de faucons",
    },
    [48880] = {
        name = "Vos gueules, les mouettes",
    },
    [48881] = {
        name = "Pêche aux cannes",
    },
    [48882] = {
        name = "Les entrailles de la poiscaille",
    },
    [48883] = {
        name = "Vol au-dessus d’un nid de mouette",
    },
    [48887] = {
        name = "La purification de l’esprit",
    },
    [48888] = {
        name = "Jaillissement éternel",
    },
    [48889] = {
        name = "Réparer le passé",
    },
    [48890] = {
        name = "L’initiation des Trolls de sang",
    },
    [48894] = {
        name = "L’épreuve de vérité",
    },
    [48895] = {
        name = "L’offrande parfaite",
    },
    [48896] = {
        name = "Le savoir du passé",
    },
    [48898] = {
        name = "Queue porte-bonheur",
    },
    [48899] = {
        name = "La sécurité avant toutes choses",
    },
    [48902] = {
        name = "Énergie monstrueuse",
    },
    [48903] = {
        name = "Il en fait une montagne à cheval",
    },
    [48904] = {
        name = "Mordre à l’appât",
    },
    [48905] = {
        name = "Parchemins minorés",
    },
    [48909] = {
        name = "De nobles responsabilités",
    },
    [48934] = {
        name = "La marque des damnés",
    },
    [48939] = {
        name = "Concours hippique",
    },
    [48941] = {
        name = "Un petit détour",
    },
    [48942] = {
        name = "Des yétis à rebrousse-poil",
    },
    [48943] = {
        name = "Droit de récupération",
    },
    [48944] = {
        name = "En quête d’histoire",
    },
    [48945] = {
        name = "Les ruines de Gol Var",
    },
    [48946] = {
        name = "L’Ordre des Braises",
    },
    [48948] = {
        name = "Les cavernes de la passe Nord",
    },
    [48963] = {
        name = "Diversion tactique",
    },
    [48965] = {
        name = "Des comptes à régler",
    },
    [48986] = {
        name = "Vers le haut",
    },
    [48987] = {
        name = "La vallée des Chagrins",
    },
    [48988] = {
        name = "Trous de mémoire",
    },
    [48991] = {
        name = "Infestation vorace",
    },
    [48992] = {
        name = "Des ossements sacrés",
    },
    [48993] = {
        name = "Conducteurs magiques",
    },
    [48996] = {
        name = "Remède à la folie",
    },
    [49001] = {
        name = "Des esprits encombrants",
    },
    [49002] = {
        name = "Atterrissage forcé",
    },
    [49003] = {
        name = "La vengeance vient d’en haut",
    },
    [49005] = {
        name = "Mémoire traumatique",
    },
    [49028] = {
        name = "Un tricot pour Rupert",
    },
    [49036] = {
        name = "Épopée hippique",
    },
    [49039] = {
        name = "Le début d’une chasse monstrueuse",
    },
    [49040] = {
        name = "Des adieux émouvants",
    },
    [49059] = {
        name = "Les os de Xibala",
    },
    [49060] = {
        name = "L’écosystème xibalani",
    },
    [49064] = {
        name = "Torga, le Loa tortue",
    },
    [49066] = {
        name = "L’art de briser la glace",
    },
    [49067] = {
        name = "Solliciter Bwonsamdi",
    },
    [49069] = {
        name = "AVIS DE RECHERCHE : Griffe-de-givre l’Ancien",
    },
    [49070] = {
        name = "Des âmes pour le Loa des morts",
    },
    [49071] = {
        name = "Combustion de tique",
    },
    [49072] = {
        name = "Seigneur à l’ouest",
    },
    [49078] = {
        name = "Empoisonner la couvée",
    },
    [49079] = {
        name = "Hir’eek, le Loa chauve-souris",
    },
    [49080] = {
        name = "Trêve d’incantations",
    },
    [49081] = {
        name = "Mort au Loa",
    },
    [49082] = {
        name = "Toujours plus haut, toujours plus loin",
    },
    [49120] = {
        name = "Entretien avec les morts",
    },
    [49122] = {
        name = "Un port en péril",
    },
    [49125] = {
        name = "Rhésus négatif",
    },
    [49126] = {
        name = "Forcer la main du destin",
    },
    [49130] = {
        name = "Régime hypocaloarique",
    },
    [49131] = {
        name = "Opération Sanctification",
    },
    [49132] = {
        name = "Briser les brise-têtes",
    },
    [49136] = {
        name = "Jungo, héraut de G’huun",
    },
    [49138] = {
        name = "Le trésor du capitaine Gulnaku",
    },
    [49139] = {
        name = "L’arsenal d’une armée",
    },
    [49141] = {
        name = "Diplomatie et domination",
    },
    [49144] = {
        name = "Le courroux des Zandalari",
    },
    [49145] = {
        name = "On n’abandonne aucun troll",
    },
    [49146] = {
        name = "Les effets des esprits",
    },
    [49147] = {
        name = "Montrer ses muscles",
    },
    [49148] = {
        name = "Effritement",
    },
    [49149] = {
        name = "Combine vaudou",
    },
    [49160] = {
        name = "L’éternel retour de Torga",
    },
    [49178] = {
        name = "Souvenirs égarés",
    },
    [49181] = {
        name = "Le médaillon scintillant",
    },
    [49185] = {
        name = "Session de rattrapage",
    },
    [49218] = {
        name = "Les naufragés",
    },
    [49223] = {
        name = "Escroquerie au long cours",
    },
    [49225] = {
        name = "Recherche de chef",
    },
    [49226] = {
        name = "Silence de mort",
    },
    [49227] = {
        name = "Le passe-partout",
    },
    [49229] = {
        name = "La pierre contre-attaque",
    },
    [49230] = {
        name = "Spécialité locale",
    },
    [49232] = {
        name = "Reliquat de reliques",
    },
    [49233] = {
        name = "Je suis druide, pas prêtre",
    },
    [49234] = {
        name = "Il faut sauver l’officier Rougemarais",
    },
    [49239] = {
        name = "Victime de la mode",
    },
    [49242] = {
        name = "Rats-épics et colégram",
    },
    [49259] = {
        name = "Et justice pour tous",
    },
    [49260] = {
        name = "Ça emballe sévère",
    },
    [49261] = {
        name = "Ragoût de crabe",
    },
    [49262] = {
        name = "Antigang",
    },
    [49268] = {
        name = "Les dents de la mer",
    },
    [49274] = {
        name = "Le levé de Morgrum",
    },
    [49276] = {
        name = "Le frisson de l’exploration",
    },
    [49278] = {
        name = "Restauration spirituelle",
    },
    [49282] = {
        name = "Le levé complémentaire de Morgrum",
    },
    [49283] = {
        name = "Qui cherche les chercheurs ?",
    },
    [49284] = {
        name = "Dans le creux de la vague",
    },
    [49285] = {
        name = "Petits trésors",
    },
    [49286] = {
        name = "Sagesse incarcérée",
    },
    [49287] = {
        name = "Évasion chélonienne",
    },
    [49288] = {
        name = "Chasse aux parchemins",
    },
    [49289] = {
        name = "Une pierre particulière",
    },
    [49290] = {
        name = "Vieilli à la perfection",
    },
    [49292] = {
        name = "Algoentérite",
    },
    [49295] = {
        name = "Coupe franche",
    },
    [49299] = {
        name = "Ennemi intérieur",
    },
    [49300] = {
        name = "Corruption abyssale",
    },
    [49302] = {
        name = "Une funeste prise",
    },
    [49309] = {
        name = "La chute du tonnerre",
    },
    [49310] = {
        name = "Le complot du prophète",
    },
    [49314] = {
        name = "Sur les traces de Zardrax",
    },
    [49315] = {
        name = "Manœuvres de la Perle-maudite",
    },
    [49327] = {
        name = "Refoulement",
    },
    [49333] = {
        name = "Constitution d’arsenal",
    },
    [49334] = {
        name = "Un puissant prisonnier",
    },
    [49335] = {
        name = "Sus aux mandeciel",
    },
    [49340] = {
        name = "Les clés des Gardiens",
    },
    [49348] = {
        name = "Un temple profané",
    },
    [49366] = {
        name = "Secours aux victimes",
    },
    [49370] = {
        name = "Au secours du chroniqueur",
    },
    [49375] = {
        name = "[LARRY TEST QUEST]",
    },
    [49377] = {
        name = "Elle a perdu la tête",
    },
    [49378] = {
        name = "La confiance, ça se mérite",
    },
    [49379] = {
        name = "Interdit aux croggs",
    },
    [49380] = {
        name = "Mauvais juju",
    },
    [49382] = {
        name = "Vous vous êtes fait un ami ?",
    },
    [49393] = {
        name = "Les Baroudeurs",
    },
    [49394] = {
        name = "Pas bouger",
    },
    [49395] = {
        name = "L’abeille et la bête",
    },
    [49398] = {
        name = "À la bonne vôtre !",
    },
    [49399] = {
        name = "Un coup fumant",
    },
    [49400] = {
        name = "Ressources humaines",
    },
    [49401] = {
        name = "Le perchoir de Rodrigo",
    },
    [49402] = {
        name = "Vol au-dessus d’un nid de titis",
    },
    [49403] = {
        name = "La vengeance de Rodrigo",
    },
    [49404] = {
        name = "Les « amis » de Bellebrise",
    },
    [49405] = {
        name = "Les défenseurs de la porte de Daelin",
    },
    [49406] = {
        name = "Le massacre de Zalamar",
    },
    [49407] = {
        name = "Le dernier coup de Trixie",
    },
    [49408] = {
        name = "Dés de pirate",
    },
    [49409] = {
        name = "Chasse au trésor !",
    },
    [49411] = {
        name = "Construire une caserne",
    },
    [49412] = {
        name = "Déblayage",
    },
    [49417] = {
        name = "Capture de griffon",
    },
    [49418] = {
        name = "Et Tak",
    },
    [49419] = {
        name = "Gelé jusqu’aux lèvres",
    },
    [49421] = {
        name = "La traque de Zul",
    },
    [49422] = {
        name = "Hérétiques",
    },
    [49424] = {
        name = "Le fin mot de la prophétie",
    },
    [49425] = {
        name = "La cité d’or",
    },
    [49426] = {
        name = "Le stratagème du roi",
    },
    [49427] = {
        name = "Ces Elfes ne sont pas des nôtres",
    },
    [49428] = {
        name = "Vol par télémancie",
    },
    [49431] = {
        name = "Tout baigne",
    },
    [49432] = {
        name = "L’âme lugubre",
    },
    [49433] = {
        name = "Wendi à gogo",
    },
    [49435] = {
        name = "À la recherche des Baroudeurs",
    },
    [49437] = {
        name = "Note en lambeaux",
    },
    [49439] = {
        name = "La vengeance du chef",
    },
    [49440] = {
        name = "Dans la peau d’une Trollesse de sang",
    },
    [49443] = {
        name = "Leçon de chasse aux sorcières",
    },
    [49450] = {
        name = "Constats d’incidents",
    },
    [49451] = {
        name = "Tissu de mensonges",
    },
    [49452] = {
        name = "Déficit d’inventaire",
    },
    [49453] = {
        name = "Espèce menacée",
    },
    [49454] = {
        name = "Extermination des nuisibles",
    },
    [49464] = {
        name = "Queues de saurolisques",
    },
    [49465] = {
        name = "Optimisation des ressources",
    },
    [49467] = {
        name = "La sorcière du fond des bois",
    },
    [49468] = {
        name = "Suivre les toiles",
    },
    [49477] = {
        name = "Renforts surprise",
    },
    [49479] = {
        name = "Est-ce vraiment une bonne idée ?",
    },
    [49488] = {
        name = "Tal’gurub",
    },
    [49489] = {
        name = "Ça manque de corps",
    },
    [49490] = {
        name = "L’urne aux voix",
    },
    [49491] = {
        name = "Nourrir le vaudou",
    },
    [49492] = {
        name = "L’arrogance de Vol’jamba",
    },
    [49493] = {
        name = "Le dilemme éthique de Zul",
    },
    [49494] = {
        name = "Décoction zuvembi",
    },
    [49495] = {
        name = "Appuyer le destin",
    },
    [49522] = {
        name = "Le paiement de Carentan",
    },
    [49523] = {
        name = "Une sale affaire",
    },
    [49529] = {
        name = "Grand ménage de printemps",
    },
    [49531] = {
        name = "Le miracle de la publicité",
    },
    [49569] = {
        name = "Croisière en eaux troubles",
    },
    [49570] = {
        name = "Pierre de creusette",
    },
    [49571] = {
        name = "Creuser dans le passé",
    },
    [49572] = {
        name = "Le sanctuaire de la Mer",
    },
    [49573] = {
        name = "Le sanctuaire du Brunant",
    },
    [49574] = {
        name = "Le sanctuaire des Tempêtes",
    },
    [49575] = {
        name = "Tol Dagor : joyau des marées",
    },
    [49576] = {
        name = "Recherches élémentaires",
    },
    [49577] = {
        name = "Fêlures et fissures",
    },
    [49581] = {
        name = "Dunes mouchetées de soleil",
    },
    [49582] = {
        name = "Atal’Dazar : non, tout ce qui brille…",
    },
    [49583] = {
        name = "Place à la nouveauté",
    },
    [49584] = {
        name = "Le chapitre manquant",
    },
    [49585] = {
        name = "Pierre de creusette",
    },
    [49586] = {
        name = "Creuser dans le passé",
    },
    [49587] = {
        name = "Le sanctuaire de la Nature",
    },
    [49588] = {
        name = "Le sanctuaire des Sables",
    },
    [49589] = {
        name = "Le sanctuaire de l’Aube",
    },
    [49599] = {
        name = "Le chapitre manquant",
    },
    [49615] = {
        name = "La confiance d’un roi",
    },
    [49661] = {
        name = "Omelette marine",
    },
    [49662] = {
        name = "La clé manquante",
    },
    [49663] = {
        name = "Fausses prophéties",
    },
    [49664] = {
        name = "Des alliés dans l’anarchie",
    },
    [49665] = {
        name = "Parés à se rebeller",
    },
    [49666] = {
        name = "Qu’advienne le règne de la terreur",
    },
    [49667] = {
        name = "Les petits vulpérins",
    },
    [49668] = {
        name = "Incendier le goulet",
    },
    [49669] = {
        name = "Un déchaînement de bêtes",
    },
    [49676] = {
        name = "Équipée pour le combat",
    },
    [49677] = {
        name = "Les plans d’attaque",
    },
    [49678] = {
        name = "Flèches de tout bois",
    },
    [49679] = {
        name = "L’incursion des Sephraks",
    },
    [49680] = {
        name = "Mandeciel Soltok",
    },
    [49681] = {
        name = "P’tit Tika",
    },
    [49694] = {
        name = "Direction Drustvar",
    },
    [49703] = {
        name = "La maison Chantorage",
    },
    [49704] = {
        name = "Moissonneurs détraqués",
    },
    [49705] = {
        name = "Pression excessive",
    },
    [49706] = {
        name = "Exploration des proclamations",
    },
    [49710] = {
        name = "Une offrande d’œufs",
    },
    [49715] = {
        name = "Troubles au donjon Pierre-Grise",
    },
    [49716] = {
        name = "Une leçon de confiance",
    },
    [49719] = {
        name = "Toute peine mérite salaire",
    },
    [49720] = {
        name = "Y a qu’à faucon",
    },
    [49725] = {
        name = "Un stratagème risqué",
    },
    [49730] = {
        name = "AVIS DE RECHERCHE : Groin-de-Tonnerre",
    },
    [49731] = {
        name = "Des adieux émouvants",
    },
    [49733] = {
        name = "Bandages en série",
    },
    [49734] = {
        name = "Élimination d’un renégat",
    },
    [49735] = {
        name = "Protection des aires",
    },
    [49736] = {
        name = "Pour Kul Tiras !",
    },
    [49737] = {
        name = "Raid aérien",
    },
    [49738] = {
        name = "Pas touche au butin !",
    },
    [49739] = {
        name = "Des ennemis à nos portes",
    },
    [49740] = {
        name = "Cessez le feu !",
    },
    [49741] = {
        name = "Une juste vindicte",
    },
    [49744] = {
        name = "Déminage express",
    },
    [49745] = {
        name = "Leurs ordres sont clairs",
    },
    [49746] = {
        name = "Pompier volontaire",
    },
    [49753] = {
        name = "Construire une armurerie",
    },
    [49754] = {
        name = "Sus à Zul",
    },
    [49755] = {
        name = "L’alchimiste artilleur",
    },
    [49757] = {
        name = "Chatte perchée",
    },
    [49758] = {
        name = "Alerte au feu !",
    },
    [49759] = {
        name = "Construire un atelier",
    },
    [49766] = {
        name = "Un choix stratégique",
    },
    [49767] = {
        name = "Un choix stratégique",
    },
    [49768] = {
        name = "Le trek de Nesingwary",
    },
    [49769] = {
        name = "Les vestiges du Cataclysme",
    },
    [49774] = {
        name = "Le buisson de la guérison",
    },
    [49775] = {
        name = "La clé du bagne",
    },
    [49776] = {
        name = "Dans le goudron jusqu’au cou",
    },
    [49777] = {
        name = "En cavale",
    },
    [49778] = {
        name = "N’allez pas vers la lumière",
    },
    [49779] = {
        name = "Pourris jusqu’à l’os",
    },
    [49780] = {
        name = "En quête du feu antique",
    },
    [49781] = {
        name = "Attrape-moi si tu peux !",
    },
    [49785] = {
        name = "Pacification",
    },
    [49791] = {
        name = "La cloche des égarés",
    },
    [49792] = {
        name = "Liés et oppressés",
    },
    [49793] = {
        name = "Instruments indispensables",
    },
    [49794] = {
        name = "Marée montante",
    },
    [49801] = {
        name = "Stratégie de reproduction agressive",
    },
    [49803] = {
        name = "Relève de la garde",
    },
    [49804] = {
        name = "Je me pique de le savoir",
    },
    [49805] = {
        name = "Instruments maléfiques",
    },
    [49806] = {
        name = "Agissements souterrains",
    },
    [49807] = {
        name = "Un ordre nouveau",
    },
    [49810] = {
        name = "Entremise monstrueuse",
    },
    [49814] = {
        name = "Ambiance romantique",
    },
    [49818] = {
        name = "Ça barde à Fort Daelin",
    },
    [49831] = {
        name = "Menace des profondeurs",
    },
    [49832] = {
        name = "Un parchemin illisible",
    },
    [49869] = {
        name = "Une défense désespérée",
    },
    [49870] = {
        name = "Être de taille",
    },
    [49871] = {
        name = "Contre vents et marées",
    },
    [49873] = {
        name = "Écrits sacrificiels",
    },
    [49874] = {
        name = "À livre ouvert",
    },
    [49876] = {
        name = "Écrit dans le sable",
    },
    [49877] = {
        name = "Temple de Sephraliss : marché du livre",
    },
    [49878] = {
        name = "Signature de protection",
    },
    [49879] = {
        name = "Écrits mortels",
    },
    [49881] = {
        name = "Verset le sang",
    },
    [49882] = {
        name = "Une épreuve qui en vaut la penne",
    },
    [49884] = {
        name = "Une lueur d’espoir",
    },
    [49886] = {
        name = "Un flair infaillible",
    },
    [49887] = {
        name = "Esclavage aquatique",
    },
    [49890] = {
        name = "La chute des drust",
    },
    [49896] = {
        name = "Vers Butte-du-Faucon !",
    },
    [49897] = {
        name = "Manufacture de mystères",
    },
    [49898] = {
        name = "Victoire éclatante",
    },
    [49901] = {
        name = "Atal’Dazar : Yazma la prêtresse déchue",
    },
    [49902] = {
        name = "En route pour Glaucombe",
    },
    [49905] = {
        name = "Rebondissement inattendu",
    },
    [49908] = {
        name = "Retour à Brennadam",
    },
    [49917] = {
        name = "Kaja’mais sans ma kaja’mite !",
    },
    [49918] = {
        name = "La gorge aux Gorilles",
    },
    [49919] = {
        name = "Ruée vers la kaja’mite",
    },
    [49920] = {
        name = "La guerre des gorilles",
    },
    [49922] = {
        name = "Le roi Da’ka",
    },
    [49926] = {
        name = "La route de Corlain",
    },
    [49932] = {
        name = "Éveil spirituel",
    },
    [49935] = {
        name = "Mode d’emploi : réparation d’un gardien des Titans",
    },
    [49937] = {
        name = "Récupération des vestiges",
    },
    [49938] = {
        name = "Terre corrompue",
    },
    [49939] = {
        name = "Adieu, vile sorcière",
    },
    [49940] = {
        name = "La brèche des Sables béants",
    },
    [49941] = {
        name = "Traitement des os usés",
    },
    [49943] = {
        name = "Juste un peu de sang",
    },
    [49944] = {
        name = "Direction Drustvar",
    },
    [49946] = {
        name = "Écrit dans le sable",
    },
    [49949] = {
        name = "Des morts-vivants importuns",
    },
    [49950] = {
        name = "Purification sanglante",
    },
    [49955] = {
        name = "Plan d’évacuation",
    },
    [49956] = {
        name = "Nettoyage par le Vide",
    },
    [49957] = {
        name = "Récupération de protocole",
    },
    [49960] = {
        name = "Chope-les, Humphrey !",
    },
    [49965] = {
        name = "La meute guerrière",
    },
    [49969] = {
        name = "Le réveil d’un dieu",
    },
    [49975] = {
        name = "Repose en profondeur",
    },
    [49980] = {
        name = "Procédure de confinement",
    },
    [49985] = {
        name = "Retour à Glaucombe",
    },
    [49995] = {
        name = "Constructions suspectes",
    },
    [49996] = {
        name = "Réarmement",
    },
    [49997] = {
        name = "Jugement de l’orage",
    },
    [49998] = {
        name = "Des voix étouffées",
    },
    [50001] = {
        name = "Ma sorcière mal-aimée",
    },
    [50002] = {
        name = "Aussi précieuse que mignonne",
    },
    [50003] = {
        name = "Le premier tour de garde",
    },
    [50005] = {
        name = "Prise en main",
    },
    [50009] = {
        name = "Extermination et récupération",
    },
    [50026] = {
        name = "Au secours des naufragés",
    },
    [50036] = {
        name = "Une arme du temps jadis",
    },
    [50041] = {
        name = "Pour une poignée de balles",
    },
    [50043] = {
        name = "L’archéologie, c’est la vie !",
    },
    [50044] = {
        name = "L’archéologie, c’est la vie !",
    },
    [50058] = {
        name = "L’araignée préférée de la sorcière",
    },
    [50059] = {
        name = "Sourde oreille",
    },
    [50063] = {
        name = "Combattre le feu par le feu",
    },
    [50064] = {
        name = "La cave interdite",
    },
    [50065] = {
        name = "Une raison de rester",
    },
    [50069] = {
        name = "La guerre d’Orchamp",
    },
    [50070] = {
        name = "L’inspecteur Mildenhall",
    },
    [50074] = {
        name = "Coup de pouce biliaire",
    },
    [50076] = {
        name = "Rallier les guerriers",
    },
    [50078] = {
        name = "Totems impérissables",
    },
    [50079] = {
        name = "Alors, ça boume ?",
    },
    [50080] = {
        name = "Contre-raid",
    },
    [50081] = {
        name = "Les sentiers de la souffrance",
    },
    [50082] = {
        name = "Une cible fortuite",
    },
    [50083] = {
        name = "La mère des croggs",
    },
    [50085] = {
        name = "En lettres de sang et de feu",
    },
    [50087] = {
        name = "La chute d’Ateena",
    },
    [50088] = {
        name = "Le dernier repos de la famille Orchamp",
    },
    [50090] = {
        name = "Retaper les défenses",
    },
    [50091] = {
        name = "Réparations au village",
    },
    [50092] = {
        name = "Étonnamment rafraîchissant",
    },
    [50110] = {
        name = "Porteurs de mauvaises nouvelles",
    },
    [50111] = {
        name = "Totems, totems, totems !",
    },
    [50112] = {
        name = "Jeter la première pierre",
    },
    [50113] = {
        name = "Extraits oculaires",
    },
    [50114] = {
        name = "Battre le fer tant qu’il est chaud",
    },
    [50115] = {
        name = "Paysagisme alchimique",
    },
    [50116] = {
        name = "Une solution possible",
    },
    [50117] = {
        name = "Une décoction mortelle",
    },
    [50118] = {
        name = "À un jet de pierre",
    },
    [50119] = {
        name = "Purification chimique",
    },
    [50120] = {
        name = "La recette du succès",
    },
    [50121] = {
        name = "Jeter la première pierre",
    },
    [50122] = {
        name = "Extraits oculaires",
    },
    [50123] = {
        name = "Un plan qui restera dans les annales",
    },
    [50124] = {
        name = "Paysagisme alchimique",
    },
    [50125] = {
        name = "Une solution possible",
    },
    [50126] = {
        name = "Une décoction mortelle",
    },
    [50127] = {
        name = "À un jet de pierre",
    },
    [50128] = {
        name = "Purification chimique",
    },
    [50129] = {
        name = "La recette du succès",
    },
    [50133] = {
        name = "Cochon qui s’en dédit",
    },
    [50134] = {
        name = "Mécanismes et gadgets à gogo",
    },
    [50135] = {
        name = "Empêcheurs de tourner en ronce",
    },
    [50136] = {
        name = "Simulation agricole",
    },
    [50138] = {
        name = "La bataille du Sang igné",
    },
    [50139] = {
        name = "Le chaînon manquant",
    },
    [50149] = {
        name = "L’œil des nues",
    },
    [50150] = {
        name = "Mise en ambiance",
    },
    [50151] = {
        name = "Un forgeron en acier",
    },
    [50152] = {
        name = "À la recherche de ferraille",
    },
    [50154] = {
        name = "Mise en appétit",
    },
    [50157] = {
        name = "Des champs qui valent de l’or",
    },
    [50158] = {
        name = "Du côté de l’effondrement",
    },
    [50161] = {
        name = "À la recherche de Raimond",
    },
    [50162] = {
        name = "Les englués",
    },
    [50165] = {
        name = "Apiculture offensive",
    },
    [50168] = {
        name = "La succession royale",
    },
    [50172] = {
        name = "Allons au bois Cramoisi",
    },
    [50173] = {
        name = "Métaux précieux",
    },
    [50174] = {
        name = "Bien emballés",
    },
    [50175] = {
        name = "Malédiction à huit pattes",
    },
    [50177] = {
        name = "Défendez les barricades !",
    },
    [50178] = {
        name = "Du rififi dans la Nouée",
    },
    [50195] = {
        name = "Brigade de Milsabor",
    },
    [50206] = {
        name = "Riposte",
    },
    [50235] = {
        name = "Sans refuge",
    },
    [50238] = {
        name = "Roncépine",
    },
    [50240] = {
        name = "Lapsus",
    },
    [50249] = {
        name = "Triple menace sur Boralus",
    },
    [50251] = {
        name = "Fers magiques",
    },
    [50252] = {
        name = "Hors-saison des amours",
    },
    [50253] = {
        name = "Un arsenal improvisé",
    },
    [50264] = {
        name = "Des journaliers à libérer",
    },
    [50265] = {
        name = "Il faut sauver maître Ashton",
    },
    [50266] = {
        name = "Aigre-douce",
    },
    [50268] = {
        name = "Un soupçon de vaudou",
    },
    [50270] = {
        name = "Au fond du Tréfonds",
    },
    [50271] = {
        name = "Piliers et fracas",
    },
    [50272] = {
        name = "L’oreille au sol",
    },
    [50274] = {
        name = "Forge titanesque",
    },
    [50275] = {
        name = "Une enclume de poids",
    },
    [50276] = {
        name = "Un plan qui restera dans les annales",
    },
    [50277] = {
        name = "Battre le fer tant qu’il est chaud",
    },
    [50278] = {
        name = "Au fond du Tréfonds",
    },
    [50279] = {
        name = "Une enclume de poids",
    },
    [50288] = {
        name = "Le choix de Therazane",
    },
    [50297] = {
        name = "La tête à Queue",
    },
    [50306] = {
        name = "Un peu de tout",
    },
    [50325] = {
        name = "L’interruption du grand rite",
    },
    [50327] = {
        name = "Un petit remontant",
    },
    [50328] = {
        name = "Aromates insolites",
    },
    [50329] = {
        name = "Les matrones du bois Cramoisi",
    },
    [50331] = {
        name = "Un résultat inattendu",
    },
    [50332] = {
        name = "Le chasseur balèze",
    },
    [50340] = {
        name = "Restitution forcée",
    },
    [50343] = {
        name = "Chaos à l’hydromellerie Mildenhall",
    },
    [50349] = {
        name = "Une mine envahie",
    },
    [50350] = {
        name = "Il nous faut un chimiste",
    },
    [50351] = {
        name = "Détournement de mine",
    },
    [50352] = {
        name = "Un soupçon d’azérite",
    },
    [50353] = {
        name = "Tour de cochon",
    },
    [50354] = {
        name = "Gardes en vue",
    },
    [50356] = {
        name = "Une rencontre explosive",
    },
    [50359] = {
        name = "Attention, ça colle !",
    },
    [50363] = {
        name = "Porcs à tout faire",
    },
    [50365] = {
        name = "Agissements suspects",
    },
    [50367] = {
        name = "Colère en bouteille",
    },
    [50368] = {
        name = "La terreur du kraal",
    },
    [50370] = {
        name = "Au fin fond de la forêt",
    },
    [50376] = {
        name = "Cache mortelle : pêche au gros",
    },
    [50381] = {
        name = "Le chapeau ou la vie !",
    },
    [50385] = {
        name = "Détermination inébranlable",
    },
    [50386] = {
        name = "Chasse en eaux troubles",
    },
    [50387] = {
        name = "Babioles et colifichets",
    },
    [50388] = {
        name = "Le poids de mon ambition",
    },
    [50389] = {
        name = "Inspiration pernicieuse",
    },
    [50391] = {
        name = "Cache mortelle : pétard mouillé",
    },
    [50393] = {
        name = "Un petit de Pa’ku",
    },
    [50394] = {
        name = "C’est votre problème",
    },
    [50395] = {
        name = "L’appel du ciel",
    },
    [50396] = {
        name = "Un pterrible destin",
    },
    [50397] = {
        name = "Les aspirations aériennes",
    },
    [50401] = {
        name = "Peur de la chute",
    },
    [50402] = {
        name = "SKRIIIIIII !",
    },
    [50412] = {
        name = "Retour au nid",
    },
    [50417] = {
        name = "La ruine venue des profondeurs",
    },
    [50418] = {
        name = "Cache mortelle : du plomb dans l’aile",
    },
    [50433] = {
        name = "La dissolution des Zanchuli",
    },
    [50444] = {
        name = "Sur Loa route",
    },
    [50445] = {
        name = "Charmante situation",
    },
    [50446] = {
        name = "Sorcicide",
    },
    [50447] = {
        name = "Souvenez-vous des morts",
    },
    [50448] = {
        name = "La reconquête de Corlain",
    },
    [50449] = {
        name = "Refuge répugnant",
    },
    [50450] = {
        name = "Une récolte agressive",
    },
    [50451] = {
        name = "Des défenses périssables",
    },
    [50452] = {
        name = "Puante protection",
    },
    [50453] = {
        name = "Brise-barrière",
    },
    [50454] = {
        name = "La mort d’un traître",
    },
    [50455] = {
        name = "Quitter le nid",
    },
    [50456] = {
        name = "Oisillons ensorcelés",
    },
    [50457] = {
        name = "Brèche",
    },
    [50466] = {
        name = "Il est tombé sur la hure !",
    },
    [50481] = {
        name = "Dans l’antre du roi drust",
    },
    [50493] = {
        name = "Chien aux abois",
    },
    [50504] = {
        name = "Dans la mielasse",
    },
    [50520] = {
        name = "Où est Sam ?",
    },
    [50530] = {
        name = "Sorcières mal-aimées",
    },
    [50531] = {
        name = "Sous leur nez",
    },
    [50533] = {
        name = "Une volée de bois vert",
    },
    [50534] = {
        name = "Wendigo dingo",
    },
    [50535] = {
        name = "La puissance de la surveillante",
    },
    [50536] = {
        name = "Le décodeur magique",
    },
    [50538] = {
        name = "Le dresseur disparu",
    },
    [50539] = {
        name = "Les secrets de Zul’Ahjin",
    },
    [50542] = {
        name = "Une opportunité explosive",
    },
    [50544] = {
        name = "Les chasseurs du pavillon Kennings",
    },
    [50550] = {
        name = "La chute de l’empereur Korphek",
    },
    [50551] = {
        name = "Temple de Sephraliss : l’avatar du Loa",
    },
    [50553] = {
        name = "Retour au labo",
    },
    [50561] = {
        name = "La pierre de Sulphis",
    },
    [50573] = {
        name = "Un message de la direction",
    },
    [50583] = {
        name = "De l’autre côté",
    },
    [50584] = {
        name = "Rituels délétères",
    },
    [50585] = {
        name = "Sabbatueur",
    },
    [50586] = {
        name = "La chute de Corlain",
    },
    [50588] = {
        name = "À l’assaut du manoir",
    },
    [50593] = {
        name = "Sanglant carnage",
    },
    [50594] = {
        name = "Sous le voile",
    },
    [50595] = {
        name = "Pas de quartier",
    },
    [50596] = {
        name = "Extermination de vermine",
    },
    [50598] = {
        name = "L’empire zandalari",
    },
    [50599] = {
        name = "L’Amirauté des Portvaillant",
    },
    [50600] = {
        name = "L’Ordre des Braises",
    },
    [50601] = {
        name = "Le Sillage des tempêtes",
    },
    [50602] = {
        name = "L’Expédition de Talanji",
    },
    [50603] = {
        name = "Les Volduni",
    },
    [50605] = {
        name = "L’effort de guerre de l’Alliance",
    },
    [50606] = {
        name = "L’effort de guerre de la Horde",
    },
    [50608] = {
        name = "Rites interdits",
    },
    [50609] = {
        name = "Depuis l’antre de la folie",
    },
    [50610] = {
        name = "Quand gronde la tempête",
    },
    [50611] = {
        name = "La vengeance de la tempête",
    },
    [50612] = {
        name = "Une maison divisée",
    },
    [50614] = {
        name = "Liberté pour la mer",
    },
    [50616] = {
        name = "Ce qui nous lie",
    },
    [50617] = {
        name = "Atul’Aman",
    },
    [50621] = {
        name = "Pris dans le filet",
    },
    [50622] = {
        name = "Deal délétère",
    },
    [50635] = {
        name = "Marées changeantes",
    },
    [50639] = {
        name = "Manoir Malvoie : la matriarche déchue",
    },
    [50640] = {
        name = "Sans peur et sanglier",
    },
    [50641] = {
        name = "L’assaut du temple",
    },
    [50644] = {
        name = "Sus aux envahisseurs !",
    },
    [50645] = {
        name = "De grosses anguilles sous roche",
    },
    [50649] = {
        name = "Les voleurs volés",
    },
    [50653] = {
        name = "La reprise de nos défenses",
    },
    [50656] = {
        name = "Un sauvetage périlleux",
    },
    [50672] = {
        name = "Munitions de fortune",
    },
    [50674] = {
        name = "Tragédie en deux Tom",
    },
    [50675] = {
        name = "Fouilles lucratives",
    },
    [50679] = {
        name = "Percer le bouclier",
    },
    [50690] = {
        name = "Avec Moxie",
    },
    [50691] = {
        name = "Pas de ça ici !",
    },
    [50696] = {
        name = "Aimants désopilants",
    },
    [50697] = {
        name = "Pierre, papier… explosif !",
    },
    [50698] = {
        name = "Une solution explosive",
    },
    [50699] = {
        name = "Les risques du métier",
    },
    [50700] = {
        name = "Les explorateurs perdus",
    },
    [50702] = {
        name = "Vaincre Jakra’zet",
    },
    [50703] = {
        name = "Informer la Horde",
    },
    [50704] = {
        name = "Des ancres trop lourdes",
    },
    [50705] = {
        name = "Un serpent à trois têtes",
    },
    [50706] = {
        name = "Du ménage dans le delta",
    },
    [50733] = {
        name = "Une aube nouvelle",
    },
    [50739] = {
        name = "Disparitions en série",
    },
    [50741] = {
        name = "Ça carapace ou ça casse",
    },
    [50742] = {
        name = "Un trésor nous tend les bras",
    },
    [50743] = {
        name = "Le problème du moment",
    },
    [50745] = {
        name = "Infiltrer l’empire",
    },
    [50746] = {
        name = "Cratère conquis",
    },
    [50748] = {
        name = "À manipuler avec précaution",
    },
    [50749] = {
        name = "Un tour gratuit",
    },
    [50750] = {
        name = "Provoquer l’empereur",
    },
    [50751] = {
        name = "Sanctuaire assiégé",
    },
    [50752] = {
        name = "Les reliques de Sephraliss",
    },
    [50753] = {
        name = "Un robot qui ne se viande jamais",
    },
    [50754] = {
        name = "Un amour perdu à jamais",
    },
    [50755] = {
        name = "L’heure de la becquée",
    },
    [50757] = {
        name = "Carnage indomptable",
    },
    [50758] = {
        name = "Souvenirs douloureux",
    },
    [50759] = {
        name = "Un petit impondérable",
    },
    [50760] = {
        name = "Dans la joie et dans la douleur",
    },
    [50761] = {
        name = "La chapelle ensanglantée",
    },
    [50762] = {
        name = "Le destin de la dame",
    },
    [50763] = {
        name = "Une dernière faveur",
    },
    [50769] = {
        name = "L’extraction de Hurlevent",
    },
    [50770] = {
        name = "Un antivenin efficace",
    },
    [50771] = {
        name = "Profession : nettoyeur",
    },
    [50773] = {
        name = "Le requin, c’est vous !",
    },
    [50774] = {
        name = "On n’abandonne aucun robot",
    },
    [50775] = {
        name = "Plagiste d’un jour",
    },
    [50777] = {
        name = "La tempête se lève",
    },
    [50778] = {
        name = "De viles intentions",
    },
    [50779] = {
        name = "Tabula rasa",
    },
    [50780] = {
        name = "Un serment inviolable",
    },
    [50781] = {
        name = "Un pont trop loin",
    },
    [50783] = {
        name = "Le Conseil abyssal",
    },
    [50784] = {
        name = "Dans l’œil du cyclone",
    },
    [50787] = {
        name = "Des preuves irréfutables",
    },
    [50788] = {
        name = "Des ennemis parmi nous",
    },
    [50789] = {
        name = "Pas de fumée sans feu",
    },
    [50790] = {
        name = "Une poursuite acharnée",
    },
    [50791] = {
        name = "Skrii…",
    },
    [50793] = {
        name = "Un tumulte souterrain",
    },
    [50794] = {
        name = "À la recherche d’un refuge",
    },
    [50795] = {
        name = "Bisbille",
    },
    [50796] = {
        name = "SKRIIIIIII !",
    },
    [50797] = {
        name = "L’invitation d’une tortue",
    },
    [50798] = {
        name = "Prise de risque",
    },
    [50801] = {
        name = "L’art de voler au-devant des ennuis",
    },
    [50802] = {
        name = "Lamineurs laminés",
    },
    [50803] = {
        name = "Jusqu’à la dernière pièce",
    },
    [50805] = {
        name = "Court-jus",
    },
    [50808] = {
        name = "Au secours de l’Empire",
    },
    [50810] = {
        name = "Liberté pour les travailleurs !",
    },
    [50812] = {
        name = "Le réveil des éléments",
    },
    [50814] = {
        name = "Un endroit horrible",
    },
    [50817] = {
        name = "Le charmeur de serpents",
    },
    [50818] = {
        name = "Une flûte égarée",
    },
    [50824] = {
        name = "La fin de l’orage",
    },
    [50825] = {
        name = "Sanctuaire des Tempêtes : murmures souterrains",
    },
    [50834] = {
        name = "Pollution sonore",
    },
    [50835] = {
        name = "Le port de Zandalar",
    },
    [50838] = {
        name = "L’art de chercher les ennuis",
    },
    [50839] = {
        name = "SKRIIIIIII !",
    },
    [50841] = {
        name = "SKRIIIIIII !",
    },
    [50842] = {
        name = "Mât de cocagne",
    },
    [50860] = {
        name = "L’art de chercher les ennuis",
    },
    [50881] = {
        name = "Rapport royal",
    },
    [50886] = {
        name = "Des ailes de substitution",
    },
    [50887] = {
        name = "Vol de confiance",
    },
    [50897] = {
        name = "Renversement de vapeur",
    },
    [50900] = {
        name = "Quand tu seras plus grand, peut-être",
    },
    [50901] = {
        name = "La surprise sauride",
    },
    [50903] = {
        name = "Un seul maître vous manque",
    },
    [50904] = {
        name = "Le passage abandonné",
    },
    [50908] = {
        name = "Des ennuis en perspective",
    },
    [50909] = {
        name = "Un arsenal en béton armé",
    },
    [50910] = {
        name = "Un gibier dangereux",
    },
    [50911] = {
        name = "Seul contre la Horde",
    },
    [50912] = {
        name = "Remise en marche",
    },
    [50913] = {
        name = "La bénédiction d’Akunda",
    },
    [50929] = {
        name = "Prendre la poudre d’Azérite",
    },
    [50930] = {
        name = "Une belle chute",
    },
    [50933] = {
        name = "Un évènement malencontreux",
    },
    [50934] = {
        name = "Une découverte fortuite",
    },
    [50940] = {
        name = "La sagesse du sans-aile",
    },
    [50942] = {
        name = "Dérapage contrôlé",
    },
    [50943] = {
        name = "L’ivresse du vol",
    },
    [50944] = {
        name = "Les pieds sur terre",
    },
    [50953] = {
        name = "Traqueur vert",
    },
    [50954] = {
        name = "Zandalar pour toujours !",
    },
    [50955] = {
        name = "On n’est pas amis",
    },
    [50956] = {
        name = "Tirelire ambulante",
    },
    [50959] = {
        name = "Les pirates pillards",
    },
    [50960] = {
        name = "Les ordres de Sweete",
    },
    [50963] = {
        name = "Crimes et châtiments",
    },
    [50965] = {
        name = "L’héritage du passé",
    },
    [50967] = {
        name = "Perdue dans les bois",
    },
    [50970] = {
        name = "La destinée d’un fermier",
    },
    [50972] = {
        name = "Les pourparlers de Portvaillant",
    },
    [50976] = {
        name = "Une malédiction antique",
    },
    [50978] = {
        name = "Virer le chef",
    },
    [50979] = {
        name = "Juste une goutte",
    },
    [50980] = {
        name = "Un problème de voisinage",
    },
    [50988] = {
        name = "Une opportunité économique",
    },
    [50990] = {
        name = "Technique de pouletologie de pointe",
    },
    [51001] = {
        name = "La dure vie du contrebandier",
    },
    [51018] = {
        name = "C’est pour un ami",
    },
    [51019] = {
        name = "Elle en a dans le ventre",
    },
    [51020] = {
        name = "Un univers impitoyable",
    },
    [51052] = {
        name = "De l’azérite pour l’Alliance !",
    },
    [51053] = {
        name = "Le jour où le port est tombé",
    },
    [51054] = {
        name = "Mutinerie à retardement",
    },
    [51055] = {
        name = "La loi du galion",
    },
    [51056] = {
        name = "Mon dernier jour sur cette terre",
    },
    [51057] = {
        name = "Politique de la mer brûlée",
    },
    [51059] = {
        name = "L’île Dorée",
    },
    [51060] = {
        name = "Notre part du butin",
    },
    [51061] = {
        name = "La première fois que je suis mort",
    },
    [51062] = {
        name = "L’évasion de Zem’lan",
    },
    [51069] = {
        name = "AVIS DE RECHERCHE : sombre orateur Jo’la",
    },
    [51071] = {
        name = "AVIS DE RECHERCHE : Impératrice sabre-d’ivoire",
    },
    [51072] = {
        name = "AVIS DE RECHERCHE : cognepoing primal",
    },
    [51085] = {
        name = "AVIS DE RECHERCHE : chroniqueur sombre",
    },
    [51087] = {
        name = "AVIS DE RECHERCHE : chroniqueur sombre",
    },
    [51088] = {
        name = "Au cœur des ténèbres",
    },
    [51089] = {
        name = "AVIS DE RECHERCHE : Tojek",
    },
    [51091] = {
        name = "AVIS DE RECHERCHE : Ten’gor et Nol’ixwan",
    },
    [51101] = {
        name = "Le roi blessé",
    },
    [51111] = {
        name = "Roi ou proie",
    },
    [51129] = {
        name = "Une offrande douteuse",
    },
    [51134] = {
        name = "Si les os pouvaient parler",
    },
    [51139] = {
        name = "AVIS DE RECHERCHE : Tojek",
    },
    [51140] = {
        name = "Un partage équitable",
    },
    [51142] = {
        name = "Vermines",
    },
    [51144] = {
        name = "Un lot de fourrures",
    },
    [51145] = {
        name = "La malédiction de Jani",
    },
    [51146] = {
        name = "Les pérégrinations de Kua’fon",
    },
    [51147] = {
        name = "Les pérégrinations de Kua’fon",
    },
    [51149] = {
        name = "Laissés au port",
    },
    [51150] = {
        name = "Hommage aux défunts",
    },
    [51151] = {
        name = "Une lettre pour la Ligue",
    },
    [51159] = {
        name = "Artillerie défensive",
    },
    [51161] = {
        name = "AVIS DE RECHERCHE : Za’roco",
    },
    [51162] = {
        name = "AVIS DE RECHERCHE : Taz’raka le Traître",
    },
    [51164] = {
        name = "ON RECHERCHE : participants à l’excursion Cobra",
    },
    [51165] = {
        name = "AVIS DE RECHERCHE : éclaireur des sables Vesarik",
    },
    [51167] = {
        name = "Sang d’Hir’eek",
    },
    [51168] = {
        name = "Zélotes de Zalamar",
    },
    [51169] = {
        name = "Un vol direct depuis la Chute",
    },
    [51170] = {
        name = "Hourra !",
    },
    [51177] = {
        name = "Les leçons des damnés",
    },
    [51190] = {
        name = "Un répit salutaire",
    },
    [51191] = {
        name = "Sauvez-les tous !",
    },
    [51192] = {
        name = "Pénurie de matériel",
    },
    [51193] = {
        name = "Pas touche à mon marteau !",
    },
    [51199] = {
        name = "La gloire de la chasse",
    },
    [51200] = {
        name = "Le mouton noir",
    },
    [51201] = {
        name = "Aveux de Troll",
    },
    [51203] = {
        name = "Au loup !",
    },
    [51204] = {
        name = "AVIS DE RECHERCHE : alpha griffe-rasoir",
    },
    [51205] = {
        name = "Maudits rongeurs !",
    },
    [51207] = {
        name = "Mamie tromblon",
    },
    [51208] = {
        name = "L’ami du petit-déjeuner",
    },
    [51209] = {
        name = "Le puissant Grokkfrap",
    },
    [51211] = {
        name = "Le Cœur d’Azeroth",
    },
    [51214] = {
        name = "Soyez un ange",
    },
    [51215] = {
        name = "Chèvres à traire",
    },
    [51217] = {
        name = "AVIS DE RECHERCHE : Yarsel’ghun",
    },
    [51218] = {
        name = "Un colis non livré",
    },
    [51220] = {
        name = "Risk capital en haute mer",
    },
    [51221] = {
        name = "Attaque préventive",
    },
    [51222] = {
        name = "Mine de rien",
    },
    [51224] = {
        name = "Reconnaissance commerciale",
    },
    [51226] = {
        name = "Mort sur deux fronts",
    },
    [51229] = {
        name = "Une tête de pont vitale",
    },
    [51231] = {
        name = "Wiccaphobie",
    },
    [51233] = {
        name = "Pourvu qu’il n’y ait pas de sorcières dans les montagnes",
    },
    [51234] = {
        name = "L’avant-poste de Cramefol",
    },
    [51240] = {
        name = "AVIS DE RECHERCHE : L’Ancrassé",
    },
    [51244] = {
        name = "La pourriture des profondeurs",
    },
    [51246] = {
        name = "Les naufrageurs",
    },
    [51247] = {
        name = "Le butin des naufragés",
    },
    [51248] = {
        name = "Insectes productifs",
    },
    [51249] = {
        name = "Du crabe au menu",
    },
    [51251] = {
        name = "On se fait une toile ?",
    },
    [51278] = {
        name = "Perte et oubli",
    },
    [51279] = {
        name = "Sectateurs nazmani",
    },
    [51280] = {
        name = "Offrandes à G’huun",
    },
    [51281] = {
        name = "Zul’Nazman",
    },
    [51282] = {
        name = "Capitaine Conrad",
    },
    [51283] = {
        name = "Voyage vers l’ouest",
    },
    [51286] = {
        name = "Arrêt de l’évacuation",
    },
    [51302] = {
        name = "Les tréfonds Putrides : confiner la corruption de G’huun",
    },
    [51308] = {
        name = "Une tête de pont à Zuldazar",
    },
    [51309] = {
        name = "Les rochers de Ragnaros",
    },
    [51310] = {
        name = "Les aventuriers de la récolte perdue",
    },
    [51314] = {
        name = "Pas de céréales pour la Horde",
    },
    [51319] = {
        name = "L’ascension finale",
    },
    [51320] = {
        name = "Destin inexorable",
    },
    [51331] = {
        name = "Les machinations des taupes",
    },
    [51332] = {
        name = "Traversée océanique",
    },
    [51335] = {
        name = "De la crème et des gâteaux",
    },
    [51339] = {
        name = "Service de dégraissage",
    },
    [51340] = {
        name = "Cap sur Drustvar !",
    },
    [51341] = {
        name = "La fille du vent salé",
    },
    [51342] = {
        name = "La bataille de Stromgarde",
    },
    [51343] = {
        name = "Leçons de natation",
    },
    [51349] = {
        name = "Une dette d’honneur",
    },
    [51350] = {
        name = "Une aide imprévue",
    },
    [51351] = {
        name = "Barbillons empoisonnés",
    },
    [51352] = {
        name = "Il ne faut pas jouer avec le feu",
    },
    [51353] = {
        name = "Grotte d’Ai’twen",
    },
    [51354] = {
        name = "Colère en bouteille",
    },
    [51356] = {
        name = "AVIS DE RECHERCHE : sœur Lilias",
    },
    [51357] = {
        name = "Armée et parée au combat",
    },
    [51358] = {
        name = "Avis de recherche : kidnappeurs de griffons",
    },
    [51359] = {
        name = "Fragment des terres de Feu",
    },
    [51364] = {
        name = "Une sortie explosive",
    },
    [51366] = {
        name = "Administration d’antivenin",
    },
    [51367] = {
        name = "AVIS DE RECHERCHE : garde-terre déchaîné",
    },
    [51368] = {
        name = "Avis de recherche : le Frelon",
    },
    [51369] = {
        name = "Amis inattendus",
    },
    [51370] = {
        name = "Récompense de rareté",
    },
    [51371] = {
        name = "Savoureuse offrande",
    },
    [51384] = {
        name = "Avis de recherche : intendant Ssylis",
    },
    [51386] = {
        name = "Offensive victorieuse",
    },
    [51389] = {
        name = "Délivré des infidèles",
    },
    [51390] = {
        name = "AVIS DE RECHERCHE : les Égorgeurs écarlates",
    },
    [51391] = {
        name = "Mise au pas des Infidèles",
    },
    [51394] = {
        name = "Briser le siège",
    },
    [51395] = {
        name = "Les clés des Gardiens",
    },
    [51401] = {
        name = "Continuez comme ça",
    },
    [51402] = {
        name = "Le point sur la situation",
    },
    [51403] = {
        name = "L’exigence de l’orateur",
    },
    [51407] = {
        name = "Maux pour mots",
    },
    [51421] = {
        name = "Que le grand cric me croque !",
    },
    [51425] = {
        name = "Rien ne vaut son chez-soi",
    },
    [51426] = {
        name = "Gadget inspecteur",
    },
    [51427] = {
        name = "J’aime les tortues",
    },
    [51430] = {
        name = "Rétro-bricolage",
    },
    [51435] = {
        name = "La classe pirate",
    },
    [51436] = {
        name = "Pourparlers avec les pirates",
    },
    [51437] = {
        name = "Grog frelaté",
    },
    [51438] = {
        name = "Marquer notre territoire",
    },
    [51439] = {
        name = "Collection de boulets de canon",
    },
    [51440] = {
        name = "Changement de direction",
    },
    [51441] = {
        name = "Elle souffle !",
    },
    [51442] = {
        name = "Le capitaine, c’est moi maintenant",
    },
    [51443] = {
        name = "Ordres de mission",
    },
    [51445] = {
        name = "Ulterres, les confins Corrompus",
    },
    [51465] = {
        name = "Récup à gogo",
    },
    [51472] = {
        name = "Préserver la vie",
    },
    [51474] = {
        name = "Forgé dans le feu et les flammes",
    },
    [51479] = {
        name = "Les incorrompus",
    },
    [51483] = {
        name = "L’héritage des Sombrefer",
    },
    [51484] = {
        name = "L’héritage des Mag’har",
    },
    [51485] = {
        name = "Pour la Horde",
    },
    [51486] = {
        name = "Pour l’Alliance",
    },
    [51487] = {
        name = "En quête de réponses",
    },
    [51488] = {
        name = "Un savoir archivé",
    },
    [51489] = {
        name = "L’art de filer en trombe",
    },
    [51490] = {
        name = "Des problèmes de frontières",
    },
    [51492] = {
        name = "Nuisibles explosifs",
    },
    [51504] = {
        name = "Livraison de gâteaux",
    },
    [51513] = {
        name = "Le retour de Zalazane",
    },
    [51514] = {
        name = "Une promesse non tenue",
    },
    [51515] = {
        name = "Vengeance pour Vol’jin",
    },
    [51516] = {
        name = "Atal’Dazar : les cendres d’un chef de guerre",
    },
    [51517] = {
        name = "Une créance d’âme",
    },
    [51518] = {
        name = "L’esprit égaré",
    },
    [51519] = {
        name = "Appel de l’esprit",
    },
    [51520] = {
        name = "Justice pour les morts",
    },
    [51521] = {
        name = "Le véritable chef de Zandalar",
    },
    [51526] = {
        name = "L’appel du seigneur de guerre",
    },
    [51532] = {
        name = "Assaut féroce",
    },
    [51533] = {
        name = "Glaive de Vol’jin",
    },
    [51534] = {
        name = "La bataille de Brennadam",
    },
    [51536] = {
        name = "En chasse",
    },
    [51538] = {
        name = "Des nouvelles des profondeurs",
    },
    [51539] = {
        name = "Prévenir la Horde",
    },
    [51540] = {
        name = "Une situation explosive",
    },
    [51543] = {
        name = "Des arbrisseaux enneigés",
    },
    [51544] = {
        name = "La neutralisation des canons",
    },
    [51545] = {
        name = "Brisé net",
    },
    [51547] = {
        name = "AVIS DE RECHERCHE : Ruissemal",
    },
    [51552] = {
        name = "On est fait comme des rats !",
    },
    [51554] = {
        name = "Ravitaillement en munitions",
    },
    [51555] = {
        name = "Garde-chiourme d’un jour",
    },
    [51557] = {
        name = "Gare aux Lamineurs !",
    },
    [51569] = {
        name = "La campagne zandalari",
    },
    [51573] = {
        name = "Une présence tranquillisante",
    },
    [51574] = {
        name = "Fraîchement pressé",
    },
    [51582] = {
        name = "Un Mildenhall sinon rien !",
    },
    [51587] = {
        name = "Droit devant",
    },
    [51589] = {
        name = "La mise au pas des Kultirassiens",
    },
    [51590] = {
        name = "Au cœur de Tiragarde",
    },
    [51591] = {
        name = "C’est notre montagne maintenant",
    },
    [51592] = {
        name = "Comme à la maison",
    },
    [51593] = {
        name = "Enquête sur Port-du-Pont",
    },
    [51594] = {
        name = "Des explosifs dans la fonderie",
    },
    [51595] = {
        name = "Explosivité",
    },
    [51596] = {
        name = "Obtention de munitions",
    },
    [51597] = {
        name = "Recherches explosives",
    },
    [51598] = {
        name = "Un soupçon de chaos",
    },
    [51599] = {
        name = "Piège mortel",
    },
    [51601] = {
        name = "La chevauchée de Port-du-Pont",
    },
    [51602] = {
        name = "Lames renégates",
    },
    [51643] = {
        name = "Un mur de fer",
    },
    [51663] = {
        name = "Prélude à la chute",
    },
    [51674] = {
        name = "Soldat du feu",
    },
    [51675] = {
        name = "Traquez-les jusqu’au dernier",
    },
    [51677] = {
        name = "Guérison du corps et de l’âme",
    },
    [51678] = {
        name = "La Puissance de Rastakhan",
    },
    [51679] = {
        name = "Un étrange port d’escale",
    },
    [51680] = {
        name = "Dans l’ombre de Bwonsamdi",
    },
    [51689] = {
        name = "Tortollans en détresse",
    },
    [51691] = {
        name = "Presque dignes d’être sauvés",
    },
    [51696] = {
        name = "La reconquête de Croc-de-guerre",
    },
    [51711] = {
        name = "Alors, ça boum ?",
    },
    [51712] = {
        name = "La loi du talion",
    },
    [51714] = {
        name = "Mission royale",
    },
    [51715] = {
        name = "La guerre des ombres",
    },
    [51717] = {
        name = "Le meilleur miel de Vol’dun",
    },
    [51718] = {
        name = "Récolte de « miel »",
    },
    [51720] = {
        name = "Déchiquetage dans les règles",
    },
    [51723] = {
        name = "Copeaux et sciure de bois",
    },
    [51726] = {
        name = "Sortez de là !",
    },
    [51728] = {
        name = "Brûlez-moi ça",
    },
    [51752] = {
        name = "Derniers adieux à l’ingénieur",
    },
    [51753] = {
        name = "Champion : Rexxar",
    },
    [51770] = {
        name = "Mission du chef de guerre",
    },
    [51771] = {
        name = "La guerre des ombres",
    },
    [51772] = {
        name = "La tribu Tortaka",
    },
    [51773] = {
        name = "La menace corsandre",
    },
    [51775] = {
        name = "Le camp du Vencestral",
    },
    [51784] = {
        name = "Une balade dans un cimetière",
    },
    [51785] = {
        name = "L’examen des épitaphes",
    },
    [51786] = {
        name = "Introuvable repos",
    },
    [51787] = {
        name = "Notre lot dans la vie",
    },
    [51788] = {
        name = "Le gardien de la crypte",
    },
    [51789] = {
        name = "Ce qu’il reste du maréchal M. Valentine",
    },
    [51795] = {
        name = "La bataille de Lordaeron",
    },
    [51796] = {
        name = "La bataille de Lordaeron",
    },
    [51797] = {
        name = "À la recherche d’un eaugure",
    },
    [51798] = {
        name = "À n’importe quel prix",
    },
    [51803] = {
        name = "La campagne de Kul Tiras",
    },
    [51805] = {
        name = "Ils connaîtront la peur",
    },
    [51810] = {
        name = "Le capitaine Hartford",
    },
    [51813] = {
        name = "Les profondeurs de Rochenoire",
    },
    [51818] = {
        name = "Commandant et capitaine",
    },
    [51819] = {
        name = "Dispersion de nos ennemis",
    },
    [51829] = {
        name = "La clé de Ranah",
    },
    [51830] = {
        name = "Le potentiel de Zelling",
    },
    [51837] = {
        name = "Une récompense tant espérée",
    },
    [51870] = {
        name = "Exploration des îles",
    },
    [51881] = {
        name = "Le démineur",
    },
    [51888] = {
        name = "Exploration des îles",
    },
    [51903] = {
        name = "Exploration des îles",
    },
    [51904] = {
        name = "Exploration des îles",
    },
    [51916] = {
        name = "L’union de Zandalar",
    },
    [51918] = {
        name = "L’union de Kul Tiras",
    },
    [51961] = {
        name = "Campagne en cours",
    },
    [51967] = {
        name = "Retour à Boralus",
    },
    [51968] = {
        name = "Retour à Boralus",
    },
    [51969] = {
        name = "Retour à Boralus",
    },
    [51975] = {
        name = "Champion : chasseur des ombres Ty’jin",
    },
    [51979] = {
        name = "Campagne en cours",
    },
    [51980] = {
        name = "AVIS DE RECHERCHE : Jabra’kan",
    },
    [51984] = {
        name = "Retour à Zuldazar",
    },
    [51985] = {
        name = "Retour à Zuldazar",
    },
    [51986] = {
        name = "Retour à Zuldazar",
    },
    [51987] = {
        name = "Champion : Hobart Martelutte",
    },
    [51990] = {
        name = "Des ailes pour le kraal",
    },
    [51991] = {
        name = "Charge des batteries",
    },
    [51998] = {
        name = "HCN : nouvelle formule à base de navrecorne",
    },
    [52003] = {
        name = "Championne : Kelsey Étinçacier",
    },
    [52008] = {
        name = "Champion : magistère Umbric",
    },
    [52013] = {
        name = "Champion : John J. Keeshan",
    },
    [52026] = {
        name = "Assassinat outremer",
    },
    [52027] = {
        name = "Le plan de Vol’dun",
    },
    [52028] = {
        name = "Ratissage du désert",
    },
    [52029] = {
        name = "Sale boulot",
    },
    [52030] = {
        name = "Poursuite du ratissage",
    },
    [52031] = {
        name = "La vilenie du Reliquaire",
    },
    [52032] = {
        name = "Ratissage sans fin",
    },
    [52033] = {
        name = "AVIS DE RECHERCHE : Gueule-de-givre",
    },
    [52034] = {
        name = "Dissuasion des exilés",
    },
    [52035] = {
        name = "Survie improvisée",
    },
    [52036] = {
        name = "De l’alpaga à gogo",
    },
    [52038] = {
        name = "Trouver la Horde",
    },
    [52039] = {
        name = "Rendez-vous avec la mort",
    },
    [52040] = {
        name = "Criblé de flèches",
    },
    [52041] = {
        name = "Rapport à Verroctone",
    },
    [52042] = {
        name = "Le gros boum",
    },
    [52061] = {
        name = "Taptaf le cochon !",
    },
    [52065] = {
        name = "Pire que ça en a l’air",
    },
    [52067] = {
        name = "Les survivants",
    },
    [52068] = {
        name = "Ne restez pas dans nos pattes",
    },
    [52069] = {
        name = "La chair à canon de Léo",
    },
    [52070] = {
        name = "À la rescousse de Bauer",
    },
    [52073] = {
        name = "L’appel à Krag’wa",
    },
    [52074] = {
        name = "Délivrance",
    },
    [52075] = {
        name = "Dans l’os",
    },
    [52113] = {
        name = "Vol’jin, fils de Sen’jin",
    },
    [52114] = {
        name = "Hommage à un grand chef",
    },
    [52122] = {
        name = "La vie d’un Réprouvé",
    },
    [52127] = {
        name = "La tanière du Loup",
    },
    [52128] = {
        name = "La carte du bac",
    },
    [52129] = {
        name = "Problèmes d’alimentation",
    },
    [52130] = {
        name = "Cache mortelle : carpe diem",
    },
    [52131] = {
        name = "Un prêté pour un rendu",
    },
    [52132] = {
        name = "Les pirates piratés",
    },
    [52139] = {
        name = "Une question de priorité",
    },
    [52146] = {
        name = "Du sang sur le sable",
    },
    [52147] = {
        name = "Estropier la Horde",
    },
    [52149] = {
        name = "Semperardent",
    },
    [52150] = {
        name = "Comment tuer un forestier-sombre",
    },
    [52151] = {
        name = "Une nation unie",
    },
    [52153] = {
        name = "Siège de Boralus : Le retour de dame Corsandre",
    },
    [52154] = {
        name = "Notre prochaine cible",
    },
    [52156] = {
        name = "Tortollans en détresse",
    },
    [52158] = {
        name = "La chasse sauvage",
    },
    [52170] = {
        name = "La mort d’Areiel",
    },
    [52171] = {
        name = "Feu de tout bois",
    },
    [52172] = {
        name = "Pas question de les laisser s’installer",
    },
    [52173] = {
        name = "Les Elfes du Vide sont prêts",
    },
    [52183] = {
        name = "Un plan qui se déroule sans accroc",
    },
    [52184] = {
        name = "Reliques rituelles",
    },
    [52185] = {
        name = "Un portail bien placé",
    },
    [52186] = {
        name = "Le gros de la garde",
    },
    [52187] = {
        name = "Anciens collègues",
    },
    [52188] = {
        name = "Les enseignements de l’eaugure",
    },
    [52189] = {
        name = "Âmes déchues",
    },
    [52190] = {
        name = "Un avantage indéniable",
    },
    [52191] = {
        name = "Une vie en otage",
    },
    [52192] = {
        name = "L’aide des marées",
    },
    [52194] = {
        name = "Une regrettable décision",
    },
    [52203] = {
        name = "Le donneur d’ordres",
    },
    [52204] = {
        name = "La solution du Vide",
    },
    [52205] = {
        name = "Fin du filon Baille-Fonds",
    },
    [52208] = {
        name = "Rencontre ruineuse",
    },
    [52210] = {
        name = "Une bouteille à la mer",
    },
    [52212] = {
        name = "La bataille de Stromgarde",
    },
    [52219] = {
        name = "Mort au prince de sang",
    },
    [52241] = {
        name = "Le paradis des Gobelins cupides",
    },
    [52246] = {
        name = "Colis perdu",
    },
    [52247] = {
        name = "Aux trousses de Gallywix",
    },
    [52252] = {
        name = "Une entrée explosive",
    },
    [52253] = {
        name = "Les clés du succès à Port-Liberté",
    },
    [52258] = {
        name = "La petite fille aux coquillettes",
    },
    [52259] = {
        name = "La fête est finie",
    },
    [52260] = {
        name = "Gallywix acculé",
    },
    [52261] = {
        name = "La fuite de Gallywix",
    },
    [52281] = {
        name = "L’équipée de Vol-au-Vent",
    },
    [52282] = {
        name = "L’art de couler un cuirassé zandalari",
    },
    [52283] = {
        name = "Le sabotage du Pa’ku",
    },
    [52284] = {
        name = "Journaux de bord",
    },
    [52285] = {
        name = "Le sous-marin miniaturisé agrandi",
    },
    [52286] = {
        name = "Juste sous leur nez",
    },
    [52287] = {
        name = "Opération de contre-espionnage",
    },
    [52288] = {
        name = "Retraite anticipée",
    },
    [52289] = {
        name = "La victoire est assurée",
    },
    [52290] = {
        name = "L’ennemi de mon ennemi est un bon déguisement",
    },
    [52291] = {
        name = "La victoire était assurée",
    },
    [52294] = {
        name = "Idoles déchues",
    },
    [52305] = {
        name = "Nature et dinoculture",
    },
    [52308] = {
        name = "Ordres interceptés",
    },
    [52311] = {
        name = "Le coffre-fort de Sweete",
    },
    [52317] = {
        name = "Attention les doigts",
    },
    [52428] = {
        name = "Remplir le Cœur",
    },
    [52431] = {
        name = "Interdiction d’accoster",
    },
    [52443] = {
        name = "La dernière tête de pont",
    },
    [52444] = {
        name = "La dernière tête de pont",
    },
    [52445] = {
        name = "Tol Dagor : la quatrième clé",
    },
    [52447] = {
        name = "Le temps de grandir",
    },
    [52449] = {
        name = "L’île mystérieuse",
    },
    [52450] = {
        name = "L’union de Kul Tiras",
    },
    [52453] = {
        name = "Un espoir ténu",
    },
    [52472] = {
        name = "Allez, Loh !",
    },
    [52473] = {
        name = "La fin de la flotte",
    },
    [52477] = {
        name = "AVIS DE RECHERCHE : Ayame",
    },
    [52480] = {
        name = "AVIS DE RECHERCHE : Ayame",
    },
    [52481] = {
        name = "Mythes et légendes",
    },
    [52482] = {
        name = "Le vieil ours",
    },
    [52483] = {
        name = "Attrape-cauchemar",
    },
    [52484] = {
        name = "Puissance enfouie",
    },
    [52485] = {
        name = "Concentration haineuse",
    },
    [52486] = {
        name = "Manoir Malvoie : le pouvoir du Sabbat malecarde",
    },
    [52487] = {
        name = "Dans les ténèbres",
    },
    [52488] = {
        name = "Résistance runique",
    },
    [52489] = {
        name = "Sus au prince de sang Dreven",
    },
    [52490] = {
        name = "Derrière les navires ennemis",
    },
    [52491] = {
        name = "Bordée dévastatrice",
    },
    [52492] = {
        name = "La spécialité des Marteaux-Hardis",
    },
    [52493] = {
        name = "Un équipage contre nature",
    },
    [52494] = {
        name = "Des cristaux impies pour des créatures impies",
    },
    [52495] = {
        name = "Neutraliser les San’layn",
    },
    [52496] = {
        name = "Net et sans bavure",
    },
    [52508] = {
        name = "Effets rituels",
    },
    [52509] = {
        name = "La force de la tempête",
    },
    [52510] = {
        name = "Sanctuaire des Tempêtes : le rituel manquant",
    },
    [52511] = {
        name = "Ouverture d’un passage",
    },
    [52512] = {
        name = "Funesterre",
    },
    [52513] = {
        name = "Perdue dans les ténèbres",
    },
    [52544] = {
        name = "La cache de guerre",
    },
    [52654] = {
        name = "La campagne militaire",
    },
    [52746] = {
        name = "La cache de guerre",
    },
    [52748] = {
        name = "Les yeux rivés sur le ciel",
    },
    [52749] = {
        name = "La campagne militaire",
    },
    [52750] = {
        name = "Fermiers armés",
    },
    [52762] = {
        name = "Un guide local",
    },
    [52764] = {
        name = "Voyage vers le grand nulle part",
    },
    [52765] = {
        name = "Plongée profonde",
    },
    [52766] = {
        name = "Épave des grands fonds",
    },
    [52767] = {
        name = "Inspection des plaques",
    },
    [52768] = {
        name = "Le cimetière englouti",
    },
    [52769] = {
        name = "Capitaine ! Mon capitaine !",
    },
    [52770] = {
        name = "Biolumi-nuisance",
    },
    [52772] = {
        name = "Récif sous-marin",
    },
    [52773] = {
        name = "Dragon aquatique",
    },
    [52774] = {
        name = "Pas la peine de s’éterniser",
    },
    [52782] = {
        name = "Appel aux armes : vallée Chantorage",
    },
    [52787] = {
        name = "Soins palliatifs",
    },
    [52788] = {
        name = "Carnage zandalari",
    },
    [52789] = {
        name = "La mort de la conseillère",
    },
    [52790] = {
        name = "Une fin au massacre",
    },
    [52793] = {
        name = "Le tour des chariots",
    },
    [52795] = {
        name = "Faire un sort au saurolisque",
    },
    [52796] = {
        name = "Point trop n’en faut",
    },
    [52800] = {
        name = "Tol Dagor : le surveillant corsandre",
    },
    [52855] = {
        name = "L’alchimie n’est pas une science exacte",
    },
    [52857] = {
        name = "Placé en observation",
    },
    [52861] = {
        name = "Championne : Lilian Voss",
    },
    [52876] = {
        name = "ON RECHERCHE : l’Étripeur de guerre",
    },
    [52942] = {
        name = "Renouer d’anciens liens",
    },
    [52943] = {
        name = "L’appel des clans",
    },
    [52944] = {
        name = "Appel aux armes : Drustvar",
    },
    [52945] = {
        name = "Des liens forgés dans le sang",
    },
    [52946] = {
        name = "Un monde à l’agonie",
    },
    [52948] = {
        name = "Appel aux armes : la rade de Tiragarde",
    },
    [52949] = {
        name = "Appel aux armes : Nazmir",
    },
    [52950] = {
        name = "Appel aux armes : Vol’dun",
    },
    [52953] = {
        name = "Appel aux armes : Vol’dun",
    },
    [52954] = {
        name = "Appel aux armes : Nazmir",
    },
    [52955] = {
        name = "La tyrannie de la Lumière",
    },
    [52956] = {
        name = "Appel aux armes : la rade de Tiragarde",
    },
    [52958] = {
        name = "Appel aux armes : Drustvar",
    },
    [52965] = {
        name = "Un cadeau pour la fête du Voile d’hiver",
    },
    [52978] = {
        name = "Un prince à bord",
    },
    [52990] = {
        name = "Retour au port",
    },
    [53003] = {
        name = "Le cycle de la haine",
    },
    [53011] = {
        name = "Un cadeau secoué doucement",
    },
    [53028] = {
        name = "Un monde à l’agonie",
    },
    [53031] = {
        name = "L’exigence de l’orateur",
    },
    [53041] = {
        name = "Un prélèvement furtif",
    },
    [53045] = {
        name = "Un coup d’œil au quai",
    },
    [53050] = {
        name = "Percée en Kul Tiras",
    },
    [53052] = {
        name = "Percée en Zandalar",
    },
    [53055] = {
        name = "Asseoir notre influence",
    },
    [53056] = {
        name = "Asseoir notre influence",
    },
    [53061] = {
        name = "Azérite tactique",
    },
    [53062] = {
        name = "Azérite tactique",
    },
    [53063] = {
        name = "Une mission fédératrice",
    },
    [53065] = {
        name = "Opération Fossoyeur",
    },
    [53066] = {
        name = "Opération Eaux troubles",
    },
    [53067] = {
        name = "Opération Grands fonds",
    },
    [53068] = {
        name = "Opération Pêche au gros",
    },
    [53069] = {
        name = "Opération Flèche de sang",
    },
    [53070] = {
        name = "Opération Vide-gousset",
    },
    [53071] = {
        name = "Opération Griffe de griffon",
    },
    [53072] = {
        name = "Opération Frappe-cœur",
    },
    [53074] = {
        name = "Renforts",
    },
    [53079] = {
        name = "Renforts",
    },
    [53096] = {
        name = "Récompense de rareté",
    },
    [53097] = {
        name = "Les ablutions du désespoir",
    },
    [53098] = {
        name = "Championne : Shandris Pennelune",
    },
    [53099] = {
        name = "Une particule de vérité cosmique",
    },
    [53105] = {
        name = "Une foi mal placée",
    },
    [53109] = {
        name = "La maison Malvoie",
    },
    [53110] = {
        name = "Le haut parlépine",
    },
    [53121] = {
        name = "Le siège de Boralus",
    },
    [53128] = {
        name = "La complainte de l’amiral suprême",
    },
    [53131] = {
        name = "Le Repos des rois",
    },
    [53185] = {
        name = "Contribution au front de guerre",
    },
    [53194] = {
        name = "Sur les lignes de front",
    },
    [53197] = {
        name = "Exploration du front",
    },
    [53198] = {
        name = "Retour à Boralus",
    },
    [53208] = {
        name = "Sur les lignes de front",
    },
    [53209] = {
        name = "Contribution au front de guerre",
    },
    [53210] = {
        name = "Exploration du front",
    },
    [53212] = {
        name = "Retour à Zuldazar",
    },
    [53330] = {
        name = "ON RECHERCHE : alpha griffe-rasoir",
    },
    [53332] = {
        name = "En temps de guerre",
    },
    [53333] = {
        name = "En temps de guerre",
    },
    [53336] = {
        name = "ON RECHERCHE : impératrice sabre-d’ivoire",
    },
    [53337] = {
        name = "AVIS DE RECHERCHE : cognepoing primal",
    },
    [53342] = {
        name = "Cœur du Magma",
    },
    [53347] = {
        name = "Bad buzz dans la ruche",
    },
    [53348] = {
        name = "AVIS DE RECHERCHE : Groin-de-Tonnerre",
    },
    [53351] = {
        name = "LE FILON ! : Hostefer",
    },
    [53352] = {
        name = "Terres de Feu",
    },
    [53353] = {
        name = "L’écho du seigneur de guerre Zaela",
    },
    [53354] = {
        name = "L’écho de Gul’dan",
    },
    [53355] = {
        name = "L’écho de Garrosh Hurlenfer",
    },
    [53369] = {
        name = "Allez, Loh !",
    },
    [53370] = {
        name = "Une juste revanche",
    },
    [53371] = {
        name = "Mieux vaut dard que jamais",
    },
    [53372] = {
        name = "Une juste revanche",
    },
    [53406] = {
        name = "La chambre du Cœur",
    },
    [53430] = {
        name = "Arbalète de l’Ordre des Braises",
    },
    [53431] = {
        name = "Flacon de l’Ordre des Braises",
    },
    [53432] = {
        name = "Couteau de l’Ordre des Braises",
    },
    [53433] = {
        name = "Chapeau de l’Ordre des Braises",
    },
    [53438] = {
        name = "AVIS DE RECHERCHE : braconniers de wyvernes",
    },
    [53440] = {
        name = "AVIS DE RECHERCHE : le Frelon",
    },
    [53449] = {
        name = "La colère des singes",
    },
    [53450] = {
        name = "Le roi Da’ka",
    },
    [53451] = {
        name = "AVIS DE RECHERCHE : garde-terre déchaîné",
    },
    [53452] = {
        name = "La guerre des gorilles",
    },
    [53453] = {
        name = "Douker ou ne pas douker",
    },
    [53454] = {
        name = "Avis de recherche : intendant Ssylis",
    },
    [53455] = {
        name = "AVIS DE RECHERCHE : les Égorgeurs écarlates",
    },
    [53456] = {
        name = "AVIS DE RECHERCHE : Gueule-de-givre",
    },
    [53458] = {
        name = "AVIS DE RECHERCHE : Ruissemal",
    },
    [53459] = {
        name = "AVIS DE RECHERCHE : sœur Lilias",
    },
    [53461] = {
        name = "Métaux précieux",
    },
    [53462] = {
        name = "Bien emballés",
    },
    [53463] = {
        name = "Malédiction à huit pattes",
    },
    [53464] = {
        name = "Le village de Ruisseval",
    },
    [53465] = {
        name = "L’heure du thé",
    },
    [53466] = {
        name = "Vision du temps",
    },
    [53467] = {
        name = "Les Grottes du temps",
    },
    [53566] = {
        name = "Nains sombrefer",
    },
    [53583] = {
        name = "Adaptation tactique",
    },
    [53602] = {
        name = "Adaptation tactique",
    },
    [53719] = {
        name = "L’allégeance des Zandalari",
    },
    [53720] = {
        name = "L’allégeance de Kul Tiras",
    },
    [53725] = {
        name = "Un peuple brisé",
    },
    [53734] = {
        name = "Marcher parmi les fantômes",
    },
    [53735] = {
        name = "Les premiers à périr",
    },
    [53736] = {
        name = "La Complainte des Bien-nés",
    },
    [53737] = {
        name = "Le jour où l’espoir s’est éteint",
    },
    [53738] = {
        name = "La défense de Quel’Danas",
    },
    [53760] = {
        name = "Conséquences imprévues",
    },
    [53761] = {
        name = "Le trésor du pirate",
    },
    [53762] = {
        name = "La couronne des tempêtes",
    },
    [53763] = {
        name = "Le couteau dans la plaie",
    },
    [53765] = {
        name = "Son œil noir vous regarde",
    },
    [53766] = {
        name = "Son œil noir vous regarde",
    },
    [53774] = {
        name = "La sagesse du chef de guerre",
    },
    [53775] = {
        name = "Les ombres de la discorde",
    },
    [53776] = {
        name = "Vers le rivage Brisé",
    },
    [53777] = {
        name = "Au lieu de sa mort",
    },
    [53778] = {
        name = "Au lieu de sa chute",
    },
    [53779] = {
        name = "Les mensonges d’un Loa",
    },
    [53780] = {
        name = "Le geôlier des damnés",
    },
    [53782] = {
        name = "Les mystères de la mort",
    },
    [53783] = {
        name = "Dans les dunes",
    },
    [53791] = {
        name = "La fierté des Sin’dorei",
    },
    [53802] = {
        name = "Persuasion des Sephraks",
    },
    [53805] = {
        name = "De fil en aiguille",
    },
    [53806] = {
        name = "La solitude des hautes sphères",
    },
    [53807] = {
        name = "Raccommodage temporel",
    },
    [53810] = {
        name = "Le fil tranché",
    },
    [53813] = {
        name = "Cent fois sur le métier",
    },
    [53815] = {
        name = "Qu’est-il arrivé à Sapphronetta Flivvers ?",
    },
    [53816] = {
        name = "Perroquet en kit",
    },
    [53817] = {
        name = "Qu’est-il arrivé à Grizzek Moussemolette ?",
    },
    [53818] = {
        name = "Perr-OK",
    },
    [53819] = {
        name = "Retour au nid",
    },
    [53820] = {
        name = "Elle est dans un monde meilleur",
    },
    [53821] = {
        name = "Il est mort, Jastor",
    },
    [53823] = {
        name = "La suite de la reine",
    },
    [53824] = {
        name = "Le rituel des rois et des reines",
    },
    [53825] = {
        name = "Le nouveau conseil zanchuli",
    },
    [53826] = {
        name = "L’agitatrice était parmi nous",
    },
    [53827] = {
        name = "Le conseil a parlé",
    },
    [53828] = {
        name = "Le regard des Loas",
    },
    [53830] = {
        name = "La reine des Zandalari",
    },
    [53831] = {
        name = "Royales réjouissances",
    },
    [53833] = {
        name = "Vengeance à haut Risk",
    },
    [53835] = {
        name = "Une précieuse découverte ?",
    },
    [53836] = {
        name = "Armure ancienne, mystère ancien",
    },
    [53837] = {
        name = "Gare à vous",
    },
    [53838] = {
        name = "Garder les pieds sur terre",
    },
    [53840] = {
        name = "Une pinte, ça vous tente ?",
    },
    [53841] = {
        name = "Les éclats du passé",
    },
    [53842] = {
        name = "Bénédiction terrestre",
    },
    [53844] = {
        name = "Recruter le maître de la Fournaise",
    },
    [53845] = {
        name = "Forger l’armure",
    },
    [53846] = {
        name = "L’héritage des Barbe-de-Bronze",
    },
    [53847] = {
        name = "Murmures au gré des vents",
    },
    [53848] = {
        name = "Vadrouille en Vol’dun",
    },
    [53849] = {
        name = "Espoir déclinant",
    },
    [53851] = {
        name = "Notre guerre se poursuit",
    },
    [53852] = {
        name = "Privation d’azérite",
    },
    [53853] = {
        name = "Le soleil couchant",
    },
    [53856] = {
        name = "La fureur de la Horde",
    },
    [53858] = {
        name = "Marcher sur ses traces",
    },
    [53866] = {
        name = "Chaussure à son pied",
    },
    [53868] = {
        name = "Mesure préventive",
    },
    [53869] = {
        name = "Tuer le temps",
    },
    [53870] = {
        name = "Des visiteurs au fort Grommash",
    },
    [53879] = {
        name = "Grand nettoyage du domaine",
    },
    [53880] = {
        name = "Machines de guerre et azérite",
    },
    [53881] = {
        name = "Taillés dans la même étoffe",
    },
    [53882] = {
        name = "Le mur du souvenir",
    },
    [53887] = {
        name = "La guerre bat son plein",
    },
    [53888] = {
        name = "Au Trident !",
    },
    [53889] = {
        name = "Une déclaration d’intention",
    },
    [53890] = {
        name = "À nouveaux alliés, nouveaux problèmes",
    },
    [53891] = {
        name = "Ce n’est pas la taille du problème qui compte",
    },
    [53892] = {
        name = "Où sont passés les ouvriers ?",
    },
    [53893] = {
        name = "Un petit geste de bonne volonté",
    },
    [53894] = {
        name = "Des réparations utiles",
    },
    [53895] = {
        name = "Promotions de péons !",
    },
    [53896] = {
        name = "Au service des plus faibles",
    },
    [53897] = {
        name = "Une fête en votre honneur",
    },
    [53898] = {
        name = "Force et honneur",
    },
    [53899] = {
        name = "En périphérie",
    },
    [53900] = {
        name = "Avec leurs propres armes",
    },
    [53901] = {
        name = "Une diversion explosive",
    },
    [53902] = {
        name = "Le meurtre de l’imploratrice des marées",
    },
    [53903] = {
        name = "Rencontre avec Meera",
    },
    [53904] = {
        name = "Les assistants du vigneron",
    },
    [53905] = {
        name = "Valorisation des atouts",
    },
    [53906] = {
        name = "Fermenté pour la Horde",
    },
    [53907] = {
        name = "Séance de dégustation",
    },
    [53908] = {
        name = "En attente de notre retour",
    },
    [53909] = {
        name = "Alliés assiégés",
    },
    [53910] = {
        name = "Repoussez la Horde !",
    },
    [53912] = {
        name = "Une chasse sans fin",
    },
    [53913] = {
        name = "Avec honneur",
    },
    [53916] = {
        name = "Armateur de Barges",
    },
    [53919] = {
        name = "De l’eau dans les canots",
    },
    [53936] = {
        name = "Travail de sape",
    },
    [53937] = {
        name = "La sup3r clé",
    },
    [53938] = {
        name = "De fil en aiguille",
    },
    [53940] = {
        name = "Raccommodage temporel",
    },
    [53941] = {
        name = "C’est l’histoire d’un méca…",
    },
    [53942] = {
        name = "Le méca de la situation",
    },
    [53947] = {
        name = "Dans les dunes",
    },
    [53948] = {
        name = "Vengeance à haut Risk",
    },
    [53949] = {
        name = "La sup3r clé",
    },
    [53962] = {
        name = "Taillés dans la même étoffe",
    },
    [53973] = {
        name = "Face à face sanglant",
    },
    [53978] = {
        name = "De la poudre pour les Barges",
    },
    [53981] = {
        name = "Victoire à l’arraché",
    },
    [53986] = {
        name = "Un calme précaire",
    },
    [53988] = {
        name = "Les rives du destin",
    },
    [53989] = {
        name = "Espoir",
    },
    [53990] = {
        name = "Au plus noir de la nuit",
    },
    [53993] = {
        name = "Une voix portée par le vent",
    },
    [53995] = {
        name = "Le tanneur tauren",
    },
    [53996] = {
        name = "Récolte de bois",
    },
    [53997] = {
        name = "Sixième sens",
    },
    [53998] = {
        name = "L’Exhumée",
    },
    [53999] = {
        name = "Fil conducteur",
    },
    [54000] = {
        name = "À cœur battant…",
    },
    [54001] = {
        name = "Destination incertaine",
    },
    [54002] = {
        name = "Assemblage final",
    },
    [54004] = {
        name = "Test n° 1 : méca contre Mekkanivelle",
    },
    [54005] = {
        name = "Le savoir perdu des Drust",
    },
    [54007] = {
        name = "Assurance routière",
    },
    [54008] = {
        name = "Renouvellement d’assurance",
    },
    [54009] = {
        name = "Carnage sur le bas-côté",
    },
    [54012] = {
        name = "Naufragés chanceux",
    },
    [54015] = {
        name = "Micmac sous-marin",
    },
    [54018] = {
        name = "Descente",
    },
    [54021] = {
        name = "La première arcaniste",
    },
    [54022] = {
        name = "Les plans de bataille de Mekkanivelle",
    },
    [54026] = {
        name = "Travail terminé",
    },
    [54027] = {
        name = "Menace écartée",
    },
    [54028] = {
        name = "Méca contre vaisseau",
    },
    [54031] = {
        name = "Le regard des Loas : Krag’wa",
    },
    [54032] = {
        name = "Le regard des Loas : Pa’ku",
    },
    [54033] = {
        name = "Le regard des Loas : Gonk",
    },
    [54034] = {
        name = "Le regard des Loas : Bwonsamdi",
    },
    [54036] = {
        name = "Un processus bien particulier",
    },
    [54041] = {
        name = "Pas de survivants",
    },
    [54042] = {
        name = "Problèmes en Sombrivage",
    },
    [54043] = {
        name = "Rafle de forestiers-sombres",
    },
    [54044] = {
        name = "L’ascension de la lune noire",
    },
    [54045] = {
        name = "Une bonne roncée !",
    },
    [54046] = {
        name = "Pas sortis des ronces",
    },
    [54047] = {
        name = "Là où l’espoir s’éteint",
    },
    [54049] = {
        name = "Le linceul de la nuit",
    },
    [54050] = {
        name = "Conséquences",
    },
    [54058] = {
        name = "Conséquences imprévues",
    },
    [54059] = {
        name = "La guerrière de la Nuit",
    },
    [54083] = {
        name = "Une mécanique bien huilée",
    },
    [54086] = {
        name = "Le robot de l’emploi",
    },
    [54087] = {
        name = "Taille maximale autorisée",
    },
    [54088] = {
        name = "La légende de Mécagone",
    },
    [54094] = {
        name = "La définition gobeline du succès",
    },
    [54096] = {
        name = "La chute du Puits de soleil",
    },
    [54097] = {
        name = "L’appel de la Dame noire",
    },
    [54099] = {
        name = "Le haut seigneur",
    },
    [54100] = {
        name = "Une porte de sortie",
    },
    [54101] = {
        name = "À la trace",
    },
    [54102] = {
        name = "Fuite vers l’est",
    },
    [54103] = {
        name = "La croisée des chemins",
    },
    [54104] = {
        name = "Sur la piste de Saurcroc",
    },
    [54105] = {
        name = "Cap plein est",
    },
    [54106] = {
        name = "L’art du pistage",
    },
    [54107] = {
        name = "De sombres nouvelles",
    },
    [54108] = {
        name = "La mort d’un guerrier",
    },
    [54109] = {
        name = "La faveur de la reine",
    },
    [54113] = {
        name = "Chaque mort est un pas en avant",
    },
    [54114] = {
        name = "Chaque mort est un pas en avant",
    },
    [54117] = {
        name = "Chaque mort est un pas en avant",
    },
    [54118] = {
        name = "Chaque mort est un pas en avant",
    },
    [54120] = {
        name = "En route pour Orgrimmar",
    },
    [54121] = {
        name = "La libération de Corsandre",
    },
    [54123] = {
        name = "Une M.E.G.A. soif",
    },
    [54124] = {
        name = "Le b.a.-ba de la fraude à l’assurance",
    },
    [54126] = {
        name = "Le couteau dans la plaie",
    },
    [54128] = {
        name = "Précautions d’usage",
    },
    [54139] = {
        name = "La guerre est à nos portes",
    },
    [54140] = {
        name = "La chevauchée des Zandalari",
    },
    [54141] = {
        name = "Le médaillon d’Azshara",
    },
    [54144] = {
        name = "Les ordres d’Azshara",
    },
    [54145] = {
        name = "Le Loa de la mort",
    },
    [54147] = {
        name = "Confrontation avec la Val’kyr",
    },
    [54156] = {
        name = "La voie du sang",
    },
    [54157] = {
        name = "On n’abandonne aucun guerrier",
    },
    [54161] = {
        name = "Le savoir perdu des Drust",
    },
    [54163] = {
        name = "Quand la poussière retombe",
    },
    [54164] = {
        name = "La mort du roi",
    },
    [54165] = {
        name = "Le retour de Derek Portvaillant",
    },
    [54169] = {
        name = "Le coup du trésor",
    },
    [54171] = {
        name = "Le sceptre abyssal",
    },
    [54174] = {
        name = "Les ordres d’Azshara",
    },
    [54175] = {
        name = "Face à face avec l’ennemi",
    },
    [54176] = {
        name = "De l’importance de l’uniformité",
    },
    [54177] = {
        name = "Une diversion brillante",
    },
    [54178] = {
        name = "Bateau stop",
    },
    [54179] = {
        name = "Par la grande porte",
    },
    [54183] = {
        name = "La revanche de la mort",
    },
    [54191] = {
        name = "Changement de cap",
    },
    [54192] = {
        name = "Informations cruciales",
    },
    [54193] = {
        name = "C’est énorme !",
    },
    [54194] = {
        name = "Puissance colossale",
    },
    [54195] = {
        name = "Pas si bête, la bête",
    },
    [54196] = {
        name = "Solution de dernier recours",
    },
    [54197] = {
        name = "Liberté pour les Da’kani",
    },
    [54198] = {
        name = "Des adieux doux-amers",
    },
    [54199] = {
        name = "Pour le bien de tous",
    },
    [54200] = {
        name = "Base de référence",
    },
    [54201] = {
        name = "Du sur-mesure pour Grong",
    },
    [54202] = {
        name = "Le calibrage du noyau",
    },
    [54203] = {
        name = "La grandification",
    },
    [54204] = {
        name = "Destruction totale du temple",
    },
    [54205] = {
        name = "Une bonne sieste",
    },
    [54206] = {
        name = "Gorille au bois dormant",
    },
    [54207] = {
        name = "La reprise de l’avant-poste",
    },
    [54208] = {
        name = "Démineurs",
    },
    [54211] = {
        name = "Tribulations de la Brigade gob",
    },
    [54212] = {
        name = "Nième reconstruction du M.E.C.H.A.",
    },
    [54213] = {
        name = "Ça marche !",
    },
    [54224] = {
        name = "La bataille des ruines de Zul’jan",
    },
    [54244] = {
        name = "Faits comme des rats",
    },
    [54249] = {
        name = "Justice zandalari",
    },
    [54265] = {
        name = "Les ordres d’Azshara",
    },
    [54269] = {
        name = "Nul ne s’échappera",
    },
    [54270] = {
        name = "Sept ans de malheur",
    },
    [54271] = {
        name = "L’élimination de Telaamon",
    },
    [54275] = {
        name = "La dissipation des brumes",
    },
    [54280] = {
        name = "À la rencontre de l’Alliance",
    },
    [54282] = {
        name = "La bataille de Dazar’alor",
    },
    [54300] = {
        name = "La fidélité",
    },
    [54301] = {
        name = "La miséricorde de Talanji",
    },
    [54302] = {
        name = "La chute de Zuldazar",
    },
    [54303] = {
        name = "La marche sur Nazmir",
    },
    [54310] = {
        name = "Village de garnison",
    },
    [54312] = {
        name = "Brouillard de guerre",
    },
    [54402] = {
        name = "La vitesse supérieure",
    },
    [54404] = {
        name = "Les machinations des Sombrefer",
    },
    [54407] = {
        name = "La traversée des marais",
    },
    [54412] = {
        name = "Déluge à Zul’jan",
    },
    [54416] = {
        name = "Préparatifs pour le front de guerre",
    },
    [54417] = {
        name = "Délogés par la force",
    },
    [54418] = {
        name = "Le mécanisme exterminateur",
    },
    [54419] = {
        name = "Répression de la populace",
    },
    [54421] = {
        name = "Re-discombobulation",
    },
    [54433] = {
        name = "Les ordres d’Azshara",
    },
    [54438] = {
        name = "Creuset des Tempêtes : les reliques de l’ombre",
    },
    [54439] = {
        name = "Creuset des Tempêtes : les reliques de l’ombre",
    },
    [54441] = {
        name = "La prise de la porte de Sang",
    },
    [54459] = {
        name = "Celui qui marche dans la Lumière",
    },
    [54485] = {
        name = "La bataille de Dazar’alor",
    },
    [54510] = {
        name = "Sécurité maritime",
    },
    [54518] = {
        name = "Zéro zeppelin",
    },
    [54519] = {
        name = "Patrouille perdue",
    },
    [54559] = {
        name = "Libérer Plumeria !",
    },
    [54576] = {
        name = "As des as de Gnomeregan",
    },
    [54577] = {
        name = "Couloirs sombres et rouages poussiéreux",
    },
    [54580] = {
        name = "Tourni dans la toundra",
    },
    [54581] = {
        name = "Ça va barder pour les bardés",
    },
    [54582] = {
        name = "Futé, pour un Trogg",
    },
    [54639] = {
        name = "Signal dans les pics Foudroyés",
    },
    [54640] = {
        name = "Pacte de Gnome-agression",
    },
    [54641] = {
        name = "Pour Gnomeregan !",
    },
    [54642] = {
        name = "Un R.O.U.A.G.E. bien huilé",
    },
    [54703] = {
        name = "Livraison express",
    },
    [54706] = {
        name = "Fabriqué en Kul Tiras",
    },
    [54708] = {
        name = "Si j’étais un charpentier",
    },
    [54721] = {
        name = "Vogue la galère",
    },
    [54723] = {
        name = "Voiler nos mâts",
    },
    [54725] = {
        name = "Les créatures des profondeurs",
    },
    [54726] = {
        name = "Une belle charpente",
    },
    [54727] = {
        name = "Les Musclés",
    },
    [54728] = {
        name = "Ce bois est hanté",
    },
    [54729] = {
        name = "Les collines Désolées",
    },
    [54730] = {
        name = "L’influence de Gorak Tul",
    },
    [54731] = {
        name = "L’équilibre en toute chose",
    },
    [54732] = {
        name = "Bas les pattes !",
    },
    [54733] = {
        name = "Les clés du problème",
    },
    [54734] = {
        name = "La convocation de Dorlan",
    },
    [54735] = {
        name = "Un équipage à la hauteur",
    },
    [54754] = {
        name = "Pour la reine",
    },
    [54759] = {
        name = "Les murmures des esprits",
    },
    [54760] = {
        name = "Les marcheurs des esprits",
    },
    [54761] = {
        name = "Un guide spirituel",
    },
    [54762] = {
        name = "Une petite retraite",
    },
    [54763] = {
        name = "Vers le monde des esprits",
    },
    [54764] = {
        name = "Tempête à Sabot-de-Sang",
    },
    [54765] = {
        name = "N’oubliez pas le guide",
    },
    [54766] = {
        name = "Répondre à l’appel",
    },
    [54787] = {
        name = "Mascarade",
    },
    [54850] = {
        name = "Opération Troggageddon",
    },
    [54851] = {
        name = "La bénédiction des marées",
    },
    [54871] = {
        name = "Nous voilà",
    },
    [54913] = {
        name = "Un éclair de génie",
    },
    [54915] = {
        name = "Télémétrie en action",
    },
    [54916] = {
        name = "Le credo du chasseur",
    },
    [54917] = {
        name = "Créance de sang",
    },
    [54918] = {
        name = "Une étincelle d’imagination",
    },
    [54919] = {
        name = "Les liens du tonnerre",
    },
    [54920] = {
        name = "Retour au bercail",
    },
    [54922] = {
        name = "Quincaillerie lourde",
    },
    [54925] = {
        name = "Hérésie !",
    },
    [54929] = {
        name = "Roulez jeunesse",
    },
    [54930] = {
        name = "Libération mécanique",
    },
    [54938] = {
        name = "L’aide d’un frère",
    },
    [54939] = {
        name = "Barbe-de-Bronze, tête de bois",
    },
    [54940] = {
        name = "Une D.A.M.E. de confiance",
    },
    [54945] = {
        name = "Première étape",
    },
    [54946] = {
        name = "Rapport à Gila",
    },
    [54947] = {
        name = "Petits mais costauds",
    },
    [54958] = {
        name = "Croisière nocturne",
    },
    [54959] = {
        name = "Sous les verrous",
    },
    [54960] = {
        name = "Amères retrouvailles",
    },
    [54961] = {
        name = "Redresser les torts",
    },
    [54964] = {
        name = "Droit au cœur",
    },
    [54965] = {
        name = "Bons pour la casse",
    },
    [54969] = {
        name = "Descente",
    },
    [54972] = {
        name = "Portail de retour",
    },
    [54975] = {
        name = "Un répit de courte durée",
    },
    [54976] = {
        name = "L’ombre de Gilnéas",
    },
    [54977] = {
        name = "Au cœur du bois de la Pénombre",
    },
    [54980] = {
        name = "La plaie des Plaies-de-nuit",
    },
    [54981] = {
        name = "Hurler à la lune",
    },
    [54982] = {
        name = "L’esprit du chasseur",
    },
    [54983] = {
        name = "Le réveil d’un rêveur",
    },
    [54984] = {
        name = "On ne réveille pas un loup qui dort",
    },
    [54990] = {
        name = "La nouvelle garde",
    },
    [54992] = {
        name = "Un début prometteur",
    },
    [54997] = {
        name = "La mer morte",
    },
    [54999] = {
        name = "Version arrangée",
    },
    [55028] = {
        name = "Opération récup’",
    },
    [55031] = {
        name = "Opération récup’",
    },
    [55033] = {
        name = "Des cendres aux Corsandre",
    },
    [55034] = {
        name = "Version arrangée",
    },
    [55039] = {
        name = "Le maître charpentier",
    },
    [55040] = {
        name = "Inspection interne",
    },
    [55043] = {
        name = "Petits potins et gros bateaux",
    },
    [55044] = {
        name = "Ne tuez pas la messagère",
    },
    [55045] = {
        name = "Le frère perdu",
    },
    [55047] = {
        name = "La sécurisation du camp Croc-de-Guerre",
    },
    [55048] = {
        name = "Jeu d’espions",
    },
    [55049] = {
        name = "Communication interrompue",
    },
    [55050] = {
        name = "Billets, s’il vous plaît !",
    },
    [55051] = {
        name = "Démonstration de puissance",
    },
    [55052] = {
        name = "La sécurisation du camp Croc-de-Guerre",
    },
    [55053] = {
        name = "Portail de retour",
    },
    [55054] = {
        name = "Soulèvement",
    },
    [55055] = {
        name = "Un plus gros piège",
    },
    [55087] = {
        name = "La tempête menace",
    },
    [55088] = {
        name = "Perdu de vue",
    },
    [55089] = {
        name = "À l’ombre de Shaw",
    },
    [55090] = {
        name = "Rassemblement ennemi",
    },
    [55092] = {
        name = "Coupure de courant",
    },
    [55094] = {
        name = "Rapidité et discrétion",
    },
    [55095] = {
        name = "Soulèvement",
    },
    [55096] = {
        name = "Un message pour mon père",
    },
    [55101] = {
        name = "En première casse",
    },
    [55103] = {
        name = "Foire aux idées",
    },
    [55116] = {
        name = "À la recherche d’indices",
    },
    [55117] = {
        name = "Correspondance énigmatique",
    },
    [55118] = {
        name = "Petite négligence",
    },
    [55119] = {
        name = "Au rapport !",
    },
    [55121] = {
        name = "Le laboratoire de Mardivas",
    },
    [55124] = {
        name = "Redresser les torts",
    },
    [55136] = {
        name = "Une vie de chien",
    },
    [55153] = {
        name = "Construction participative",
    },
    [55171] = {
        name = "Contre-espionnage",
    },
    [55175] = {
        name = "Là où mène la route",
    },
    [55177] = {
        name = "Un accroc dans le temps",
    },
    [55179] = {
        name = "Coordination des représailles",
    },
    [55182] = {
        name = "Réparations requises",
    },
    [55183] = {
        name = "Prendre de la hauteur",
    },
    [55185] = {
        name = "Écoutez !",
    },
    [55188] = {
        name = "Un accroc dans le temps",
    },
    [55195] = {
        name = "Réverbération",
    },
    [55210] = {
        name = "Piles non incluses",
    },
    [55211] = {
        name = "Recharger Mécarouille",
    },
    [55214] = {
        name = "Sous toutes les coutures",
    },
    [55216] = {
        name = "L’audition",
    },
    [55217] = {
        name = "Recouvrement de dette de sang",
    },
    [55218] = {
        name = "Le précieux cuir de Sheza",
    },
    [55219] = {
        name = "Un petit tour à la base",
    },
    [55220] = {
        name = "Pêche miraculeuse",
    },
    [55221] = {
        name = "Jusqu’à l’os",
    },
    [55222] = {
        name = "Tambour battant",
    },
    [55223] = {
        name = "Instruments de destruction",
    },
    [55227] = {
        name = "L’artisane des Éons",
    },
    [55228] = {
        name = "L’audition",
    },
    [55229] = {
        name = "Recouvrement de dette",
    },
    [55230] = {
        name = "Le précieux cuir de Telonis",
    },
    [55231] = {
        name = "L’autre Danse-Fantôme",
    },
    [55232] = {
        name = "La menace de Mevris",
    },
    [55233] = {
        name = "Jusqu’à l’os",
    },
    [55234] = {
        name = "Tambour battant",
    },
    [55235] = {
        name = "Instruments de destruction",
    },
    [55247] = {
        name = "Une confiance bien méritée",
    },
    [55252] = {
        name = "Un Loa sans temple",
    },
    [55253] = {
        name = "Une preuve de confiance",
    },
    [55254] = {
        name = "Un sommeil éternel",
    },
    [55258] = {
        name = "Manger, dormir et recommencer",
    },
    [55298] = {
        name = "Dodu fretin",
    },
    [55339] = {
        name = "On fait le ménage",
    },
    [55361] = {
        name = "Le chaman disparu",
    },
    [55362] = {
        name = "Fureur élémentaire",
    },
    [55363] = {
        name = "Au secours du long-voyant",
    },
    [55373] = {
        name = "À fond les caisses",
    },
    [55374] = {
        name = "Perturbation souterraine",
    },
    [55384] = {
        name = "Emménagement",
    },
    [55385] = {
        name = "Exploration des enclos",
    },
    [55390] = {
        name = "Dans les ténèbres, je rêve",
    },
    [55392] = {
        name = "Sur le chemin du Rêve",
    },
    [55393] = {
        name = "La nature a horreur du Vide",
    },
    [55394] = {
        name = "Éclats d’émeraude",
    },
    [55395] = {
        name = "Ne fermez pas les yeux",
    },
    [55396] = {
        name = "Un rêve devenu réalité",
    },
    [55397] = {
        name = "Avant de me réveiller",
    },
    [55398] = {
        name = "La longue veille",
    },
    [55400] = {
        name = "Prenez ma main",
    },
    [55407] = {
        name = "Nuits d’Échine",
    },
    [55425] = {
        name = "Dompter l’Indomptable",
    },
    [55462] = {
        name = "L’appel de la Montagne errante",
    },
    [55465] = {
        name = "Au cœur du Rêve",
    },
    [55469] = {
        name = "En route pour Zin-Azshari",
    },
    [55481] = {
        name = "Reconnaissance du palais",
    },
    [55482] = {
        name = "Passez-moi le 22 à Nazjatar",
    },
    [55485] = {
        name = "Terreurs des profondeurs",
    },
    [55486] = {
        name = "Les secrets de la télémancie",
    },
    [55488] = {
        name = "Palabres avec les morts",
    },
    [55489] = {
        name = "À la suivante",
    },
    [55490] = {
        name = "On va leur crever les yeux",
    },
    [55497] = {
        name = "Un visage amical",
    },
    [55500] = {
        name = "Une amie en détresse",
    },
    [55503] = {
        name = "La navrecorne et le sauride",
    },
    [55504] = {
        name = "Les sanctuaires de Zuldazar",
    },
    [55505] = {
        name = "En mémoire de Roo’li",
    },
    [55506] = {
        name = "La fin d’une route",
    },
    [55507] = {
        name = "La bénédiction de Torcali",
    },
    [55519] = {
        name = "Un nouveau traumatisme",
    },
    [55520] = {
        name = "Au chevet de Nordrassil",
    },
    [55521] = {
        name = "Traitement à l’azérite",
    },
    [55529] = {
        name = "Reprendre, c’est voler",
    },
    [55530] = {
        name = "Un endroit plus sûr",
    },
    [55533] = {
        name = "D.A.M.E. a toujours raison",
    },
    [55558] = {
        name = "Un point d’appui",
    },
    [55560] = {
        name = "La vengeance d’Utama",
    },
    [55561] = {
        name = "Ce qu’il reste de Zin-Azshari",
    },
    [55565] = {
        name = "Le plein de mana",
    },
    [55569] = {
        name = "Échos de douleur",
    },
    [55570] = {
        name = "Les secrets des ruines",
    },
    [55571] = {
        name = "Œillères d’outre-tombe",
    },
    [55573] = {
        name = "L’élimination des profanateurs",
    },
    [55574] = {
        name = "Les javelots d’Azshara",
    },
    [55585] = {
        name = "Des débuts prometteurs",
    },
    [55586] = {
        name = "Du travail d’orfèvre",
    },
    [55590] = {
        name = "Problème réglé",
    },
    [55592] = {
        name = "Des débuts prometteurs",
    },
    [55593] = {
        name = "Renseignements sur l’ennemi",
    },
    [55594] = {
        name = "Du travail d’orfèvre",
    },
    [55595] = {
        name = "Savoir en perdition",
    },
    [55596] = {
        name = "Problème réglé",
    },
    [55597] = {
        name = "Liés par l’honneur",
    },
    [55598] = {
        name = "Ce que nous savons des Nagas",
    },
    [55599] = {
        name = "Infiltration exploratoire",
    },
    [55600] = {
        name = "Morfales mordragons",
    },
    [55601] = {
        name = "Cristaux très recherchés",
    },
    [55608] = {
        name = "Projet personnel",
    },
    [55618] = {
        name = "La forge du Cœur",
    },
    [55622] = {
        name = "Remise en circulation",
    },
    [55630] = {
        name = "Première étape",
    },
    [55632] = {
        name = "Taille maximale autorisée",
    },
    [55635] = {
        name = "Une voix portée par le vent",
    },
    [55645] = {
        name = "Une visite princière",
    },
    [55646] = {
        name = "La légende de Mécagone",
    },
    [55647] = {
        name = "Joyeuse bousculade",
    },
    [55648] = {
        name = "Garder la chambre forte",
    },
    [55649] = {
        name = "Machinations à Mécagone",
    },
    [55650] = {
        name = "Une équipe triée sur le volet",
    },
    [55651] = {
        name = "Cap sur Mécagone !",
    },
    [55652] = {
        name = "La baie des Bonnes Affaires",
    },
    [55657] = {
        name = "À l’ombre d’ailes cramoisies",
    },
    [55685] = {
        name = "Paix et profits",
    },
    [55694] = {
        name = "Il y a quelque chose dans l’eau",
    },
    [55696] = {
        name = "Un tour d’essai",
    },
    [55697] = {
        name = "Mise en jambes",
    },
    [55707] = {
        name = "Premier mois gratuit",
    },
    [55708] = {
        name = "Mise à niveau",
    },
    [55729] = {
        name = "La résistance a besoin de VOUS !",
    },
    [55730] = {
        name = "Au secours de la résistance",
    },
    [55731] = {
        name = "Les armées de mon père",
    },
    [55732] = {
        name = "Une vieille balafre",
    },
    [55734] = {
        name = "Construction de foreuse",
    },
    [55735] = {
        name = "Défendre le Maelström",
    },
    [55736] = {
        name = "Bienvenue dans la résistance",
    },
    [55737] = {
        name = "Azérite quand tu nous tiens",
    },
    [55752] = {
        name = "Union draconique",
    },
    [55753] = {
        name = "À bas le robot",
    },
    [55778] = {
        name = "Visions menaçantes",
    },
    [55779] = {
        name = "Sursis à l’exécution",
    },
    [55780] = {
        name = "De vieux alliés",
    },
    [55781] = {
        name = "De vieux alliés",
    },
    [55782] = {
        name = "Sursis à l’exécution",
    },
    [55783] = {
        name = "Sursis à l’exécution",
    },
    [55784] = {
        name = "Paiement en nature",
    },
    [55795] = {
        name = "La montagne en marche",
    },
    [55796] = {
        name = "Hérésie de grand chemin",
    },
    [55797] = {
        name = "La colère d’une mère navrecorne",
    },
    [55798] = {
        name = "Le compagnon de toute une vie",
    },
    [55799] = {
        name = "Une marée inexorable",
    },
    [55860] = {
        name = "Liquidation des limaces",
    },
    [55861] = {
        name = "Résidu, où es-tu ?",
    },
    [55862] = {
        name = "Renseignements sur l’ennemi",
    },
    [55863] = {
        name = "Savoir en perdition",
    },
    [55864] = {
        name = "La mort en punition",
    },
    [55865] = {
        name = "Ce que nous savons des Nagas",
    },
    [55866] = {
        name = "Infiltration exploratoire",
    },
    [55867] = {
        name = "Cristaux très recherchés",
    },
    [55868] = {
        name = "Résidu, où es-tu ?",
    },
    [55869] = {
        name = "Confiscation des armes",
    },
    [55870] = {
        name = "Liquidation des limaces",
    },
    [55937] = {
        name = "Confiscation des armes",
    },
    [55967] = {
        name = "Morfales mordragons",
    },
    [55983] = {
        name = "Un endroit plus sûr",
    },
    [55995] = {
        name = "Foreuse d’occasion",
    },
    [56030] = {
        name = "L’ordre du chef de guerre",
    },
    [56031] = {
        name = "L’offensive du Loup",
    },
    [56037] = {
        name = "Les secrets des Nagas",
    },
    [56038] = {
        name = "Un travail pas si insignifiant",
    },
    [56039] = {
        name = "Toujours à l’affûtage",
    },
    [56043] = {
        name = "L’envoi de la flotte",
    },
    [56044] = {
        name = "L’envoi de la flotte",
    },
    [56045] = {
        name = "Les secrets des Nagas",
    },
    [56046] = {
        name = "Un travail pas si insignifiant",
    },
    [56047] = {
        name = "Toujours à l’affûtage",
    },
    [56063] = {
        name = "Noires marées",
    },
    [56095] = {
        name = "L’héritage de Nar’anan",
    },
    [56118] = {
        name = "La gueule de l’emploi",
    },
    [56143] = {
        name = "Le sort du professeur Elryna",
    },
    [56156] = {
        name = "Une lame trempée",
    },
    [56167] = {
        name = "Enquête dans les hautes-terres",
    },
    [56168] = {
        name = "Pièces reconditionnées",
    },
    [56175] = {
        name = "Sans émissions polluantes",
    },
    [56181] = {
        name = "Prime d’activité",
    },
    [56209] = {
        name = "Les salles de l’Origine",
    },
    [56210] = {
        name = "Pierres de vision",
    },
    [56211] = {
        name = "Pierres de vision",
    },
    [56234] = {
        name = "Des amis dans le besoin",
    },
    [56235] = {
        name = "Retour à Nazjatar",
    },
    [56236] = {
        name = "À terre, mais en vie",
    },
    [56239] = {
        name = "L’étrange couteau en argent",
    },
    [56240] = {
        name = "L’étrange couteau en argent",
    },
    [56241] = {
        name = "Indices préservés",
    },
    [56242] = {
        name = "Indices préservés",
    },
    [56243] = {
        name = "Les journaux des morts",
    },
    [56244] = {
        name = "Les journaux des morts",
    },
    [56245] = {
        name = "Le verrou enchanté",
    },
    [56246] = {
        name = "Le verrou enchanté",
    },
    [56247] = {
        name = "L’histoire des trésors",
    },
    [56248] = {
        name = "L’histoire des trésors",
    },
    [56304] = {
        name = "On n’est pas Bien-né, là ?",
    },
    [56305] = {
        name = "Partie de pêche",
    },
    [56309] = {
        name = "La cité des amis noyés",
    },
    [56310] = {
        name = "La cité des amis noyés",
    },
    [56311] = {
        name = "Noyade perpétuelle",
    },
    [56312] = {
        name = "Noyade perpétuelle",
    },
    [56313] = {
        name = "Porteguerre",
    },
    [56314] = {
        name = "Porteguerre",
    },
    [56315] = {
        name = "Ils ont fait leur choix",
    },
    [56316] = {
        name = "Ils ont fait leur choix",
    },
    [56319] = {
        name = "L’accord verbal de Chargéclair",
    },
    [56320] = {
        name = "Première recharge gratuite !",
    },
    [56321] = {
        name = "À la rescousse de Corin",
    },
    [56325] = {
        name = "Portés par la marée",
    },
    [56346] = {
        name = "Technologie ancestrale",
    },
    [56347] = {
        name = "Une chance abyssale",
    },
    [56348] = {
        name = "Le palais Éternel : Nous pouvons le renforcer…",
    },
    [56349] = {
        name = "Le palais Éternel : Repousser les limites",
    },
    [56350] = {
        name = "Reconnaissance du palais",
    },
    [56351] = {
        name = "Le palais Éternel : Repousser les limites",
    },
    [56352] = {
        name = "Le palais Éternel : Nous pouvons le renforcer…",
    },
    [56353] = {
        name = "Une chance abyssale",
    },
    [56354] = {
        name = "Technologie ancestrale",
    },
    [56356] = {
        name = "Le palais Éternel : le stratagème de la reine",
    },
    [56358] = {
        name = "Le palais Éternel : le stratagème de la reine",
    },
    [56374] = {
        name = "Problème titanesque",
    },
    [56375] = {
        name = "Vers Ramkahen",
    },
    [56376] = {
        name = "Menaces émergentes",
    },
    [56377] = {
        name = "Forger l’avenir",
    },
    [56378] = {
        name = "L’équipage disparu",
    },
    [56379] = {
        name = "L’équipage disparu",
    },
    [56401] = {
        name = "Un soupçon de bleu",
    },
    [56422] = {
        name = "Sur des ailes spectrales",
    },
    [56429] = {
        name = "Nagas en force",
    },
    [56472] = {
        name = "L’accord d’Uldum",
    },
    [56494] = {
        name = "La veille du combat",
    },
    [56495] = {
        name = "Le ver dans la pomme",
    },
    [56496] = {
        name = "La veille du combat",
    },
    [56536] = {
        name = "Une mission de longue haleine",
    },
    [56537] = {
        name = "Le mystérieux cachet",
    },
    [56538] = {
        name = "Les clans mogu",
    },
    [56539] = {
        name = "À la recherche des Rajani",
    },
    [56540] = {
        name = "Preuve de ténacité",
    },
    [56541] = {
        name = "Le moteur de Nalak’sha",
    },
    [56542] = {
        name = "Espoir retrouvé",
    },
    [56560] = {
        name = "Une curieuse découverte",
    },
    [56561] = {
        name = "Une curieuse découverte",
    },
    [56574] = {
        name = "Réflexions d’ambre",
    },
    [56575] = {
        name = "Nouvelle corvée à Kor’vess",
    },
    [56576] = {
        name = "Extermination d’Aqir",
    },
    [56577] = {
        name = "Un coup à la ruche",
    },
    [56578] = {
        name = "Pourri jusqu’à la racine",
    },
    [56580] = {
        name = "Secrets d’ambre",
    },
    [56616] = {
        name = "À vieilles connaissances, nouveaux problèmes",
    },
    [56617] = {
        name = "L’essaim uni",
    },
    [56640] = {
        name = "Naufragés chanceux",
    },
    [56641] = {
        name = "Coupure de courant\13\
",
    },
    [56642] = {
        name = "Noires marées",
    },
    [56643] = {
        name = "Micmac sous-marin",
    },
    [56644] = {
        name = "Nagas en force",
    },
    [56645] = {
        name = "Cœur de l’essaim",
    },
    [56647] = {
        name = "La menace mantide",
    },
    [56719] = {
        name = "Grise mine",
    },
    [56739] = {
        name = "Le pouvoir de la foi",
    },
    [56741] = {
        name = "La Lance de la destinée",
    },
    [56771] = {
        name = "Guerriers perdus dans le temps",
    },
    [56833] = {
        name = "Les chefs de la Horde",
    },
    [56979] = {
        name = "Sauvetage du siège",
    },
    [56980] = {
        name = "Tentative de noyautage",
    },
    [56981] = {
        name = "Déploiement stratégique",
    },
    [56982] = {
        name = "Devant les portes d’Orgrimmar",
    },
    [56993] = {
        name = "Le prix de la victoire",
    },
    [57002] = {
        name = "Vieux briscard",
    },
    [57005] = {
        name = "Un ami en devenir",
    },
    [57006] = {
        name = "Un allié qui se respecte",
    },
    [57010] = {
        name = "Cœur de puissance",
    },
    [57043] = {
        name = "Vieux amis, nouvelles opportunités",
    },
    [57045] = {
        name = "Une livraison spéciale",
    },
    [57047] = {
        name = "Une simple expérience",
    },
    [57048] = {
        name = "Pièces au détail",
    },
    [57051] = {
        name = "Recouvrement de dettes !",
    },
    [57052] = {
        name = "J’ai tout ce qu’il vous faut",
    },
    [57053] = {
        name = "Test de résistance aux chocs",
    },
    [57058] = {
        name = "Mines en folie",
    },
    [57059] = {
        name = "Ça va chauffer !",
    },
    [57067] = {
        name = "Des Mogu à nos portes",
    },
    [57068] = {
        name = "Cerf-volant de reconnaissance",
    },
    [57069] = {
        name = "Des têtes à couper",
    },
    [57070] = {
        name = "Massacre de Mogu",
    },
    [57071] = {
        name = "Objectif bière",
    },
    [57072] = {
        name = "Yack à tout faire",
    },
    [57074] = {
        name = "Dos à la porte",
    },
    [57075] = {
        name = "Élixir de bravoure",
    },
    [57076] = {
        name = "Retour à Tombe-Brume",
    },
    [57077] = {
        name = "À la recherche d’acheteurs !",
    },
    [57078] = {
        name = "La liste VIP",
    },
    [57079] = {
        name = "Quel fourbe ! Mais que fait la police ?",
    },
    [57080] = {
        name = "Une récompense bien méritée",
    },
    [57088] = {
        name = "Grise mine",
    },
    [57090] = {
        name = "Sauvetage du siège",
    },
    [57091] = {
        name = "Tentative de noyautage",
    },
    [57092] = {
        name = "Déploiement stratégique",
    },
    [57093] = {
        name = "Devant les portes d’Orgrimmar",
    },
    [57094] = {
        name = "Le prix de la victoire",
    },
    [57095] = {
        name = "Vieux briscard",
    },
    [57126] = {
        name = "Suivre le courant",
    },
    [57130] = {
        name = "Des traîtres parmi nous",
    },
    [57147] = {
        name = "Pas mon chef de guerre",
    },
    [57148] = {
        name = "Briseurs de siège",
    },
    [57149] = {
        name = "Contre-propagande",
    },
    [57150] = {
        name = "Milice citoyenne",
    },
    [57151] = {
        name = "Tracer une ligne dans le sable",
    },
    [57152] = {
        name = "Indéfectible loyauté",
    },
    [57198] = {
        name = "Le sens du devoir",
    },
    [57220] = {
        name = "Activation du protocole d’alimentation",
    },
    [57221] = {
        name = "Réorigination",
    },
    [57222] = {
        name = "Enquête dans les salles",
    },
    [57290] = {
        name = "Entamer la descente",
    },
    [57324] = {
        name = "Au gré de la marée",
    },
    [57362] = {
        name = "Au fin fond des ténèbres",
    },
    [57373] = {
        name = "Plongée dans la folie",
    },
    [57374] = {
        name = "Dans les sombres profondeurs",
    },
    [57376] = {
        name = "La nécessité cachée",
    },
    [57378] = {
        name = "Les vestiges d’un monde brisé",
    },
    [57448] = {
        name = "De nouveaux alliés parmi nous",
    },
    [57486] = {
        name = "Énergie déclinante",
    },
    [57487] = {
        name = "Une âme charitable",
    },
    [57488] = {
        name = "Le schéma actuel",
    },
    [57490] = {
        name = "En route pour la sécurité",
    },
    [57491] = {
        name = "Plus fort… Plus solide… Moins mort",
    },
    [57492] = {
        name = "Lui ?",
    },
    [57493] = {
        name = "Harmonisation mentale",
    },
    [57494] = {
        name = "Un cœur solide",
    },
    [57495] = {
        name = "L’avenir de Mécagone",
    },
    [57497] = {
        name = "Répandre la nouvelle",
    },
    [57524] = {
        name = "Accès aux archives",
    },
    [57873] = {
        name = "Des nouvelles d’Orsis",
    },
    [57915] = {
        name = "En quête de survivants",
    },
    [57954] = {
        name = "Brûler les cadavres",
    },
    [57955] = {
        name = "En route pour le Port d’Ankhaten",
    },
    [57956] = {
        name = "Hôtes bat-le-désert",
    },
    [57969] = {
        name = "Des blessés à soigner",
    },
    [57970] = {
        name = "Ruineur Xok’nixx",
    },
    [57971] = {
        name = "Ruines d’Ammon",
    },
    [57990] = {
        name = "Obélisque du Soleil",
    },
    [58008] = {
        name = "Le plein est fait",
    },
    [58009] = {
        name = "Objectif Lune",
    },
    [58087] = {
        name = "Briser les batteries",
    },
    [58214] = {
        name = "Une affaire urgente",
    },
    [58496] = {
        name = "Un conseil malvenu",
    },
    [58498] = {
        name = "Le retour du roi guerrier",
    },
    [58502] = {
        name = "Du cœur à l’ouvrage",
    },
    [58506] = {
        name = "Diagnostics réseau",
    },
    [58582] = {
        name = "Le retour du prince noir",
    },
    [58583] = {
        name = "Du cœur à l’ouvrage",
    },
    [58606] = {
        name = "Aqir sinon rien",
    },
    [58615] = {
        name = "Murmures dans les ténèbres",
    },
    [58631] = {
        name = "Dans les rêves",
    },
    [58632] = {
        name = "Ny’alotha, la cité en éveil : la fin du Corrupteur",
    },
    [58634] = {
        name = "Une porte ouverte sur les ténèbres",
    },
    [58636] = {
        name = "Les yeux rivés sur les Amathet",
    },
    [58638] = {
        name = "Exploration approfondie",
    },
    [58639] = {
        name = "Passé enfoui",
    },
    [58640] = {
        name = "Une brèche dans l’armure",
    },
    [58641] = {
        name = "Chercheurs en corruption",
    },
    [58642] = {
        name = "Objectifs communs",
    },
    [58643] = {
        name = "Destruction mutuelle assurée",
    },
    [58645] = {
        name = "Un monde digne d’être sauvé",
    },
    [58646] = {
        name = "Mange ça !",
    },
    [58737] = {
        name = "Les découvertes de Magni",
    },
})
]])()
