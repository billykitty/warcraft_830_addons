----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "esMX" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Firma sangrienta",
    },
    [44785] = {
        name = "La hora del té",
    },
    [45079] = {
        name = "La aldea de Glenbrook",
    },
    [45972] = {
        name = "El matorral maldito",
    },
    [46727] = {
        name = "Mareas de guerra",
    },
    [46728] = {
        name = "La nación de Kul Tiras",
    },
    [46729] = {
        name = "El viejo caballero",
    },
    [46846] = {
        name = "La palabra de Zul",
    },
    [46926] = {
        name = "Ajuste de cuentas",
    },
    [46927] = {
        name = "El castigo de Tal'aman",
    },
    [46928] = {
        name = "El castigo de Tal'farrak",
    },
    [46929] = {
        name = "Disuasivo",
    },
    [46931] = {
        name = "Portavoz de la Horda",
    },
    [46957] = {
        name = "Bienvenido a Zuldazar",
    },
    [47098] = {
        name = "Libre como Flynn",
    },
    [47099] = {
        name = "Orientación básica",
    },
    [47103] = {
        name = "Viaje a Nazmir",
    },
    [47105] = {
        name = "Hacia la oscuridad",
    },
    [47130] = {
        name = "Entierro inapropiado",
    },
    [47181] = {
        name = "El arma humeante",
    },
    [47186] = {
        name = "Sagrario de los Sabios",
    },
    [47188] = {
        name = "La ayuda de los loa",
    },
    [47189] = {
        name = "Una nación dividida",
    },
    [47198] = {
        name = "Nos quieren con vida",
    },
    [47199] = {
        name = "La Puerta de Sangre",
    },
    [47200] = {
        name = "Garrapatas",
    },
    [47204] = {
        name = "Nuevo frente de batalla",
    },
    [47205] = {
        name = "Madreguerra",
    },
    [47226] = {
        name = "La cría huérfana",
    },
    [47228] = {
        name = "Ecología xibalana",
    },
    [47229] = {
        name = "Baluarte de Torcali",
    },
    [47235] = {
        name = "La visión del Ojo",
    },
    [47241] = {
        name = "La sombra de la muerte",
    },
    [47244] = {
        name = "Un sacrificio de almas",
    },
    [47245] = {
        name = "Un mensaje claro",
    },
    [47247] = {
        name = "Lo que acecha a los muertos",
    },
    [47248] = {
        name = "Hasta que la muerte nos separe",
    },
    [47249] = {
        name = "Ligado al alma",
    },
    [47250] = {
        name = "Volveremos a vernos",
    },
    [47257] = {
        name = "Los huesos de Xibala",
    },
    [47258] = {
        name = "Prepárate para el asedio",
    },
    [47259] = {
        name = "Cuidado de cuernoatroz",
    },
    [47260] = {
        name = "Los efectos secundarios incluyen...",
    },
    [47261] = {
        name = "Cómo entrenar a tu cuernoatroz",
    },
    [47262] = {
        name = "Acaba con los trols de sangre",
    },
    [47263] = {
        name = "La hora de la revelación",
    },
    [47264] = {
        name = "Que no quede ni uno en pie",
    },
    [47272] = {
        name = "Hormona de crecimiento de cuernoatroz",
    },
    [47289] = {
        name = "Ositos y tecitos",
    },
    [47310] = {
        name = "Hora de una siesta",
    },
    [47311] = {
        name = "A cabezazo limpio",
    },
    [47312] = {
        name = "Plumarreina",
    },
    [47313] = {
        name = "La discreción ante todo",
    },
    [47314] = {
        name = "Rumores de exilio",
    },
    [47315] = {
        name = "Camino a las dunas",
    },
    [47316] = {
        name = "Secretos en la arena",
    },
    [47317] = {
        name = "En busca de sobrevivientes",
    },
    [47319] = {
        name = "Veneno revitalizador",
    },
    [47320] = {
        name = "Un bálsamo de lo más sano",
    },
    [47321] = {
        name = "Recupera las chucherías",
    },
    [47322] = {
        name = "Un rescate muy astuto",
    },
    [47324] = {
        name = "Aliados inusuales",
    },
    [47327] = {
        name = "Respuesta a las agresiones",
    },
    [47329] = {
        name = "El legado Mirasangre",
    },
    [47332] = {
        name = "Tu próximo movimiento",
    },
    [47418] = {
        name = "Dolores crecientes",
    },
    [47422] = {
        name = "Una situación nefasta",
    },
    [47423] = {
        name = "Prácticas prohibidas",
    },
    [47428] = {
        name = "¿Gatito?",
    },
    [47432] = {
        name = "Trato hecho",
    },
    [47433] = {
        name = "Una defensa ofensiva",
    },
    [47434] = {
        name = "Orden de alejamiento",
    },
    [47435] = {
        name = "Disputa pterrortorial",
    },
    [47437] = {
        name = "Devoción competitiva",
    },
    [47438] = {
        name = "Elige un bando",
    },
    [47439] = {
        name = "Gonk, el jefe de la manada",
    },
    [47440] = {
        name = "Pa'ku, maestro de los vientos",
    },
    [47441] = {
        name = "Plagas",
    },
    [47442] = {
        name = "Maldición de Jani",
    },
    [47445] = {
        name = "El Concilio de Zanchuli",
    },
    [47485] = {
        name = "La Compañía Comercial Aspafresno",
    },
    [47486] = {
        name = "Cargamentos sospechosos",
    },
    [47487] = {
        name = "Disputa laboral",
    },
    [47488] = {
        name = "Explotación infantil",
    },
    [47489] = {
        name = "Polizón",
    },
    [47491] = {
        name = "Restos de los condenados",
    },
    [47497] = {
        name = "Conoce a la pandilla Colmilloáureo",
    },
    [47498] = {
        name = "El amigo perdido de Rhan'ka",
    },
    [47499] = {
        name = "Los ídolos sonrientes",
    },
    [47501] = {
        name = "No bebas en horario laboral",
    },
    [47502] = {
        name = "El plan perfecto",
    },
    [47503] = {
        name = "Gozda'kun el Esclavizador",
    },
    [47509] = {
        name = "Bancal de los Elegidos",
    },
    [47520] = {
        name = "Las paredes tienen oídos",
    },
    [47521] = {
        name = "Medianoche en el Jardín de los Loa",
    },
    [47522] = {
        name = "El Cazador",
    },
    [47525] = {
        name = "Quédate en las sombras",
    },
    [47527] = {
        name = "Rituales de herejía",
    },
    [47528] = {
        name = "La dama de las mentiras",
    },
    [47540] = {
        name = "Restauración totémica",
    },
    [47564] = {
        name = "Reabastecimiento del bufet",
    },
    [47570] = {
        name = "Motivos ocultos",
    },
    [47571] = {
        name = "La sabiduría del ancestro",
    },
    [47573] = {
        name = "Infestación telaselva",
    },
    [47574] = {
        name = "Una maraña de telarañas",
    },
    [47576] = {
        name = "La cólera del tigre",
    },
    [47577] = {
        name = "Llegaron desde el mar",
    },
    [47578] = {
        name = "La marca del loa",
    },
    [47580] = {
        name = "La maldición de Mekjila",
    },
    [47581] = {
        name = "La bendición de Kimbul",
    },
    [47583] = {
        name = "Diemetradones diezmados",
    },
    [47584] = {
        name = "Una espina clavada",
    },
    [47585] = {
        name = "Depredador",
    },
    [47586] = {
        name = "Cazar al cazador",
    },
    [47587] = {
        name = "Rebanacabezas Jo",
    },
    [47596] = {
        name = "No tenemos un plan \"B\"",
    },
    [47597] = {
        name = "Ningún goblin rezagado",
    },
    [47598] = {
        name = "Espadas y botines",
    },
    [47599] = {
        name = "Plato caliente de venganza",
    },
    [47601] = {
        name = "Prueba de campo",
    },
    [47602] = {
        name = "Listo para la acción",
    },
    [47621] = {
        name = "Un festín digno de un loa",
    },
    [47622] = {
        name = "Un brillo mágico",
    },
    [47623] = {
        name = "El último médico brujo de Krag'wa",
    },
    [47631] = {
        name = "Reunión en el Libación",
    },
    [47638] = {
        name = "Espíritus poderosos",
    },
    [47647] = {
        name = "Monstruos de Zem'lan",
    },
    [47659] = {
        name = "Cazadora cazada",
    },
    [47660] = {
        name = "Ídolos caídos",
    },
    [47695] = {
        name = "¡Alerta! ¡Alerta!",
    },
    [47696] = {
        name = "Krag'wa el Terrible",
    },
    [47697] = {
        name = "La ayuda de Krag'wa",
    },
    [47706] = {
        name = "La cacería del rey K'tal",
    },
    [47711] = {
        name = "La cabeza de la víbora",
    },
    [47716] = {
        name = "Búsqueda en las ruinas",
    },
    [47733] = {
        name = "La traición de la portavoz loa",
    },
    [47734] = {
        name = "Socios en herejía",
    },
    [47735] = {
        name = "Remedios tortollanos ancestrales",
    },
    [47736] = {
        name = "Rodarán cabezas",
    },
    [47737] = {
        name = "El Templo de Rezan",
    },
    [47738] = {
        name = "La voluntad del loa",
    },
    [47739] = {
        name = "El aroma de la venganza",
    },
    [47740] = {
        name = "La casa del rey",
    },
    [47741] = {
        name = "El sacrificio de un loa",
    },
    [47742] = {
        name = "El motín de Zul",
    },
    [47755] = {
        name = "Capturados y fascinados",
    },
    [47756] = {
        name = "La liberación de las libaciones",
    },
    [47797] = {
        name = "Gajes del oficio",
    },
    [47868] = {
        name = "La Necrópolis",
    },
    [47870] = {
        name = "Los muertos no cuentan cuentos",
    },
    [47871] = {
        name = "Equipamiento marítimo",
    },
    [47873] = {
        name = "El alijo del capitán",
    },
    [47874] = {
        name = "Despejando dudas",
    },
    [47880] = {
        name = "Un tributo a la muerte",
    },
    [47894] = {
        name = "Saltos y brincos",
    },
    [47897] = {
        name = "Traidores zanchuli",
    },
    [47915] = {
        name = "Misión de rescate",
    },
    [47918] = {
        name = "Al servicio de Krag'wa",
    },
    [47919] = {
        name = "Di no al canibalismo",
    },
    [47924] = {
        name = "Fin de la profanación",
    },
    [47925] = {
        name = "Menú del día: Shoak",
    },
    [47928] = {
        name = "Una ofrenda para el loa",
    },
    [47939] = {
        name = "Si la llave entra...",
    },
    [47943] = {
        name = "Caza de cangrejos",
    },
    [47945] = {
        name = "Envíos demorados",
    },
    [47946] = {
        name = "¡Por el tocino!",
    },
    [47947] = {
        name = "Lobos malosos",
    },
    [47948] = {
        name = "Chuleta de cerdo",
    },
    [47949] = {
        name = "Ese no es mi fetiche",
    },
    [47950] = {
        name = "Jamón curado",
    },
    [47952] = {
        name = "La flota perdida",
    },
    [47959] = {
        name = "El rastro de la guardiana bélica",
    },
    [47960] = {
        name = "Canal de Tiragarde",
    },
    [47962] = {
        name = "Valle Canto Tormenta",
    },
    [47963] = {
        name = "La antigua",
    },
    [47965] = {
        name = "El templo en ruinas",
    },
    [47968] = {
        name = "Señales y augurios",
    },
    [47969] = {
        name = "La maldición de Amparo del Ocaso",
    },
    [47978] = {
        name = "La vieja bruja díscola",
    },
    [47979] = {
        name = "Cacería de brujas",
    },
    [47980] = {
        name = "Familiares furiosos",
    },
    [47981] = {
        name = "Rota maldición",
    },
    [47982] = {
        name = "El fin de la efigie",
    },
    [47996] = {
        name = "Exterminación de faucemalignas",
    },
    [47998] = {
        name = "Asesinato de caníbales",
    },
    [48003] = {
        name = "La orden del lord",
    },
    [48004] = {
        name = "Equitación para principiantes",
    },
    [48005] = {
        name = "Siéntete como en casa",
    },
    [48008] = {
        name = "Cargamento peligroso",
    },
    [48009] = {
        name = "Traición de la guardia",
    },
    [48014] = {
        name = "Saca la basura",
    },
    [48015] = {
        name = "Los pergaminos de Gral",
    },
    [48025] = {
        name = "Guárdalo para después",
    },
    [48026] = {
        name = "Bajo las olas",
    },
    [48070] = {
        name = "El Festival de Norwington",
    },
    [48077] = {
        name = "La cacería de armiños",
    },
    [48080] = {
        name = "Una pizca de peligro",
    },
    [48087] = {
        name = "Recuperación equina",
    },
    [48088] = {
        name = "Entre tragos y troggs",
    },
    [48089] = {
        name = "Sonidos montañeses",
    },
    [48090] = {
        name = "Los elegidos de Krag'wa",
    },
    [48092] = {
        name = "La venganza de las ranas",
    },
    [48093] = {
        name = "No dejes naga con vida",
    },
    [48104] = {
        name = "Un desafío mayor",
    },
    [48108] = {
        name = "La hija Tarjasenda",
    },
    [48109] = {
        name = "El bosque tiene ojos",
    },
    [48110] = {
        name = "En caso de emboscada",
    },
    [48111] = {
        name = "Juicio por superstición",
    },
    [48113] = {
        name = "Una solución picante",
    },
    [48165] = {
        name = "Ingesta peligrosa",
    },
    [48170] = {
        name = "Pican, pican",
    },
    [48171] = {
        name = "La maldición de Hondonada Fletcher",
    },
    [48179] = {
        name = "Forestales en apuros",
    },
    [48180] = {
        name = "Gran problemón",
    },
    [48181] = {
        name = "No, no, no",
    },
    [48182] = {
        name = "No más hitos",
    },
    [48183] = {
        name = "Las colinas están vivas",
    },
    [48184] = {
        name = "Fragmentos de historia",
    },
    [48195] = {
        name = "Matones molestos",
    },
    [48196] = {
        name = "Tras el rastro de Eddie",
    },
    [48198] = {
        name = "El peso de la verdad",
    },
    [48237] = {
        name = "Derrota a Nekthara",
    },
    [48283] = {
        name = "La acusada",
    },
    [48313] = {
        name = "Un remedio natural",
    },
    [48314] = {
        name = "Arenas traicioneras",
    },
    [48315] = {
        name = "Una mirada vacía y profunda",
    },
    [48317] = {
        name = "Olfato mágico",
    },
    [48320] = {
        name = "¿Un oasis repleto de avispas?",
    },
    [48321] = {
        name = "Marketing creativo",
    },
    [48322] = {
        name = "Una bienvenida áurea",
    },
    [48324] = {
        name = "Perdidos en Zem'lan",
    },
    [48326] = {
        name = "Esto es un motín",
    },
    [48327] = {
        name = "Un pedido extraño",
    },
    [48329] = {
        name = "Golpeado pero jamás vencido",
    },
    [48330] = {
        name = "Tesoro zandalari",
    },
    [48331] = {
        name = "Almas succionantes",
    },
    [48332] = {
        name = "El recurso ranishu",
    },
    [48334] = {
        name = "Veo gólems de gente muerta",
    },
    [48335] = {
        name = "La cuerda más resistente de todo Vol'dun",
    },
    [48347] = {
        name = "Muelle Puntanzuelo",
    },
    [48348] = {
        name = "Púas hirientes",
    },
    [48352] = {
        name = "Una cura marina",
    },
    [48353] = {
        name = "Pulso del muelle",
    },
    [48354] = {
        name = "Envíos contaminados",
    },
    [48355] = {
        name = "Evacuación del perímetro",
    },
    [48356] = {
        name = "Protector de cabeza posesivo",
    },
    [48365] = {
        name = "El joven Lord Canto Tormenta",
    },
    [48366] = {
        name = "Remar por la salvación",
    },
    [48367] = {
        name = "Esos no son huevos de pescado",
    },
    [48368] = {
        name = "Profanación de las profundidades",
    },
    [48369] = {
        name = "Estrategia emergente",
    },
    [48370] = {
        name = "Muerte en las profundidades",
    },
    [48372] = {
        name = "Invocaciones siniestras",
    },
    [48399] = {
        name = "La amenaza tiene patas cortas",
    },
    [48400] = {
        name = "El gran robo telemántico",
    },
    [48402] = {
        name = "Toque venenoso",
    },
    [48404] = {
        name = "Los bribones",
    },
    [48405] = {
        name = "Sr. Sonrisa",
    },
    [48419] = {
        name = "Atraído y atrapado",
    },
    [48421] = {
        name = "Marea de sangre",
    },
    [48452] = {
        name = "El mercado rojo",
    },
    [48454] = {
        name = "Evidencia del mal",
    },
    [48456] = {
        name = "Médica bruja Jala.",
    },
    [48468] = {
        name = "La liberación de Bwonsamdi",
    },
    [48473] = {
        name = "Respeto a los ritos",
    },
    [48474] = {
        name = "Guardianes de la cripta",
    },
    [48475] = {
        name = "Clarividencia",
    },
    [48476] = {
        name = "Grupo separado",
    },
    [48477] = {
        name = "En busca de una más",
    },
    [48478] = {
        name = "El hogar de Kel'vax",
    },
    [48479] = {
        name = "Protección ósea",
    },
    [48480] = {
        name = "La caída de Kel'vax",
    },
    [48492] = {
        name = "A pierna suelta",
    },
    [48496] = {
        name = "Reunión de compañía",
    },
    [48497] = {
        name = "Muestra de fuerza",
    },
    [48498] = {
        name = "No tengas piedad con Sithis",
    },
    [48499] = {
        name = "Al polvo volverás",
    },
    [48504] = {
        name = "Por los caminos antiguos",
    },
    [48505] = {
        name = "Perdido y con el corazón roto",
    },
    [48515] = {
        name = "Espadas de plata",
    },
    [48516] = {
        name = "Comunidad tóxica",
    },
    [48517] = {
        name = "Baja honorable",
    },
    [48518] = {
        name = "Salvemos a los se pueda",
    },
    [48519] = {
        name = "Ojalá no sepan nadar",
    },
    [48520] = {
        name = "Las tres hermanas",
    },
    [48521] = {
        name = "Talismán anticautivos",
    },
    [48522] = {
        name = "Una misiva reveladora",
    },
    [48523] = {
        name = "La matrona homicida",
    },
    [48524] = {
        name = "La masacre del aquelarre",
    },
    [48525] = {
        name = "Hazlos polvo",
    },
    [48527] = {
        name = "Tierraburones voraces",
    },
    [48529] = {
        name = "Bocas hambrientas que alimentar",
    },
    [48530] = {
        name = "Un pastor sin rebaño",
    },
    [48531] = {
        name = "Carne misteriosa",
    },
    [48532] = {
        name = "Alpacas descontroladas",
    },
    [48533] = {
        name = "Pollo frito a la vol'duni",
    },
    [48534] = {
        name = "El que gruñe último...",
    },
    [48535] = {
        name = "Nazmir, el pantano prohibido",
    },
    [48538] = {
        name = "Una coartada impecable",
    },
    [48539] = {
        name = "Puerto Libre",
    },
    [48540] = {
        name = "Ayuda en el muelle",
    },
    [48549] = {
        name = "Grozztok el de Corazón Negro",
    },
    [48550] = {
        name = "Bolsos robados",
    },
    [48551] = {
        name = "Riega con la regadera de Ranah",
    },
    [48553] = {
        name = "Que fluya",
    },
    [48554] = {
        name = "La fuente del problema",
    },
    [48555] = {
        name = "Podemos rescatar las semillas",
    },
    [48557] = {
        name = "Sembrando las semillas",
    },
    [48558] = {
        name = "La tripulación mareaférrea",
    },
    [48573] = {
        name = "La vitalidad de los crocoliscos",
    },
    [48574] = {
        name = "Arráncales los colmillos",
    },
    [48576] = {
        name = "Vuelo seguro",
    },
    [48577] = {
        name = "Ovomatanza",
    },
    [48578] = {
        name = "Ojos de aterracielos",
    },
    [48581] = {
        name = "Una buena nalgada",
    },
    [48584] = {
        name = "La sangre de mis enemigos",
    },
    [48585] = {
        name = "Sobreviviente del páramo",
    },
    [48588] = {
        name = "Purga la infección",
    },
    [48590] = {
        name = "Mi cabeza y mis hombros",
    },
    [48591] = {
        name = "La verdadera muerte de Urok",
    },
    [48597] = {
        name = "Escape de sauroliscos",
    },
    [48606] = {
        name = "Cargado y listo",
    },
    [48616] = {
        name = "Aves y boleadoras",
    },
    [48622] = {
        name = "El señor evanescente",
    },
    [48655] = {
        name = "Aprendiz de chef",
    },
    [48656] = {
        name = "Sauroliscos salvajes",
    },
    [48657] = {
        name = "Quizá sean deliciosos",
    },
    [48669] = {
        name = "Urok, el Terror de los humedales",
    },
    [48670] = {
        name = "Jinete fugitivo",
    },
    [48677] = {
        name = "Culto del mimbre",
    },
    [48678] = {
        name = "Ofrendas dudosas",
    },
    [48679] = {
        name = "Cuidado con las colmenas",
    },
    [48680] = {
        name = "¡No! ¡Las abejas no!",
    },
    [48682] = {
        name = "Un sacrificio sencillo",
    },
    [48683] = {
        name = "Temporadas de cambio",
    },
    [48684] = {
        name = "En camino",
    },
    [48699] = {
        name = "Infiltración en Zalamar",
    },
    [48715] = {
        name = "Akunda aguarda",
    },
    [48773] = {
        name = "Los papeles, por favor",
    },
    [48774] = {
        name = "Las palizas continuarán",
    },
    [48776] = {
        name = "Un enredo",
    },
    [48778] = {
        name = "Sopa de piedra",
    },
    [48790] = {
        name = "Bienes robados",
    },
    [48792] = {
        name = "Una amenaza para la sociedad",
    },
    [48793] = {
        name = "Sociedad de aventureros",
    },
    [48800] = {
        name = "Marca del murciélago",
    },
    [48801] = {
        name = "Aislamiento de Zalamar",
    },
    [48804] = {
        name = "Errores y más errores",
    },
    [48805] = {
        name = "Recuperación de la investigación",
    },
    [48823] = {
        name = "Destrucción de proyecciones",
    },
    [48825] = {
        name = "Poder denegado",
    },
    [48840] = {
        name = "Venta piramidal en las ruinas",
    },
    [48846] = {
        name = "Motivación espirituosa",
    },
    [48847] = {
        name = "Armas para la tribu",
    },
    [48852] = {
        name = "Detén a Zardrax",
    },
    [48853] = {
        name = "Grado terminal",
    },
    [48854] = {
        name = "Oferta de poder",
    },
    [48855] = {
        name = "Adiós a los terrores",
    },
    [48856] = {
        name = "Conductos obstruidos",
    },
    [48857] = {
        name = "Todo está perdido",
    },
    [48869] = {
        name = "Exexánime",
    },
    [48871] = {
        name = "Recupera las reliquias",
    },
    [48872] = {
        name = "Menos charla y más excavación",
    },
    [48873] = {
        name = "Un final espantoso",
    },
    [48874] = {
        name = "Trampas tramposas",
    },
    [48879] = {
        name = "Cuando hay hambre...",
    },
    [48880] = {
        name = "Gaviotas malignas",
    },
    [48881] = {
        name = "¿Ya picó algo?",
    },
    [48882] = {
        name = "Me gustan las entrañas, me gustas tú",
    },
    [48883] = {
        name = "Una gaviota enfurecida",
    },
    [48887] = {
        name = "Purificación de la mente",
    },
    [48888] = {
        name = "La fuente más fuerte",
    },
    [48889] = {
        name = "Reparación del pasado",
    },
    [48890] = {
        name = "Aprende a ser un trol de sangre",
    },
    [48894] = {
        name = "Prueba de la verdad",
    },
    [48895] = {
        name = "La ofrenda perfecta",
    },
    [48896] = {
        name = "Conocimientos del pasado",
    },
    [48898] = {
        name = "Amuleto de la suerte",
    },
    [48899] = {
        name = "La seguridad primero",
    },
    [48902] = {
        name = "Energía monstruosa",
    },
    [48903] = {
        name = "A caballo regalado...",
    },
    [48904] = {
        name = "Toma la carnada",
    },
    [48905] = {
        name = "Pergaminos desapreciados",
    },
    [48909] = {
        name = "Una responsabilidad noble",
    },
    [48934] = {
        name = "Marca de los condenados",
    },
    [48939] = {
        name = "Demuéstrame lo que tienes",
    },
    [48941] = {
        name = "Un ligero desvío",
    },
    [48942] = {
        name = "La lucha contra el yeti",
    },
    [48943] = {
        name = "Derecho de salvamento",
    },
    [48944] = {
        name = "Descubrimiento histórico",
    },
    [48945] = {
        name = "Las ruinas de Gol Var",
    },
    [48946] = {
        name = "La Orden de las Ascuas",
    },
    [48948] = {
        name = "Las Cavernas del Paso del Norte",
    },
    [48963] = {
        name = "Tácticas de distracción",
    },
    [48965] = {
        name = "Cuentas saldadas",
    },
    [48986] = {
        name = "Busca a Lucille",
    },
    [48987] = {
        name = "Valle de las Penas",
    },
    [48988] = {
        name = "Recuerdos robados",
    },
    [48991] = {
        name = "Infestación vil",
    },
    [48992] = {
        name = "Restos sagrados",
    },
    [48993] = {
        name = "Conductores potentes",
    },
    [48996] = {
        name = "Ponerle fin a la locura",
    },
    [49001] = {
        name = "Espíritus inoportunos",
    },
    [49002] = {
        name = "Aterrizaje forzoso",
    },
    [49003] = {
        name = "Venganza desde las alturas",
    },
    [49005] = {
        name = "Devastado y destruido",
    },
    [49028] = {
        name = "Un suéter para Rupert",
    },
    [49036] = {
        name = "La estrella del espectáculo",
    },
    [49039] = {
        name = "El comienzo de una cacería de monstruos",
    },
    [49040] = {
        name = "Una despedida afectuosa",
    },
    [49059] = {
        name = "Los huesos de Xibala",
    },
    [49060] = {
        name = "Ecología xibalana",
    },
    [49064] = {
        name = "Torga, el loa de las tortugas",
    },
    [49066] = {
        name = "Un refrigerador primigenio",
    },
    [49067] = {
        name = "Búsqueda de Bwonsamdi",
    },
    [49069] = {
        name = "SE BUSCA: Viejo Garrascarcha",
    },
    [49070] = {
        name = "Almas para el loa de la muerte",
    },
    [49071] = {
        name = "Combustión de espantácaros",
    },
    [49072] = {
        name = "Noble oriental",
    },
    [49078] = {
        name = "Veneno para la cría",
    },
    [49079] = {
        name = "Hir'eek, el loa murciélago",
    },
    [49080] = {
        name = "Cese de invocaciones",
    },
    [49081] = {
        name = "Matar un loa",
    },
    [49082] = {
        name = "Arriba y adelante",
    },
    [49120] = {
        name = "Comunicación espiritual",
    },
    [49122] = {
        name = "Un puerto en peligro",
    },
    [49125] = {
        name = "Sangre negativa",
    },
    [49126] = {
        name = "Forzando la mano del destino",
    },
    [49130] = {
        name = "Una dieta libre de loa",
    },
    [49131] = {
        name = "Santificación del suelo",
    },
    [49132] = {
        name = "Tritura los cráneos de los trituracráneos",
    },
    [49136] = {
        name = "Jungo, Heraldo de G'huun",
    },
    [49138] = {
        name = "Tesoro del capitán Gulnaku",
    },
    [49139] = {
        name = "El arsenal de un ejército",
    },
    [49141] = {
        name = "Diplomacia y dominio",
    },
    [49144] = {
        name = "La ira de los zandalari",
    },
    [49145] = {
        name = "Ningún trol queda atrás",
    },
    [49146] = {
        name = "Pertenencias de los espíritus",
    },
    [49147] = {
        name = "Demostración de fuerza",
    },
    [49148] = {
        name = "Desmoronamiento",
    },
    [49149] = {
        name = "Acepta el vudú",
    },
    [49160] = {
        name = "El regreso eterno de Torga",
    },
    [49178] = {
        name = "Mis objetos favoritos",
    },
    [49181] = {
        name = "Guardapelo brillante",
    },
    [49185] = {
        name = "Al día",
    },
    [49218] = {
        name = "Los náufragos",
    },
    [49223] = {
        name = "La gran estafa",
    },
    [49225] = {
        name = "En busca de la líder",
    },
    [49226] = {
        name = "El silencio de las hermanas",
    },
    [49227] = {
        name = "La llave maestra",
    },
    [49229] = {
        name = "Las ruinas se defienden",
    },
    [49230] = {
        name = "Sabor local",
    },
    [49232] = {
        name = "Salvamento de un desastre",
    },
    [49233] = {
        name = "Soy un druida, no un sacerdote",
    },
    [49234] = {
        name = "Rescatando al soldado Redfen",
    },
    [49239] = {
        name = "Entrada libre",
    },
    [49242] = {
        name = "Un camino de espinas",
    },
    [49259] = {
        name = "Que se haga justicia",
    },
    [49260] = {
        name = "Cuida mi espalda y yo cuidaré mis reliquias",
    },
    [49261] = {
        name = "Un estupendo estofado de cangrejo de estación",
    },
    [49262] = {
        name = "Un poco de disciplina",
    },
    [49268] = {
        name = "Tiburones en las aguas",
    },
    [49274] = {
        name = "La investigación de Morgrum",
    },
    [49276] = {
        name = "La emoción de explorar",
    },
    [49278] = {
        name = "Restauración espiritual",
    },
    [49282] = {
        name = "La investigación extendida de Morgrum",
    },
    [49283] = {
        name = "¿Quién busca a los buscadores?",
    },
    [49284] = {
        name = "Sabueso de mareas",
    },
    [49285] = {
        name = "Tesoritos",
    },
    [49286] = {
        name = "Sabiduría enjaulada",
    },
    [49287] = {
        name = "Quelónidos perdidos",
    },
    [49288] = {
        name = "Cazapergaminos",
    },
    [49289] = {
        name = "Una piedra especial",
    },
    [49290] = {
        name = "El sabor del añejamiento",
    },
    [49292] = {
        name = "Estrujones marinos",
    },
    [49295] = {
        name = "Despeja los flancos",
    },
    [49299] = {
        name = "El enemigo interior",
    },
    [49300] = {
        name = "Corrupción de las criaturas",
    },
    [49302] = {
        name = "Pesca mortal",
    },
    [49309] = {
        name = "El trueno entre tus manos",
    },
    [49310] = {
        name = "El plan del profeta",
    },
    [49314] = {
        name = "A la caza de Zardrax",
    },
    [49315] = {
        name = "Complot Perlaterror",
    },
    [49327] = {
        name = "¡Ahuyéntalos!",
    },
    [49333] = {
        name = "Armas para el arsenal",
    },
    [49334] = {
        name = "Un prisionero poderoso",
    },
    [49335] = {
        name = "La masacre de los clamacielos",
    },
    [49340] = {
        name = "Las llaves de los guardianes",
    },
    [49348] = {
        name = "Un templo profanado",
    },
    [49366] = {
        name = "Asiste al herido",
    },
    [49370] = {
        name = "Rescata al Cronista",
    },
    [49377] = {
        name = "Dile adiós a tu cabeza",
    },
    [49378] = {
        name = "Gánate su confianza",
    },
    [49379] = {
        name = "Zona libre de crustájeos",
    },
    [49380] = {
        name = "Malas vibras",
    },
    [49382] = {
        name = "Parece que tienes un nuevo amigo",
    },
    [49393] = {
        name = "Los Rabaleros",
    },
    [49394] = {
        name = "Quieeetas",
    },
    [49395] = {
        name = "Miel para gol-osos",
    },
    [49398] = {
        name = "¡Un brindis!",
    },
    [49399] = {
        name = "El gran trabajo",
    },
    [49400] = {
        name = "Campaña de reclutamiento",
    },
    [49401] = {
        name = "El aviario de Rodrigo",
    },
    [49402] = {
        name = "Escape de prisión",
    },
    [49403] = {
        name = "La venganza de Rodrigo",
    },
    [49404] = {
        name = "\"Amigos\" de Céfiro",
    },
    [49405] = {
        name = "Defensores de la Puerta de Daelin",
    },
    [49406] = {
        name = "Masacre en Zalamar",
    },
    [49407] = {
        name = "Mala espina",
    },
    [49408] = {
        name = "Dados pirata",
    },
    [49409] = {
        name = "¡Tesoro perdido!",
    },
    [49411] = {
        name = "Construcción de cuarteles",
    },
    [49412] = {
        name = "Una ayuda para Henry",
    },
    [49417] = {
        name = "Jinetes rabaleros",
    },
    [49418] = {
        name = "El jefazo",
    },
    [49419] = {
        name = "Congelado",
    },
    [49421] = {
        name = "La cacería de Zul",
    },
    [49422] = {
        name = "Herejes",
    },
    [49424] = {
        name = "La profecía completa",
    },
    [49425] = {
        name = "Ciudad de oro",
    },
    [49426] = {
        name = "La estrategia del rey",
    },
    [49427] = {
        name = "Esos elfos morados no nos pertenecen",
    },
    [49428] = {
        name = "El gran robo telemántico",
    },
    [49431] = {
        name = "Calentito",
    },
    [49432] = {
        name = "Un alma abandonada",
    },
    [49433] = {
        name = "De wendigo a mendigo",
    },
    [49435] = {
        name = "¿A dónde se fueron?",
    },
    [49437] = {
        name = "Nota hecha trizas",
    },
    [49439] = {
        name = "La venganza del jefe",
    },
    [49440] = {
        name = "Una trol de sangre por fuera...",
    },
    [49443] = {
        name = "Introducción a la cacería de brujas",
    },
    [49450] = {
        name = "Informes de incidentes",
    },
    [49451] = {
        name = "Solicitudes de descanso",
    },
    [49452] = {
        name = "Déficit de inventario",
    },
    [49453] = {
        name = "Presas del destino",
    },
    [49454] = {
        name = "Prevención de plagas",
    },
    [49464] = {
        name = "Colas de saurolisco",
    },
    [49465] = {
        name = "Aprovechamiento máximo",
    },
    [49467] = {
        name = "La bruja del bosque",
    },
    [49468] = {
        name = "Red de trabajo",
    },
    [49477] = {
        name = "Refuerzos sorpresa",
    },
    [49479] = {
        name = "No lo pensaron dos veces",
    },
    [49489] = {
        name = "Solo falta un cuerpo",
    },
    [49490] = {
        name = "La urna de las voces",
    },
    [49491] = {
        name = "Alimento para el vudú",
    },
    [49492] = {
        name = "Arrogancia de Vol'jamba",
    },
    [49493] = {
        name = "El dilema ético de Zul",
    },
    [49494] = {
        name = "Brebaje de zuvembi",
    },
    [49495] = {
        name = "Una ayuda para el destino",
    },
    [49522] = {
        name = "El pago de Carentan",
    },
    [49523] = {
        name = "Un pésimo trato",
    },
    [49529] = {
        name = "Limpieza manantial",
    },
    [49531] = {
        name = "La belleza del marketing",
    },
    [49569] = {
        name = "Río abajo",
    },
    [49570] = {
        name = "Un comienzo pedregoso",
    },
    [49571] = {
        name = "Excavaciones del pasado",
    },
    [49572] = {
        name = "El Santuario del Mar",
    },
    [49573] = {
        name = "El Santuario del Manto de la Noche",
    },
    [49574] = {
        name = "El Santuario de Tormentas",
    },
    [49575] = {
        name = "Tol Dagor: Joya de las mareas",
    },
    [49576] = {
        name = "Prospección santificada",
    },
    [49577] = {
        name = "Bajo la superficie",
    },
    [49581] = {
        name = "Dunas soleadas",
    },
    [49582] = {
        name = "Atal'Dazar: No todo lo que brilla...",
    },
    [49583] = {
        name = "Lo pasado, pisado",
    },
    [49584] = {
        name = "El capítulo faltante",
    },
    [49585] = {
        name = "Un comienzo pedregoso",
    },
    [49586] = {
        name = "Excavaciones del pasado",
    },
    [49587] = {
        name = "El Santuario de Naturaleza",
    },
    [49588] = {
        name = "El Santuario de las Arenas",
    },
    [49589] = {
        name = "El Santuario del Alba",
    },
    [49599] = {
        name = "El capítulo faltante",
    },
    [49615] = {
        name = "La confianza de un rey",
    },
    [49661] = {
        name = "Suministro local de huevos",
    },
    [49662] = {
        name = "La llave faltante",
    },
    [49663] = {
        name = "Falsas profecías",
    },
    [49664] = {
        name = "Aliados en tiempos de anarquía",
    },
    [49665] = {
        name = "Listos para la batalla",
    },
    [49666] = {
        name = "Que los invada el terror",
    },
    [49667] = {
        name = "Los pequeñines",
    },
    [49668] = {
        name = "Incendia el barranco",
    },
    [49669] = {
        name = "Libera a las bestias",
    },
    [49676] = {
        name = "Vestido para la batalla",
    },
    [49677] = {
        name = "Planes de ataque",
    },
    [49678] = {
        name = "Entre espiras y escamas",
    },
    [49679] = {
        name = "La incursión sethrak",
    },
    [49680] = {
        name = "Clamacielos Soltok",
    },
    [49681] = {
        name = "Tikita",
    },
    [49694] = {
        name = "Un drusto conocerte",
    },
    [49703] = {
        name = "Casa Canto Tormenta",
    },
    [49704] = {
        name = "Cosechadores confundidos",
    },
    [49705] = {
        name = "Dureza innecesaria",
    },
    [49706] = {
        name = "Investigación de proclamaciones",
    },
    [49710] = {
        name = "Una ofrenda de huevos",
    },
    [49715] = {
        name = "Problemas en la Fortaleza Petragrís",
    },
    [49716] = {
        name = "Una lección de confianza",
    },
    [49719] = {
        name = "Un pago justo",
    },
    [49720] = {
        name = "Libre como el viento",
    },
    [49725] = {
        name = "Una estratagema arriesgada",
    },
    [49730] = {
        name = "SE BUSCA: Truenahocico",
    },
    [49731] = {
        name = "Una despedida afectuosa",
    },
    [49733] = {
        name = "Parches en la retaguardia",
    },
    [49734] = {
        name = "Atrapa al traidor",
    },
    [49735] = {
        name = "Protege los nidos",
    },
    [49736] = {
        name = "¡Por Kul Tiras!",
    },
    [49737] = {
        name = "Asalto aéreo",
    },
    [49738] = {
        name = "¡Quita tus manos de ahí!",
    },
    [49739] = {
        name = "Enemigos en las puertas",
    },
    [49740] = {
        name = "¡Alto el fuego!",
    },
    [49741] = {
        name = "Retribución justa",
    },
    [49744] = {
        name = "Fuera bombas",
    },
    [49745] = {
        name = "Órdenes recibidas",
    },
    [49746] = {
        name = "Sofocando las llamas",
    },
    [49753] = {
        name = "Construcción de Armería",
    },
    [49754] = {
        name = "No \"solo Zul\"",
    },
    [49755] = {
        name = "Artillería pesada",
    },
    [49757] = {
        name = "La gata sobre el tejado de cobre",
    },
    [49758] = {
        name = "¡Envía la señal!",
    },
    [49759] = {
        name = "Construcción de taller",
    },
    [49766] = {
        name = "Tu próximo movimiento",
    },
    [49767] = {
        name = "Tu próximo movimiento",
    },
    [49768] = {
        name = "Sendero de Nesingwary",
    },
    [49769] = {
        name = "Restos del Cataclismo",
    },
    [49774] = {
        name = "Todas las hojas dulces son del viento",
    },
    [49775] = {
        name = "La llave de la prisión",
    },
    [49776] = {
        name = "Una cucharadita de alquitrán",
    },
    [49777] = {
        name = "La fuga",
    },
    [49778] = {
        name = "No vayas hacia la luz",
    },
    [49779] = {
        name = "Maldad hasta los huesos",
    },
    [49780] = {
        name = "Recuperación del fuego ancestral",
    },
    [49781] = {
        name = "Atrápame si puedes",
    },
    [49785] = {
        name = "Destruye el arma",
    },
    [49791] = {
        name = "Perdidos, pero no olvidados",
    },
    [49792] = {
        name = "Atrapados y oprimidos",
    },
    [49793] = {
        name = "Medios para un fin",
    },
    [49794] = {
        name = "La marea creciente",
    },
    [49801] = {
        name = "Estrategia de apareamiento agresiva",
    },
    [49803] = {
        name = "Un cambio en la guardia",
    },
    [49804] = {
        name = "Un pinchazo de realidad",
    },
    [49805] = {
        name = "Implementos con intenciones inapropiadas",
    },
    [49806] = {
        name = "Asuntos internos",
    },
    [49807] = {
        name = "Nuevas órdenes",
    },
    [49810] = {
        name = "Cupido jurásico",
    },
    [49814] = {
        name = "Aroma para un brutosaurio",
    },
    [49818] = {
        name = "Problemas en el Fuerte Daelin",
    },
    [49831] = {
        name = "Desde las profundidades",
    },
    [49832] = {
        name = "Un pergamino ilegible",
    },
    [49869] = {
        name = "Una defensa desesperada",
    },
    [49870] = {
        name = "El tamaño importa",
    },
    [49871] = {
        name = "Contra la marea",
    },
    [49873] = {
        name = "Escritos de sacrificio",
    },
    [49874] = {
        name = "Al pie de la letra",
    },
    [49876] = {
        name = "La travesía del desierto",
    },
    [49877] = {
        name = "Templo de Sethraliss: Un favor literario",
    },
    [49878] = {
        name = "Protección de la pluma",
    },
    [49879] = {
        name = "Roce con la muerte",
    },
    [49881] = {
        name = "El último verso",
    },
    [49882] = {
        name = "Prueba de plumas",
    },
    [49884] = {
        name = "La luz azul de la esperanza",
    },
    [49886] = {
        name = "Sigue tu olfato",
    },
    [49887] = {
        name = "Trabajos forzados",
    },
    [49890] = {
        name = "El ocaso de los drust",
    },
    [49896] = {
        name = "¡Hacia Halcónida!",
    },
    [49897] = {
        name = "Maestros del misterio",
    },
    [49898] = {
        name = "Una victoria clara",
    },
    [49901] = {
        name = "Atal'Dazar: Yazma la Sacerdotisa caída",
    },
    [49902] = {
        name = "Hacia Hondonada Penumbrosa",
    },
    [49905] = {
        name = "Giro argumental",
    },
    [49908] = {
        name = "Regreso a Presabrenna",
    },
    [49917] = {
        name = "¿Kaja'mita? ¡Toda mía!",
    },
    [49918] = {
        name = "Cañón de Gorilas",
    },
    [49919] = {
        name = "Mena de kaja'mita minada",
    },
    [49920] = {
        name = "Guerra de gorilas",
    },
    [49922] = {
        name = "Rey Da'ka",
    },
    [49926] = {
        name = "El camino hacia Corlain",
    },
    [49932] = {
        name = "Hora de despertarse",
    },
    [49935] = {
        name = "Cómo reparar un guardián titánico",
    },
    [49937] = {
        name = "Recuperación de los restos",
    },
    [49938] = {
        name = "Tierra corrupta",
    },
    [49939] = {
        name = "Adiós, hermana",
    },
    [49940] = {
        name = "Brecha Cicatriz Arenácea",
    },
    [49941] = {
        name = "Procesamiento óseo.",
    },
    [49943] = {
        name = "Firma sangrienta",
    },
    [49944] = {
        name = "Un drusto conocerte",
    },
    [49946] = {
        name = "La travesía del desierto",
    },
    [49949] = {
        name = "No-muertos no bienvenidos",
    },
    [49950] = {
        name = "Purificación de sangre",
    },
    [49955] = {
        name = "No apto para este mundo",
    },
    [49956] = {
        name = "El Vacío queda prohibido",
    },
    [49957] = {
        name = "Recuperación del protocolo",
    },
    [49960] = {
        name = "¡Al ataque!",
    },
    [49965] = {
        name = "La manada de guerra",
    },
    [49969] = {
        name = "El despertar de un dios",
    },
    [49975] = {
        name = "Descansa en las profundidades",
    },
    [49980] = {
        name = "Procedimiento de contención",
    },
    [49985] = {
        name = "Regresa a Hondonada Penumbrosa",
    },
    [49995] = {
        name = "Falsedades falseadas",
    },
    [49996] = {
        name = "Rearme",
    },
    [49997] = {
        name = "Juicio de la tormenta",
    },
    [49998] = {
        name = "Voces desde las profundidades",
    },
    [50001] = {
        name = "Una cacería de brujas",
    },
    [50002] = {
        name = "Un cargamento muy preciado",
    },
    [50003] = {
        name = "La primera avanzada",
    },
    [50005] = {
        name = "Toma mi mano",
    },
    [50009] = {
        name = "Equipo de salvamento del naufragio",
    },
    [50026] = {
        name = "Salva a nuestros compañeros",
    },
    [50036] = {
        name = "Arma de tiempos pasados",
    },
    [50041] = {
        name = "Un puñado de cartuchos",
    },
    [50043] = {
        name = "Eficacia arqueológica",
    },
    [50044] = {
        name = "Eficacia arqueológica",
    },
    [50058] = {
        name = "La mascota de la bruja",
    },
    [50059] = {
        name = "No escucho nada",
    },
    [50063] = {
        name = "Contraataque de fuego",
    },
    [50064] = {
        name = "No vayas al sótano",
    },
    [50065] = {
        name = "Una razón para quedarse",
    },
    [50069] = {
        name = "La guerra de Campoáureo",
    },
    [50074] = {
        name = "Estímulo brutal",
    },
    [50076] = {
        name = "Reúne a los guerreros",
    },
    [50078] = {
        name = "Tótems imperecederos",
    },
    [50079] = {
        name = "La bomba hace bum",
    },
    [50080] = {
        name = "Asalto a los asaltantes",
    },
    [50081] = {
        name = "La ruta del dolor",
    },
    [50082] = {
        name = "Oportunidad única",
    },
    [50083] = {
        name = "La madre de lo' crustájeos",
    },
    [50085] = {
        name = "Mensaje de sangre y fuego",
    },
    [50087] = {
        name = "La caída de Ateena",
    },
    [50088] = {
        name = "Campo áureo, descansa en paz",
    },
    [50090] = {
        name = "Construcción de defensas",
    },
    [50091] = {
        name = "Reparación del pueblo",
    },
    [50092] = {
        name = "Extrafuertes",
    },
    [50110] = {
        name = "Portadores de malas noticias",
    },
    [50111] = {
        name = "¡Tótems, tótems, tótems!",
    },
    [50112] = {
        name = "Que arroje la primera piedra",
    },
    [50113] = {
        name = "Extracción ocular",
    },
    [50114] = {
        name = "Interrogatorio hostil",
    },
    [50115] = {
        name = "Cambio de escenario",
    },
    [50116] = {
        name = "Una solución posible",
    },
    [50117] = {
        name = "Un cóctel mortal",
    },
    [50118] = {
        name = "Tiro de piedra",
    },
    [50119] = {
        name = "Compuesto químico",
    },
    [50120] = {
        name = "Receta para el éxito",
    },
    [50121] = {
        name = "Que arroje la primera piedra",
    },
    [50122] = {
        name = "Extracción ocular",
    },
    [50123] = {
        name = "Una receta para la eternidad",
    },
    [50124] = {
        name = "Cambio de escenario",
    },
    [50125] = {
        name = "Una solución posible",
    },
    [50126] = {
        name = "Un cóctel mortal",
    },
    [50127] = {
        name = "Tiro de piedra",
    },
    [50128] = {
        name = "Compuesto químico",
    },
    [50129] = {
        name = "Receta para el éxito",
    },
    [50133] = {
        name = "Aplasta hierbas",
    },
    [50134] = {
        name = "Dispositivos y gizmos a montones",
    },
    [50135] = {
        name = "¡Basta de enredaderas!",
    },
    [50136] = {
        name = "Granja mecanizada",
    },
    [50138] = {
        name = "La batalla del Barranco Sangre Ardiente",
    },
    [50139] = {
        name = "El eslabón perdido",
    },
    [50149] = {
        name = "Un ojo alerta",
    },
    [50150] = {
        name = "Preparando el terreno",
    },
    [50151] = {
        name = "La angustia de Angus",
    },
    [50152] = {
        name = "Búsqueda de desechos",
    },
    [50154] = {
        name = "Dicen que es una delicia",
    },
    [50157] = {
        name = "Hacia los campos dorados",
    },
    [50158] = {
        name = "Revisa el derrumbamiento",
    },
    [50161] = {
        name = "Recupera a Raimond",
    },
    [50162] = {
        name = "Situación pegajosa",
    },
    [50165] = {
        name = "Cada abeja en su colmena",
    },
    [50168] = {
        name = "Sucesión real",
    },
    [50172] = {
        name = "En el Bosque Carmesí",
    },
    [50173] = {
        name = "Metales preciosos",
    },
    [50174] = {
        name = "Envuelto en telarañas",
    },
    [50175] = {
        name = "Una maldición con ocho patas",
    },
    [50177] = {
        name = "¡Defiende la barricada!",
    },
    [50178] = {
        name = "Problemas en Sendarraíz",
    },
    [50195] = {
        name = "Brigada de Magullalote",
    },
    [50206] = {
        name = "Contraataque",
    },
    [50235] = {
        name = "Sin refugio",
    },
    [50238] = {
        name = "Cardón",
    },
    [50240] = {
        name = "Los juegos del hambre",
    },
    [50249] = {
        name = "Triple amenaza en Boralus",
    },
    [50251] = {
        name = "Hechizados",
    },
    [50252] = {
        name = "Tiempo muerto en la temporada de apareamiento",
    },
    [50253] = {
        name = "Un arsenal improvisado",
    },
    [50264] = {
        name = "Mozos melosos",
    },
    [50265] = {
        name = "Rescatando al maestro Ashton",
    },
    [50266] = {
        name = "Agridulce",
    },
    [50268] = {
        name = "Una gota de sabor",
    },
    [50270] = {
        name = "En las profundidades del núcleo",
    },
    [50271] = {
        name = "Arrebato",
    },
    [50272] = {
        name = "Mensajes de la tierra",
    },
    [50274] = {
        name = "Forja titánica",
    },
    [50275] = {
        name = "Lluvia de yunques",
    },
    [50276] = {
        name = "Una receta para la eternidad",
    },
    [50277] = {
        name = "Interrogatorio hostil",
    },
    [50278] = {
        name = "En las profundidades del núcleo",
    },
    [50279] = {
        name = "Lluvia de yunques",
    },
    [50288] = {
        name = "La elección de Therazane",
    },
    [50297] = {
        name = "La cabeza del enemigo",
    },
    [50306] = {
        name = "De todo un poco",
    },
    [50325] = {
        name = "Interrupción del gran rito",
    },
    [50327] = {
        name = "Un pequeño energizante",
    },
    [50328] = {
        name = "Aromatizantes poco convencionales",
    },
    [50329] = {
        name = "Matronas del Bosque Carmesí",
    },
    [50331] = {
        name = "Un resultado diferente",
    },
    [50332] = {
        name = "El gran cazado'",
    },
    [50340] = {
        name = "El que roba a un ladrón...",
    },
    [50343] = {
        name = "Pánico y locura en la Hidromielería de Mildenhall",
    },
    [50349] = {
        name = "Una mina infestada",
    },
    [50350] = {
        name = "Necesitamos a un químico",
    },
    [50351] = {
        name = "Operación de minería",
    },
    [50352] = {
        name = "Una pizca de azerita",
    },
    [50353] = {
        name = "Fuera, zarzalomo, fuera",
    },
    [50354] = {
        name = "¡Detenlos \"otearán\" pedazos!",
    },
    [50356] = {
        name = "Rocas y dinamita",
    },
    [50359] = {
        name = "Trabajo de limpieza",
    },
    [50363] = {
        name = "Cerdos de guerra",
    },
    [50365] = {
        name = "Corre a las colinas",
    },
    [50367] = {
        name = "Cólera embotellada",
    },
    [50368] = {
        name = "El terror del horado",
    },
    [50370] = {
        name = "En lo profundo del bosque",
    },
    [50376] = {
        name = "Trofeo más preciado: Pescado rabioso",
    },
    [50381] = {
        name = "El gran robo del sombrero",
    },
    [50385] = {
        name = "Compromiso incansable",
    },
    [50386] = {
        name = "La sal del mal",
    },
    [50387] = {
        name = "Abalorios y baratijas",
    },
    [50388] = {
        name = "El peso de mi ambición",
    },
    [50389] = {
        name = "Inspiración maligna",
    },
    [50391] = {
        name = "Trofeo más preciado: Pesca de armas",
    },
    [50393] = {
        name = "Cría de Pa'ku",
    },
    [50394] = {
        name = "Ahora es tú problema",
    },
    [50395] = {
        name = "El llamado de los cielos",
    },
    [50396] = {
        name = "Un destino pterrible",
    },
    [50397] = {
        name = "Aspiraciones aéreas",
    },
    [50401] = {
        name = "Miedo a caer",
    },
    [50402] = {
        name = "¡RIIIIII!",
    },
    [50412] = {
        name = "De vuelta al nido",
    },
    [50417] = {
        name = "La ruina ha llegado",
    },
    [50418] = {
        name = "Trofeo más preciado: Hundimiento y nado",
    },
    [50433] = {
        name = "Segregación zanchuli",
    },
    [50444] = {
        name = "Desloa al loa",
    },
    [50445] = {
        name = "El control de la situación",
    },
    [50446] = {
        name = "Matando brujas",
    },
    [50447] = {
        name = "En memoria de los caídos",
    },
    [50448] = {
        name = "Recuperación de Corlain",
    },
    [50449] = {
        name = "Amparo apestoso",
    },
    [50450] = {
        name = "Una cosecha ofensiva",
    },
    [50451] = {
        name = "Defensas devoradas",
    },
    [50452] = {
        name = "Protección potente",
    },
    [50453] = {
        name = "Barrera borrada",
    },
    [50454] = {
        name = "La muerte de un traidor",
    },
    [50455] = {
        name = "Fuera del nido",
    },
    [50456] = {
        name = "Halcones hechizados",
    },
    [50457] = {
        name = "Ábrete paso",
    },
    [50466] = {
        name = "¡Ha enloquecido!",
    },
    [50481] = {
        name = "En el salón del rey drust",
    },
    [50493] = {
        name = "En busca de Wrex",
    },
    [50504] = {
        name = "Sam el meloso",
    },
    [50520] = {
        name = "¿Dónde está Sam?",
    },
    [50530] = {
        name = "¿Dónde está la salida?",
    },
    [50531] = {
        name = "Bajo sus narices",
    },
    [50533] = {
        name = "¡Muéstrales quién manda!",
    },
    [50534] = {
        name = "¡Fuera wendigo digo!",
    },
    [50535] = {
        name = "El poder de la sobrestante",
    },
    [50536] = {
        name = "Dispositivo decodificador mágico",
    },
    [50538] = {
        name = "Se busca: adiestrador",
    },
    [50539] = {
        name = "Los secretos de Zul'Ahjin",
    },
    [50542] = {
        name = "Una oportunidad explosiva",
    },
    [50544] = {
        name = "Los cazadores del Recinto de Kennings",
    },
    [50550] = {
        name = "La caída del emperador Korthek",
    },
    [50551] = {
        name = "Templo de Sethraliss: Avatar de la loa",
    },
    [50553] = {
        name = "De vuelta al laboratorio",
    },
    [50561] = {
        name = "Piedra de Sulthis",
    },
    [50573] = {
        name = "Mensaje de la administración",
    },
    [50583] = {
        name = "Hacia el otro lado",
    },
    [50584] = {
        name = "Rituales en ruinas",
    },
    [50585] = {
        name = "¡Abramatanza!",
    },
    [50586] = {
        name = "La caída de Corlain",
    },
    [50588] = {
        name = "Asedio a la mansión",
    },
    [50593] = {
        name = "Mala sangre",
    },
    [50594] = {
        name = "Bajo el velo",
    },
    [50595] = {
        name = "Sin piedad",
    },
    [50596] = {
        name = "Extermina a la escoria",
    },
    [50598] = {
        name = "Imperio zandalari",
    },
    [50599] = {
        name = "Almirantazgo Valiente",
    },
    [50600] = {
        name = "Orden de las Ascuas",
    },
    [50601] = {
        name = "Estela de la Tormenta",
    },
    [50602] = {
        name = "Expedición de Talanji",
    },
    [50605] = {
        name = "Esfuerzo de guerra de la Alianza",
    },
    [50606] = {
        name = "Esfuerzo de guerra de la Horda",
    },
    [50608] = {
        name = "Ritos prohibidos",
    },
    [50609] = {
        name = "Desde las fauces de la locura",
    },
    [50610] = {
        name = "La tormenta se cierne",
    },
    [50611] = {
        name = "La venganza de la tormenta",
    },
    [50612] = {
        name = "Una casa dividida",
    },
    [50614] = {
        name = "Libertad para el mar",
    },
    [50616] = {
        name = "Vínculo asesino",
    },
    [50621] = {
        name = "Atrapados en la red",
    },
    [50622] = {
        name = "Rescate en la granja",
    },
    [50635] = {
        name = "Mareas cambiantes",
    },
    [50639] = {
        name = "Mansión Tarjasenda: La madre caída",
    },
    [50640] = {
        name = "Gigante, y con espinas",
    },
    [50641] = {
        name = "Acaba con sus filas",
    },
    [50644] = {
        name = "Enfrenta a los invasores",
    },
    [50645] = {
        name = "Pesca de colmillos",
    },
    [50649] = {
        name = "Migajas de los ladrones",
    },
    [50653] = {
        name = "Recuperemos nuestras defensas",
    },
    [50656] = {
        name = "Rescate arriesgado",
    },
    [50672] = {
        name = "Tus municiones, mis municiones",
    },
    [50674] = {
        name = "Escoria pirata de dos caras",
    },
    [50675] = {
        name = "Búsqueda de tesoros",
    },
    [50679] = {
        name = "Perforación del escudo",
    },
    [50690] = {
        name = "Con Moxie",
    },
    [50691] = {
        name = "Esto no era parte del trabajo",
    },
    [50696] = {
        name = "Atracción magnética",
    },
    [50697] = {
        name = "La bomba le gana a la roca",
    },
    [50698] = {
        name = "Solución de problemas con pólvora",
    },
    [50699] = {
        name = "Derechos del trabajador",
    },
    [50700] = {
        name = "Drusto a tiempo",
    },
    [50702] = {
        name = "Derrota a Jakra'zet",
    },
    [50703] = {
        name = "Informe para la Horda",
    },
    [50704] = {
        name = "Leven anclas y a vender",
    },
    [50705] = {
        name = "Serpiente de tres cabezas",
    },
    [50706] = {
        name = "Despeja el delta",
    },
    [50733] = {
        name = "Un nuevo amanecer",
    },
    [50739] = {
        name = "Turones en apurotes",
    },
    [50741] = {
        name = "A paso de tortuga",
    },
    [50742] = {
        name = "Al alcance de la mano",
    },
    [50743] = {
        name = "El problema inmediato",
    },
    [50745] = {
        name = "Infiltración en el imperio",
    },
    [50746] = {
        name = "Cráter conquistado",
    },
    [50748] = {
        name = "Con cuidado...",
    },
    [50749] = {
        name = "Viaje gratis",
    },
    [50750] = {
        name = "La furia del emperador",
    },
    [50751] = {
        name = "Santuario en peligro",
    },
    [50752] = {
        name = "Reliquias de Sethraliss",
    },
    [50753] = {
        name = "Al que Madrug-A, la Luz lo ayuda",
    },
    [50754] = {
        name = "Amar y perder...",
    },
    [50755] = {
        name = "Alimento de aves",
    },
    [50757] = {
        name = "Matanza indomable",
    },
    [50758] = {
        name = "Recuerdos dolorosos",
    },
    [50759] = {
        name = "El tiempo corre",
    },
    [50760] = {
        name = "Hasta que las muerte nos separe",
    },
    [50761] = {
        name = "Sangre en la capilla",
    },
    [50762] = {
        name = "El destino de la dama",
    },
    [50763] = {
        name = "Un último pedido",
    },
    [50769] = {
        name = "La extracción de Ventormenta",
    },
    [50770] = {
        name = "Antídoto eficaz",
    },
    [50771] = {
        name = "A trabajar, limpiadores",
    },
    [50773] = {
        name = "Eres un tiburón",
    },
    [50774] = {
        name = "Ningún robot queda atrás",
    },
    [50775] = {
        name = "Un poco de playa para nosotros",
    },
    [50777] = {
        name = "Se avecina la tormenta",
    },
    [50778] = {
        name = "Intenciones retorcidas",
    },
    [50779] = {
        name = "Un nuevo comienzo",
    },
    [50780] = {
        name = "Juramentos solemnes",
    },
    [50781] = {
        name = "Un puente demasiado lejos",
    },
    [50783] = {
        name = "El consejo abisal",
    },
    [50784] = {
        name = "El ojo de la tormenta",
    },
    [50787] = {
        name = "Evidencia contundente",
    },
    [50788] = {
        name = "Enemigos interiores",
    },
    [50789] = {
        name = "Despeja el aire",
    },
    [50790] = {
        name = "Persecución desenfrenada",
    },
    [50791] = {
        name = "Riiii...",
    },
    [50793] = {
        name = "Conmoción subterránea",
    },
    [50794] = {
        name = "Se busca: refugio",
    },
    [50795] = {
        name = "Prepárate para los problemas",
    },
    [50796] = {
        name = "¡RIIIIII!",
    },
    [50797] = {
        name = "La invitación de una tortuga",
    },
    [50798] = {
        name = "En una pata",
    },
    [50801] = {
        name = "La curiosidad mató al pterrordáctilo",
    },
    [50802] = {
        name = "Mareamuerta",
    },
    [50803] = {
        name = "Lo quiero todo y lo quiero ya",
    },
    [50805] = {
        name = "Apagón de clamacielos",
    },
    [50808] = {
        name = "El imperio no caerá",
    },
    [50810] = {
        name = "Liberación",
    },
    [50812] = {
        name = "Elementos perturbados",
    },
    [50814] = {
        name = "Un lugar horrible",
    },
    [50817] = {
        name = "Una cola encantadora",
    },
    [50818] = {
        name = "Una flauta perdida",
    },
    [50824] = {
        name = "El fin de la tormenta",
    },
    [50825] = {
        name = "Santuario de la Tormenta: los susurros de las profundidades",
    },
    [50834] = {
        name = "¡Baja la voz!",
    },
    [50835] = {
        name = "El Puerto de Zandalar",
    },
    [50838] = {
        name = "La curiosidad mató al pterrordáctilo",
    },
    [50839] = {
        name = "¡RIIIIII!",
    },
    [50841] = {
        name = "¡RIIIIII!",
    },
    [50842] = {
        name = "Ptierra a la vista",
    },
    [50860] = {
        name = "La curiosidad mató al pterrordáctilo",
    },
    [50881] = {
        name = "Informe real",
    },
    [50886] = {
        name = "Alas sustitutas",
    },
    [50887] = {
        name = "Ptodo a su tiempo",
    },
    [50897] = {
        name = "Si juegas con fuego...",
    },
    [50900] = {
        name = "Tal vez cuando seas mayor",
    },
    [50901] = {
        name = "Sorpresa sáurida",
    },
    [50903] = {
        name = "Un maestro perdido",
    },
    [50904] = {
        name = "El pasaje abandonado",
    },
    [50908] = {
        name = "Huele a problemas",
    },
    [50909] = {
        name = "Armas suficientes",
    },
    [50910] = {
        name = "Juego peligroso",
    },
    [50911] = {
        name = "Un solo hombre contra la Horda",
    },
    [50912] = {
        name = "Ignición sin munición",
    },
    [50913] = {
        name = "Bendición de Akunda",
    },
    [50929] = {
        name = "Azerita para el pueblo",
    },
    [50930] = {
        name = "Un paseo por las nubes",
    },
    [50933] = {
        name = "Un evento desafortunado",
    },
    [50934] = {
        name = "Un avistamiento oportuno",
    },
    [50940] = {
        name = "Sabiduría sin alas",
    },
    [50942] = {
        name = "Caer con estilo",
    },
    [50943] = {
        name = "El placer de volar",
    },
    [50944] = {
        name = "Abatido, mas no vencido",
    },
    [50953] = {
        name = "Acechador Glauco",
    },
    [50954] = {
        name = "¡Zandalar por siempre!",
    },
    [50955] = {
        name = "No somos amigos",
    },
    [50956] = {
        name = "Dinero con patas",
    },
    [50959] = {
        name = "Piratas saqueadores",
    },
    [50960] = {
        name = "Órdenes de Sweete",
    },
    [50963] = {
        name = "Actos oscuros, días oscuros",
    },
    [50965] = {
        name = "Los que perduran",
    },
    [50967] = {
        name = "Perdida en el bosque",
    },
    [50970] = {
        name = "El sino del campesino",
    },
    [50972] = {
        name = "El Parlamento de Valiente",
    },
    [50976] = {
        name = "Una maldición antigua",
    },
    [50978] = {
        name = "Jefe pasado, pisado",
    },
    [50979] = {
        name = "Mordelón",
    },
    [50980] = {
        name = "Mi vecina la asesina",
    },
    [50988] = {
        name = "Una oportunidad económica",
    },
    [50990] = {
        name = "Ciencia de corral de vanguardia",
    },
    [51001] = {
        name = "Peligro: Tiburones",
    },
    [51018] = {
        name = "Pregunto para un amigo",
    },
    [51019] = {
        name = "Las apariencias engañan",
    },
    [51020] = {
        name = "Prácticas empresariales despiadadas",
    },
    [51052] = {
        name = "¡Azerita para la Alianza!",
    },
    [51053] = {
        name = "El día que el puerto cayó",
    },
    [51054] = {
        name = "Motín al fin",
    },
    [51055] = {
        name = "No-muertos, sí-colgados",
    },
    [51056] = {
        name = "Mi último día de vida",
    },
    [51057] = {
        name = "Derríbalos con fuego",
    },
    [51059] = {
        name = "La Isla Dorada",
    },
    [51060] = {
        name = "Nuestra parte del botín",
    },
    [51061] = {
        name = "La primera vez que morí",
    },
    [51062] = {
        name = "Hay que escapar de Zem'lan",
    },
    [51069] = {
        name = "SE BUSCA: Hablaoscuro Jo'la",
    },
    [51071] = {
        name = "SE BUSCA: Emperatriz colmillosable",
    },
    [51072] = {
        name = "SE BUSCA: Golpuñetazo primitivo",
    },
    [51085] = {
        name = "SE BUSCA: Cronista oscuro",
    },
    [51087] = {
        name = "SE BUSCA: Cronista oscuro",
    },
    [51088] = {
        name = "El Corazón de las Tinieblas",
    },
    [51089] = {
        name = "SE BUSCA: Tojek",
    },
    [51091] = {
        name = "SE BUSCA: Ten'gor y Nol'ixwan",
    },
    [51101] = {
        name = "El rey herido",
    },
    [51111] = {
        name = "Rey o presa",
    },
    [51129] = {
        name = "Una oferta dudosa",
    },
    [51134] = {
        name = "Si los huesos hablaran",
    },
    [51139] = {
        name = "SE BUSCA: Tojek",
    },
    [51140] = {
        name = "Comparte las riquezas",
    },
    [51142] = {
        name = "Plagas",
    },
    [51144] = {
        name = "Un fardo de pelajes",
    },
    [51145] = {
        name = "La maldición de Jani",
    },
    [51146] = {
        name = "Cuidado: Kua'fon suelto",
    },
    [51147] = {
        name = "Cuidado: Kua'fon suelto",
    },
    [51149] = {
        name = "Olvidado en el puerto",
    },
    [51150] = {
        name = "En honor a los caídos",
    },
    [51151] = {
        name = "Carta para la Liga",
    },
    [51159] = {
        name = "El gran cañón",
    },
    [51161] = {
        name = "SE BUSCA: Za'roco",
    },
    [51162] = {
        name = "SE BUSCA: Taz'raka el Traidor",
    },
    [51164] = {
        name = "SE BUSCA: Participantes para excursión de cobra",
    },
    [51165] = {
        name = "SE BUSCA: Sondarenas Vesarik",
    },
    [51167] = {
        name = "Sangre de Hir'eek",
    },
    [51168] = {
        name = "Zelotes de Zalamar",
    },
    [51169] = {
        name = "Un vuelo desde La Caída",
    },
    [51170] = {
        name = "¡A la orden!",
    },
    [51177] = {
        name = "Lecciones de los malditos",
    },
    [51190] = {
        name = "Un momento de alivio",
    },
    [51191] = {
        name = "Sálvalos a todos",
    },
    [51192] = {
        name = "Falta de excedente",
    },
    [51193] = {
        name = "Ese es mío",
    },
    [51199] = {
        name = "La gloria de la cacería",
    },
    [51200] = {
        name = "La oveja negra",
    },
    [51201] = {
        name = "La historial del trol",
    },
    [51203] = {
        name = "En la boca del lobo",
    },
    [51204] = {
        name = "SE BUSCA: Zarpador alfa",
    },
    [51205] = {
        name = "¡Ahh! ¡Ratas!",
    },
    [51207] = {
        name = "A morder el polvo",
    },
    [51208] = {
        name = "Granos a granel",
    },
    [51209] = {
        name = "Puñogrokk potente",
    },
    [51211] = {
        name = "El Corazón de Azeroth",
    },
    [51214] = {
        name = "Sé bueno",
    },
    [51215] = {
        name = "Cabras lecheras",
    },
    [51217] = {
        name = "SE BUSCA: Yarsel'ghun",
    },
    [51218] = {
        name = "Paquete sin entregar",
    },
    [51220] = {
        name = "Hunde a la Compañía",
    },
    [51221] = {
        name = "Una respuesta inmediata",
    },
    [51222] = {
        name = "De su propia medicina",
    },
    [51224] = {
        name = "Exploración rentable",
    },
    [51226] = {
        name = "Muerte de ambos lados",
    },
    [51229] = {
        name = "Avanzada en la costa",
    },
    [51231] = {
        name = "Vicafobia",
    },
    [51233] = {
        name = "Espero que no haya brujas en la montaña",
    },
    [51234] = {
        name = "Avanzada de Krazzlefrazz",
    },
    [51240] = {
        name = "SE BUSCA: Anclafaz",
    },
    [51244] = {
        name = "La podredumbre bajo tus pies",
    },
    [51246] = {
        name = "Juicio a los náufragos",
    },
    [51247] = {
        name = "Lo que se llevaron",
    },
    [51248] = {
        name = "Pestes productivas",
    },
    [51249] = {
        name = "Festín cangrejoso",
    },
    [51251] = {
        name = "Invasión arácnida",
    },
    [51278] = {
        name = "Perdidos y olvidados",
    },
    [51279] = {
        name = "Cultistas nazmani",
    },
    [51280] = {
        name = "Ofrendas para G'huun",
    },
    [51282] = {
        name = "Capitana Conrad",
    },
    [51283] = {
        name = "Un viaje hacia el oeste",
    },
    [51286] = {
        name = "Detén la evacuación",
    },
    [51302] = {
        name = "Bardoma: Sellar la corrupción de G'huun",
    },
    [51308] = {
        name = "Base de Zuldazar",
    },
    [51309] = {
        name = "Rocas de Ragnaros",
    },
    [51310] = {
        name = "En busca de la cosecha perdida",
    },
    [51314] = {
        name = "Al grano",
    },
    [51319] = {
        name = "El ascenso final",
    },
    [51320] = {
        name = "Destino sellado",
    },
    [51331] = {
        name = "Maquinaciones topo",
    },
    [51332] = {
        name = "A cruzar el océano",
    },
    [51335] = {
        name = "Galletas y crema",
    },
    [51339] = {
        name = "Factura de limpieza",
    },
    [51340] = {
        name = "¡A Drustvar!",
    },
    [51341] = {
        name = "Hija del mar",
    },
    [51342] = {
        name = "Batalla por Stromgarde",
    },
    [51343] = {
        name = "Lecciones de natación",
    },
    [51349] = {
        name = "Unión de honor",
    },
    [51350] = {
        name = "Ayuda inesperada",
    },
    [51351] = {
        name = "Púas envenenadas",
    },
    [51352] = {
        name = "No juegues con cerillas",
    },
    [51353] = {
        name = "Cueva de Ai'twen",
    },
    [51354] = {
        name = "Cólera embotellada",
    },
    [51356] = {
        name = "SE BUSCA: Hermana Lilias",
    },
    [51357] = {
        name = "Armado y listo",
    },
    [51358] = {
        name = "SE BUSCA: Ladrones de grifos",
    },
    [51359] = {
        name = "Fragmento de las Tierras de Fuego",
    },
    [51364] = {
        name = "Fuga explosiva",
    },
    [51366] = {
        name = "Aplicación de antídoto",
    },
    [51367] = {
        name = "SE BUSCA: Guardatierra enfurecido",
    },
    [51368] = {
        name = "SE BUSCA: El avispón",
    },
    [51369] = {
        name = "Amigos en lugares extraños",
    },
    [51370] = {
        name = "Recompensa de escasez de suministros",
    },
    [51371] = {
        name = "Ofrenda suculenta",
    },
    [51384] = {
        name = "SE BUSCA: Intendente Ssylis",
    },
    [51386] = {
        name = "Victoria en batalla",
    },
    [51389] = {
        name = "Hasta la libertad siempre",
    },
    [51390] = {
        name = "SE BUSCA: Degolladores carmesí",
    },
    [51391] = {
        name = "Infieles descolmillados",
    },
    [51394] = {
        name = "Rompe el asedio",
    },
    [51395] = {
        name = "Las llaves de los guardianes",
    },
    [51401] = {
        name = "Adelante",
    },
    [51402] = {
        name = "¡Reportándose!",
    },
    [51403] = {
        name = "La urgencia del Portavoz",
    },
    [51407] = {
        name = "Búsqueda de palabras",
    },
    [51421] = {
        name = "¡Que me parta un rayo!",
    },
    [51425] = {
        name = "No hay lugar como el hogar",
    },
    [51426] = {
        name = "Dispositivo de inspección",
    },
    [51427] = {
        name = "Las tortugas son geniales",
    },
    [51430] = {
        name = "Ingeniería inversa de gnomos",
    },
    [51435] = {
        name = "Moda pirata",
    },
    [51436] = {
        name = "Negocios de piratas",
    },
    [51437] = {
        name = "Tragos al agua",
    },
    [51438] = {
        name = "Marcando territorio",
    },
    [51439] = {
        name = "Colección de balas de cañón",
    },
    [51440] = {
        name = "Cambio de dirección",
    },
    [51441] = {
        name = "¡Cómo vuela!",
    },
    [51442] = {
        name = "Ahora yo soy el capitán",
    },
    [51443] = {
        name = "Misión imponderable",
    },
    [51445] = {
        name = "Thros, Las Tierras Plagadas",
    },
    [51465] = {
        name = "Un montón de chatarra",
    },
    [51472] = {
        name = "Preservadora de la vida",
    },
    [51474] = {
        name = "Forjados en fuego y llamas",
    },
    [51479] = {
        name = "Los incorruptos",
    },
    [51483] = {
        name = "Legado de los Hierro Negro",
    },
    [51484] = {
        name = "Legado de los Mag'har",
    },
    [51485] = {
        name = "Por la Horda",
    },
    [51486] = {
        name = "Por la Alianza",
    },
    [51487] = {
        name = "En busca de respuestas",
    },
    [51488] = {
        name = "Conocimiento archivado",
    },
    [51489] = {
        name = "Hora de partir",
    },
    [51490] = {
        name = "Asuntos fronterizos",
    },
    [51492] = {
        name = "La conspiración de la pólvora",
    },
    [51504] = {
        name = "Entrega de galletas",
    },
    [51513] = {
        name = "El regreso de Zalazane",
    },
    [51514] = {
        name = "Trato roto",
    },
    [51515] = {
        name = "Venganza para Vol'jin",
    },
    [51516] = {
        name = "Las cenizas de un jefe de guerra",
    },
    [51517] = {
        name = "Me debes un espíritu",
    },
    [51518] = {
        name = "El espíritu perdido",
    },
    [51519] = {
        name = "Llamado espiritual",
    },
    [51520] = {
        name = "Justicia por los caídos",
    },
    [51521] = {
        name = "La verdadera líder de Zandalar",
    },
    [51526] = {
        name = "El llamado del señor de la guerra",
    },
    [51532] = {
        name = "Fuerte cual tormenta",
    },
    [51533] = {
        name = "Guja de Vol'jin",
    },
    [51534] = {
        name = "La batalla por Presabrenna",
    },
    [51536] = {
        name = "De cacería",
    },
    [51538] = {
        name = "Palabra de las profundidades",
    },
    [51539] = {
        name = "¡Informa a la Horda!",
    },
    [51540] = {
        name = "Situación explosiva",
    },
    [51543] = {
        name = "Retoños en la nieve",
    },
    [51544] = {
        name = "Desarme de cañones",
    },
    [51545] = {
        name = "Rompedor rompido",
    },
    [51547] = {
        name = "SE BUSCA: Penagua",
    },
    [51552] = {
        name = "Días ajetreados",
    },
    [51554] = {
        name = "Recargando",
    },
    [51555] = {
        name = "La disciplina ante todo",
    },
    [51557] = {
        name = "Advertencia mareaférrea",
    },
    [51569] = {
        name = "La campaña de Zandalar",
    },
    [51573] = {
        name = "Yo te cubro",
    },
    [51574] = {
        name = "Recién exprimido",
    },
    [51582] = {
        name = "Mildenhall: la mejor elección",
    },
    [51587] = {
        name = "¡Adelante!",
    },
    [51589] = {
        name = "Aplasta la voluntad kultirana",
    },
    [51590] = {
        name = "Hacia el corazón de Tiragarde",
    },
    [51591] = {
        name = "Ahora es nuestra montaña",
    },
    [51592] = {
        name = "Como en casa",
    },
    [51593] = {
        name = "Investigación en Puerto del Puente",
    },
    [51594] = {
        name = "Explosivos en la fundición",
    },
    [51595] = {
        name = "Explosividad",
    },
    [51596] = {
        name = "Adquisición de municiones",
    },
    [51597] = {
        name = "Investigación de pólvora",
    },
    [51598] = {
        name = "Un poco de caos",
    },
    [51599] = {
        name = "Trampa mortal",
    },
    [51601] = {
        name = "Persecución en Puerto del Puente",
    },
    [51602] = {
        name = "Cuchillas bandidas",
    },
    [51643] = {
        name = "Un muro de hierro",
    },
    [51663] = {
        name = "Preparativos para la caída",
    },
    [51674] = {
        name = "Sofocar las llamas",
    },
    [51675] = {
        name = "A cazarlos",
    },
    [51677] = {
        name = "Sanación de cuerpo y alma",
    },
    [51678] = {
        name = "Poderío de Rastakhan",
    },
    [51679] = {
        name = "Un extraño puerto al que acudir",
    },
    [51680] = {
        name = "A la sombra de Bwonsamdi",
    },
    [51689] = {
        name = "Rescate tortollano",
    },
    [51691] = {
        name = "Casi valen la pena",
    },
    [51696] = {
        name = "Recuperemos lo nuestro",
    },
    [51711] = {
        name = "A pasarla bomba",
    },
    [51712] = {
        name = "Ojo por ojo",
    },
    [51714] = {
        name = "Misión del rey",
    },
    [51715] = {
        name = "Guerra de sombras",
    },
    [51717] = {
        name = "La mejor miel de Vol'dun",
    },
    [51718] = {
        name = "Cosecha de \"miel\"",
    },
    [51720] = {
        name = "Hecho añicos",
    },
    [51723] = {
        name = "Cubierto de aserrín",
    },
    [51726] = {
        name = "Salgamos de aquí",
    },
    [51728] = {
        name = "¡Que arda!",
    },
    [51752] = {
        name = "Un día Grizz",
    },
    [51753] = {
        name = "Campeón: Rexxar",
    },
    [51770] = {
        name = "Misión de la jefa de guerra",
    },
    [51771] = {
        name = "Guerra de sombras",
    },
    [51772] = {
        name = "La tribu Tortaka",
    },
    [51773] = {
        name = "La amenaza Aspafresno",
    },
    [51775] = {
        name = "Campamento Tardoviento",
    },
    [51784] = {
        name = "Un paseo por el cementerio",
    },
    [51785] = {
        name = "Revisión de epitafios",
    },
    [51786] = {
        name = "No hay paz en la muerte",
    },
    [51787] = {
        name = "Las vueltas de la vida",
    },
    [51788] = {
        name = "El Guardián de la cripta",
    },
    [51789] = {
        name = "Los restos del mariscal M. Valentine",
    },
    [51795] = {
        name = "Batalla por Lordaeron",
    },
    [51796] = {
        name = "Batalla por Lordaeron",
    },
    [51797] = {
        name = "En busca de maresabios",
    },
    [51798] = {
        name = "Ningún precio es muy alto",
    },
    [51803] = {
        name = "La campaña de Kul Tiras",
    },
    [51805] = {
        name = "Conocerán el miedo",
    },
    [51810] = {
        name = "Capitán Hartford",
    },
    [51813] = {
        name = "Profundidades de Roca Negra",
    },
    [51818] = {
        name = "Comandante y capitana",
    },
    [51819] = {
        name = "Dispersa a nuestros enemigos",
    },
    [51829] = {
        name = "Llave de Ranah",
    },
    [51830] = {
        name = "El potencial de Zelling",
    },
    [51837] = {
        name = "Que sea lo que sea",
    },
    [51870] = {
        name = "Expedición insular",
    },
    [51881] = {
        name = "El barredor de minas",
    },
    [51888] = {
        name = "Expedición insular",
    },
    [51903] = {
        name = "Expedición insular",
    },
    [51904] = {
        name = "Expedición insular",
    },
    [51916] = {
        name = "La unificación de Zandalar",
    },
    [51918] = {
        name = "La unificación de Kul Tiras",
    },
    [51961] = {
        name = "Campaña continua",
    },
    [51967] = {
        name = "Regreso a Boralus",
    },
    [51968] = {
        name = "Regreso a Boralus",
    },
    [51969] = {
        name = "Regreso a Boralus",
    },
    [51975] = {
        name = "Campeón: Cazador de las Sombras Ty'jin",
    },
    [51979] = {
        name = "Campaña continua",
    },
    [51980] = {
        name = "SE BUSCA: Jabra'kan",
    },
    [51984] = {
        name = "Regreso a Zuldazar",
    },
    [51985] = {
        name = "Regreso a Zuldazar",
    },
    [51986] = {
        name = "Regreso a Zuldazar",
    },
    [51987] = {
        name = "Campeón: Hobart Martillazos",
    },
    [51990] = {
        name = "Alas para el redil",
    },
    [51991] = {
        name = "Carga las baterías",
    },
    [51998] = {
        name = "HCC: ¡Ahora con auténticos trozos de cuernoatroz!",
    },
    [52003] = {
        name = "Campeona: Kelsey Chispacero",
    },
    [52008] = {
        name = "Campeón: Magíster Umbric",
    },
    [52013] = {
        name = "Campeón: John J. Keeshan",
    },
    [52026] = {
        name = "Asesinato transoceánico",
    },
    [52027] = {
        name = "El plan de Vol'dun",
    },
    [52028] = {
        name = "Rastrillaje del desierto",
    },
    [52029] = {
        name = "Trabajo sucio",
    },
    [52030] = {
        name = "Rastrillaje continuo",
    },
    [52031] = {
        name = "Relicario clásico",
    },
    [52032] = {
        name = "No dejes de rastrillar",
    },
    [52033] = {
        name = "SE BUSCA: Cazadora de la helada blanca",
    },
    [52034] = {
        name = "Un mensaje para los zandalari",
    },
    [52035] = {
        name = "Supervivencia improvisada",
    },
    [52036] = {
        name = "¡Hay alpacas!",
    },
    [52038] = {
        name = "Caminos separados",
    },
    [52039] = {
        name = "Mortificación demorada",
    },
    [52040] = {
        name = "Repleto de flechas",
    },
    [52041] = {
        name = "Preséntate ante Aterravermis",
    },
    [52042] = {
        name = "El Big Bum",
    },
    [52061] = {
        name = "¡Taptaf el Cerdo!",
    },
    [52065] = {
        name = "Peor de lo que parece",
    },
    [52067] = {
        name = "Sobrevivientes",
    },
    [52068] = {
        name = "Ve a ayudar a otro lado",
    },
    [52069] = {
        name = "Más carne de cañón",
    },
    [52070] = {
        name = "Busca a Bauer",
    },
    [52073] = {
        name = "Una petición a Krag'wa",
    },
    [52074] = {
        name = "Entrega",
    },
    [52075] = {
        name = "Patea sus huesudos traseros",
    },
    [52113] = {
        name = "Vol'jin, hijo de Sen'jin",
    },
    [52114] = {
        name = "Honra a un verdadero líder",
    },
    [52122] = {
        name = "Ser un Renegado",
    },
    [52127] = {
        name = "La Guarida del Lobo",
    },
    [52128] = {
        name = "Boleto de ferry",
    },
    [52129] = {
        name = "Problemas de energía",
    },
    [52130] = {
        name = "Trofeo más preciado: Carpe Diem",
    },
    [52131] = {
        name = "Necesidad mutua",
    },
    [52132] = {
        name = "La prueba de la piratería",
    },
    [52139] = {
        name = "Ocupémonos de lo nuestro",
    },
    [52146] = {
        name = "Sangre en la arena",
    },
    [52147] = {
        name = "Diezma a la Horda",
    },
    [52149] = {
        name = "Deber eterno",
    },
    [52150] = {
        name = "Cómo matar a un forestal oscuro",
    },
    [52151] = {
        name = "Una nación unida",
    },
    [52153] = {
        name = "Asedio de Boralus: El regreso de Lady Aspafresno",
    },
    [52154] = {
        name = "Nuestro próximo objetivo",
    },
    [52156] = {
        name = "Tortollanos en apuros",
    },
    [52158] = {
        name = "Una cacería salvaje",
    },
    [52170] = {
        name = "El fin de Areiel",
    },
    [52171] = {
        name = "Una opción: Fuego",
    },
    [52172] = {
        name = "No pueden quedarse",
    },
    [52173] = {
        name = "Los elfos del Vacío están preparados",
    },
    [52183] = {
        name = "Cuando un plan sale a la perfección",
    },
    [52184] = {
        name = "Reliquias del ritual",
    },
    [52185] = {
        name = "Un portal bien ubicado",
    },
    [52186] = {
        name = "La vanguardia de la Guardia",
    },
    [52187] = {
        name = "Viejos colegas",
    },
    [52188] = {
        name = "Los sabios maresabios",
    },
    [52189] = {
        name = "Almas perdidas",
    },
    [52190] = {
        name = "Sacar ventaja",
    },
    [52191] = {
        name = "Una vida en cautiverio",
    },
    [52192] = {
        name = "La ayuda de las mareas",
    },
    [52194] = {
        name = "Motivo de arrepentimiento",
    },
    [52203] = {
        name = "Encuentra el rastro de papeles",
    },
    [52204] = {
        name = "La solución del Vacío",
    },
    [52205] = {
        name = "Punto final a la prosperidad Pantoque",
    },
    [52208] = {
        name = "Una reunión no tan privada",
    },
    [52210] = {
        name = "Un pedido de ayuda",
    },
    [52212] = {
        name = "Batalla por Stromgarde",
    },
    [52219] = {
        name = "Objetivo: Príncipe de Sangre Dreven",
    },
    [52241] = {
        name = "El paraíso de un goblin avaro",
    },
    [52246] = {
        name = "Cargamento perdido",
    },
    [52247] = {
        name = "En busca de Gallywix",
    },
    [52252] = {
        name = "Una entrada explosiva",
    },
    [52253] = {
        name = "Las llaves del éxito en Puerto Libre",
    },
    [52258] = {
        name = "Al son del caparazón",
    },
    [52259] = {
        name = "Esto no me da ningún placer",
    },
    [52260] = {
        name = "Lo tenemos arrinconado",
    },
    [52261] = {
        name = "Gallywix escapó",
    },
    [52281] = {
        name = "Bajo la cobija de Alapresta",
    },
    [52282] = {
        name = "Cómo hundir un acorazado zandalari",
    },
    [52283] = {
        name = "El sabotaje del Pa'ku",
    },
    [52284] = {
        name = "Registros navales",
    },
    [52285] = {
        name = "El submarino miniaturizado agrandado",
    },
    [52286] = {
        name = "Debajo de sus narices",
    },
    [52287] = {
        name = "Inteligencia denegada",
    },
    [52288] = {
        name = "Vaciovacaciones",
    },
    [52289] = {
        name = "Victoria garantizada",
    },
    [52290] = {
        name = "El enemigo de mi enemigo es mi disfraz",
    },
    [52291] = {
        name = "La victoria estaba garantizada",
    },
    [52294] = {
        name = "Ídolos caídos",
    },
    [52305] = {
        name = "¿Se nace o se hace?",
    },
    [52308] = {
        name = "Órdenes interceptadas",
    },
    [52311] = {
        name = "La caja fuerte de Sweete",
    },
    [52317] = {
        name = "Cuántas veces ptero tengo que decir",
    },
    [52428] = {
        name = "Azerita para el corazón",
    },
    [52431] = {
        name = "Prohibido aterrizar",
    },
    [52443] = {
        name = "La base final",
    },
    [52444] = {
        name = "La base final",
    },
    [52445] = {
        name = "Tol Dagor: La cuarta llave",
    },
    [52447] = {
        name = "Etapa de crecimiento",
    },
    [52449] = {
        name = "La isla misteriosa",
    },
    [52450] = {
        name = "La unificación de Kul Tiras",
    },
    [52453] = {
        name = "Una ligera esperanza",
    },
    [52472] = {
        name = "¡Guía a Loh!",
    },
    [52473] = {
        name = "¡Flota abajo!",
    },
    [52477] = {
        name = "SE BUSCA: Ayame",
    },
    [52480] = {
        name = "SE BUSCA: Ayame",
    },
    [52481] = {
        name = "De mitos y fábulas",
    },
    [52482] = {
        name = "El viejo oso",
    },
    [52483] = {
        name = "Atrapapesadillas",
    },
    [52484] = {
        name = "Poder enterrado",
    },
    [52485] = {
        name = "El foco del odio",
    },
    [52486] = {
        name = "Mansión Tarjasenda: Drenar a los Hiel de corazón",
    },
    [52487] = {
        name = "Hacia la oscuridad",
    },
    [52488] = {
        name = "Resistencia rúnica",
    },
    [52489] = {
        name = "A la caza del príncipe de sangre Dreven",
    },
    [52490] = {
        name = "Detrás de los barcos enemigos",
    },
    [52491] = {
        name = "Fuego \"amigo\"",
    },
    [52492] = {
        name = "La especialidad de los Martillo Salvaje",
    },
    [52493] = {
        name = "Una tripulación antinatural",
    },
    [52494] = {
        name = "Cristales fatales",
    },
    [52495] = {
        name = "Acabar con la amenaza san'layn",
    },
    [52496] = {
        name = "Una huida limpia",
    },
    [52508] = {
        name = "Efectos de ritual",
    },
    [52509] = {
        name = "La fuerza de la tormenta",
    },
    [52510] = {
        name = "Santuario de la Tormenta: El ritual faltante",
    },
    [52511] = {
        name = "Despeja el camino",
    },
    [52512] = {
        name = "Límite del Destino",
    },
    [52513] = {
        name = "Perdidos en la oscuridad",
    },
    [52544] = {
        name = "El alijo bélico",
    },
    [52654] = {
        name = "La campaña de guerra",
    },
    [52746] = {
        name = "El alijo bélico",
    },
    [52748] = {
        name = "Ojos en los cielos",
    },
    [52749] = {
        name = "La campaña de guerra",
    },
    [52750] = {
        name = "Granjeros de armas tomar",
    },
    [52762] = {
        name = "Un guía local",
    },
    [52764] = {
        name = "Viaje al medio de la nada",
    },
    [52765] = {
        name = "Zambullida",
    },
    [52766] = {
        name = "Naufragio en el fondo marino",
    },
    [52767] = {
        name = "Un mar de placas",
    },
    [52768] = {
        name = "El cementerio hundido",
    },
    [52769] = {
        name = "Un capitán y otro capitán",
    },
    [52770] = {
        name = "Biolumimolestia",
    },
    [52772] = {
        name = "La cornisa submarina",
    },
    [52773] = {
        name = "Dragón escupeagua",
    },
    [52774] = {
        name = "¡Tómalo y vámonos!",
    },
    [52782] = {
        name = "Llamamiento a las armas: Valle Canto Tormenta",
    },
    [52787] = {
        name = "Aliviar el dolor",
    },
    [52788] = {
        name = "Nadie debe quedar con vida",
    },
    [52789] = {
        name = "Silencia a la asesora",
    },
    [52790] = {
        name = "El fin de la matanza",
    },
    [52793] = {
        name = "Rodea las carretas",
    },
    [52795] = {
        name = "Más agrio que el vinagre",
    },
    [52796] = {
        name = "A veces, menos es más",
    },
    [52800] = {
        name = "Tol Dagor: El sobrestante Aspafresno",
    },
    [52855] = {
        name = "La alquimia es una ciencia inexacta",
    },
    [52857] = {
        name = "Sujeto de observación",
    },
    [52861] = {
        name = "Campeona: Lilian Voss",
    },
    [52876] = {
        name = "SE BUSCA: Belisangre",
    },
    [52942] = {
        name = "Reavivar lazos antiguos",
    },
    [52943] = {
        name = "Clamar a los clanes",
    },
    [52944] = {
        name = "Llamamiento a las armas: Drustvar",
    },
    [52945] = {
        name = "Lazos forjados en el campo de batalla",
    },
    [52946] = {
        name = "El ocaso de un mundo",
    },
    [52948] = {
        name = "Llamamiento a las armas: Canal de Tiragarde",
    },
    [52949] = {
        name = "Llamamiento a las armas: Nazmir",
    },
    [52950] = {
        name = "Llamamiento a las armas: Vol'Dun",
    },
    [52953] = {
        name = "Llamamiento a las armas: Vol'Dun",
    },
    [52954] = {
        name = "Llamamiento a las armas: Nazmir",
    },
    [52955] = {
        name = "Tiranía de la Luz",
    },
    [52956] = {
        name = "Llamamiento a las armas: Canal de Tiragarde",
    },
    [52958] = {
        name = "Llamamiento a las armas: Drustvar",
    },
    [52965] = {
        name = "Un obsequio del Festival de Invierno",
    },
    [52978] = {
        name = "Una carga real",
    },
    [52990] = {
        name = "Regreso al puerto",
    },
    [53003] = {
        name = "Ciclo de odio",
    },
    [53011] = {
        name = "Un obsequio ligeramente agitado",
    },
    [53028] = {
        name = "El ocaso de un mundo",
    },
    [53031] = {
        name = "La urgencia del Portavoz",
    },
    [53041] = {
        name = "Artículos de muestra",
    },
    [53045] = {
        name = "Evaluación del muelle",
    },
    [53050] = {
        name = "Hacia Kul Tiras",
    },
    [53052] = {
        name = "Hacia Zandalar",
    },
    [53055] = {
        name = "Propagación de nuestra influencia",
    },
    [53056] = {
        name = "Propagación de nuestra influencia",
    },
    [53061] = {
        name = "Apremio de azerita",
    },
    [53062] = {
        name = "Apremio de azerita",
    },
    [53063] = {
        name = "Una misión de unidad",
    },
    [53065] = {
        name = "Operación: Cavador de tumbas",
    },
    [53066] = {
        name = "Operación: Rumbo al agua",
    },
    [53067] = {
        name = "Operación: Alimento para el océano",
    },
    [53068] = {
        name = "Operación: Carnada",
    },
    [53069] = {
        name = "Operación: Flecha sangrienta",
    },
    [53070] = {
        name = "Operación: Saqueo",
    },
    [53071] = {
        name = "Operación: Zarpa de grifo",
    },
    [53072] = {
        name = "Operación: Ataque al corazón",
    },
    [53074] = {
        name = "Refuerzos",
    },
    [53079] = {
        name = "Refuerzos",
    },
    [53096] = {
        name = "Recompensa de escasez de suministros",
    },
    [53097] = {
        name = "Abluciones abatidas",
    },
    [53098] = {
        name = "Campeona: Shandris Plumaluna",
    },
    [53099] = {
        name = "Una mota de verdad cósmica",
    },
    [53105] = {
        name = "Fe no correspondida",
    },
    [53109] = {
        name = "Casa Tarjasenda",
    },
    [53110] = {
        name = "El alto orador de espinas",
    },
    [53121] = {
        name = "Asedio de Boralus",
    },
    [53128] = {
        name = "El lamento del Lord almirante",
    },
    [53131] = {
        name = "Reposo de los Reyes",
    },
    [53185] = {
        name = "Contribución al frente de batalla",
    },
    [53194] = {
        name = "Al frente",
    },
    [53197] = {
        name = "Recorrido del frente",
    },
    [53198] = {
        name = "Regreso a Boralus",
    },
    [53208] = {
        name = "Al frente",
    },
    [53209] = {
        name = "Contribución al frente de batalla",
    },
    [53210] = {
        name = "Recorrido del frente",
    },
    [53212] = {
        name = "Regreso a Zuldazar",
    },
    [53330] = {
        name = "SE BUSCA: Zarpador alfa",
    },
    [53332] = {
        name = "La guerra ha llegado",
    },
    [53333] = {
        name = "La guerra ha llegado",
    },
    [53336] = {
        name = "SE BUSCA: Emperatriz colmillosable",
    },
    [53337] = {
        name = "SE BUSCA: Golpuñetazo primitivo",
    },
    [53342] = {
        name = "Núcleo de magma",
    },
    [53347] = {
        name = "Aguijón, la abeja",
    },
    [53348] = {
        name = "SE BUSCA: Truenahocico",
    },
    [53351] = {
        name = "¡¡El FILÓN!!: Ferromazo",
    },
    [53352] = {
        name = "Tierras de Fuego",
    },
    [53353] = {
        name = "Eco de la señora de la guerra Zaela",
    },
    [53354] = {
        name = "Eco de Gul'dan",
    },
    [53355] = {
        name = "Eco de Garrosh Grito Infernal",
    },
    [53369] = {
        name = "¡Guía a Loh!",
    },
    [53370] = {
        name = "Hora de ajustar cuentas",
    },
    [53371] = {
        name = "Una abeja amigable",
    },
    [53372] = {
        name = "Hora de ajustar cuentas",
    },
    [53406] = {
        name = "La Cámara del Corazón",
    },
    [53430] = {
        name = "Ballesta de la Orden de las Ascuas",
    },
    [53431] = {
        name = "Frasco de la Orden de las Ascuas",
    },
    [53432] = {
        name = "Cuchillo de la Orden de las Ascuas",
    },
    [53433] = {
        name = "Sombrero de la Orden de las Ascuas",
    },
    [53438] = {
        name = "SE BUSCA: Cazadores furtivos de dracoleones",
    },
    [53440] = {
        name = "SE BUSCA: El avispón",
    },
    [53449] = {
        name = "Simios a las armas",
    },
    [53450] = {
        name = "Rey Da'ka",
    },
    [53451] = {
        name = "SE BUSCA: Guardatierra enfurecido",
    },
    [53452] = {
        name = "Guerra de gorilas",
    },
    [53453] = {
        name = "Aplastar o no aplastar... esa es la cuestión",
    },
    [53454] = {
        name = "SE BUSCA: Intendente Ssylis",
    },
    [53455] = {
        name = "SE BUSCA: Degolladores carmesí",
    },
    [53456] = {
        name = "SE BUSCA: Cazadora de la helada blanca",
    },
    [53458] = {
        name = "SE BUSCA: Penagua",
    },
    [53459] = {
        name = "SE BUSCA: Hermana Lilias",
    },
    [53461] = {
        name = "Metales preciosos",
    },
    [53462] = {
        name = "Envuelto en telarañas",
    },
    [53463] = {
        name = "Una maldición con ocho patas",
    },
    [53464] = {
        name = "La aldea de Glenbrook",
    },
    [53465] = {
        name = "La hora del té",
    },
    [53466] = {
        name = "Visión en el tiempo",
    },
    [53467] = {
        name = "Cavernas del Tiempo",
    },
    [53566] = {
        name = "Enanos Hierro Negro",
    },
    [53583] = {
        name = "Adaptaciones tácticas",
    },
    [53602] = {
        name = "Adaptaciones tácticas",
    },
    [53719] = {
        name = "La lealtad de los zandalari",
    },
    [53720] = {
        name = "La lealtad de Kul Tiras",
    },
    [53725] = {
        name = "Un pueblo devastado",
    },
    [53734] = {
        name = "Caminata entre fantasmas",
    },
    [53735] = {
        name = "Los primeros en caer",
    },
    [53736] = {
        name = "Lamento de los Altonato",
    },
    [53737] = {
        name = "El día que murió la esperanza",
    },
    [53738] = {
        name = "La defensa de Quel'Danas",
    },
    [53760] = {
        name = "Consecuencias inesperadas",
    },
    [53761] = {
        name = "El tesoro de la pirata",
    },
    [53762] = {
        name = "La corona de la tempestad",
    },
    [53763] = {
        name = "Torcer el puñal",
    },
    [53765] = {
        name = "Su mirada se ha posado sobre ti",
    },
    [53766] = {
        name = "Su mirada se ha posado sobre ti",
    },
    [53774] = {
        name = "La sabiduría del jefe de guerra",
    },
    [53775] = {
        name = "Sombras perturbadoras",
    },
    [53776] = {
        name = "A la Costa Quebrada",
    },
    [53777] = {
        name = "El lugar de su muerte",
    },
    [53778] = {
        name = "Donde cayó",
    },
    [53779] = {
        name = "Las mentiras de un loa",
    },
    [53780] = {
        name = "Carcelero de los malditos",
    },
    [53782] = {
        name = "Misterios de la muerte",
    },
    [53783] = {
        name = "En las dunas",
    },
    [53791] = {
        name = "El orgullo de los sin'dorei",
    },
    [53802] = {
        name = "Persuasión sethrak",
    },
    [53805] = {
        name = "Un de-sastre temporal",
    },
    [53806] = {
        name = "Sin límites",
    },
    [53807] = {
        name = "Una puntada a tiempo",
    },
    [53810] = {
        name = "El hilo cortado",
    },
    [53813] = {
        name = "Manos a la obra",
    },
    [53815] = {
        name = "¿Qué le sucedió a Saffy Flivvers?",
    },
    [53816] = {
        name = "Se requiere algo de reensamblaje",
    },
    [53817] = {
        name = "¿Qué le sucedió a Grizzek Llavesilbo?",
    },
    [53818] = {
        name = "Relorización",
    },
    [53819] = {
        name = "Regreso al nido",
    },
    [53820] = {
        name = "Está en un lugar mejor",
    },
    [53821] = {
        name = "Está muerto, Jastor",
    },
    [53823] = {
        name = "El séquito de una reina",
    },
    [53824] = {
        name = "El rito de reyes y reinas",
    },
    [53825] = {
        name = "El nuevo Concilio zanchuli",
    },
    [53826] = {
        name = "La instigadora entre nosotros",
    },
    [53827] = {
        name = "El Concilio ha hablado",
    },
    [53828] = {
        name = "La mirada de los loa",
    },
    [53830] = {
        name = "La reina de los zandalari",
    },
    [53831] = {
        name = "Una celebración real",
    },
    [53833] = {
        name = "Ventura vengativa",
    },
    [53835] = {
        name = "¿Habrá algo de valor?",
    },
    [53836] = {
        name = "Armadura antigua, misterio antiguo",
    },
    [53837] = {
        name = "Ten cuidado",
    },
    [53838] = {
        name = "Mantén los pies sobre la tierra",
    },
    [53840] = {
        name = "¿Nos tomamos una pinta?",
    },
    [53841] = {
        name = "Fragmentos del pasado",
    },
    [53842] = {
        name = "Bendición terránea",
    },
    [53844] = {
        name = "Reclutamiento del Maestro de la Caldera",
    },
    [53845] = {
        name = "La forja de la armadura",
    },
    [53846] = {
        name = "El legado de los Barbabronce",
    },
    [53847] = {
        name = "Vientos susurrados",
    },
    [53848] = {
        name = "Las llaves de Vol'dun",
    },
    [53849] = {
        name = "Esperanza fugaz",
    },
    [53851] = {
        name = "Nuestra guerra continúa",
    },
    [53852] = {
        name = "Azerita denegada",
    },
    [53853] = {
        name = "El ocaso del sol",
    },
    [53856] = {
        name = "La furia de la Horda",
    },
    [53858] = {
        name = "Ponte en sus zapatos",
    },
    [53866] = {
        name = "Si el zapato calza...",
    },
    [53868] = {
        name = "Sutura de las heridas del tiempo",
    },
    [53869] = {
        name = "Matar el tiempo",
    },
    [53870] = {
        name = "Invitados en Fuerte Grommash",
    },
    [53879] = {
        name = "Limpieza de la finca",
    },
    [53880] = {
        name = "Máquinas de guerra y azerita",
    },
    [53881] = {
        name = "Cortados con la misma tijera",
    },
    [53882] = {
        name = "Escrituras en la pared",
    },
    [53887] = {
        name = "La guerra continúa",
    },
    [53888] = {
        name = "A Puntanzuelo",
    },
    [53896] = {
        name = "Firme",
    },
    [53909] = {
        name = "Aliados asediados",
    },
    [53910] = {
        name = "¡Expulsa a la Horda!",
    },
    [53912] = {
        name = "La cacería nunca termina",
    },
    [53913] = {
        name = "Con honor",
    },
    [53916] = {
        name = "¡Firmes, firmemares!",
    },
    [53919] = {
        name = "Disparos realizados",
    },
    [53936] = {
        name = "Zurra a los zapadores",
    },
    [53937] = {
        name = "La Ub3r-Llave",
    },
    [53938] = {
        name = "Un de-sastre temporal",
    },
    [53940] = {
        name = "Una puntada a tiempo",
    },
    [53941] = {
        name = "Un meca para un goblin",
    },
    [53942] = {
        name = "El meca indicado para el trabajo",
    },
    [53947] = {
        name = "En las dunas",
    },
    [53948] = {
        name = "Ventura vengativa",
    },
    [53949] = {
        name = "La Ub3r-Llave",
    },
    [53962] = {
        name = "Cortados con la misma tijera",
    },
    [53973] = {
        name = "Carga a la batalla",
    },
    [53978] = {
        name = "Planes explosivos",
    },
    [53981] = {
        name = "El día nos pertenece",
    },
    [53986] = {
        name = "La calma que precede",
    },
    [53988] = {
        name = "Las costas del destino",
    },
    [53989] = {
        name = "Esperanza",
    },
    [53990] = {
        name = "Aun en la noche más oscura",
    },
    [53993] = {
        name = "Una voz en el viento",
    },
    [53995] = {
        name = "El curtidor tauren",
    },
    [53996] = {
        name = "De buena madera",
    },
    [53997] = {
        name = "Sexto sentido",
    },
    [53998] = {
        name = "Exhumación",
    },
    [53999] = {
        name = "Los hilos que atan",
    },
    [54000] = {
        name = "Un cachito de tu corazón",
    },
    [54001] = {
        name = "Allá vamos",
    },
    [54002] = {
        name = "Todas las piezas juntas",
    },
    [54004] = {
        name = "Caso de pruebas 1: Meca vs. Mekkatorque",
    },
    [54005] = {
        name = "Gajes de los drust",
    },
    [54007] = {
        name = "Póliza de seguro",
    },
    [54008] = {
        name = "Renovación de seguro",
    },
    [54009] = {
        name = "Todo asegurado",
    },
    [54012] = {
        name = "Almas afortunadas",
    },
    [54015] = {
        name = "Hacia las profundidades",
    },
    [54018] = {
        name = "Descenso",
    },
    [54021] = {
        name = "La Primera Arcanista",
    },
    [54022] = {
        name = "Planes de batalla de Mekkatorque",
    },
    [54028] = {
        name = "Meca contra nave de guerra",
    },
    [54031] = {
        name = "La mirada de los loa: Krag'wa",
    },
    [54032] = {
        name = "La mirada de los loa: Pa'ku",
    },
    [54033] = {
        name = "La mirada de los loa: Gonk",
    },
    [54034] = {
        name = "La mirada de los loa: Bwonsamdi",
    },
    [54041] = {
        name = "Sin sobrevivientes",
    },
    [54042] = {
        name = "Problemas en Costa Oscura",
    },
    [54043] = {
        name = "Reunión de forestales oscuros",
    },
    [54044] = {
        name = "Luna negra en el cielo",
    },
    [54045] = {
        name = "¡Basta de enredaderas!",
    },
    [54046] = {
        name = "Esto aún no ha terminado",
    },
    [54047] = {
        name = "Donde muere la esperanza",
    },
    [54049] = {
        name = "En medio de la noche",
    },
    [54050] = {
        name = "Secuelas",
    },
    [54058] = {
        name = "Consecuencias inesperadas",
    },
    [54059] = {
        name = "La guerrera nocturna",
    },
    [54083] = {
        name = "Engrasa las ruedas",
    },
    [54086] = {
        name = "El robot indicado para el trabajo",
    },
    [54087] = {
        name = "Tienes que tener esta altura",
    },
    [54088] = {
        name = "La leyenda de Mecalópolis",
    },
    [54094] = {
        name = "La definición de éxito según un goblin",
    },
    [54096] = {
        name = "La caída de la Fuente del Sol",
    },
    [54097] = {
        name = "El llamado de la Dama Oscura",
    },
    [54099] = {
        name = "El alto señor supremo",
    },
    [54100] = {
        name = "Una salida",
    },
    [54101] = {
        name = "Siguiendo la pista",
    },
    [54102] = {
        name = "Escape en el este",
    },
    [54103] = {
        name = "Encrucijada",
    },
    [54104] = {
        name = "Señales de Colmillosauro",
    },
    [54105] = {
        name = "Siempre hacia el este",
    },
    [54106] = {
        name = "Rastros revelados",
    },
    [54107] = {
        name = "Novedades funestas",
    },
    [54108] = {
        name = "La muerte de un guerrero",
    },
    [54109] = {
        name = "El favor de la reina",
    },
    [54113] = {
        name = "Toda muerte sirve",
    },
    [54114] = {
        name = "Toda muerte sirve",
    },
    [54117] = {
        name = "Toda muerte sirve",
    },
    [54118] = {
        name = "Toda muerte sirve",
    },
    [54120] = {
        name = "A Orgrimmar",
    },
    [54121] = {
        name = "Fuga de Aspafresno",
    },
    [54123] = {
        name = "¡Eso es de mi meca!",
    },
    [54124] = {
        name = "Cómo evitar demandas - Vol. I",
    },
    [54126] = {
        name = "Torcer el puñal",
    },
    [54128] = {
        name = "Medidas preventivas",
    },
    [54139] = {
        name = "El estallido de la guerra",
    },
    [54140] = {
        name = "El viaje de los zandalari",
    },
    [54141] = {
        name = "El medallón de Azshara",
    },
    [54144] = {
        name = "Órdenes de Azshara",
    },
    [54145] = {
        name = "El loa de la muerte",
    },
    [54147] = {
        name = "Confronta a la Val'kyr",
    },
    [54156] = {
        name = "Un rastro de sangre",
    },
    [54157] = {
        name = "Nadie queda atrás",
    },
    [54161] = {
        name = "Gajes de los drust",
    },
    [54163] = {
        name = "A fin de cuentas",
    },
    [54164] = {
        name = "La muerte del rey",
    },
    [54165] = {
        name = "El regreso de Derek Valiente",
    },
    [54169] = {
        name = "Asalto a la tesorería",
    },
    [54171] = {
        name = "El cetro abisal",
    },
    [54174] = {
        name = "Órdenes de Azshara",
    },
    [54175] = {
        name = "Enfrenta a tu enemigo",
    },
    [54176] = {
        name = "Una estrategia uniforme",
    },
    [54177] = {
        name = "Una distracción brillante",
    },
    [54178] = {
        name = "Consigue un transporte",
    },
    [54179] = {
        name = "Por la puerta principal",
    },
    [54183] = {
        name = "Tarea de reconocimiento",
    },
    [54191] = {
        name = "Cambio de rumbo",
    },
    [54192] = {
        name = "Información sensible",
    },
    [54193] = {
        name = "¡Esto es enorme!",
    },
    [54194] = {
        name = "Un poder enorme",
    },
    [54195] = {
        name = "Una bestia intelectual",
    },
    [54196] = {
        name = "Opciones agotadas",
    },
    [54197] = {
        name = "Libertad para los da'kani",
    },
    [54198] = {
        name = "Despedida agridulce",
    },
    [54199] = {
        name = "Las necesidades de la mayoría",
    },
    [54200] = {
        name = "La base es lo primero",
    },
    [54201] = {
        name = "A la medida de Grong",
    },
    [54202] = {
        name = "Calibración del núcleo",
    },
    [54203] = {
        name = "El engrandecimiento",
    },
    [54204] = {
        name = "Destrucción total del templo",
    },
    [54205] = {
        name = "Una buena siesta",
    },
    [54206] = {
        name = "El agente somnífero",
    },
    [54207] = {
        name = "Recuperación de la avanzada",
    },
    [54208] = {
        name = "Buscaminas",
    },
    [54211] = {
        name = "Faltan algunos goblins en tu escuadrón",
    },
    [54212] = {
        name = "Re-reconstrucción del M.I.D.A.S.-V",
    },
    [54213] = {
        name = "¡Está vivo!",
    },
    [54224] = {
        name = "La batalla por las Ruinas de Zul'jan",
    },
    [54244] = {
        name = "Los tenemos arrinconados",
    },
    [54249] = {
        name = "Justicia zandalari",
    },
    [54265] = {
        name = "Órdenes de Azshara",
    },
    [54269] = {
        name = "Nadie escapará",
    },
    [54270] = {
        name = "Espejos rotos",
    },
    [54271] = {
        name = "La purga de Telaamon",
    },
    [54275] = {
        name = "Basta de niebla",
    },
    [54280] = {
        name = "Vuela a la batalla",
    },
    [54282] = {
        name = "Batalla de Dazar'alor",
    },
    [54300] = {
        name = "Crisis de fe",
    },
    [54301] = {
        name = "La piedad de Talanji",
    },
    [54302] = {
        name = "La caída de Zuldazar",
    },
    [54303] = {
        name = "La marcha hacia Nazmir",
    },
    [54310] = {
        name = "Un nuevo propósito para la aldea",
    },
    [54312] = {
        name = "Niebla de guerra",
    },
    [54402] = {
        name = "Cambio de velocidades",
    },
    [54404] = {
        name = "Maquinaciones de los Hierro Negro",
    },
    [54407] = {
        name = "Al acecho en el pantano",
    },
    [54412] = {
        name = "La inundación de Zul'jan",
    },
    [54416] = {
        name = "Preparativos del frente de batalla",
    },
    [54417] = {
        name = "Demostración de poderío",
    },
    [54418] = {
        name = "El meca de la muerte",
    },
    [54419] = {
        name = "Pacificación de masas",
    },
    [54421] = {
        name = "Bestias domadas",
    },
    [54433] = {
        name = "Órdenes de Azshara",
    },
    [54438] = {
        name = "Crisol de Tormentas: Reliquias de sombra",
    },
    [54439] = {
        name = "Crisol de Tormentas: Reliquias de sombra",
    },
    [54441] = {
        name = "Conquista de la Puerta de Sangre",
    },
    [54459] = {
        name = "El que camina en la Luz",
    },
    [54485] = {
        name = "Batalla de Dazar'alor",
    },
    [54510] = {
        name = "Travesura realizada",
    },
    [54518] = {
        name = "Sin zepelín",
    },
    [54519] = {
        name = "Una patrulla en apuros",
    },
    [54559] = {
        name = "¡Libera a Plumeria!",
    },
    [54576] = {
        name = "Lo mejor de Gnomeregan",
    },
    [54577] = {
        name = "Cámaras sombrías y engranajes polvorientos",
    },
    [54580] = {
        name = "Un enigma boreal",
    },
    [54581] = {
        name = "Ahora con más aves mecánicas",
    },
    [54582] = {
        name = "Más astuto que el trogg promedio",
    },
    [54639] = {
        name = "Una señal de Las Cumbres Tormentosas",
    },
    [54640] = {
        name = "¡Gno-más piedad!",
    },
    [54641] = {
        name = "¡Por Gnomeregan!",
    },
    [54642] = {
        name = "¡A la C.A.R.G.A.!",
    },
    [54703] = {
        name = "Correo urgente",
    },
    [54706] = {
        name = "Hecho en Kul Tiras",
    },
    [54708] = {
        name = "A la vista",
    },
    [54721] = {
        name = "No tengo edad para esto",
    },
    [54723] = {
        name = "A cubrirse",
    },
    [54725] = {
        name = "Criaturas de las profundidades",
    },
    [54726] = {
        name = "Marco de trabajo",
    },
    [54727] = {
        name = "Trabajo en equipo",
    },
    [54728] = {
        name = "La madera embrujada",
    },
    [54729] = {
        name = "Las Colinas Lóbregas",
    },
    [54730] = {
        name = "La influencia de Gorak Tul",
    },
    [54731] = {
        name = "El equilibrio de todas las cosas",
    },
    [54732] = {
        name = "¡Suelta eso!",
    },
    [54733] = {
        name = "Una Wright en apuros",
    },
    [54734] = {
        name = "El llamado de Doriana",
    },
    [54735] = {
        name = "Una tripulación digna",
    },
    [54754] = {
        name = "Por la reina",
    },
    [54759] = {
        name = "Cuando los espíritus susurran",
    },
    [54760] = {
        name = "Los caminaespíritus",
    },
    [54761] = {
        name = "Guía espiritual",
    },
    [54762] = {
        name = "Un pequeño retiro",
    },
    [54763] = {
        name = "Cruce al otro lado",
    },
    [54764] = {
        name = "Tormenta en Pezuña de Sangre",
    },
    [54765] = {
        name = "Agradécele a tu guía",
    },
    [54766] = {
        name = "Responde al llamado",
    },
    [54787] = {
        name = "Mascarada",
    },
    [54850] = {
        name = "Operación: Troggagedón",
    },
    [54851] = {
        name = "Bendición de las mareas",
    },
    [54871] = {
        name = "Estamos en camino",
    },
    [54913] = {
        name = "Chispa de genialidad",
    },
    [54915] = {
        name = "Telemetría en línea",
    },
    [54916] = {
        name = "El credo del montero",
    },
    [54917] = {
        name = "Pago con sangre",
    },
    [54918] = {
        name = "La Chispa de la Imaginación",
    },
    [54919] = {
        name = "Vínculos atronadores",
    },
    [54920] = {
        name = "Camino a casa",
    },
    [54922] = {
        name = "Tuercas, tornillos y muchos colores",
    },
    [54925] = {
        name = "¡Herejía!",
    },
    [54929] = {
        name = "Listo para la pelea",
    },
    [54930] = {
        name = "Liberación mecánica",
    },
    [54938] = {
        name = "La ayuda de un hermano",
    },
    [54939] = {
        name = "Terco como un Barbabronce",
    },
    [54940] = {
        name = "La necesidad es la MADRE",
    },
    [54945] = {
        name = "Un buen comienzo",
    },
    [54946] = {
        name = "Preséntate ante Gina",
    },
    [54947] = {
        name = "Un equipo pequeño",
    },
    [54958] = {
        name = "Un encuentro fugaz",
    },
    [54959] = {
        name = "Bajo llave",
    },
    [54960] = {
        name = "Un amargo reencuentro",
    },
    [54961] = {
        name = "Subsanando errores",
    },
    [54964] = {
        name = "Un boleto de ida al corazón",
    },
    [54965] = {
        name = "Robots desguazados",
    },
    [54969] = {
        name = "Descenso",
    },
    [54972] = {
        name = "Un camino a casa",
    },
    [54975] = {
        name = "Un breve respiro",
    },
    [54992] = {
        name = "El comienzo de algo más grande",
    },
    [54997] = {
        name = "Atrapado en altamar",
    },
    [54999] = {
        name = "Con banderas falsas",
    },
    [55028] = {
        name = "Es trabajo para un chatarrero...",
    },
    [55031] = {
        name = "Es trabajo para un chatarrero...",
    },
    [55033] = {
        name = "Un freno a Aspafresno",
    },
    [55034] = {
        name = "Con banderas falsas",
    },
    [55039] = {
        name = "Carpintero de barcos maestro",
    },
    [55040] = {
        name = "Un vistazo al interior",
    },
    [55043] = {
        name = "Historias de pescadores y velas lejanas",
    },
    [55044] = {
        name = "No mates al mensajero",
    },
    [55045] = {
        name = "El guardián de mi hermano",
    },
    [55047] = {
        name = "Asegurar Fuerte Guerracolmillo",
    },
    [55048] = {
        name = "Juegos de espías",
    },
    [55049] = {
        name = "Problemas de comunicación",
    },
    [55050] = {
        name = "¿Podría ver su boleto?",
    },
    [55051] = {
        name = "Una demostración de poder",
    },
    [55052] = {
        name = "Asegurar Fuerte Guerracolmillo",
    },
    [55053] = {
        name = "Un camino a casa",
    },
    [55054] = {
        name = "Levantamiento",
    },
    [55055] = {
        name = "Una trampa para peces más grande",
    },
    [55087] = {
        name = "La tormenta se cierne",
    },
    [55088] = {
        name = "Perdido en el campo",
    },
    [55089] = {
        name = "Un espía y medio",
    },
    [55090] = {
        name = "Una congregación de enemigos",
    },
    [55092] = {
        name = "Perturbación de poder",
    },
    [55094] = {
        name = "¡Rápido y sigiloso!",
    },
    [55095] = {
        name = "Levantamiento",
    },
    [55096] = {
        name = "Envíale un mensaje a mi padre",
    },
    [55101] = {
        name = "Guía práctica del arte de la chatarrería",
    },
    [55103] = {
        name = "Las ideas pueden venir de cualquier lado",
    },
    [55116] = {
        name = "Consigue una pista",
    },
    [55117] = {
        name = "Correspondencia enigmática",
    },
    [55118] = {
        name = "Cabos sueltos",
    },
    [55119] = {
        name = "¡Reportándose!",
    },
    [55121] = {
        name = "El laboratorio de Mardivas",
    },
    [55124] = {
        name = "Subsanando errores",
    },
    [55136] = {
        name = "Horrores perros",
    },
    [55153] = {
        name = "Construcción colaborativa",
    },
    [55171] = {
        name = "Espía contra espía",
    },
    [55175] = {
        name = "A donde lleva el camino",
    },
    [55177] = {
        name = "Costuras desgarradas",
    },
    [55179] = {
        name = "Represalias coordinadas",
    },
    [55182] = {
        name = "Reensamblaje forzoso",
    },
    [55183] = {
        name = "En busca de terreno elevado",
    },
    [55185] = {
        name = "¡Escucha con atención!",
    },
    [55188] = {
        name = "Costuras desgarradas",
    },
    [55195] = {
        name = "Reverberancia",
    },
    [55210] = {
        name = "No incluye baterías",
    },
    [55211] = {
        name = "Pernoxidado recargado",
    },
    [55214] = {
        name = "Puntos y puntadas",
    },
    [55216] = {
        name = "La audición",
    },
    [55217] = {
        name = "Deuda saldada",
    },
    [55218] = {
        name = "Cuero preciado de Sheza",
    },
    [55219] = {
        name = "Una visita a la base",
    },
    [55220] = {
        name = "Pesca de profundidad",
    },
    [55221] = {
        name = "Lo siento en los huesos",
    },
    [55222] = {
        name = "Hora de hacer bullicio",
    },
    [55223] = {
        name = "Instrumentos de destrucción",
    },
    [55227] = {
        name = "La artesana de los eones",
    },
    [55228] = {
        name = "La audición",
    },
    [55229] = {
        name = "Deuda saldada",
    },
    [55230] = {
        name = "Cuero preciado de Telonis",
    },
    [55231] = {
        name = "El otro Danzaespíritus",
    },
    [55232] = {
        name = "La amenaza de Mevris",
    },
    [55233] = {
        name = "Lo siento en los huesos",
    },
    [55234] = {
        name = "Hora de hacer bullicio",
    },
    [55235] = {
        name = "Instrumentos de destrucción",
    },
    [55247] = {
        name = "La confianza ganada",
    },
    [55252] = {
        name = "Un loa sin templo",
    },
    [55253] = {
        name = "Una prueba de fe",
    },
    [55254] = {
        name = "Un sueño eterno",
    },
    [55258] = {
        name = "Dormir, comer, repetir",
    },
    [55298] = {
        name = "Pesca mayor",
    },
    [55339] = {
        name = "Limpieza mayor",
    },
    [55361] = {
        name = "El chamán perdido",
    },
    [55362] = {
        name = "Furia elemental",
    },
    [55363] = {
        name = "El rescate del clarividente",
    },
    [55373] = {
        name = "Palizas mecánicas",
    },
    [55374] = {
        name = "Perturbaciones subterráneas",
    },
    [55384] = {
        name = "Asentamiento",
    },
    [55385] = {
        name = "Exploración de los recintos",
    },
    [55390] = {
        name = "Sueño en la oscuridad",
    },
    [55392] = {
        name = "Entrada a la Senda de los Sueños",
    },
    [55393] = {
        name = "Anula el Vacío",
    },
    [55394] = {
        name = "Fragmentos de esmeralda",
    },
    [55395] = {
        name = "No cierres los ojos",
    },
    [55396] = {
        name = "La esencia de los sueños",
    },
    [55397] = {
        name = "Antes de despertar",
    },
    [55398] = {
        name = "La larga vigilia",
    },
    [55400] = {
        name = "Toma mi mano",
    },
    [55407] = {
        name = "Calma la Espina",
    },
    [55425] = {
        name = "Dominar lo indómito",
    },
    [55462] = {
        name = "El llamado de la errante",
    },
    [55465] = {
        name = "Debemos adentrarnos más",
    },
    [55469] = {
        name = "Hacia Zin-Azshari",
    },
    [55481] = {
        name = "Explorando el Palacio",
    },
    [55482] = {
        name = "En busca de una conexión",
    },
    [55485] = {
        name = "Terror en las profundidades",
    },
    [55486] = {
        name = "Los secretos de la telemancia",
    },
    [55488] = {
        name = "Habla con los muertos",
    },
    [55489] = {
        name = "La historia de la fámula",
    },
    [55490] = {
        name = "Les pincharemos los ojos",
    },
    [55497] = {
        name = "Un rostro aliado",
    },
    [55500] = {
        name = "Salva a una amiga",
    },
    [55503] = {
        name = "El cuernoatroz y el sáurido",
    },
    [55504] = {
        name = "Santuarios de Zuldazar",
    },
    [55505] = {
        name = "En memoria de Roo'li",
    },
    [55506] = {
        name = "Un camino termina",
    },
    [55507] = {
        name = "Bendición de Torcali",
    },
    [55519] = {
        name = "Trauma reciente",
    },
    [55520] = {
        name = "Curando Nordrassil",
    },
    [55521] = {
        name = "Al estilo de la azerita",
    },
    [55529] = {
        name = "Sin sobras",
    },
    [55530] = {
        name = "Un lugar más seguro",
    },
    [55533] = {
        name = "Escucha siempre a MADRE",
    },
    [55558] = {
        name = "Un refugio",
    },
    [55560] = {
        name = "La venganza de Utama",
    },
    [55561] = {
        name = "Los restos de Zin-Azshari",
    },
    [55565] = {
        name = "Acumulación de reservas de maná",
    },
    [55569] = {
        name = "Ecos de dolor",
    },
    [55570] = {
        name = "Secretos en la ruinas",
    },
    [55571] = {
        name = "Ayúdalos a conocer la verdad",
    },
    [55573] = {
        name = "La purga de los profanadores",
    },
    [55574] = {
        name = "Las Jabalinas de Azshara",
    },
    [55585] = {
        name = "Un comienzo prometedor",
    },
    [55586] = {
        name = "Pulido y encerado",
    },
    [55590] = {
        name = "Reparaciones sagradas",
    },
    [55592] = {
        name = "Un comienzo prometedor",
    },
    [55593] = {
        name = "Información sobre nuestros enemigos",
    },
    [55594] = {
        name = "Pulido y encerado",
    },
    [55595] = {
        name = "Conocimiento en deterioro",
    },
    [55596] = {
        name = "Reparaciones sagradas",
    },
    [55597] = {
        name = "Atados por el honor",
    },
    [55598] = {
        name = "Lo que sabemos de los nagas",
    },
    [55599] = {
        name = "Exploración encubierta",
    },
    [55600] = {
        name = "Cómo saciar a un boca de dragón",
    },
    [55601] = {
        name = "Cristales preciados",
    },
    [55608] = {
        name = "Proyecto de taller",
    },
    [55618] = {
        name = "La Forja del Corazón",
    },
    [55622] = {
        name = "A conducir",
    },
    [55630] = {
        name = "Un buen comienzo",
    },
    [55632] = {
        name = "Tienes que tener esta altura",
    },
    [55635] = {
        name = "Una voz en el viento",
    },
    [55645] = {
        name = "Visita principesca",
    },
    [55646] = {
        name = "La leyenda de Mecalópolis",
    },
    [55647] = {
        name = "Espionaje veloz",
    },
    [55648] = {
        name = "Ahora es nuestra bóveda",
    },
    [55649] = {
        name = "Maquinaciones para Mecalópolis",
    },
    [55650] = {
        name = "Solo los mejores",
    },
    [55651] = {
        name = "¡A Mecalópolis!",
    },
    [55652] = {
        name = "Bahía de Prospectus",
    },
    [55657] = {
        name = "Bajo la sombra de alas carmesí",
    },
    [55685] = {
        name = "En busca de paz… y dinero",
    },
    [55694] = {
        name = "Algo en el agua",
    },
    [55696] = {
        name = "Paseo de prueba",
    },
    [55697] = {
        name = "Las dos patitas de atrás",
    },
    [55707] = {
        name = "La primera es gratis",
    },
    [55708] = {
        name = "Mejora",
    },
    [55729] = {
        name = "¡La Resistencia te necesita!",
    },
    [55730] = {
        name = "El rescate de la Resistencia",
    },
    [55731] = {
        name = "Los ejércitos de mi padre",
    },
    [55732] = {
        name = "Una vieja cicatriz",
    },
    [55734] = {
        name = "Construcción de plataforma de excavación",
    },
    [55735] = {
        name = "La defensa de la Vorágine",
    },
    [55736] = {
        name = "Bienvenido a la Resistencia",
    },
    [55737] = {
        name = "En los tiempos de la azerita",
    },
    [55752] = {
        name = "Estamos unidos",
    },
    [55753] = {
        name = "Esquemas esquemáticos",
    },
    [55778] = {
        name = "Visiones de peligro",
    },
    [55779] = {
        name = "Ejecución pospuesta",
    },
    [55780] = {
        name = "Viejos aliados",
    },
    [55781] = {
        name = "Viejos aliados",
    },
    [55782] = {
        name = "Ejecución pospuesta",
    },
    [55783] = {
        name = "Ejecución pospuesta",
    },
    [55784] = {
        name = "Pago en retribución",
    },
    [55795] = {
        name = "Montaña en movimiento",
    },
    [55796] = {
        name = "Herejía en el Cruce",
    },
    [55797] = {
        name = "La furia de la madre cuernoatroz",
    },
    [55798] = {
        name = "No deambules en soledad",
    },
    [55799] = {
        name = "Cambia la marea",
    },
    [55860] = {
        name = "Liquidación de babosas marinas",
    },
    [55861] = {
        name = "Que los residuos te guíen",
    },
    [55862] = {
        name = "Información sobre nuestros enemigos",
    },
    [55863] = {
        name = "Conocimiento en deterioro",
    },
    [55864] = {
        name = "Pagarán con su vida",
    },
    [55865] = {
        name = "Lo que sabemos de los nagas",
    },
    [55866] = {
        name = "Exploración encubierta",
    },
    [55867] = {
        name = "Cristales preciados",
    },
    [55868] = {
        name = "Que los residuos te guíen",
    },
    [55869] = {
        name = "Limpieza de las reservas",
    },
    [55870] = {
        name = "Liquidación de babosas marinas",
    },
    [55937] = {
        name = "Limpieza de las reservas",
    },
    [55967] = {
        name = "Cómo saciar a un boca de dragón",
    },
    [55983] = {
        name = "Un lugar más seguro",
    },
    [55995] = {
        name = "Podemos repararlo",
    },
    [56030] = {
        name = "La orden de la jefa de guerra",
    },
    [56031] = {
        name = "La ofensiva del lobo",
    },
    [56037] = {
        name = "Robar los secretos de los nagas",
    },
    [56038] = {
        name = "Trabajar con propósito",
    },
    [56039] = {
        name = "Armas desafiladas nunca",
    },
    [56043] = {
        name = "Envía la flota",
    },
    [56044] = {
        name = "Envía la flota",
    },
    [56045] = {
        name = "Robar los secretos de los nagas",
    },
    [56046] = {
        name = "Trabajar con propósito",
    },
    [56047] = {
        name = "Armas desafiladas nunca",
    },
    [56063] = {
        name = "Mareas oscuras",
    },
    [56095] = {
        name = "Legado de Nar'anan",
    },
    [56118] = {
        name = "Contraataque",
    },
    [56143] = {
        name = "El destino de la profesora Elryna",
    },
    [56156] = {
        name = "Una espada templada",
    },
    [56167] = {
        name = "Investigación de las Tierras Altas",
    },
    [56168] = {
        name = "Renovación fabril",
    },
    [56175] = {
        name = "Libre de humo",
    },
    [56181] = {
        name = "Yo invito",
    },
    [56209] = {
        name = "Cámaras de los Orígenes",
    },
    [56210] = {
        name = "Piedras de detección",
    },
    [56211] = {
        name = "Piedras de detección",
    },
    [56234] = {
        name = "Amigos necesitados",
    },
    [56235] = {
        name = "Hacia Nazjatar",
    },
    [56236] = {
        name = "Un problema menos",
    },
    [56239] = {
        name = "Extraño cuchillo de plata",
    },
    [56240] = {
        name = "Extraño cuchillo de plata",
    },
    [56241] = {
        name = "Pistas conservadas",
    },
    [56242] = {
        name = "Pistas conservadas",
    },
    [56243] = {
        name = "Diarios de los muertos",
    },
    [56244] = {
        name = "Diarios de los muertos",
    },
    [56245] = {
        name = "Candado encantado",
    },
    [56246] = {
        name = "Candado encantado",
    },
    [56247] = {
        name = "Historias de tesoros",
    },
    [56248] = {
        name = "Historias de tesoros",
    },
    [56304] = {
        name = "Búsqueda de vida",
    },
    [56305] = {
        name = "¡Vamos a pescar!",
    },
    [56309] = {
        name = "Ciudad de amigos ahogados",
    },
    [56310] = {
        name = "Ciudad de amigos ahogados",
    },
    [56311] = {
        name = "El ahogo eterno",
    },
    [56312] = {
        name = "El ahogo eterno",
    },
    [56313] = {
        name = "Portento de guerra",
    },
    [56314] = {
        name = "Portento de guerra",
    },
    [56315] = {
        name = "Tomaron una decisión",
    },
    [56316] = {
        name = "Tomaron una decisión",
    },
    [56319] = {
        name = "El contrato Supercarga",
    },
    [56320] = {
        name = "¡La primera carga es gratis!",
    },
    [56321] = {
        name = "Salva a Corin",
    },
    [56325] = {
        name = "Un cambio en la marea",
    },
    [56346] = {
        name = "Tecnología antigua",
    },
    [56347] = {
        name = "Una oportunidad abisal",
    },
    [56348] = {
        name = "El Palacio Eterno: Podemos hacerlo mejor...",
    },
    [56349] = {
        name = "El Palacio Eterno: Hasta el límite",
    },
    [56350] = {
        name = "Explorando el Palacio",
    },
    [56351] = {
        name = "El Palacio Eterno: Hasta el límite",
    },
    [56352] = {
        name = "El Palacio Eterno: Podemos hacerlo mejor...",
    },
    [56353] = {
        name = "Una oportunidad abisal",
    },
    [56354] = {
        name = "Tecnología antigua",
    },
    [56356] = {
        name = "El Palacio Eterno: La estrategia de la reina",
    },
    [56358] = {
        name = "El Palacio Eterno: La estrategia de la reina",
    },
    [56374] = {
        name = "Un problema titánico",
    },
    [56375] = {
        name = "A Ramkahen",
    },
    [56376] = {
        name = "Amenazas incipientes",
    },
    [56377] = {
        name = "La forja eterna",
    },
    [56378] = {
        name = "La tripulación faltante",
    },
    [56379] = {
        name = "La tripulación faltante",
    },
    [56401] = {
        name = "Aporte azul",
    },
    [56422] = {
        name = "Sobre alas fantasmales",
    },
    [56429] = {
        name = "En aprietos",
    },
    [56472] = {
        name = "Convenio de Uldum",
    },
    [56494] = {
        name = "Víspera de la batalla",
    },
    [56495] = {
        name = "Actúan en nuestra contra",
    },
    [56496] = {
        name = "Víspera de la batalla",
    },
    [56536] = {
        name = "Nada es fácil",
    },
    [56537] = {
        name = "El sigilo misterioso",
    },
    [56538] = {
        name = "Clanes de los mogu",
    },
    [56539] = {
        name = "En busca de los Rajani",
    },
    [56540] = {
        name = "Prueba de tenacidad",
    },
    [56541] = {
        name = "El Motor de Nalak'sha",
    },
    [56542] = {
        name = "Esperanza renovada",
    },
    [56560] = {
        name = "Un descubrimiento curioso",
    },
    [56561] = {
        name = "Un descubrimiento curioso",
    },
    [56574] = {
        name = "Reflexiones en ámbar",
    },
    [56575] = {
        name = "Una vez más a Kor'vess",
    },
    [56576] = {
        name = "Exterminación de aqir",
    },
    [56577] = {
        name = "Paralizando a la colmena",
    },
    [56578] = {
        name = "Corrupción desde las raíces",
    },
    [56580] = {
        name = "Secretos de ámbar",
    },
    [56616] = {
        name = "Caras viejas, problemas nuevos",
    },
    [56617] = {
        name = "Un enjambre unificado",
    },
    [56640] = {
        name = "Almas afortunadas",
    },
    [56641] = {
        name = "Perturbación de poder",
    },
    [56642] = {
        name = "Mareas oscuras",
    },
    [56643] = {
        name = "Hacia las profundidades",
    },
    [56644] = {
        name = "En aprietos",
    },
    [56645] = {
        name = "Corazón del enjambre",
    },
    [56647] = {
        name = "La amenaza mántide",
    },
    [56719] = {
        name = "Esto no es mío",
    },
    [56739] = {
        name = "El poder de la oración",
    },
    [56741] = {
        name = "La lanza del destino",
    },
    [56771] = {
        name = "Guerreros perdidos en el tiempo",
    },
    [56833] = {
        name = "Líderes de la Horda",
    },
    [56979] = {
        name = "Salvar el asedio",
    },
    [56980] = {
        name = "Ocultos entre nosotros",
    },
    [56981] = {
        name = "Despliegue estratégico",
    },
    [56982] = {
        name = "Ante las puertas de Orgrimmar",
    },
    [56993] = {
        name = "El precio de la victoria",
    },
    [57002] = {
        name = "Soldado veterano",
    },
    [57005] = {
        name = "Nuevos amigos",
    },
    [57006] = {
        name = "Un aliado valioso",
    },
    [57010] = {
        name = "Inyección de poder",
    },
    [57067] = {
        name = "Mogu en las puertas",
    },
    [57068] = {
        name = "Espionaje en cometa",
    },
    [57069] = {
        name = "Córtales la cabeza",
    },
    [57070] = {
        name = "Masacre mogu",
    },
    [57071] = {
        name = "Ninguna cerveza queda atrás",
    },
    [57072] = {
        name = "Yak multifunción",
    },
    [57074] = {
        name = "Entre la espada y la puerta",
    },
    [57076] = {
        name = "Regreso a Bruma Otoñal",
    },
    [57088] = {
        name = "Esto no es mío",
    },
    [57090] = {
        name = "Salvar el asedio",
    },
    [57091] = {
        name = "Ocultos entre nosotros",
    },
    [57092] = {
        name = "Despliegue estratégico",
    },
    [57093] = {
        name = "Ante las puertas de Orgrimmar",
    },
    [57094] = {
        name = "El precio de la victoria",
    },
    [57095] = {
        name = "Soldado veterano",
    },
    [57126] = {
        name = "...y vientos favorables",
    },
    [57130] = {
        name = "Traidores entre nosotros",
    },
    [57147] = {
        name = "Abajo Sylvanas",
    },
    [57148] = {
        name = "Rompeasedios",
    },
    [57149] = {
        name = "Acaba con la propaganda",
    },
    [57150] = {
        name = "Milicia",
    },
    [57151] = {
        name = "Una línea en la arena",
    },
    [57152] = {
        name = "Fiel hasta la muerte",
    },
    [57198] = {
        name = "Sentido del deber",
    },
    [57220] = {
        name = "Inicio del protocolo de potencia",
    },
    [57221] = {
        name = "Reoriginación",
    },
    [57222] = {
        name = "Investigación de Cámaras",
    },
    [57290] = {
        name = "Comienzo del descenso",
    },
    [57324] = {
        name = "Sigue a la marea",
    },
    [57362] = {
        name = "En lo profundo de la oscuridad",
    },
    [57373] = {
        name = "Descenso hacia la locura",
    },
    [57374] = {
        name = "Hacia Las Profundidades Más Oscuras",
    },
    [57376] = {
        name = "La necesidad oculta",
    },
    [57378] = {
        name = "Restos de un mundo destrozado",
    },
    [57486] = {
        name = "Energía menguante",
    },
    [57487] = {
        name = "Alguien que nos ayude",
    },
    [57488] = {
        name = "El esquema actual",
    },
    [57490] = {
        name = "Viaje a la seguridad",
    },
    [57491] = {
        name = "Mejor, más fuerte y menos muerto",
    },
    [57492] = {
        name = "¿Él?",
    },
    [57493] = {
        name = "Armonización mental",
    },
    [57494] = {
        name = "Un corazón fuerte",
    },
    [57495] = {
        name = "El futuro de Mecalópolis",
    },
    [57496] = {
        name = "Ascensión",
    },
    [57497] = {
        name = "Propagación de noticias",
    },
    [57524] = {
        name = "Acceso a los archivos",
    },
    [57873] = {
        name = "Novedades de Orsis",
    },
    [57915] = {
        name = "Búsqueda de sobrevivientes",
    },
    [57954] = {
        name = "Quema los cuerpos",
    },
    [57955] = {
        name = "Hacia el Puerto Anjesenamón",
    },
    [57956] = {
        name = "Anfitriones vagayermos",
    },
    [57969] = {
        name = "Atender a los heridos",
    },
    [57970] = {
        name = "Arruinador Xok'nixx",
    },
    [57971] = {
        name = "Ruinas de Ammon",
    },
    [57990] = {
        name = "Obelisco del Sol",
    },
    [58008] = {
        name = "Tanque lleno",
    },
    [58009] = {
        name = "A la luna",
    },
    [58214] = {
        name = "Atención urgente",
    },
    [58496] = {
        name = "Un consejero inoportuno",
    },
    [58498] = {
        name = "El regreso de rey guerrero",
    },
    [58502] = {
        name = "Directo al corazón",
    },
    [58506] = {
        name = "Diagnósticos de red",
    },
    [58582] = {
        name = "Regreso del Príncipe Negro",
    },
    [58606] = {
        name = "Un poco de investigación",
    },
    [58615] = {
        name = "Susurros en la oscuridad",
    },
    [58631] = {
        name = "Hacia los sueños",
    },
    [58632] = {
        name = "Ny'alotha, la Ciudad Despierta: El fin del Corruptor",
    },
    [58634] = {
        name = "Apertura del portal",
    },
    [58636] = {
        name = "Ojos puestos en los Amathet",
    },
    [58638] = {
        name = "Una mirada más a fondo",
    },
    [58639] = {
        name = "Historia enterrada",
    },
    [58640] = {
        name = "Una rajadura en la armadura",
    },
    [58641] = {
        name = "Inquiridores de la corrupción",
    },
    [58642] = {
        name = "Objetivos en común",
    },
    [58643] = {
        name = "Destrucción mutuamente asegurada",
    },
    [58645] = {
        name = "Un mundo por salvar",
    },
    [58646] = {
        name = "¡Coman esto!",
    },
    [58737] = {
        name = "Los descubrimientos de Magni",
    },
})
]])()
