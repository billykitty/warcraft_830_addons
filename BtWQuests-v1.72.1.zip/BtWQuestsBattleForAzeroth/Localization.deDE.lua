----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "deDE" then
    return
end

local L = BtWQuests.L
L["ALLIED_RACE_MECHAGNOME"] = "Verbündete Völker: Mechagnom"
L["ALLIED_RACE_VULPERA"] = "Verbündete Völker: Vulpera"
L["BTWQUESTS_COSMETIC_WAIST_OF_TIME"] = "Kosmetisch: Zeitvergoldung"
L["BTWQUESTS_GIFT_OF_NZOTH"] = "N'Zoths Geschenk"
L["BTWQUESTS_HATI_REBORN"] = "Wiedergeborener Hati"
L["BTWQUESTS_HERITAGE_OF_GILNEAS"] = "Tradition von Gilneas"
L["BTWQUESTS_HERITAGE_OF_GNOMEREGAN"] = "Tradition von Gnomeregan"
L["BTWQUESTS_HERITAGE_OF_KEZAN"] = "Tradition von Kezan"
L["BTWQUESTS_HERITAGE_OF_THE_BRONZEBEARD"] = "Tradition der Bronzebarts"
L["BTWQUESTS_HERITAGE_OF_THE_SHUHALO"] = "Tradition der Shu'halo"
L["BTWQUESTS_HERITAGE_OF_THE_SINDOREI"] = "Tradition der Sin'dorei"
L["BTWQUESTS_MAGHAR_ORC"] = "Mag'har"
L["BTWQUESTS_NIGHT_WARRIOR_NIGHT_ELF_CUSTOMIZATION"] = "Anpassung \"Nachtkrieger\" für Nachtelfen"
L["BTWQUESTS_THE_WAR_CAMPAIGN"] = "Die Kriegskampagne"
L["BTWQUESTS_THE_WAR_CAMPAIGN_8_1"] = "Die Kriegskampagne: Die Schlacht von Dazar'alor"
L["BTWQUESTS_WARFRONT_THE_BATTLE_FOR_DARKSHORE"] = "Kriegsfront: Die Schlacht um die Dunkelküste"
L["DUNGEON_KINGS_REST"] = "Dungeon: Die Königsruh"
L["DUNGEON_SIEGE_OF_BORALUS"] = "Dungeon: Die Belagerung von Boralus"
L["MECHAGNOME"] = "Mechagnom"
L["WAIST_OF_TIME"] = "Zeitvergoldung"
