----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "itIT" then
    return
end

local L = BtWQuests.L
L["ALLIED_RACE_MECHAGNOME"] = "Allied Race: Meccagnomo"
L["BTWQUESTS_COSMETIC_WAIST_OF_TIME"] = "Decorativo: Cinta del Perditempo"
L["BTWQUESTS_GIFT_OF_NZOTH"] = "Dono di N'zoth"
L["BTWQUESTS_HATI_REBORN"] = "Rinascita di Hati"
L["BTWQUESTS_HERITAGE_OF_GILNEAS"] = "Retaggio di Gilneas"
L["BTWQUESTS_HERITAGE_OF_GNOMEREGAN"] = "Retaggio di Gnomeregan"
L["BTWQUESTS_HERITAGE_OF_KEZAN"] = "Retaggio di Kezan"
L["BTWQUESTS_HERITAGE_OF_THE_BRONZEBEARD"] = "Retaggio dei Barbabronzea"
L["BTWQUESTS_HERITAGE_OF_THE_SHUHALO"] = "Retaggio degli Shu'halo"
L["BTWQUESTS_HERITAGE_OF_THE_SINDOREI"] = "Retaggio dei Sin'dorei"
L["BTWQUESTS_MAGHAR_ORC"] = "Orco Mag'har"
L["BTWQUESTS_NIGHT_WARRIOR_NIGHT_ELF_CUSTOMIZATION"] = "Personalizzazione \"Guerriera della Notte\" per Elfi della Notte"
L["BTWQUESTS_THE_WAR_CAMPAIGN"] = "Campagna di Guerra"
L["BTWQUESTS_THE_WAR_CAMPAIGN_8_1"] = "Campagna di Guerra: Battaglia di Dazar'alor"
L["BTWQUESTS_WARFRONT_THE_BATTLE_FOR_DARKSHORE"] = "Fronte di Guerra: La Battaglia per Rivafosca"
L["DUNGEON_KINGS_REST"] = "Spedizione: Requie dei Re"
L["DUNGEON_SIEGE_OF_BORALUS"] = "Spedizione: Assedio di Boralus"
L["MECHAGNOME"] = "Meccagnomo"
L["WAIST_OF_TIME"] = "Cinta del Perditempo"
