----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "itIT" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateQuestsTable({
    [40537] = {
        name = "Prelievo di sangue",
    },
    [44785] = {
        name = "L'ora del tè",
    },
    [45079] = {
        name = "Il villaggio di Acqualunga",
    },
    [45972] = {
        name = "Il boschetto maledetto",
    },
    [46727] = {
        name = "Venti di guerra",
    },
    [46728] = {
        name = "La nazione di Kul Tiras",
    },
    [46729] = {
        name = "Il vecchio cavaliere",
    },
    [46846] = {
        name = "Parola di Zul",
    },
    [46926] = {
        name = "Estorsioni al porto",
    },
    [46927] = {
        name = "La punizione di Tal'aman",
    },
    [46928] = {
        name = "La punizione di Tal'farrak",
    },
    [46929] = {
        name = "Meglio prevenire che curare",
    },
    [46931] = {
        name = "Un'ambasciata per l'Orda",
    },
    [46957] = {
        name = "Benvenuti a Zuldazar",
    },
    [47098] = {
        name = "Fuga per la vittoria",
    },
    [47099] = {
        name = "Come sentirsi a proprio agio",
    },
    [47103] = {
        name = "In viaggio verso Nazmir",
    },
    [47105] = {
        name = "Nell'oscurità",
    },
    [47130] = {
        name = "Una sepoltura inappropriata",
    },
    [47181] = {
        name = "La pistola fumante",
    },
    [47186] = {
        name = "Santuario dei Saggi",
    },
    [47188] = {
        name = "Chiedere aiuto ai Loa",
    },
    [47189] = {
        name = "Una nazione divisa",
    },
    [47198] = {
        name = "Ci vogliono prendere vivi",
    },
    [47199] = {
        name = "La Porta Insanguinata",
    },
    [47200] = {
        name = "Zecche",
    },
    [47204] = {
        name = "La nuova prima linea",
    },
    [47205] = {
        name = "La Madre della Guerra",
    },
    [47226] = {
        name = "Il cucciolo orfano",
    },
    [47228] = {
        name = "L'ecologia di Xibala",
    },
    [47229] = {
        name = "Il Baluardo di Torcali",
    },
    [47235] = {
        name = "Occhio all'occhio",
    },
    [47241] = {
        name = "L'ombra della morte",
    },
    [47244] = {
        name = "Una selezione di anime",
    },
    [47245] = {
        name = "Messaggio ricevuto",
    },
    [47247] = {
        name = "Colui che perseguita i morti",
    },
    [47248] = {
        name = "Finché morte non ci separi",
    },
    [47249] = {
        name = "Vincolato",
    },
    [47250] = {
        name = "Arrivederci",
    },
    [47257] = {
        name = "Le Ossa di Xibala",
    },
    [47258] = {
        name = "Prepararsi all'assedio",
    },
    [47259] = {
        name = "Come prendersi cura di un cornofurente",
    },
    [47260] = {
        name = "Effetti collaterali inaspettati...",
    },
    [47261] = {
        name = "Come addestrare un cornofurente",
    },
    [47262] = {
        name = "Eliminare i Troll del Sangue",
    },
    [47263] = {
        name = "Un momento di rivelazione",
    },
    [47264] = {
        name = "Senza risparmiare nessuno",
    },
    [47272] = {
        name = "L'Ormone della Crescita dei Cornofurente",
    },
    [47289] = {
        name = "Orsetti e biscotti",
    },
    [47310] = {
        name = "L'ora del sonnellino",
    },
    [47311] = {
        name = "50 testate di divertimento",
    },
    [47312] = {
        name = "Regina delle Piume",
    },
    [47313] = {
        name = "Conversazioni discrete",
    },
    [47314] = {
        name = "Sussurri d'esilio",
    },
    [47315] = {
        name = "Tra le dune",
    },
    [47316] = {
        name = "Segreti nelle sabbie",
    },
    [47317] = {
        name = "Sopravvissuti sopravviventi",
    },
    [47319] = {
        name = "Un veleno curativo",
    },
    [47320] = {
        name = "Un balsamo per calmarli e delle loro ferite curarli",
    },
    [47321] = {
        name = "Una mano lava l'altra...",
    },
    [47322] = {
        name = "...ed entrambe lavano il viso",
    },
    [47324] = {
        name = "Alleati improbabili",
    },
    [47327] = {
        name = "Rispondere all'attacco",
    },
    [47329] = {
        name = "Il retaggio dei Mirasangue",
    },
    [47332] = {
        name = "La prossima mossa",
    },
    [47418] = {
        name = "Mal di Crescita",
    },
    [47422] = {
        name = "Una situazione terribile",
    },
    [47423] = {
        name = "Pratiche proibite",
    },
    [47428] = {
        name = "Miciooo!",
    },
    [47432] = {
        name = "Affare fatto",
    },
    [47433] = {
        name = "Offensivamente difensivo",
    },
    [47434] = {
        name = "Ordini restrittivi",
    },
    [47435] = {
        name = "Disputa pterritoriale",
    },
    [47437] = {
        name = "Il troppo stroppia",
    },
    [47438] = {
        name = "Scegliere da che parte stare",
    },
    [47439] = {
        name = "Gonk, Signore del Branco",
    },
    [47440] = {
        name = "Pa'ku, Signora dei Venti",
    },
    [47441] = {
        name = "Piccole Pesti",
    },
    [47442] = {
        name = "La maledizione di Jani",
    },
    [47445] = {
        name = "Il Concilio degli Zanchuli",
    },
    [47485] = {
        name = "La Compagnia dei Bracescura",
    },
    [47486] = {
        name = "Spedizioni sospette",
    },
    [47487] = {
        name = "Disputa lavorativa",
    },
    [47488] = {
        name = "Lavoro minorile",
    },
    [47489] = {
        name = "Nel mio paese nessuno è clandestino",
    },
    [47491] = {
        name = "I resti dei dannati",
    },
    [47497] = {
        name = "La Banda della Zannadoro",
    },
    [47498] = {
        name = "L'amico perduto di Rhan'ka",
    },
    [47499] = {
        name = "Gli idoli ghignanti",
    },
    [47501] = {
        name = "Lavoro sporco per bevande sporche",
    },
    [47502] = {
        name = "Il colpo del secolo",
    },
    [47503] = {
        name = "Godza'kun lo Schiavista",
    },
    [47509] = {
        name = "Terrazza dei Prescelti",
    },
    [47520] = {
        name = "Anche i muri hanno le orecchie",
    },
    [47521] = {
        name = "Mezzanotte nel Giardino dei Loa",
    },
    [47522] = {
        name = "Il cacciatore",
    },
    [47525] = {
        name = "Dobbiamo restare nascosti",
    },
    [47527] = {
        name = "Rituali eretici",
    },
    [47528] = {
        name = "La signora delle menzogne",
    },
    [47540] = {
        name = "Rigenerazione totemica",
    },
    [47564] = {
        name = "Rifornire il buffet",
    },
    [47570] = {
        name = "Scopi nascosti",
    },
    [47571] = {
        name = "La saggezza dell'Anziano",
    },
    [47573] = {
        name = "Un'infestazione di Tessigiungla",
    },
    [47574] = {
        name = "Ragnatele dappertutto",
    },
    [47576] = {
        name = "L'ira della tigre",
    },
    [47577] = {
        name = "Sono venuti dal mare",
    },
    [47578] = {
        name = "Il Sigillo dei Loa",
    },
    [47580] = {
        name = "La maledizione di Mepjila",
    },
    [47581] = {
        name = "La benedizione di Kimbul",
    },
    [47583] = {
        name = "Diemetradontologia",
    },
    [47584] = {
        name = "Una spina nel fianco",
    },
    [47585] = {
        name = "Predatori",
    },
    [47586] = {
        name = "A caccia del Cacciatore",
    },
    [47587] = {
        name = "Il Cacciatore di Teste Jo",
    },
    [47596] = {
        name = "Non c'è nessun piano B",
    },
    [47597] = {
        name = "Nessun Goblin verrà abbandonato",
    },
    [47598] = {
        name = "Furto e ricettazione",
    },
    [47599] = {
        name = "La vendetta è un piatto che va servito caldo",
    },
    [47601] = {
        name = "Prova sul campo",
    },
    [47602] = {
        name = "Pronti all'azione",
    },
    [47621] = {
        name = "Un vero banchetto da Loa",
    },
    [47622] = {
        name = "Una luce magica",
    },
    [47623] = {
        name = "L'ultimo Taumaturgo di Krag'wa",
    },
    [47631] = {
        name = "Punto di raduno... con libagione",
    },
    [47638] = {
        name = "Spiriti potenti",
    },
    [47647] = {
        name = "I mostri di Zem'lan",
    },
    [47659] = {
        name = "A caccia di cacciatori",
    },
    [47660] = {
        name = "Idoli caduti",
    },
    [47695] = {
        name = "Suonare la sirena",
    },
    [47696] = {
        name = "Krag'wa il Terribile",
    },
    [47697] = {
        name = "L'aiuto di Krag'wa",
    },
    [47706] = {
        name = "A caccia di Re K'tal",
    },
    [47711] = {
        name = "La testa della vipera",
    },
    [47716] = {
        name = "Pattugliare le rovine",
    },
    [47733] = {
        name = "Il tradimento dell'Oratrice dei Loa",
    },
    [47734] = {
        name = "Compagni d'eresia",
    },
    [47735] = {
        name = "Antichi rimedi dei Tortolliani",
    },
    [47736] = {
        name = "Molte cape cadranno",
    },
    [47737] = {
        name = "Il Tempio di Rezan",
    },
    [47738] = {
        name = "La volontà del Loa",
    },
    [47739] = {
        name = "L'odore della vendetta",
    },
    [47740] = {
        name = "La casa del Re",
    },
    [47741] = {
        name = "Il sacrificio di un Loa",
    },
    [47742] = {
        name = "Ammutinamento di Zul",
    },
    [47755] = {
        name = "Catturati e soggiogati",
    },
    [47756] = {
        name = "La liberazione della Grande Libagione",
    },
    [47797] = {
        name = "Occupazione a rischio",
    },
    [47868] = {
        name = "La Necropoli",
    },
    [47870] = {
        name = "I morti non raccontano storie",
    },
    [47871] = {
        name = "Accessori marittimi",
    },
    [47873] = {
        name = "La cassa del capitano",
    },
    [47874] = {
        name = "La nebbia si dirada",
    },
    [47880] = {
        name = "Un tributo alla morte",
    },
    [47894] = {
        name = "Un salto dopo l'altro",
    },
    [47897] = {
        name = "I traditori Zanchuli",
    },
    [47915] = {
        name = "Una Druida da salvare",
    },
    [47918] = {
        name = "Al servizio di Krag'wa",
    },
    [47919] = {
        name = "Basta al cannibalismo",
    },
    [47924] = {
        name = "Un turpiloquio filtrato",
    },
    [47925] = {
        name = "Oggi il menu prevede... Shoak",
    },
    [47928] = {
        name = "Offerte per il Loa",
    },
    [47939] = {
        name = "Se la chiave entra...",
    },
    [47943] = {
        name = "Caccia al granchio",
    },
    [47945] = {
        name = "Tanto va la gatta al lardo...",
    },
    [47946] = {
        name = "...che ci lascia lo zampino",
    },
    [47947] = {
        name = "Lupi cattivi",
    },
    [47948] = {
        name = "Braciole di maiale",
    },
    [47949] = {
        name = "Che il fuoco lo purifichi",
    },
    [47950] = {
        name = "Maiale affumicato",
    },
    [47952] = {
        name = "La flotta scomparsa",
    },
    [47959] = {
        name = "Le tracce della Guardia da Guerra",
    },
    [47960] = {
        name = "Baia di Tiragarde",
    },
    [47962] = {
        name = "Valle dei Sacraonda",
    },
    [47963] = {
        name = "Antiche tradizioni",
    },
    [47965] = {
        name = "Il tempio in rovina",
    },
    [47968] = {
        name = "Premonizioni",
    },
    [47969] = {
        name = "La maledizione di Malautunno",
    },
    [47978] = {
        name = "La strega ribelle",
    },
    [47979] = {
        name = "Caccia alle streghe",
    },
    [47980] = {
        name = "Animali imbestialiti",
    },
    [47981] = {
        name = "Spezzare la maledizione",
    },
    [47982] = {
        name = "L'effige finale",
    },
    [47996] = {
        name = "Sterminare i Demoni delle Fauci",
    },
    [47998] = {
        name = "Cannibali da scannare",
    },
    [48003] = {
        name = "Il volere del signore",
    },
    [48004] = {
        name = "Principiante in equitazione",
    },
    [48005] = {
        name = "Un caldo benvenuto",
    },
    [48008] = {
        name = "Carichi pericolosi",
    },
    [48009] = {
        name = "Il tradimento delle guardie",
    },
    [48014] = {
        name = "Ripulire la zona",
    },
    [48015] = {
        name = "Le Pergamene di Gral",
    },
    [48025] = {
        name = "Le tengo per dopo",
    },
    [48026] = {
        name = "Sotto le onde",
    },
    [48070] = {
        name = "Il festival dei Norwington",
    },
    [48077] = {
        name = "Caccia all'ermellino",
    },
    [48080] = {
        name = "Il pericolo è il nostro mestiere",
    },
    [48087] = {
        name = "A caval donato...",
    },
    [48088] = {
        name = "...non si guarda in bocca!",
    },
    [48089] = {
        name = "Echi di montagna",
    },
    [48090] = {
        name = "Le prescelte di Krag'wa",
    },
    [48092] = {
        name = "La vendetta delle rane",
    },
    [48093] = {
        name = "Negare i Naga",
    },
    [48104] = {
        name = "Una sfida più ardua",
    },
    [48108] = {
        name = "La figlia dei Crestabianca",
    },
    [48109] = {
        name = "Le foreste hanno gli occhi",
    },
    [48110] = {
        name = "In caso d'imboscata...",
    },
    [48111] = {
        name = "Processo causa superstizione",
    },
    [48113] = {
        name = "Una soluzione pungente",
    },
    [48165] = {
        name = "Non ingerire",
    },
    [48170] = {
        name = "Il gatto scottato teme l'acqua fredda",
    },
    [48171] = {
        name = "La maledizione della Conca degli Impennatori",
    },
    [48179] = {
        name = "Salvataggio selvaggio",
    },
    [48180] = {
        name = "Un problema veramente GROSSO",
    },
    [48181] = {
        name = "No no no",
    },
    [48182] = {
        name = "Cairneficina",
    },
    [48183] = {
        name = "Eppur si muove",
    },
    [48184] = {
        name = "Pezzi di storia",
    },
    [48195] = {
        name = "Trogloditi parassiti",
    },
    [48196] = {
        name = "Sui passi di Eddie",
    },
    [48198] = {
        name = "L'onere della prova",
    },
    [48237] = {
        name = "La sconfitta di Nekthara",
    },
    [48283] = {
        name = "Il Conestabile",
    },
    [48313] = {
        name = "Un rimedio naturale",
    },
    [48314] = {
        name = "Una morte strisciante",
    },
    [48315] = {
        name = "Occhi vuoti",
    },
    [48317] = {
        name = "Ci vuole naso per la magia",
    },
    [48320] = {
        name = "Prevenire è meglio che curare",
    },
    [48321] = {
        name = "Pubblicità creativa",
    },
    [48322] = {
        name = "Benvenuti alla Locanda Zannadoro",
    },
    [48324] = {
        name = "Perdersi a Zem'lan",
    },
    [48326] = {
        name = "Chesto è n'ammutinamento",
    },
    [48327] = {
        name = "Una strana consegna",
    },
    [48329] = {
        name = "Piegato ma non spezzato",
    },
    [48330] = {
        name = "Il tesoro ritrovato degli Zandalari",
    },
    [48331] = {
        name = "Un totem per ghermirle...",
    },
    [48332] = {
        name = "I ranishu sono la nostra risorsa",
    },
    [48334] = {
        name = "Loro hanno i golem",
    },
    [48335] = {
        name = "Il materiale più resistente di Vol'dun",
    },
    [48347] = {
        name = "Il Pontile di Pescagrossa",
    },
    [48348] = {
        name = "Barbigli appuntiti",
    },
    [48352] = {
        name = "La cura che viene dal mare",
    },
    [48353] = {
        name = "La situazione alle Palafitte",
    },
    [48354] = {
        name = "Spedizioni contaminate",
    },
    [48355] = {
        name = "Evacuare la sede",
    },
    [48356] = {
        name = "Parassiti possessivi",
    },
    [48365] = {
        name = "Il giovane Ser Sacraonda",
    },
    [48366] = {
        name = "Remare verso la salvezza",
    },
    [48367] = {
        name = "Non sono uova di pesce",
    },
    [48368] = {
        name = "Una contaminazione profonda",
    },
    [48369] = {
        name = "Strategie emergenti",
    },
    [48370] = {
        name = "Morte nelle profondità",
    },
    [48372] = {
        name = "Invocazioni sinistre",
    },
    [48399] = {
        name = "Una ferrea marea oscura",
    },
    [48400] = {
        name = "Telemanzia con scasso",
    },
    [48402] = {
        name = "Un tocco velenoso",
    },
    [48404] = {
        name = "Le canaglie",
    },
    [48405] = {
        name = "Buon Cumpà",
    },
    [48419] = {
        name = "Affascinato e adescato",
    },
    [48421] = {
        name = "Una marea di sangue",
    },
    [48452] = {
        name = "Il mercato rosso",
    },
    [48454] = {
        name = "Prove del male",
    },
    [48456] = {
        name = "La Taumaturga Jala",
    },
    [48468] = {
        name = "La salvezza di Bwonsamdi",
    },
    [48473] = {
        name = "Rispetto per i riti",
    },
    [48474] = {
        name = "I custodi della cripta",
    },
    [48475] = {
        name = "Vedo la gente morta",
    },
    [48476] = {
        name = "Un gruppo diviso",
    },
    [48477] = {
        name = "Ne manca ancora una",
    },
    [48478] = {
        name = "La casa di Kel'vax",
    },
    [48479] = {
        name = "Ossa contro vudù",
    },
    [48480] = {
        name = "La caduta di Kel'vax",
    },
    [48492] = {
        name = "In gamba, eh!",
    },
    [48496] = {
        name = "Tutti insieme appassionatamente",
    },
    [48497] = {
        name = "Dimostrazione di forza",
    },
    [48498] = {
        name = "Nessuna pietà per Sithis",
    },
    [48499] = {
        name = "Polvere eri e polvere tornerai",
    },
    [48504] = {
        name = "Vecchie strade",
    },
    [48505] = {
        name = "Amor ch'a nullo amato amar perdona",
    },
    [48515] = {
        name = "Lame d'argento",
    },
    [48516] = {
        name = "Una comunità tossica",
    },
    [48517] = {
        name = "Congedo con onore",
    },
    [48518] = {
        name = "Ci salvi chi può",
    },
    [48519] = {
        name = "Speriamo non sappiano nuotare",
    },
    [48520] = {
        name = "Le tre sorelle",
    },
    [48521] = {
        name = "Controllare la vita di creature senza vita",
    },
    [48522] = {
        name = "Una lettera rivelatoria",
    },
    [48523] = {
        name = "La matrona assassina",
    },
    [48524] = {
        name = "Epurazione totale",
    },
    [48525] = {
        name = "Riducili a pezzetti",
    },
    [48527] = {
        name = "Predatori terrestri particolarmente voraci",
    },
    [48529] = {
        name = "Bocche affamate da sfamare",
    },
    [48530] = {
        name = "Un poco di alpaca",
    },
    [48531] = {
        name = "La carne misteriosa",
    },
    [48532] = {
        name = "Alpaca selvatici",
    },
    [48533] = {
        name = "Pollo fritto di Vol'dun",
    },
    [48534] = {
        name = "L'ultima risata di Ringhiadenti",
    },
    [48535] = {
        name = "Nazmir, la palude proibita",
    },
    [48538] = {
        name = "Un alibi solido",
    },
    [48539] = {
        name = "Il Covo della Libertà",
    },
    [48540] = {
        name = "Un aiuto alle palafitte",
    },
    [48549] = {
        name = "Grozztok Cuornero",
    },
    [48550] = {
        name = "Borseggiare i borseggiatori",
    },
    [48551] = {
        name = "Acqua alla gola",
    },
    [48553] = {
        name = "Acqua corrente",
    },
    [48554] = {
        name = "La sorgente del problema",
    },
    [48555] = {
        name = "Chi semina vento...",
    },
    [48557] = {
        name = "Seminare arboscelli",
    },
    [48558] = {
        name = "L'equipaggio dei Marferreo",
    },
    [48573] = {
        name = "Una vita da crocolisco",
    },
    [48574] = {
        name = "Estrazione senza anestesia",
    },
    [48576] = {
        name = "Volare in tutta sicurezza",
    },
    [48577] = {
        name = "Uova di Terrore terrorizzate",
    },
    [48578] = {
        name = "Occhio per occhio",
    },
    [48581] = {
        name = "Una bella sculacciata",
    },
    [48584] = {
        name = "Il sangue dei miei nemici",
    },
    [48585] = {
        name = "Sopravvivere nella terra desolata",
    },
    [48588] = {
        name = "Epurare l'infezione",
    },
    [48590] = {
        name = "Una testa sulle spalle",
    },
    [48591] = {
        name = "La vera morte (finalmente) di Urok",
    },
    [48597] = {
        name = "Saurolischi in fuga",
    },
    [48606] = {
        name = "Fuoco ai cannoni",
    },
    [48616] = {
        name = "Bolas e becchi",
    },
    [48622] = {
        name = "Es-ser scomparso",
    },
    [48655] = {
        name = "L'apprendista dello chef",
    },
    [48656] = {
        name = "Saurolischi selvaggi",
    },
    [48657] = {
        name = "Potrebbero essere deliziose",
    },
    [48669] = {
        name = "Urok, Terrore delle Paludi Grigie",
    },
    [48670] = {
        name = "Cavallo in fuga",
    },
    [48677] = {
        name = "L'adorazione dei vimini",
    },
    [48678] = {
        name = "Offerte discutibili",
    },
    [48679] = {
        name = "Api assassine",
    },
    [48680] = {
        name = "Non le api!",
    },
    [48682] = {
        name = "Un semplice sacrificio",
    },
    [48683] = {
        name = "La stagione del cambiamento",
    },
    [48684] = {
        name = "In movimento",
    },
    [48699] = {
        name = "Intrufolarsi a Zalamar",
    },
    [48715] = {
        name = "Akunda attende",
    },
    [48773] = {
        name = "Carta canta",
    },
    [48774] = {
        name = "Pirati sì, ma liberi",
    },
    [48776] = {
        name = "Il nodo groghiano",
    },
    [48778] = {
        name = "La zuppa di sassi",
    },
    [48790] = {
        name = "Merci Rubate",
    },
    [48792] = {
        name = "Una minaccia per la società",
    },
    [48793] = {
        name = "La Compagnia dell'Avventuriero",
    },
    [48800] = {
        name = "Il marchio del pipistrello",
    },
    [48801] = {
        name = "Isolare Zalamar",
    },
    [48804] = {
        name = "Sono stati compiuti errori",
    },
    [48805] = {
        name = "Ricerca e recupero",
    },
    [48823] = {
        name = "Fuoco cammina con me",
    },
    [48825] = {
        name = "Un piano interessante",
    },
    [48840] = {
        name = "Pubblicità tra le rovine",
    },
    [48846] = {
        name = "Motivazione liquida",
    },
    [48847] = {
        name = "Armare la tribù",
    },
    [48852] = {
        name = "Fermare Zardrax",
    },
    [48853] = {
        name = "Tutto è bene ciò che finisce bene",
    },
    [48854] = {
        name = "Un'offerta che non si può rifiutare",
    },
    [48855] = {
        name = "Zonizzare gli zombi",
    },
    [48856] = {
        name = "Interruzione di canalizzazione",
    },
    [48857] = {
        name = "Ogni speranza è perduta",
    },
    [48869] = {
        name = "Vendette difficili",
    },
    [48871] = {
        name = "Salvare le reliquie",
    },
    [48872] = {
        name = "Velocizzare gli scavi",
    },
    [48873] = {
        name = "Una fine grezza",
    },
    [48874] = {
        name = "Problemi di ruggine",
    },
    [48879] = {
        name = "A caccia di uova di falco",
    },
    [48880] = {
        name = "Gabbiani fastidiosi",
    },
    [48881] = {
        name = "Ecce lenza",
    },
    [48882] = {
        name = "Amo i pancioni, che ci posso fare",
    },
    [48883] = {
        name = "Gabbiano al gabbio",
    },
    [48887] = {
        name = "Purificare la mente",
    },
    [48888] = {
        name = "Acqua infinita",
    },
    [48889] = {
        name = "Riparare agli errori del passato",
    },
    [48890] = {
        name = "Una vita da Troll del Sangue",
    },
    [48894] = {
        name = "La prova della verità",
    },
    [48895] = {
        name = "L'offerta perfetta",
    },
    [48896] = {
        name = "La conoscenza del passato",
    },
    [48898] = {
        name = "Un amuleto fortunato",
    },
    [48899] = {
        name = "La sicurezza prima di tutto",
    },
    [48902] = {
        name = "Un'energia mostruosa",
    },
    [48903] = {
        name = "Il cavallo senza fallo",
    },
    [48904] = {
        name = "Esci l'esca",
    },
    [48905] = {
        name = "Pergamene poco apprezzate",
    },
    [48909] = {
        name = "Nobili responsabilità",
    },
    [48934] = {
        name = "Il marchio dei dannati",
    },
    [48939] = {
        name = "Vediamo che sai fare",
    },
    [48941] = {
        name = "Una piccola deviazione",
    },
    [48942] = {
        name = "Yeti poco lieti",
    },
    [48943] = {
        name = "Recuperare il recuperabile",
    },
    [48944] = {
        name = "Una porta aperta sulla storia",
    },
    [48945] = {
        name = "Le rovine di Gol Var",
    },
    [48946] = {
        name = "L'Ordine delle Braci",
    },
    [48948] = {
        name = "Caverne del Passo Settentrionale",
    },
    [48963] = {
        name = "Tattiche diversive",
    },
    [48965] = {
        name = "Pareggiare i conti",
    },
    [48986] = {
        name = "Chi lascia la via vecchia per la nuova...",
    },
    [48987] = {
        name = "La Valle del Dolore",
    },
    [48988] = {
        name = "Ricordi violati",
    },
    [48991] = {
        name = "Chiamate i disinfestatori",
    },
    [48992] = {
        name = "Resti sacri",
    },
    [48993] = {
        name = "Conduttori potenti",
    },
    [48996] = {
        name = "Fermare la follia",
    },
    [49001] = {
        name = "Spiriti seccanti",
    },
    [49002] = {
        name = "Atterraggio forzato",
    },
    [49003] = {
        name = "Vendetta dall'alto",
    },
    [49005] = {
        name = "Spezzato e fiaccato",
    },
    [49028] = {
        name = "Un maglioncino per Rupert",
    },
    [49036] = {
        name = "Campioni di razza",
    },
    [49039] = {
        name = "L'inizio di una caccia al mostro",
    },
    [49040] = {
        name = "Addii amichevoli",
    },
    [49059] = {
        name = "Le Ossa di Xibala",
    },
    [49060] = {
        name = "L'ecologia di Xibala",
    },
    [49064] = {
        name = "Torga, Loa delle Tartarughe",
    },
    [49066] = {
        name = "Conservare in luogo fresco e asciutto",
    },
    [49067] = {
        name = "Una richiesta a Bwonsamdi",
    },
    [49069] = {
        name = "RICERCATO: Vecchio Gelartigli",
    },
    [49070] = {
        name = "Anime per il Loa della Morte",
    },
    [49071] = {
        name = "Combustione di zecche",
    },
    [49072] = {
        name = "Nobili occidentali",
    },
    [49078] = {
        name = "Avvelenare la stirpe",
    },
    [49079] = {
        name = "Hir'eek, il Loa Pipistrello",
    },
    [49080] = {
        name = "Cessare l'evocazione",
    },
    [49081] = {
        name = "Uccidere un Loa",
    },
    [49082] = {
        name = "Avanti verso l'alto!",
    },
    [49120] = {
        name = "Parlare coi morti",
    },
    [49122] = {
        name = "Un porto in pericolo",
    },
    [49125] = {
        name = "Sangue negativo",
    },
    [49126] = {
        name = "Forzare la mano del destino",
    },
    [49130] = {
        name = "Dieta priva di Loa",
    },
    [49131] = {
        name = "Terreno in via di santificazione",
    },
    [49132] = {
        name = "Sfasciare le Sfasciateste",
    },
    [49136] = {
        name = "Jungo, l'Alfiere di G'huun",
    },
    [49138] = {
        name = "Il tesoro del Capitano Gulnaku",
    },
    [49139] = {
        name = "L'arsenale di un'armata",
    },
    [49141] = {
        name = "Diplomazia e dominio",
    },
    [49144] = {
        name = "L'ira degli Zandalari",
    },
    [49145] = {
        name = "Nessun Troll verrà abbandonato",
    },
    [49146] = {
        name = "I beni degli spiriti",
    },
    [49147] = {
        name = "Uno sfoggio di forza",
    },
    [49148] = {
        name = "Cadere a pezzi",
    },
    [49149] = {
        name = "Abbraccia il vudù",
    },
    [49160] = {
        name = "L'eterno ritorno di Torga",
    },
    [49178] = {
        name = "Le mie cose preferite",
    },
    [49181] = {
        name = "Il medaglione scintillante",
    },
    [49185] = {
        name = "Stare al passo",
    },
    [49218] = {
        name = "I naufraghi",
    },
    [49223] = {
        name = "Lungo Raggiro",
    },
    [49225] = {
        name = "In cerca del capo",
    },
    [49226] = {
        name = "Silenziare le sorelle",
    },
    [49227] = {
        name = "La chiave universale",
    },
    [49229] = {
        name = "Le rovine si muovono!",
    },
    [49230] = {
        name = "Sapori locali",
    },
    [49232] = {
        name = "Rimediare a un disastro",
    },
    [49233] = {
        name = "Sono un Druido, non un Sacerdote",
    },
    [49234] = {
        name = "Un soldato fuori dall'acqua",
    },
    [49239] = {
        name = "In ghingheri",
    },
    [49242] = {
        name = "Rattospino allo spiedo",
    },
    [49259] = {
        name = "Più giustizia per tutti",
    },
    [49260] = {
        name = "Guardarsi alle spalle",
    },
    [49261] = {
        name = "Zuppe stimolanti",
    },
    [49262] = {
        name = "Sgominare le bande",
    },
    [49268] = {
        name = "Terrore sott'acqua",
    },
    [49274] = {
        name = "Lo Scavatore Morgrum",
    },
    [49276] = {
        name = "Il piacere di scavare",
    },
    [49278] = {
        name = "Rigenerazione Spirituale",
    },
    [49282] = {
        name = "Il rilevamento di Morgrum",
    },
    [49283] = {
        name = "Chi cerca i Cercatori?",
    },
    [49284] = {
        name = "Buone notizie",
    },
    [49285] = {
        name = "Piccoli tesori",
    },
    [49286] = {
        name = "Saggezza incatenata",
    },
    [49287] = {
        name = "Tartarughe perdute",
    },
    [49288] = {
        name = "Cacciatori di pergamene",
    },
    [49289] = {
        name = "Una roccia speciale",
    },
    [49290] = {
        name = "Invecchiato alla perfezione",
    },
    [49292] = {
        name = "Frullato alle alghe",
    },
    [49295] = {
        name = "Una bella ripulita",
    },
    [49299] = {
        name = "Il nemico interiore",
    },
    [49300] = {
        name = "La corruzione delle creature",
    },
    [49302] = {
        name = "Pesca estrema",
    },
    [49309] = {
        name = "Rovina del Tuono",
    },
    [49310] = {
        name = "Il complotto del profeta",
    },
    [49314] = {
        name = "A caccia di Zardrax",
    },
    [49315] = {
        name = "La collusione dei Perlatruce",
    },
    [49327] = {
        name = "Respingere il nemico",
    },
    [49333] = {
        name = "Ingrandire l'arsenale",
    },
    [49334] = {
        name = "Un potente prigioniero",
    },
    [49335] = {
        name = "Gli Invocatori Celesti",
    },
    [49340] = {
        name = "Le chiavi dei Custodi",
    },
    [49348] = {
        name = "Un tempio dissacrato",
    },
    [49366] = {
        name = "Aiutare i feriti",
    },
    [49370] = {
        name = "Salvare la storia",
    },
    [49375] = {
        name = "[LARRY TEST QUEST]",
    },
    [49377] = {
        name = "Ma dove hai la testa?",
    },
    [49378] = {
        name = "Guadagnare la loro fiducia",
    },
    [49379] = {
        name = "Zona libera per i crog",
    },
    [49380] = {
        name = "Il juju cattivo",
    },
    [49382] = {
        name = "Posso tenerlo?",
    },
    [49393] = {
        name = "I Collorozzo",
    },
    [49394] = {
        name = "Feeermo...",
    },
    [49395] = {
        name = "Orsi e api",
    },
    [49398] = {
        name = "Alla salute!",
    },
    [49399] = {
        name = "Grosso lavoro in vista",
    },
    [49400] = {
        name = "Reclutamento selvaggio",
    },
    [49401] = {
        name = "Il nido di Rodrigo",
    },
    [49402] = {
        name = "I miei tesssori",
    },
    [49403] = {
        name = "La vendetta di Rodrigo",
    },
    [49404] = {
        name = "Gli \"amici\" di Ventofermo",
    },
    [49405] = {
        name = "I difensori dei Cancelli di Daelin",
    },
    [49406] = {
        name = "Il massacro di Zalamar",
    },
    [49407] = {
        name = "Vele strappate",
    },
    [49408] = {
        name = "I dadi dei pirati",
    },
    [49409] = {
        name = "Il tesoro perduto",
    },
    [49411] = {
        name = "Costruire la Caserma",
    },
    [49412] = {
        name = "Aiutiamo Henry",
    },
    [49417] = {
        name = "Rozzi Collorozzo",
    },
    [49418] = {
        name = "Il grande boss",
    },
    [49419] = {
        name = "Congelato",
    },
    [49421] = {
        name = "A caccia di Zul",
    },
    [49422] = {
        name = "Eretici",
    },
    [49424] = {
        name = "La profezia intera",
    },
    [49425] = {
        name = "La Città d'Oro",
    },
    [49426] = {
        name = "L'azzardo del re",
    },
    [49427] = {
        name = "Non quelli viola",
    },
    [49428] = {
        name = "Telemanzia con scasso",
    },
    [49431] = {
        name = "Al caldo e al sicuro",
    },
    [49432] = {
        name = "L'anima triste",
    },
    [49433] = {
        name = "Occhio per occhio per occhio",
    },
    [49435] = {
        name = "Dove saranno finiti?",
    },
    [49437] = {
        name = "La nota lacera",
    },
    [49439] = {
        name = "La vendetta del capo",
    },
    [49440] = {
        name = "Troll fuori",
    },
    [49443] = {
        name = "...sa quel che lascia e non sa quel che trova",
    },
    [49450] = {
        name = "Rapporti sugli incidenti",
    },
    [49451] = {
        name = "Richieste di straordinario",
    },
    [49452] = {
        name = "Ammanchi di magazzino",
    },
    [49453] = {
        name = "Dighe per castori",
    },
    [49454] = {
        name = "Prevenzione parassitaria",
    },
    [49464] = {
        name = "Le code dei saurolischi",
    },
    [49465] = {
        name = "Massimizzare le risorse",
    },
    [49467] = {
        name = "La Strega del Bosco",
    },
    [49468] = {
        name = "Detelatura",
    },
    [49477] = {
        name = "Aiuto a sorpresa",
    },
    [49479] = {
        name = "Forse non avrebbero dovuto",
    },
    [49489] = {
        name = "Manca un po' di corposità",
    },
    [49490] = {
        name = "L'Urna delle Voci",
    },
    [49491] = {
        name = "Alimentare il vudù",
    },
    [49492] = {
        name = "L'arroganza di Vol'jamba",
    },
    [49493] = {
        name = "Il dilemma etico di Zul",
    },
    [49494] = {
        name = "Lo Zuvembi",
    },
    [49495] = {
        name = "Forzare il destino",
    },
    [49522] = {
        name = "La ricompensa di Carentan",
    },
    [49523] = {
        name = "Un pessimo accordo",
    },
    [49529] = {
        name = "Pulizie di primavera",
    },
    [49531] = {
        name = "L'importanza della pubblicità",
    },
    [49569] = {
        name = "Lungo il fiume",
    },
    [49570] = {
        name = "Un inizio difficile",
    },
    [49571] = {
        name = "Scavare nel passato",
    },
    [49572] = {
        name = "Il Santuario del Mare",
    },
    [49573] = {
        name = "Il Santuario del Vespro",
    },
    [49574] = {
        name = "Il Santuario delle Tempeste",
    },
    [49575] = {
        name = "Tol Dagor: il Gioiello delle Maree",
    },
    [49576] = {
        name = "Alta prospezione",
    },
    [49577] = {
        name = "Spaccare la superficie",
    },
    [49581] = {
        name = "Dune ingioiellate di sole",
    },
    [49582] = {
        name = "Atal'dazar: non tutto ciò che luccica...",
    },
    [49583] = {
        name = "Il vecchio lascia il posto al nuovo",
    },
    [49584] = {
        name = "Il capitolo scomparso",
    },
    [49585] = {
        name = "Un inizio difficile",
    },
    [49586] = {
        name = "Scavare nel passato",
    },
    [49587] = {
        name = "Il Santuario della Natura",
    },
    [49588] = {
        name = "Il Santuario delle Sabbie",
    },
    [49589] = {
        name = "Il Santuario dell'Alba",
    },
    [49599] = {
        name = "Il capitolo scomparso",
    },
    [49615] = {
        name = "Una fiducia da re",
    },
    [49661] = {
        name = "Uova biologiche a chilometro zero",
    },
    [49662] = {
        name = "La chiave mancante",
    },
    [49663] = {
        name = "False profezie",
    },
    [49664] = {
        name = "Alleati nell'anarchia",
    },
    [49665] = {
        name = "Pronti alla rivolta",
    },
    [49666] = {
        name = "Devono imparare a temerci",
    },
    [49667] = {
        name = "Qualcuno pensi ai cuccioli!",
    },
    [49668] = {
        name = "Incendiare la fossa",
    },
    [49669] = {
        name = "Liberare le bestie",
    },
    [49676] = {
        name = "Vestirsi per la battaglia",
    },
    [49677] = {
        name = "Piani d'attacco",
    },
    [49678] = {
        name = "Guglie tempestose",
    },
    [49679] = {
        name = "L'incursione dei Sethrak",
    },
    [49680] = {
        name = "L'Invocatrice Celeste Soltok",
    },
    [49681] = {
        name = "La Piccola Tika",
    },
    [49694] = {
        name = "Decisioni drustiche",
    },
    [49703] = {
        name = "La Casata dei Sacraonda",
    },
    [49704] = {
        name = "Mietitori fuori controllo",
    },
    [49705] = {
        name = "Coercizione inutile",
    },
    [49706] = {
        name = "Indagine sui proclami",
    },
    [49710] = {
        name = "Un'offerta di uova",
    },
    [49715] = {
        name = "Grosso guaio alla Fortezza di Pietragrigia",
    },
    [49716] = {
        name = "Una lezione sulla fiducia",
    },
    [49719] = {
        name = "Riscuotere la paga",
    },
    [49720] = {
        name = "Liberare i falchi",
    },
    [49725] = {
        name = "Un'idea rischiosa",
    },
    [49730] = {
        name = "RICERCATO: Grugnolampo",
    },
    [49731] = {
        name = "Addii amichevoli",
    },
    [49733] = {
        name = "Bendare i feriti",
    },
    [49734] = {
        name = "Uccidere il traditore",
    },
    [49735] = {
        name = "Proteggere i nidi",
    },
    [49736] = {
        name = "Per Kul Tiras!",
    },
    [49737] = {
        name = "Incursione aerea",
    },
    [49738] = {
        name = "Giù le mani dal bottino!",
    },
    [49739] = {
        name = "Nemici ai cancelli",
    },
    [49740] = {
        name = "Cessare il fuoco",
    },
    [49741] = {
        name = "Giusta vendetta",
    },
    [49744] = {
        name = "Che bombe!",
    },
    [49745] = {
        name = "Hai i loro ordini",
    },
    [49746] = {
        name = "Spegnere le fiamme",
    },
    [49753] = {
        name = "Costruire l'Armeria",
    },
    [49754] = {
        name = "Non \"solo Zul\"",
    },
    [49755] = {
        name = "Artiglieria pesante",
    },
    [49757] = {
        name = "Qualcuno si arrampicò sul tetto della casa in fiamme",
    },
    [49758] = {
        name = "Mandare il segnale",
    },
    [49759] = {
        name = "Costruire l'Officina",
    },
    [49766] = {
        name = "La prossima mossa",
    },
    [49767] = {
        name = "La prossima mossa",
    },
    [49768] = {
        name = "Il Percorso di Nesingwary",
    },
    [49769] = {
        name = "Rovine del Cataclisma",
    },
    [49774] = {
        name = "Una foglia per la vita",
    },
    [49775] = {
        name = "La chiave della cella",
    },
    [49776] = {
        name = "La pece risolve qualsiasi problema",
    },
    [49777] = {
        name = "In fuga",
    },
    [49778] = {
        name = "Non andare verso la luce",
    },
    [49779] = {
        name = "Cattivi fino al midollo",
    },
    [49780] = {
        name = "Recuperare l'antico fuoco",
    },
    [49781] = {
        name = "Prendimi se ci riesci",
    },
    [49785] = {
        name = "Distruggere l'arma",
    },
    [49791] = {
        name = "Morti ma non dimenticati",
    },
    [49792] = {
        name = "Prigionieri e oppressi",
    },
    [49793] = {
        name = "Il fine giustifica i mezzi",
    },
    [49794] = {
        name = "La marea crescente",
    },
    [49801] = {
        name = "Se vuoi che t'ami, fa' che ti brami",
    },
    [49803] = {
        name = "Il cambio della guardia",
    },
    [49804] = {
        name = "Un'idea acuta",
    },
    [49805] = {
        name = "La via dell'inferno è lastricata di buone intenzioni",
    },
    [49806] = {
        name = "Trame segrete",
    },
    [49807] = {
        name = "Un nuovo ordine",
    },
    [49810] = {
        name = "La Taumaturga Stranamore",
    },
    [49814] = {
        name = "Per il brutosauro che non deve chiedere mai",
    },
    [49818] = {
        name = "Problemi al Forte Daelin",
    },
    [49831] = {
        name = "Dagli abisssi",
    },
    [49832] = {
        name = "Una pergamena illeggibile",
    },
    [49869] = {
        name = "Una difesa disperata",
    },
    [49870] = {
        name = "Le dimensioni contano",
    },
    [49871] = {
        name = "Contro la marea",
    },
    [49873] = {
        name = "Scritti sacrificali",
    },
    [49874] = {
        name = "Come da manuale",
    },
    [49876] = {
        name = "Disegni nella sabbia",
    },
    [49877] = {
        name = "Tempio di Sethraliss: tomo del sangue",
    },
    [49878] = {
        name = "Creatività e protezione",
    },
    [49879] = {
        name = "Pennellate di morte",
    },
    [49881] = {
        name = "L'ultimo verso",
    },
    [49882] = {
        name = "Una prova di penne",
    },
    [49884] = {
        name = "La luce blu della speranza",
    },
    [49886] = {
        name = "Cane da Spinomanto",
    },
    [49887] = {
        name = "Lavori forzati",
    },
    [49890] = {
        name = "La caduta dei Drust",
    },
    [49896] = {
        name = "Verso Collefalco!",
    },
    [49897] = {
        name = "Creare l'inspiegabile",
    },
    [49898] = {
        name = "Vittoria netta",
    },
    [49901] = {
        name = "Atal'Dazar: Yazma, la Sacerdotessa Caduta",
    },
    [49902] = {
        name = "Verso la Conca Nera",
    },
    [49905] = {
        name = "Colpo di scena",
    },
    [49908] = {
        name = "Di ritorno a Brennadam",
    },
    [49917] = {
        name = "Kaja'mite? Kaja'spietata!",
    },
    [49918] = {
        name = "La Gola dei Gorilla",
    },
    [49919] = {
        name = "La febbre della kaja'mite",
    },
    [49920] = {
        name = "La guerra dei gorilla",
    },
    [49922] = {
        name = "Re Da'ka",
    },
    [49926] = {
        name = "La via per Corlain",
    },
    [49932] = {
        name = "Il risveglio",
    },
    [49935] = {
        name = "Come riparare un Guardiano dei Titani",
    },
    [49937] = {
        name = "Recupero resti",
    },
    [49938] = {
        name = "Terra corrotta",
    },
    [49939] = {
        name = "Addio, sorella",
    },
    [49940] = {
        name = "Breccia Spezzasabbia",
    },
    [49941] = {
        name = "Processazione delle Ossa",
    },
    [49943] = {
        name = "Prelievo di sangue",
    },
    [49944] = {
        name = "Decisioni drustiche",
    },
    [49946] = {
        name = "Disegni nella sabbia",
    },
    [49949] = {
        name = "Non morti non graditi",
    },
    [49950] = {
        name = "Aspetta e sfera!",
    },
    [49955] = {
        name = "Eliminare il Vuoto",
    },
    [49956] = {
        name = "Vietato al Vuoto",
    },
    [49957] = {
        name = "Recupero del Protocollo",
    },
    [49960] = {
        name = "Alla gola!",
    },
    [49965] = {
        name = "Il Branco da Guerra",
    },
    [49969] = {
        name = "Il risveglio di un dio",
    },
    [49975] = {
        name = "Riposare nelle profondità",
    },
    [49980] = {
        name = "Procedura di contenimento",
    },
    [49985] = {
        name = "Ritorno alla Conca Nera",
    },
    [49995] = {
        name = "Progetti pericolosi",
    },
    [49996] = {
        name = "Riarmarsi",
    },
    [49997] = {
        name = "Il giudizio dell'onda",
    },
    [49998] = {
        name = "Voci dal profondo",
    },
    [50001] = {
        name = "Le streghe son tornate",
    },
    [50002] = {
        name = "Un carico molto prezioso",
    },
    [50003] = {
        name = "La prima veglia",
    },
    [50005] = {
        name = "Tienimi la mano",
    },
    [50009] = {
        name = "Recuperare il carico",
    },
    [50026] = {
        name = "Salvare i marinai",
    },
    [50036] = {
        name = "Un'arma del passato",
    },
    [50041] = {
        name = "Una manciata di proiettili",
    },
    [50043] = {
        name = "Efficienza archeologica",
    },
    [50044] = {
        name = "Efficienza archeologica",
    },
    [50058] = {
        name = "Cocco di strega",
    },
    [50059] = {
        name = "Non ho sentito nulla",
    },
    [50063] = {
        name = "Combattere con il fuoco",
    },
    [50064] = {
        name = "Non entrare in cantina",
    },
    [50065] = {
        name = "Una ragione per restare",
    },
    [50069] = {
        name = "La guerra di Terraricca",
    },
    [50070] = {
        name = "L'ispettore Mildenhall",
    },
    [50074] = {
        name = "Potenziamento brutale",
    },
    [50076] = {
        name = "Radunare i guerrieri",
    },
    [50078] = {
        name = "Totem immortali",
    },
    [50079] = {
        name = "Fuoco alle polveri",
    },
    [50080] = {
        name = "Incursione contro gli incursori",
    },
    [50081] = {
        name = "La via del dolore",
    },
    [50082] = {
        name = "Bersaglio d'opportunità",
    },
    [50083] = {
        name = "La Ma'ma dei Crog",
    },
    [50085] = {
        name = "Un messaggio di sangue e fuoco",
    },
    [50087] = {
        name = "La caduta di Ateena",
    },
    [50088] = {
        name = "L'eterno riposo",
    },
    [50090] = {
        name = "Alzare le difese",
    },
    [50091] = {
        name = "Un villaggio al sicuro",
    },
    [50092] = {
        name = "Extra forte",
    },
    [50110] = {
        name = "Messaggeri infausti",
    },
    [50111] = {
        name = "Totem, totem, totem!",
    },
    [50112] = {
        name = "Lanciare la prima pietra",
    },
    [50113] = {
        name = "Estratti oculari",
    },
    [50114] = {
        name = "Ottenere informazioni a martellate",
    },
    [50115] = {
        name = "Cambiare scenario",
    },
    [50116] = {
        name = "Una possibile soluzione",
    },
    [50117] = {
        name = "Una pozione letale",
    },
    [50118] = {
        name = "Lancio della pietra",
    },
    [50119] = {
        name = "Composto chimico",
    },
    [50120] = {
        name = "La ricetta del successo",
    },
    [50121] = {
        name = "Lanciare la prima pietra",
    },
    [50122] = {
        name = "Estratti oculari",
    },
    [50123] = {
        name = "Un progetto inestimabile",
    },
    [50124] = {
        name = "Cambiare scenario",
    },
    [50125] = {
        name = "Una possibile soluzione",
    },
    [50126] = {
        name = "Una pozione letale",
    },
    [50127] = {
        name = "Lancio della pietra",
    },
    [50128] = {
        name = "Composto chimico",
    },
    [50129] = {
        name = "La ricetta del successo",
    },
    [50133] = {
        name = "Tiro al bersaglio",
    },
    [50134] = {
        name = "Viti e bulloni in quantità",
    },
    [50135] = {
        name = "Rovi invadenti",
    },
    [50136] = {
        name = "Contadino contro Verrospino",
    },
    [50138] = {
        name = "La battaglia della Gola Sanguecaldo",
    },
    [50139] = {
        name = "L'anello mancante",
    },
    [50149] = {
        name = "Occhio di falco",
    },
    [50150] = {
        name = "L'umore giusto",
    },
    [50151] = {
        name = "Una zavorra salda",
    },
    [50152] = {
        name = "Scavare negli scarti",
    },
    [50154] = {
        name = "Dicono sia una prelibatezza",
    },
    [50157] = {
        name = "La vanga ha la punta d'oro",
    },
    [50158] = {
        name = "Il contadino mancante",
    },
    [50161] = {
        name = "Recuperare Raimond",
    },
    [50162] = {
        name = "Una situazione appiccicosa",
    },
    [50165] = {
        name = "Salvare la fattoria",
    },
    [50168] = {
        name = "Successione reale",
    },
    [50172] = {
        name = "Tra le Legnocremisi",
    },
    [50173] = {
        name = "Metalli preziosi",
    },
    [50174] = {
        name = "Fine dei giochi",
    },
    [50175] = {
        name = "Una maledizione a otto zampe",
    },
    [50177] = {
        name = "Barricare la barricata",
    },
    [50178] = {
        name = "Problemi a Radivia",
    },
    [50195] = {
        name = "La brigata di Magliolordo",
    },
    [50206] = {
        name = "Al contrattacco",
    },
    [50235] = {
        name = "Non sono al sicuro",
    },
    [50238] = {
        name = "Rovospina",
    },
    [50240] = {
        name = "Un giro in pterrordattilo",
    },
    [50249] = {
        name = "Tripla minaccia per Boralus",
    },
    [50251] = {
        name = "Vincolati dalla magia",
    },
    [50252] = {
        name = "La stagione degli amori",
    },
    [50253] = {
        name = "Un arsenale improvvisato",
    },
    [50264] = {
        name = "Liberare i contadini",
    },
    [50265] = {
        name = "Salvare il Maestro Ashton",
    },
    [50266] = {
        name = "Voglio armarmi",
    },
    [50268] = {
        name = "Basta un poco di vudù",
    },
    [50270] = {
        name = "Nel fondo di Rocciafonda",
    },
    [50271] = {
        name = "Spacca e scappa",
    },
    [50272] = {
        name = "Tenere le orecchie aperte",
    },
    [50274] = {
        name = "Forgiatura titanica",
    },
    [50275] = {
        name = "Incudine della cupidigia",
    },
    [50276] = {
        name = "Un progetto inestimabile",
    },
    [50277] = {
        name = "Ottenere informazioni a martellate",
    },
    [50278] = {
        name = "Nel fondo di Rocciafonda",
    },
    [50279] = {
        name = "Incudine della cupidigia",
    },
    [50288] = {
        name = "La scelta di Therazane",
    },
    [50297] = {
        name = "La testa del nemico",
    },
    [50306] = {
        name = "Campioni da studiare",
    },
    [50325] = {
        name = "Fermare il Gran Rituale",
    },
    [50327] = {
        name = "Ingredienti per la pozione",
    },
    [50328] = {
        name = "Aromi non convenzionali",
    },
    [50329] = {
        name = "Le Matrone Legnocremisi",
    },
    [50331] = {
        name = "Un risultato diverso",
    },
    [50332] = {
        name = "Il grande Cumpà Cacciatore",
    },
    [50340] = {
        name = "Rubare la refurtiva",
    },
    [50343] = {
        name = "Grosso guaio alla Distilleria dei Mildenhall",
    },
    [50349] = {
        name = "Una miniera invasa",
    },
    [50350] = {
        name = "Ci serve un chimico",
    },
    [50351] = {
        name = "Operazioni minerarie",
    },
    [50352] = {
        name = "Un pizzico di Azerite",
    },
    [50353] = {
        name = "Gallerie pericolose",
    },
    [50354] = {
        name = "Vedette!",
    },
    [50356] = {
        name = "Roccia contro dinamite",
    },
    [50359] = {
        name = "Pulizie necessarie",
    },
    [50363] = {
        name = "Maiali da guerra",
    },
    [50365] = {
        name = "In fuga verso le colline",
    },
    [50367] = {
        name = "Rabbia in bottiglia",
    },
    [50368] = {
        name = "Il terrore delle gallerie",
    },
    [50370] = {
        name = "Nel cuore della foresta",
    },
    [50376] = {
        name = "Preda letale: pesca grossa",
    },
    [50381] = {
        name = "Il grande furto di cappelli",
    },
    [50385] = {
        name = "Scopo instancabile",
    },
    [50386] = {
        name = "Spazzali via",
    },
    [50387] = {
        name = "Monili e ninnoli",
    },
    [50388] = {
        name = "Il peso della mia ambizione",
    },
    [50389] = {
        name = "Ispirazione maligna",
    },
    [50391] = {
        name = "Preda letale: pesca con polvere da sparo",
    },
    [50393] = {
        name = "Un figlio di Pa'ku",
    },
    [50394] = {
        name = "Adesso è un tuo problema",
    },
    [50395] = {
        name = "Il richiamo dei cieli",
    },
    [50396] = {
        name = "Un destino pterribile",
    },
    [50397] = {
        name = "Aspirazioni aeree",
    },
    [50401] = {
        name = "Paura di cadere",
    },
    [50402] = {
        name = "REEEEEE!",
    },
    [50412] = {
        name = "Ritorno al nido",
    },
    [50417] = {
        name = "La rovina è giunta",
    },
    [50418] = {
        name = "Preda letale: affonda e nuota",
    },
    [50433] = {
        name = "Zanchuli divisi",
    },
    [50444] = {
        name = "La strada del Loa",
    },
    [50445] = {
        name = "Controllare la situazione",
    },
    [50446] = {
        name = "Lo Straziastreghe",
    },
    [50447] = {
        name = "Ricordare i caduti",
    },
    [50448] = {
        name = "Reclamare Corlain",
    },
    [50449] = {
        name = "Rifugi puzzolenti",
    },
    [50450] = {
        name = "Un raccolto offensivo",
    },
    [50451] = {
        name = "Difese divorate",
    },
    [50452] = {
        name = "Protezioni potenti",
    },
    [50453] = {
        name = "Sfondabarriere",
    },
    [50454] = {
        name = "La morte di un traditore",
    },
    [50455] = {
        name = "Lasciare il nido",
    },
    [50456] = {
        name = "Cuccioli maledetti",
    },
    [50457] = {
        name = "Sfondare le difese",
    },
    [50466] = {
        name = "È impazzito!",
    },
    [50481] = {
        name = "Nell'antro del Re dei Drust",
    },
    [50493] = {
        name = "Torna a casa Wrex",
    },
    [50504] = {
        name = "Sam il mieloso",
    },
    [50520] = {
        name = "Dov'è Sam?",
    },
    [50530] = {
        name = "Chiavi in mano",
    },
    [50531] = {
        name = "Sotto il loro naso",
    },
    [50533] = {
        name = "Demolizioni professionali",
    },
    [50534] = {
        name = "Vietato l'ingresso ai Wendigo",
    },
    [50535] = {
        name = "Potere della Sovrintendente",
    },
    [50536] = {
        name = "Il dispositivo magico di decodifica",
    },
    [50538] = {
        name = "L'addestratore scomparso",
    },
    [50539] = {
        name = "I segreti di Zul'ahjin",
    },
    [50542] = {
        name = "Un'opportunità esplosiva",
    },
    [50544] = {
        name = "I cacciatori del Rifugio dei Kennings",
    },
    [50550] = {
        name = "La caduta dell'Imperatore Korthek",
    },
    [50551] = {
        name = "Tempio di Sethraliss: Avatar del Loa",
    },
    [50553] = {
        name = "Ritorno al laboratorio",
    },
    [50561] = {
        name = "La Pietra di Sulthis",
    },
    [50573] = {
        name = "Messaggio dalla gestione",
    },
    [50583] = {
        name = "Dall'altra parte",
    },
    [50584] = {
        name = "Rituali della rovina",
    },
    [50585] = {
        name = "Caccia alle streghe",
    },
    [50586] = {
        name = "La caduta di Corlain",
    },
    [50588] = {
        name = "Assalto al maniero",
    },
    [50593] = {
        name = "Sangue disgustoso",
    },
    [50594] = {
        name = "Sotto il velo",
    },
    [50595] = {
        name = "Senza quartiere",
    },
    [50596] = {
        name = "Sterminare la feccia",
    },
    [50598] = {
        name = "Impero degli Zandalari",
    },
    [50599] = {
        name = "Ammiragliato Marefiero",
    },
    [50600] = {
        name = "Ordine delle Braci",
    },
    [50601] = {
        name = "Destatempesta",
    },
    [50602] = {
        name = "Spedizione di Talanji",
    },
    [50605] = {
        name = "Sforzo Bellico: Alleanza",
    },
    [50606] = {
        name = "Sforzo Bellico: Orda",
    },
    [50608] = {
        name = "Riti proibiti",
    },
    [50609] = {
        name = "Dalle Fauci della Follia",
    },
    [50610] = {
        name = "Radunare le tempeste",
    },
    [50611] = {
        name = "La vendetta della tempesta",
    },
    [50612] = {
        name = "Una casata divisa",
    },
    [50614] = {
        name = "Libertà per il mare",
    },
    [50616] = {
        name = "Basta un poco di vincolo",
    },
    [50617] = {
        name = "Atul'aman",
    },
    [50621] = {
        name = "Dritti nella rete",
    },
    [50622] = {
        name = "Nella vecchia fattoria",
    },
    [50635] = {
        name = "Le Maree Mutevoli",
    },
    [50639] = {
        name = "Maniero dei Crestabianca: La caduta della madre",
    },
    [50640] = {
        name = "Una questione di verrontà",
    },
    [50641] = {
        name = "Rompere i loro ranghi",
    },
    [50644] = {
        name = "Affrontare gli invasori",
    },
    [50645] = {
        name = "Pesca grossa",
    },
    [50649] = {
        name = "Fregare i ladri",
    },
    [50653] = {
        name = "Reclamare le difese",
    },
    [50656] = {
        name = "Un salvataggio rischioso",
    },
    [50672] = {
        name = "Qualsiasi munizione andrà bene",
    },
    [50674] = {
        name = "Feccia a due facce",
    },
    [50675] = {
        name = "A caccia di tesori",
    },
    [50679] = {
        name = "Penetrare lo scudo",
    },
    [50690] = {
        name = "Colloquio con Moxie",
    },
    [50691] = {
        name = "Non sul nostro libro paga",
    },
    [50696] = {
        name = "Divertirsi coi magneti",
    },
    [50697] = {
        name = "Bomba batte sasso",
    },
    [50698] = {
        name = "Le esplosioni risolvono ogni problema",
    },
    [50699] = {
        name = "I diritti dei lavoratori",
    },
    [50700] = {
        name = "Drust in tempo",
    },
    [50702] = {
        name = "Sconfiggere Jakra'zet",
    },
    [50703] = {
        name = "Informare l'Orda",
    },
    [50704] = {
        name = "Ancore pesantissime",
    },
    [50705] = {
        name = "Un serpente a tre teste",
    },
    [50706] = {
        name = "Ripulire la foce",
    },
    [50733] = {
        name = "Una nuova alba",
    },
    [50739] = {
        name = "Scomparse misteriose",
    },
    [50741] = {
        name = "Trattative tortolliane",
    },
    [50742] = {
        name = "Lavoro facilitato",
    },
    [50743] = {
        name = "Il problema immediato",
    },
    [50745] = {
        name = "Infiltrarsi nell'impero",
    },
    [50746] = {
        name = "Cratere conquistato",
    },
    [50748] = {
        name = "Non farle cadere... per ora",
    },
    [50749] = {
        name = "Passaggio gratuito",
    },
    [50750] = {
        name = "Far infuriare l'imperatore",
    },
    [50751] = {
        name = "Santuario sotto assedio",
    },
    [50752] = {
        name = "Reliquie di Sethraliss",
    },
    [50753] = {
        name = "Earl-E prende i vermi",
    },
    [50754] = {
        name = "Amato e perduto",
    },
    [50755] = {
        name = "Pasti per uccelli",
    },
    [50757] = {
        name = "Addomesticamenti massacranti",
    },
    [50758] = {
        name = "Ricordi dolorosi",
    },
    [50759] = {
        name = "In ritardo",
    },
    [50760] = {
        name = "Per il resto della nostra vita",
    },
    [50761] = {
        name = "Nozze di Sangue",
    },
    [50762] = {
        name = "Il fato della dama",
    },
    [50763] = {
        name = "Un'ultima richiesta",
    },
    [50769] = {
        name = "Estrazione da Roccavento",
    },
    [50770] = {
        name = "Un antiveleno efficace",
    },
    [50771] = {
        name = "Richiamo: Ripulitore",
    },
    [50773] = {
        name = "Lo squalo",
    },
    [50774] = {
        name = "Mai abbandonare un robot",
    },
    [50775] = {
        name = "A spasso per la spiaggia",
    },
    [50777] = {
        name = "La tempesta si risveglia",
    },
    [50778] = {
        name = "Intenti distorti",
    },
    [50779] = {
        name = "Una pagina bianca",
    },
    [50780] = {
        name = "Giuramenti",
    },
    [50781] = {
        name = "Un ponte troppo lontano",
    },
    [50783] = {
        name = "Il Concilio Abissale",
    },
    [50784] = {
        name = "L'occhio della tempesta",
    },
    [50787] = {
        name = "Prove inconfutabili",
    },
    [50788] = {
        name = "Serpi in seno",
    },
    [50789] = {
        name = "Ripulire l'aria",
    },
    [50790] = {
        name = "La grande fuga",
    },
    [50791] = {
        name = "Reee...",
    },
    [50793] = {
        name = "Confusione nelle caverne",
    },
    [50794] = {
        name = "In cerca di rifugio",
    },
    [50795] = {
        name = "Prepararsi al peggio",
    },
    [50796] = {
        name = "REEEEEE!",
    },
    [50797] = {
        name = "Un invito che non si può rifiutare",
    },
    [50798] = {
        name = "Compiti rischiosi",
    },
    [50801] = {
        name = "Fiuto per i guai",
    },
    [50802] = {
        name = "Carne da Marferreo",
    },
    [50803] = {
        name = "Con un deca",
    },
    [50805] = {
        name = "Invocatori disattivati",
    },
    [50808] = {
        name = "Impedire la caduta dell'impero",
    },
    [50810] = {
        name = "Fuga dalla prigionia",
    },
    [50812] = {
        name = "Elementi indeboliti",
    },
    [50814] = {
        name = "Un luogo terribile",
    },
    [50817] = {
        name = "Ammaliare i serpenti",
    },
    [50818] = {
        name = "Un flauto perduto",
    },
    [50824] = {
        name = "La fine di Sacraonda",
    },
    [50825] = {
        name = "Santuario della Tempesta: Sussurri sotterranei",
    },
    [50834] = {
        name = "Abbassa il volume!",
    },
    [50835] = {
        name = "Il Porto di Zandalar",
    },
    [50838] = {
        name = "Fiuto per i guai",
    },
    [50839] = {
        name = "REEEEEE!",
    },
    [50841] = {
        name = "REEEEEE!",
    },
    [50842] = {
        name = "Un albero irresistibile",
    },
    [50860] = {
        name = "Fiuto per i guai",
    },
    [50881] = {
        name = "Rapporto regale",
    },
    [50886] = {
        name = "Ali di supporto",
    },
    [50887] = {
        name = "Una questione di fiducia",
    },
    [50897] = {
        name = "Deviare il calore",
    },
    [50900] = {
        name = "Forse quando sarà più grande",
    },
    [50901] = {
        name = "Sauridana al Cartoccio",
    },
    [50903] = {
        name = "Un Maestro disperso",
    },
    [50904] = {
        name = "Il Passaggio Abbandonato",
    },
    [50908] = {
        name = "Profumo di guai",
    },
    [50909] = {
        name = "Mai senz'armi",
    },
    [50910] = {
        name = "Giochi pericolosi",
    },
    [50911] = {
        name = "Da soli contro l'Orda",
    },
    [50912] = {
        name = "Attenti al fuoco",
    },
    [50913] = {
        name = "La benedizione di Akunda",
    },
    [50929] = {
        name = "Polvere al popolo",
    },
    [50930] = {
        name = "In caduta, ma con stile",
    },
    [50933] = {
        name = "Uno sfortunato evento",
    },
    [50934] = {
        name = "Un avvistamento fortuito",
    },
    [50940] = {
        name = "Saggezza dei Senza Ali",
    },
    [50942] = {
        name = "Vestirsi per il volo",
    },
    [50943] = {
        name = "La gioia del volo",
    },
    [50944] = {
        name = "A terra, ma non sconfitto",
    },
    [50953] = {
        name = "Calcaverde",
    },
    [50954] = {
        name = "Zandalar per sempre!",
    },
    [50955] = {
        name = "Non siamo amici",
    },
    [50956] = {
        name = "Paghetta",
    },
    [50959] = {
        name = "Pirati saccheggiati",
    },
    [50960] = {
        name = "Ordini di Sweete",
    },
    [50963] = {
        name = "Giorni cupi di cupi eventi",
    },
    [50965] = {
        name = "Ciò che resta",
    },
    [50967] = {
        name = "Persi nella foresta",
    },
    [50970] = {
        name = "Il destino di un contadino",
    },
    [50972] = {
        name = "L'apertura di Marefiero",
    },
    [50976] = {
        name = "Un'antica maledizione",
    },
    [50978] = {
        name = "Cambia il vecchio con il nuovo",
    },
    [50979] = {
        name = "Solo un goccio",
    },
    [50980] = {
        name = "Una vicina vorace",
    },
    [50988] = {
        name = "Un'opportunità economica",
    },
    [50990] = {
        name = "Scienza del pollame all'avanguardia",
    },
    [51001] = {
        name = "Problemi di contrabbando",
    },
    [51018] = {
        name = "Per conto di un amico",
    },
    [51019] = {
        name = "Non avrà un grande aspetto ma non gli manca niente",
    },
    [51020] = {
        name = "Pratiche economiche tagliagole",
    },
    [51052] = {
        name = "Azerite per l'Alleanza!",
    },
    [51053] = {
        name = "Il giorno in cui il porto cadde",
    },
    [51054] = {
        name = "Un atteso ammutinamento",
    },
    [51055] = {
        name = "Il braccio ossuto della legge",
    },
    [51056] = {
        name = "Il mio ultimo giorno da vivo",
    },
    [51057] = {
        name = "Battesimo del fuoco",
    },
    [51059] = {
        name = "L'Isola Dorata",
    },
    [51060] = {
        name = "La nostra fetta del bottino",
    },
    [51061] = {
        name = "La prima volta che morii",
    },
    [51062] = {
        name = "Fuga da Zem'lan",
    },
    [51069] = {
        name = "RICERCATO: Oratore Oscuro Jo'la",
    },
    [51071] = {
        name = "RICERCATA: Imperatrice Lamazanna",
    },
    [51072] = {
        name = "RICERCATO: Schiantanocche Patriarca",
    },
    [51085] = {
        name = "RICERCATO: Storiografo Oscuro",
    },
    [51087] = {
        name = "RICERCATO: Storiografo Oscuro",
    },
    [51088] = {
        name = "Cuore di tenebra",
    },
    [51089] = {
        name = "RICERCATO: Tojek",
    },
    [51091] = {
        name = "RICERCATI: Ten'gor e Nol'ixwan",
    },
    [51101] = {
        name = "Il re ferito",
    },
    [51111] = {
        name = "Re o preda",
    },
    [51129] = {
        name = "Offerte dubbie",
    },
    [51134] = {
        name = "Se le ossa potessero parlare",
    },
    [51139] = {
        name = "RICERCATO: Tojek",
    },
    [51140] = {
        name = "Dividere le ricchezze",
    },
    [51142] = {
        name = "La Prova di Jani",
    },
    [51144] = {
        name = "Consegna di pellicce",
    },
    [51145] = {
        name = "La Maledizione di Jani",
    },
    [51146] = {
        name = "Il giorno libero di Kua'fon",
    },
    [51147] = {
        name = "Il giorno libero di Kua'fon",
    },
    [51149] = {
        name = "Dimenticato al porto",
    },
    [51150] = {
        name = "Onore ai caduti",
    },
    [51151] = {
        name = "Una lettera per la Lega",
    },
    [51159] = {
        name = "Un pezzo da novanta",
    },
    [51161] = {
        name = "RICERCATO: Za'roco",
    },
    [51162] = {
        name = "RICERCATO: Taz'raka il Traditore",
    },
    [51164] = {
        name = "RICERCATI: Partecipanti all'Escursione del Cobra",
    },
    [51165] = {
        name = "RICERCATO: Esploratore delle Sabbie Vesarik",
    },
    [51167] = {
        name = "Il sangue di Hir'eek",
    },
    [51168] = {
        name = "Zeloti di Zalamar",
    },
    [51169] = {
        name = "Caduta in volo",
    },
    [51170] = {
        name = "Urrà!",
    },
    [51177] = {
        name = "Lezioni dei dannati",
    },
    [51190] = {
        name = "Tregua concessa",
    },
    [51191] = {
        name = "Salviamoli tutti",
    },
    [51192] = {
        name = "C'è bisogno di tutto",
    },
    [51193] = {
        name = "Un martello per amico",
    },
    [51199] = {
        name = "La gloria della caccia",
    },
    [51200] = {
        name = "La pecora nera",
    },
    [51201] = {
        name = "Il racconto del Troll",
    },
    [51203] = {
        name = "Caccia al lupo",
    },
    [51204] = {
        name = "RICERCATO: Unghiaguzza Alfa",
    },
    [51205] = {
        name = "Uff, Ratti!",
    },
    [51207] = {
        name = "Etti 'na crozza",
    },
    [51208] = {
        name = "Aspetta un frumento...",
    },
    [51209] = {
        name = "Grokk Pugnoatroce il possente",
    },
    [51211] = {
        name = "Il Cuore di Azeroth",
    },
    [51214] = {
        name = "Sii gentile",
    },
    [51215] = {
        name = "Mungere capre",
    },
    [51217] = {
        name = "RICERCATA: Yarsel'ghun",
    },
    [51218] = {
        name = "Consegne in ritardo",
    },
    [51220] = {
        name = "Sprechi in alto mare",
    },
    [51221] = {
        name = "Agente 00S.P.R. & Co.",
    },
    [51222] = {
        name = "Quel che è tuo è mi(nat)o",
    },
    [51224] = {
        name = "Profitto e perlustrazioni",
    },
    [51226] = {
        name = "Morte da due fronti",
    },
    [51229] = {
        name = "Stabilire un avamposto",
    },
    [51231] = {
        name = "Wiccafobia",
    },
    [51233] = {
        name = "Niente streghe tra i monti",
    },
    [51234] = {
        name = "L'Avamposto di Krazzfrazz",
    },
    [51240] = {
        name = "RICERCATO: Stuzzicancora",
    },
    [51244] = {
        name = "C'è del marcio a Nazmir",
    },
    [51246] = {
        name = "Se non ti ha ucciso il naufragio... ci penso io",
    },
    [51247] = {
        name = "La conoscenza è potere",
    },
    [51248] = {
        name = "Insetti produttivi",
    },
    [51249] = {
        name = "Un banchetto granchioso",
    },
    [51251] = {
        name = "Combattenti da cantina",
    },
    [51278] = {
        name = "Morti e dimenticati",
    },
    [51279] = {
        name = "Cultisti Nazmani",
    },
    [51280] = {
        name = "Offerte per G'huun",
    },
    [51281] = {
        name = "Zul'nazman",
    },
    [51282] = {
        name = "Il Capitano Conrad",
    },
    [51283] = {
        name = "Viaggio verso ovest",
    },
    [51286] = {
        name = "Fermare l'evacuazione",
    },
    [51302] = {
        name = "Grottamarcia: Fermare la corruzione di G'huun",
    },
    [51308] = {
        name = "Avanzare a Zuldazar",
    },
    [51309] = {
        name = "Rocce di Ragnaros",
    },
    [51310] = {
        name = "I predatori del raccolto perduto",
    },
    [51314] = {
        name = "Il grano porta grane",
    },
    [51319] = {
        name = "L'ascesa finale",
    },
    [51320] = {
        name = "Un destino inevitabile",
    },
    [51331] = {
        name = "Macchinazioni trivellanti",
    },
    [51332] = {
        name = "Un viaggio attraverso l'oceano",
    },
    [51335] = {
        name = "Latte e biscotti",
    },
    [51339] = {
        name = "Operazione ali pulite",
    },
    [51340] = {
        name = "Rotta verso Drustvar!",
    },
    [51341] = {
        name = "La Figlia del Mare",
    },
    [51342] = {
        name = "Battaglia per Stromgarde",
    },
    [51343] = {
        name = "Lezioni di nuoto",
    },
    [51349] = {
        name = "Vincolo d'onore",
    },
    [51350] = {
        name = "Aiuto inaspettato",
    },
    [51351] = {
        name = "Pungiglioni avvelenati",
    },
    [51352] = {
        name = "Non si gioca coi fiammiferi",
    },
    [51353] = {
        name = "La Caverna di Ai'twen",
    },
    [51354] = {
        name = "Rabbia in bottiglia",
    },
    [51356] = {
        name = "RICERCATA: Sorella Lilias",
    },
    [51357] = {
        name = "Armata e pronta",
    },
    [51358] = {
        name = "RICERCATI: Rapitori di Grifoni",
    },
    [51359] = {
        name = "Frammenti delle Terre del Fuoco",
    },
    [51364] = {
        name = "Una fuga esplosiva",
    },
    [51366] = {
        name = "Somministrare l'antidoto",
    },
    [51367] = {
        name = "RICERCATO: Guardiaterra Infuriato",
    },
    [51368] = {
        name = "RICERCATA: La Vespa",
    },
    [51369] = {
        name = "Amici in luoghi strani",
    },
    [51370] = {
        name = "Ricompense per scarse provviste",
    },
    [51371] = {
        name = "Un'offerta alghettante",
    },
    [51384] = {
        name = "RICERCATO: Quartiermastro Ssylis",
    },
    [51386] = {
        name = "Una vittoria in pugno",
    },
    [51389] = {
        name = "Evasione",
    },
    [51390] = {
        name = "RICERCATI: Tagliagole Cremisi",
    },
    [51391] = {
        name = "Strappare le zanne ai Senzafede",
    },
    [51394] = {
        name = "Spezzare l'assedio",
    },
    [51395] = {
        name = "Le chiavi dei Custodi",
    },
    [51401] = {
        name = "Chi la dura la vince",
    },
    [51402] = {
        name = "A rapporto!",
    },
    [51403] = {
        name = "Priorità dell'Oratore",
    },
    [51407] = {
        name = "Trovare le parole",
    },
    [51421] = {
        name = "Mi tremano le assi!",
    },
    [51425] = {
        name = "Aria di casa",
    },
    [51426] = {
        name = "Ispezione Gadget",
    },
    [51427] = {
        name = "Mi piacciono le tartarughe",
    },
    [51430] = {
        name = "Ingegneria inversa",
    },
    [51435] = {
        name = "Negoziare con stile",
    },
    [51436] = {
        name = "Negoziazioni tra pirati",
    },
    [51437] = {
        name = "Lasciarli all'asciutto",
    },
    [51438] = {
        name = "Segnare il territorio",
    },
    [51439] = {
        name = "Palle di cannone collezionabili",
    },
    [51440] = {
        name = "Cambio di direzione",
    },
    [51441] = {
        name = "Fuoco in buca!",
    },
    [51442] = {
        name = "Sono io il capitano, ora",
    },
    [51443] = {
        name = "Notifica di missione",
    },
    [51445] = {
        name = "Thros, le Terre Ammorbate",
    },
    [51465] = {
        name = "Raccolta differenziata",
    },
    [51472] = {
        name = "Preservare la vita",
    },
    [51474] = {
        name = "Forgiato nel fuoco e nelle fiamme",
    },
    [51479] = {
        name = "Gli Incorrotti",
    },
    [51483] = {
        name = "Il retaggio dei Ferroscuro",
    },
    [51484] = {
        name = "Retaggio dei Mag'har",
    },
    [51485] = {
        name = "Per l'Orda",
    },
    [51486] = {
        name = "Per l'Alleanza!",
    },
    [51487] = {
        name = "Alla ricerca di risposte",
    },
    [51488] = {
        name = "Finalmente qualche informazione",
    },
    [51489] = {
        name = "È ora di andare",
    },
    [51490] = {
        name = "Problemi sui confini",
    },
    [51492] = {
        name = "La congiura delle polveri da sparo",
    },
    [51504] = {
        name = "Biscotti in arrivo",
    },
    [51513] = {
        name = "Il ritorno di Zalazane",
    },
    [51514] = {
        name = "Patto infranto",
    },
    [51515] = {
        name = "Vendetta per Vol'jin",
    },
    [51516] = {
        name = "Atal'dazar: Le ceneri di un Capoguerra",
    },
    [51517] = {
        name = "Debiti di spirito",
    },
    [51518] = {
        name = "Lo spirito perduto",
    },
    [51519] = {
        name = "Richiamo degli Spiriti",
    },
    [51520] = {
        name = "Giustizia per i caduti",
    },
    [51521] = {
        name = "Il vero capo di Zandalar",
    },
    [51526] = {
        name = "Il richiamo del Signore della Guerra",
    },
    [51532] = {
        name = "Invasioni tempestive",
    },
    [51533] = {
        name = "La Lama di Vol'jin",
    },
    [51534] = {
        name = "La battaglia per Brennadam",
    },
    [51536] = {
        name = "A Caccia",
    },
    [51538] = {
        name = "Voci dagli abissi",
    },
    [51539] = {
        name = "Informare l'Orda!",
    },
    [51540] = {
        name = "Una situazione esplosiva",
    },
    [51543] = {
        name = "Arboscelli nella neve",
    },
    [51544] = {
        name = "Disarmare i cannoni",
    },
    [51545] = {
        name = "Spezzare lo spezzatore",
    },
    [51547] = {
        name = "RICERCATO: Troncomarcio",
    },
    [51552] = {
        name = "La vita che stress",
    },
    [51554] = {
        name = "Ricarica",
    },
    [51555] = {
        name = "Mantenere il controllo",
    },
    [51557] = {
        name = "Un avvertimento ferreo",
    },
    [51569] = {
        name = "La Campagna di Zandalar",
    },
    [51573] = {
        name = "Ti copro le spalle!",
    },
    [51574] = {
        name = "Un sacco di succo",
    },
    [51582] = {
        name = "Una distilleria distinta",
    },
    [51587] = {
        name = "Avanti!",
    },
    [51589] = {
        name = "Spezzare i Kul Tirani",
    },
    [51590] = {
        name = "Nel cuore di Tiragarde",
    },
    [51591] = {
        name = "I signori della montagna",
    },
    [51592] = {
        name = "Decorazioni domestiche",
    },
    [51593] = {
        name = "Indagine a Portoponte",
    },
    [51594] = {
        name = "Esplosivi nella Fonderia",
    },
    [51595] = {
        name = "Esplosività",
    },
    [51596] = {
        name = "Acquisizione di munizioni",
    },
    [51597] = {
        name = "Studi sulla Polvere da Sparo",
    },
    [51598] = {
        name = "Un po' di caos",
    },
    [51599] = {
        name = "Trappola Mortale",
    },
    [51601] = {
        name = "La Corsa di Portoponte",
    },
    [51602] = {
        name = "Lame ribelli",
    },
    [51643] = {
        name = "Muro di Ferro",
    },
    [51663] = {
        name = "Prepararsi alla caduta",
    },
    [51674] = {
        name = "Estinguere le fiamme",
    },
    [51675] = {
        name = "Battuta di caccia",
    },
    [51677] = {
        name = "Curare anima e corpo",
    },
    [51678] = {
        name = "Furia di Rastakhan",
    },
    [51679] = {
        name = "Uno strano porto sicuro",
    },
    [51680] = {
        name = "L'ombra di Bwonsamdi",
    },
    [51689] = {
        name = "Soccorrere i Tortolliani",
    },
    [51691] = {
        name = "Quasi degni di essere salvati",
    },
    [51696] = {
        name = "Riprendersi il maltolto",
    },
    [51711] = {
        name = "Situazione esplosiva",
    },
    [51712] = {
        name = "Occhio per Occhio",
    },
    [51714] = {
        name = "In missione per il Re",
    },
    [51715] = {
        name = "Guerra delle ombre",
    },
    [51717] = {
        name = "Il miglior miele di Vol'dun",
    },
    [51718] = {
        name = "Raccolta del \"Miele\"",
    },
    [51720] = {
        name = "Segatronchi attivato",
    },
    [51723] = {
        name = "Polvere di falegname",
    },
    [51726] = {
        name = "Via di qua",
    },
    [51728] = {
        name = "Bruciare tutto",
    },
    [51752] = {
        name = "Uccidere Grizz",
    },
    [51753] = {
        name = "Campione: Rexxar",
    },
    [51770] = {
        name = "Missione dalla Capoguerra",
    },
    [51771] = {
        name = "Guerra delle ombre",
    },
    [51772] = {
        name = "Tribù Tortaka",
    },
    [51773] = {
        name = "La minaccia dei Bracescura",
    },
    [51775] = {
        name = "Accampamento Ventotardo",
    },
    [51784] = {
        name = "Passeggiata funeraria",
    },
    [51785] = {
        name = "Esaminare le iscrizioni",
    },
    [51786] = {
        name = "Stato d'inquietudine",
    },
    [51787] = {
        name = "Il nostro destino",
    },
    [51788] = {
        name = "Il Custode della Cripta",
    },
    [51789] = {
        name = "Ciò che resta del Maresciallo M. Valentine",
    },
    [51795] = {
        name = "La Battaglia per Lordaeron",
    },
    [51796] = {
        name = "La Battaglia per Lordaeron",
    },
    [51797] = {
        name = "Sulle tracce del Saggio delle Maree",
    },
    [51798] = {
        name = "Nulla è mai troppo",
    },
    [51803] = {
        name = "La campagna di Kul Tiras",
    },
    [51805] = {
        name = "Conosceranno la paura",
    },
    [51810] = {
        name = "Capitano Hartford",
    },
    [51813] = {
        name = "I Sotterranei di Roccianera",
    },
    [51818] = {
        name = "Comandante e capitano",
    },
    [51819] = {
        name = "Disperdere i nemici",
    },
    [51829] = {
        name = "La chiave meccanica di Ranah",
    },
    [51830] = {
        name = "Il potenziale di Zelling",
    },
    [51837] = {
        name = "Qualsiasi cosa accada",
    },
    [51870] = {
        name = "Scorreria sulle Isole",
    },
    [51881] = {
        name = "Campo minato",
    },
    [51888] = {
        name = "Scorreria sulle Isole",
    },
    [51903] = {
        name = "Scorreria sulle Isole",
    },
    [51904] = {
        name = "Scorreria sulle Isole",
    },
    [51916] = {
        name = "Riunire Zandalar",
    },
    [51918] = {
        name = "Riunire Kul Tiras",
    },
    [51961] = {
        name = "Un avamposto per la campagna",
    },
    [51967] = {
        name = "Ritorno a Boralus",
    },
    [51968] = {
        name = "Ritorno a Boralus",
    },
    [51969] = {
        name = "Ritorno a Boralus",
    },
    [51975] = {
        name = "Campione: Cacciatore dell'Ombra Ty'jin",
    },
    [51979] = {
        name = "Un avamposto per la campagna",
    },
    [51980] = {
        name = "RICERCATO: Jabra'kan",
    },
    [51984] = {
        name = "Ritorno a Zuldazar",
    },
    [51985] = {
        name = "Ritorno a Zuldazar",
    },
    [51986] = {
        name = "Ritorno a Zuldazar",
    },
    [51987] = {
        name = "Campione: Hobart Multivite",
    },
    [51990] = {
        name = "Ali per il Kraal",
    },
    [51991] = {
        name = "Caricare le batterie",
    },
    [51998] = {
        name = "OCC, ora con vero cornofurente!",
    },
    [52003] = {
        name = "Campione: Kelsey Ferfavilla",
    },
    [52008] = {
        name = "Campione: Magistro Umbric",
    },
    [52013] = {
        name = "Campione: John J. Keeshan",
    },
    [52026] = {
        name = "Assassinio internazionale",
    },
    [52027] = {
        name = "Il piano di Vol'dun",
    },
    [52028] = {
        name = "Setacciare il deserto",
    },
    [52029] = {
        name = "Lavoro sporco",
    },
    [52030] = {
        name = "La ricerca continua",
    },
    [52031] = {
        name = "Circolo del Reliquiario classico",
    },
    [52032] = {
        name = "Mai smettere di cercare",
    },
    [52033] = {
        name = "RICERCATA: Cacciabrina",
    },
    [52034] = {
        name = "Un messaggio per gli Zandalari",
    },
    [52035] = {
        name = "Sopravvivenza improvvisata",
    },
    [52036] = {
        name = "L'insostenibile morbidezza degli alpaca",
    },
    [52038] = {
        name = "Divisioni",
    },
    [52039] = {
        name = "Morte a distanza",
    },
    [52040] = {
        name = "Un pieno di frecce",
    },
    [52041] = {
        name = "Rapporto a Sventradraghi",
    },
    [52042] = {
        name = "Grossa Esplosione",
    },
    [52061] = {
        name = "Caramellino il maialino",
    },
    [52065] = {
        name = "Peggio di quanto sembri",
    },
    [52067] = {
        name = "Sopravvissuti",
    },
    [52068] = {
        name = "Aiutare altrove",
    },
    [52069] = {
        name = "Altra carne da macello",
    },
    [52070] = {
        name = "In cerca di Bauer",
    },
    [52073] = {
        name = "L'evocazione di Krag'wa",
    },
    [52074] = {
        name = "Servizio consegne",
    },
    [52075] = {
        name = "Ossa rissose",
    },
    [52113] = {
        name = "Vol'jin, figlio di Sen'jin",
    },
    [52114] = {
        name = "Onorare un vero capo",
    },
    [52122] = {
        name = "La natura dei Reietti",
    },
    [52127] = {
        name = "Tana del Lupo",
    },
    [52128] = {
        name = "Il lasciapassare",
    },
    [52129] = {
        name = "Problemi energetici",
    },
    [52130] = {
        name = "Preda letale: Carpa Diem",
    },
    [52131] = {
        name = "Reciproca utilità",
    },
    [52132] = {
        name = "Prova di pirateria",
    },
    [52139] = {
        name = "Faccende pressanti",
    },
    [52146] = {
        name = "Sangue sulla sabbia",
    },
    [52147] = {
        name = "Azzoppare l'Orda",
    },
    [52149] = {
        name = "Fiamma eterna",
    },
    [52150] = {
        name = "Come uccidere una Guardaboschi Oscura",
    },
    [52151] = {
        name = "Una nazione unita",
    },
    [52153] = {
        name = "Assedio di Boralus: Il ritorno di Dama Bracescura",
    },
    [52154] = {
        name = "Il prossimo bersaglio",
    },
    [52156] = {
        name = "Tortolliani in difficoltà",
    },
    [52158] = {
        name = "Caccia selvaggia",
    },
    [52170] = {
        name = "La fine di Areiel",
    },
    [52171] = {
        name = "Opzione incendiaria",
    },
    [52172] = {
        name = "Divieto di soggiorno",
    },
    [52173] = {
        name = "Gli Elfi del Vuoto sono pronti",
    },
    [52183] = {
        name = "Quando un piano funziona",
    },
    [52184] = {
        name = "Reliquie del rituale",
    },
    [52185] = {
        name = "Un portale ben posizionato",
    },
    [52186] = {
        name = "Il grosso della guardia",
    },
    [52187] = {
        name = "Vecchi colleghi",
    },
    [52188] = {
        name = "Insegnamenti dei Saggi delle Maree",
    },
    [52189] = {
        name = "Resa delle anime",
    },
    [52190] = {
        name = "Ottenere un vantaggio",
    },
    [52191] = {
        name = "Vita in ostaggio",
    },
    [52192] = {
        name = "L'aiuto delle maree",
    },
    [52194] = {
        name = "Possibili rimpianti",
    },
    [52203] = {
        name = "Ricerca di informazioni",
    },
    [52204] = {
        name = "Soluzione del Vuoto",
    },
    [52205] = {
        name = "Gettare l'Acqualorda",
    },
    [52208] = {
        name = "Incontro esclusivo",
    },
    [52210] = {
        name = "Inviare un S.O.S.",
    },
    [52212] = {
        name = "Battaglia per Stromgarde",
    },
    [52219] = {
        name = "Bersaglio: Principe del Sangue Dreven",
    },
    [52241] = {
        name = "Paradiso dei Goblin",
    },
    [52246] = {
        name = "Carico perduto",
    },
    [52247] = {
        name = "Caccia a Gallywix",
    },
    [52252] = {
        name = "Ingresso esplosivo",
    },
    [52253] = {
        name = "Le chiavi della libertà",
    },
    [52258] = {
        name = "La ragazza e le conchiglie",
    },
    [52259] = {
        name = "Nessun piacere",
    },
    [52260] = {
        name = "Con le spalle al muro",
    },
    [52261] = {
        name = "La fuga di Gallywix",
    },
    [52281] = {
        name = "In viaggio con Alalesta",
    },
    [52282] = {
        name = "Colpito e affondato",
    },
    [52283] = {
        name = "Sabotaggio di Pa'ku",
    },
    [52284] = {
        name = "Registri Navali",
    },
    [52285] = {
        name = "Sottomarino Miniaturizzato Gigante",
    },
    [52286] = {
        name = "Sotto il naso del nemico",
    },
    [52287] = {
        name = "Controspionaggio",
    },
    [52288] = {
        name = "Vacanze nel Vuoto",
    },
    [52289] = {
        name = "Vittoria assicurata",
    },
    [52290] = {
        name = "Il nemico del mio nemico è il mio travestimento",
    },
    [52291] = {
        name = "Vittoria (non proprio) assicurata",
    },
    [52294] = {
        name = "Idoli caduti",
    },
    [52305] = {
        name = "Natura contro allevamento",
    },
    [52308] = {
        name = "Ordini intercettati",
    },
    [52311] = {
        name = "Il forziere di Sweete",
    },
    [52317] = {
        name = "Tu lanci, io ptrendo",
    },
    [52428] = {
        name = "Infondere il Cuore",
    },
    [52431] = {
        name = "Divieto di attracco",
    },
    [52443] = {
        name = "L'ultimo avamposto",
    },
    [52444] = {
        name = "L'ultimo avamposto",
    },
    [52445] = {
        name = "Tol Dagor: La quarta chiave",
    },
    [52447] = {
        name = "Ogni giorno un passo avanti",
    },
    [52449] = {
        name = "L'isola misteriosa",
    },
    [52450] = {
        name = "Riunire Kul Tiras",
    },
    [52453] = {
        name = "Una speranza perduta",
    },
    [52472] = {
        name = "Lohmanji",
    },
    [52473] = {
        name = "Affondare la flotta",
    },
    [52477] = {
        name = "RICERCATO: Ayame",
    },
    [52480] = {
        name = "RICERCATO: Ayame",
    },
    [52481] = {
        name = "Miti e favole",
    },
    [52482] = {
        name = "Il vecchio orso",
    },
    [52483] = {
        name = "Acchiappaincubi",
    },
    [52484] = {
        name = "Potere sotterrato",
    },
    [52485] = {
        name = "Il nucleo dell'odio",
    },
    [52486] = {
        name = "Maniero dei Crestabianca: prosciugare le Frangicuore",
    },
    [52487] = {
        name = "Nell'oscurità",
    },
    [52488] = {
        name = "Resistenza runica",
    },
    [52489] = {
        name = "A caccia del Principe del Sangue Dreven",
    },
    [52490] = {
        name = "Sulle navi nemiche",
    },
    [52491] = {
        name = "Baraonda furibonda",
    },
    [52492] = {
        name = "Specialità dei Granmartello",
    },
    [52493] = {
        name = "Equipaggio innaturale",
    },
    [52494] = {
        name = "Cristalli di sangue",
    },
    [52495] = {
        name = "La fine della minaccia San'layn",
    },
    [52496] = {
        name = "Fuga da manuale",
    },
    [52508] = {
        name = "Effetti rituali",
    },
    [52509] = {
        name = "La forza della tempesta",
    },
    [52510] = {
        name = "Santuario della Tempesta: il rituale mancante",
    },
    [52511] = {
        name = "Aprire la via",
    },
    [52512] = {
        name = "Fine del Destino",
    },
    [52513] = {
        name = "Persi nell'oscurità",
    },
    [52544] = {
        name = "Bottino di guerra",
    },
    [52654] = {
        name = "Campagna di Guerra",
    },
    [52746] = {
        name = "Bottino di guerra",
    },
    [52748] = {
        name = "Rivolgi gli occhi al cielo",
    },
    [52749] = {
        name = "Campagna di Guerra",
    },
    [52750] = {
        name = "Contadini coraggiosi",
    },
    [52762] = {
        name = "Guida locale",
    },
    [52764] = {
        name = "Viaggio verso il nulla",
    },
    [52765] = {
        name = "Immersione in profondità",
    },
    [52766] = {
        name = "Relitto sul fondale",
    },
    [52767] = {
        name = "Controllo delle piastrine",
    },
    [52768] = {
        name = "Cimitero sommerso",
    },
    [52769] = {
        name = "Un capitano alla volta",
    },
    [52770] = {
        name = "Fastidio Bioluminescente",
    },
    [52772] = {
        name = "Sporgenza sottomarina",
    },
    [52773] = {
        name = "Il drago acquatico",
    },
    [52774] = {
        name = "Prendi e scappa",
    },
    [52782] = {
        name = "Chiamata alle armi: Valle dei Sacraonda",
    },
    [52787] = {
        name = "Lenire il dolore",
    },
    [52788] = {
        name = "Nessuno deve sopravvivere",
    },
    [52789] = {
        name = "Silenziare il consiglio",
    },
    [52790] = {
        name = "La fine delle uccisioni",
    },
    [52793] = {
        name = "Il carro perduto",
    },
    [52795] = {
        name = "Aspra verità",
    },
    [52796] = {
        name = "Pochi ma quasi buoni",
    },
    [52800] = {
        name = "Tol Dagor: Sovrintendente dei Bracescura",
    },
    [52855] = {
        name = "L'Alchimia è una scienza inesatta",
    },
    [52857] = {
        name = "In osservazione",
    },
    [52861] = {
        name = "Campione: Lilian Voss",
    },
    [52876] = {
        name = "RICERCATO: Sbudellaguerra",
    },
    [52942] = {
        name = "Ristabilire i vecchi legami",
    },
    [52943] = {
        name = "Richiamare i clan",
    },
    [52944] = {
        name = "Chiamata alle armi: Drustvar",
    },
    [52945] = {
        name = "Legami forgiati in battaglia",
    },
    [52946] = {
        name = "Un mondo morente",
    },
    [52948] = {
        name = "Chiamata alle armi: Baia di Tiragarde",
    },
    [52949] = {
        name = "Chiamata alle armi: Nazmir",
    },
    [52950] = {
        name = "Chiamata alle armi: Vol'dun",
    },
    [52953] = {
        name = "Chiamata alle armi: Vol'dun",
    },
    [52954] = {
        name = "Chiamata alle armi: Nazmir",
    },
    [52955] = {
        name = "Tirannia della Luce",
    },
    [52956] = {
        name = "Chiamata alle armi: Baia di Tiragarde",
    },
    [52958] = {
        name = "Chiamata alle armi: Drustvar",
    },
    [52965] = {
        name = "Un regalo di Grande Inverno",
    },
    [52978] = {
        name = "Principe al seguito",
    },
    [52990] = {
        name = "Ritorno al Porto",
    },
    [53003] = {
        name = "Il ciclo dell'Odio",
    },
    [53011] = {
        name = "Dono Dolcemente Scosso",
    },
    [53028] = {
        name = "Un mondo morente",
    },
    [53031] = {
        name = "Priorità dell'Oratore",
    },
    [53041] = {
        name = "Provare la merce",
    },
    [53045] = {
        name = "Informazioni sul pontile",
    },
    [53050] = {
        name = "Nel cuore di Kul Tiras",
    },
    [53052] = {
        name = "Nel profondo di Zandalar",
    },
    [53055] = {
        name = "Espandere l'influenza",
    },
    [53056] = {
        name = "Espandere l'influenza",
    },
    [53061] = {
        name = "Vantaggio di Azerite",
    },
    [53062] = {
        name = "Vantaggio di Azerite",
    },
    [53063] = {
        name = "Missione di unità",
    },
    [53065] = {
        name = "Operazione Scavatombe",
    },
    [53066] = {
        name = "Operazione Saggezza acquatica",
    },
    [53067] = {
        name = "Operazione Pesce di fondale",
    },
    [53068] = {
        name = "Operazione Amo e lenza",
    },
    [53069] = {
        name = "Operazione Freccia Insanguinata",
    },
    [53070] = {
        name = "Operazione Tagliaborse",
    },
    [53071] = {
        name = "Operazione Artiglio del Grifone",
    },
    [53072] = {
        name = "Operazione Colpo al cuore",
    },
    [53074] = {
        name = "Rinforzi",
    },
    [53079] = {
        name = "Rinforzi",
    },
    [53096] = {
        name = "Ricompensa breve rifornimento",
    },
    [53097] = {
        name = "Abluzioni sconfortate",
    },
    [53098] = {
        name = "Campionessa: Shandris Piumaluna",
    },
    [53099] = {
        name = "Una goccia nel mare cosmico",
    },
    [53105] = {
        name = "Fede malriposta",
    },
    [53109] = {
        name = "La Casata dei Crestabianca",
    },
    [53110] = {
        name = "Il Sommo Cantaspine",
    },
    [53121] = {
        name = "Assedio di Boralus",
    },
    [53128] = {
        name = "Lamento dell'Ammiraglio Supremo",
    },
    [53131] = {
        name = "Requie dei Re",
    },
    [53185] = {
        name = "Contributi al Fronte di Guerra",
    },
    [53194] = {
        name = "Al Fronte",
    },
    [53197] = {
        name = "Visita al Fronte",
    },
    [53198] = {
        name = "Ritorno a Boralus",
    },
    [53208] = {
        name = "Al Fronte",
    },
    [53209] = {
        name = "Contributi al Fronte di Guerra",
    },
    [53210] = {
        name = "Visita al Fronte",
    },
    [53212] = {
        name = "Ritorno a Zuldazar",
    },
    [53330] = {
        name = "RICERCATO: Unghiaguzza Alfa",
    },
    [53332] = {
        name = "Tempo di guerra",
    },
    [53333] = {
        name = "Tempo di guerra",
    },
    [53336] = {
        name = "RICERCATA: Imperatrice Lamazanna",
    },
    [53337] = {
        name = "RICERCATO: Schiantanocche Patriarca",
    },
    [53342] = {
        name = "Nucleo Ardente",
    },
    [53347] = {
        name = "Bombo di tuono",
    },
    [53348] = {
        name = "RICERCATA: Grugnolampo",
    },
    [53351] = {
        name = "La Vena Madre: Ferroavverso",
    },
    [53352] = {
        name = "Terre del Fuoco",
    },
    [53353] = {
        name = "Eco della Signora della Guerra Zaela",
    },
    [53354] = {
        name = "Eco di Gul'dan",
    },
    [53355] = {
        name = "Eco di Garrosh Malogrido",
    },
    [53369] = {
        name = "Lohmanji",
    },
    [53370] = {
        name = "L'ora della Resa dei Conti",
    },
    [53371] = {
        name = "Apicizia",
    },
    [53372] = {
        name = "L'ora della Resa dei Conti",
    },
    [53406] = {
        name = "Sala del Cuore",
    },
    [53430] = {
        name = "Balestra dell'Ordine delle Braci",
    },
    [53431] = {
        name = "Tonico dell'Ordine delle Braci",
    },
    [53432] = {
        name = "Coltello dell'Ordine delle Braci",
    },
    [53433] = {
        name = "Cappello dell'Ordine delle Braci",
    },
    [53438] = {
        name = "RICERCATI: Bracconieri di Viverne",
    },
    [53440] = {
        name = "RICERCATA: La Vespa",
    },
    [53449] = {
        name = "Primati dell'ira",
    },
    [53450] = {
        name = "Re Da'ka",
    },
    [53451] = {
        name = "RICERCATO: Guardiaterra Infuriato",
    },
    [53452] = {
        name = "La guerra dei gorilla",
    },
    [53453] = {
        name = "Schiacciare o non schiacciare",
    },
    [53454] = {
        name = "RICERCATO: Quartiermastro Ssylis",
    },
    [53455] = {
        name = "RICERCATI: Tagliagole Cremisi",
    },
    [53456] = {
        name = "RICERCATA: Cacciabrina",
    },
    [53458] = {
        name = "RICERCATO: Troncomarcio",
    },
    [53459] = {
        name = "RICERCATA: Sorella Lilias",
    },
    [53461] = {
        name = "Metalli preziosi",
    },
    [53462] = {
        name = "Fine dei giochi",
    },
    [53463] = {
        name = "Una maledizione a otto zampe",
    },
    [53464] = {
        name = "Il villaggio di Acqualunga",
    },
    [53465] = {
        name = "Ora del tè",
    },
    [53466] = {
        name = "Visione del Tempo",
    },
    [53467] = {
        name = "Caverne del Tempo",
    },
    [53566] = {
        name = "Nani Ferroscuro",
    },
    [53583] = {
        name = "Adattare le nostre tattiche",
    },
    [53602] = {
        name = "Adattare le nostre tattiche",
    },
    [53719] = {
        name = "L'alleanza degli Zandalari",
    },
    [53720] = {
        name = "Alleanza di Kul Tiras",
    },
    [53725] = {
        name = "Un popolo distrutto",
    },
    [53734] = {
        name = "Camminare tra i fantasmi",
    },
    [53735] = {
        name = "I primi a cadere",
    },
    [53736] = {
        name = "Lamento degli Alti Nobili",
    },
    [53737] = {
        name = "Il giorno in cui la speranza morì",
    },
    [53738] = {
        name = "In difesa di Quel'Danas",
    },
    [53760] = {
        name = "Conseguenze inattese",
    },
    [53761] = {
        name = "Il tesoro dei pirati",
    },
    [53762] = {
        name = "La corona della tempesta",
    },
    [53763] = {
        name = "Girare la lama",
    },
    [53765] = {
        name = "Il suo occhio su di te",
    },
    [53766] = {
        name = "Il suo occhio su di te",
    },
    [53774] = {
        name = "La saggezza del Capoguerra",
    },
    [53775] = {
        name = "Ombre ostacolanti",
    },
    [53776] = {
        name = "Verso la Riva Dispersa",
    },
    [53777] = {
        name = "Dove morì",
    },
    [53778] = {
        name = "Dove cadde",
    },
    [53779] = {
        name = "Le menzogne dei Loa",
    },
    [53780] = {
        name = "Il carceriere dei dannati",
    },
    [53782] = {
        name = "Misteri della morte",
    },
    [53783] = {
        name = "Tra le dune",
    },
    [53791] = {
        name = "L'orgoglio dei Sin'dorei",
    },
    [53802] = {
        name = "Persuadere i Sethrak",
    },
    [53805] = {
        name = "Amici di cucito",
    },
    [53806] = {
        name = "Testa pesante",
    },
    [53807] = {
        name = "Ricucire il tempo",
    },
    [53810] = {
        name = "Il filo spezzato",
    },
    [53813] = {
        name = "Tirarsi su le maniche",
    },
    [53815] = {
        name = "Cos'è successo a Saffy Flivvers?",
    },
    [53816] = {
        name = "Ricostruzioni urgenti",
    },
    [53817] = {
        name = "Lo strano caso di Grizzek Frizzachiavi",
    },
    [53818] = {
        name = "Programma di richiamo",
    },
    [53819] = {
        name = "Ritorno al nido",
    },
    [53820] = {
        name = "In un posto migliore",
    },
    [53821] = {
        name = "È morto, Jastor",
    },
    [53823] = {
        name = "La cerchia della Regina",
    },
    [53824] = {
        name = "Il rito di re e regine",
    },
    [53825] = {
        name = "Il nuovo Concilio degli Zanchuli",
    },
    [53826] = {
        name = "L'istigatrice è tra noi",
    },
    [53827] = {
        name = "Il concilio ha parlato",
    },
    [53828] = {
        name = "Lo sguardo dei Loa",
    },
    [53830] = {
        name = "La Regina degli Zandalari",
    },
    [53831] = {
        name = "Un'occasione reale",
    },
    [53833] = {
        name = "Nessuno S.P.R. & Co.",
    },
    [53835] = {
        name = "Qualcosa di valore, magari?",
    },
    [53836] = {
        name = "Antica armatura, antico mistero",
    },
    [53837] = {
        name = "Guardarsi le spalle",
    },
    [53838] = {
        name = "Tenere i piedi per terra",
    },
    [53840] = {
        name = "Ti va una pinta?",
    },
    [53841] = {
        name = "Frammenti del passato",
    },
    [53842] = {
        name = "La benedizione dei Terrigeni",
    },
    [53844] = {
        name = "Reclutare il Maestro della Forgia",
    },
    [53845] = {
        name = "Forgiare l'armatura",
    },
    [53846] = {
        name = "L'eredità dei Barbabronzea",
    },
    [53847] = {
        name = "Il soffio della brezza",
    },
    [53848] = {
        name = "Attrezzarsi d'attrezzi",
    },
    [53849] = {
        name = "Speranza calante",
    },
    [53851] = {
        name = "La nostra guerra continua",
    },
    [53852] = {
        name = "Divieto d'Azerite",
    },
    [53853] = {
        name = "Il sole calante",
    },
    [53856] = {
        name = "La furia dell'Orda",
    },
    [53858] = {
        name = "Tessere i suoi panni",
    },
    [53866] = {
        name = "La Delitha perfetta",
    },
    [53868] = {
        name = "In soccorso del tempo",
    },
    [53869] = {
        name = "È tempo di morire",
    },
    [53870] = {
        name = "Ospiti al Mastio Grommash",
    },
    [53879] = {
        name = "Ripulire la tenuta",
    },
    [53880] = {
        name = "Macchine da Guerra d'Azerite",
    },
    [53881] = {
        name = "Tagliare dallo stesso tessuto",
    },
    [53882] = {
        name = "Scrivere sul muro",
    },
    [53887] = {
        name = "La guerra prosegue",
    },
    [53888] = {
        name = "A Pescagrossa",
    },
    [53889] = {
        name = "Una dichiarazione d'intenti",
    },
    [53890] = {
        name = "Nuovi alleati, nuovi problemi",
    },
    [53891] = {
        name = "Nessun problema è trascurabile",
    },
    [53892] = {
        name = "Assenze sul lavoro",
    },
    [53893] = {
        name = "Buona volontà alla griglia",
    },
    [53894] = {
        name = "Riparazioni di valore",
    },
    [53895] = {
        name = "Peoni di alto livello",
    },
    [53896] = {
        name = "Tenere la posizione",
    },
    [53897] = {
        name = "Una festa ai... per i Peoni",
    },
    [53898] = {
        name = "Forza e onore",
    },
    [53899] = {
        name = "Intanto, in periferia...",
    },
    [53900] = {
        name = "Le loro armi contro di loro",
    },
    [53901] = {
        name = "Le esplosioni funzionano sempre",
    },
    [53902] = {
        name = "La truce Invocatrice delle Maree",
    },
    [53903] = {
        name = "Incontro con Meerah",
    },
    [53904] = {
        name = "Gli assistenti del Vinaio",
    },
    [53905] = {
        name = "A ognuno il suo",
    },
    [53906] = {
        name = "Un'Orda in fermento",
    },
    [53907] = {
        name = "Un assaggio di prova",
    },
    [53908] = {
        name = "L'attesa dell'arrivo",
    },
    [53909] = {
        name = "Alleati sotto assedio",
    },
    [53910] = {
        name = "Respingere l'Orda",
    },
    [53912] = {
        name = "La caccia non termina mai",
    },
    [53913] = {
        name = "Con onore",
    },
    [53916] = {
        name = "Armi per i Chigliatori",
    },
    [53919] = {
        name = "Preso in pieno!",
    },
    [53936] = {
        name = "Fermare i genieri",
    },
    [53937] = {
        name = "La Chiave ad Arco Ultr4",
    },
    [53938] = {
        name = "Amici di cucito",
    },
    [53940] = {
        name = "Ricucire il tempo",
    },
    [53941] = {
        name = "Un robot per un Goblin",
    },
    [53942] = {
        name = "Fatti mandare con il M.IM.MO.G.",
    },
    [53947] = {
        name = "Tra le dune",
    },
    [53948] = {
        name = "Nessuno S.P.R. & Co.",
    },
    [53949] = {
        name = "La Chiave ad Arco Ultr4",
    },
    [53962] = {
        name = "Tagliare dallo stesso tessuto",
    },
    [53973] = {
        name = "Affrontarli apertamente",
    },
    [53978] = {
        name = "Le congiure delle polveri",
    },
    [53981] = {
        name = "Altro giorno, altra vittoria",
    },
    [53986] = {
        name = "La quiete che precede",
    },
    [53988] = {
        name = "Coste del destino",
    },
    [53989] = {
        name = "Speranza",
    },
    [53990] = {
        name = "Nella notte più oscura",
    },
    [53993] = {
        name = "Una voce nel vento",
    },
    [53995] = {
        name = "Il conciatore Tauren",
    },
    [53996] = {
        name = "Raccogliere la legna",
    },
    [53997] = {
        name = "Il sesto senso",
    },
    [53998] = {
        name = "Esumazione",
    },
    [53999] = {
        name = "Tela per il corpo",
    },
    [54000] = {
        name = "Procedere col piano",
    },
    [54001] = {
        name = "Entrare nel santuario",
    },
    [54002] = {
        name = "Assemblare il corpo",
    },
    [54004] = {
        name = "Esperimento 1: M.IM.MO.G. contro Meccatork",
    },
    [54005] = {
        name = "Il sapere dei Drust",
    },
    [54007] = {
        name = "Polizza d'assicurazione",
    },
    [54008] = {
        name = "Rinnovare l'assicurazione",
    },
    [54009] = {
        name = "Uccisioni collaterali",
    },
    [54012] = {
        name = "Anime salve",
    },
    [54015] = {
        name = "Nel profondo",
    },
    [54018] = {
        name = "Discesa",
    },
    [54021] = {
        name = "La Prima Arcanista",
    },
    [54022] = {
        name = "I Piani di Battaglia di Meccatork",
    },
    [54026] = {
        name = "Finito",
    },
    [54027] = {
        name = "Minaccia neutralizzata",
    },
    [54028] = {
        name = "Costrutti contro navi",
    },
    [54031] = {
        name = "Lo sguardo dei Loa: Krag'wa",
    },
    [54032] = {
        name = "Lo sguardo dei Loa: Pa'ku",
    },
    [54033] = {
        name = "Lo sguardo dei Loa: Gonk",
    },
    [54034] = {
        name = "Lo sguardo dei Loa: Bwonsamdi",
    },
    [54036] = {
        name = "Un processo particolare",
    },
    [54041] = {
        name = "Che nessuno sopravviva",
    },
    [54042] = {
        name = "Problemi a Rivafosca",
    },
    [54043] = {
        name = "Reclutare i Guardaboschi Oscuri",
    },
    [54044] = {
        name = "La luna oscura sorge",
    },
    [54045] = {
        name = "Giro di vite",
    },
    [54046] = {
        name = "Non siamo ancora fuori pericolo",
    },
    [54047] = {
        name = "Dove muore la speranza",
    },
    [54049] = {
        name = "La notte dei vivi morenti",
    },
    [54050] = {
        name = "Conseguenze",
    },
    [54058] = {
        name = "Conseguenze inattese",
    },
    [54059] = {
        name = "La Guerriera della Notte",
    },
    [54083] = {
        name = "Oliare gli ingranaggi",
    },
    [54086] = {
        name = "Il robot giusto per il lavoro",
    },
    [54087] = {
        name = "Limiti di altezza",
    },
    [54088] = {
        name = "La leggenda di Meccagon",
    },
    [54094] = {
        name = "Il successo per i Goblin",
    },
    [54096] = {
        name = "La caduta del Pozzo Solare",
    },
    [54097] = {
        name = "La Dama Oscura chiama",
    },
    [54099] = {
        name = "Il Gran Supremo",
    },
    [54100] = {
        name = "Una via di fuga",
    },
    [54101] = {
        name = "Sulle tracce",
    },
    [54102] = {
        name = "Fuga verso est",
    },
    [54103] = {
        name = "Direzioni impreviste",
    },
    [54104] = {
        name = "Tracce di Faucisaure",
    },
    [54105] = {
        name = "Sempre verso est",
    },
    [54106] = {
        name = "Una soffiata inattesa",
    },
    [54107] = {
        name = "Risvolti cupi",
    },
    [54108] = {
        name = "Una morte da guerriero",
    },
    [54109] = {
        name = "Il favore della regina",
    },
    [54113] = {
        name = "Ogni piccola morte può aiutarci",
    },
    [54114] = {
        name = "Ogni piccola morte può aiutarci",
    },
    [54117] = {
        name = "Ogni piccola morte può aiutarci",
    },
    [54118] = {
        name = "Ogni piccola morte può aiutarci",
    },
    [54120] = {
        name = "Verso Orgrimmar",
    },
    [54121] = {
        name = "L'evasione di Bracescura",
    },
    [54123] = {
        name = "Deve stare nel mio robot!",
    },
    [54124] = {
        name = "Infortuni sul lavoro",
    },
    [54126] = {
        name = "Girare la lama",
    },
    [54128] = {
        name = "Precauzioni necessarie",
    },
    [54139] = {
        name = "Guerra in casa",
    },
    [54140] = {
        name = "La cavalcata degli Zandalari",
    },
    [54141] = {
        name = "Il Medaglione di Azshara",
    },
    [54144] = {
        name = "Ordini da Azshara",
    },
    [54145] = {
        name = "Il Loa della Morte",
    },
    [54147] = {
        name = "Affrontare le Val'kyr",
    },
    [54156] = {
        name = "Un sentiero di sangue",
    },
    [54157] = {
        name = "Salvate il soldato Rokhan",
    },
    [54161] = {
        name = "Il sapere dei Drust",
    },
    [54163] = {
        name = "Al diradarsi della nebbia",
    },
    [54164] = {
        name = "La morte del Re",
    },
    [54165] = {
        name = "Il ritorno di Derek Marefiero",
    },
    [54169] = {
        name = "Assalto alla Tesoreria",
    },
    [54171] = {
        name = "Lo Scettro Abissale",
    },
    [54174] = {
        name = "Ordini da Azshara",
    },
    [54175] = {
        name = "Affronta il tuo nemico",
    },
    [54176] = {
        name = "Sii più uniforme",
    },
    [54177] = {
        name = "Una distrazione brillante",
    },
    [54178] = {
        name = "Serve un passaggio?",
    },
    [54179] = {
        name = "Dalla porta principale",
    },
    [54183] = {
        name = "Calcolo delle perdite",
    },
    [54191] = {
        name = "Cambio di rotta",
    },
    [54192] = {
        name = "Informazioni sensibili",
    },
    [54193] = {
        name = "Tanta roba!",
    },
    [54194] = {
        name = "Potere definitivo",
    },
    [54195] = {
        name = "Una bestia con del cervello",
    },
    [54196] = {
        name = "Senza alcuna opzione",
    },
    [54197] = {
        name = "Vita Da'kani",
    },
    [54198] = {
        name = "Saluti Agrodolci",
    },
    [54199] = {
        name = "Il bisogno di tanti",
    },
    [54200] = {
        name = "Statistiche di base",
    },
    [54201] = {
        name = "Un Ingrossatore più grosso",
    },
    [54202] = {
        name = "Calibrare il nucleo",
    },
    [54203] = {
        name = "L'ingrossamento",
    },
    [54204] = {
        name = "Distruzione totale del tempio",
    },
    [54205] = {
        name = "Un bel pisolino",
    },
    [54206] = {
        name = "Agente dormiente",
    },
    [54207] = {
        name = "Riconquistare l'avamposto",
    },
    [54208] = {
        name = "Campo minato",
    },
    [54211] = {
        name = "Salvare la Squadra Gob",
    },
    [54212] = {
        name = "Ricostruire il M.IM.MO.VO.",
    },
    [54213] = {
        name = "È vivo!",
    },
    [54224] = {
        name = "La Battaglia delle Rovine di Zul'jan",
    },
    [54244] = {
        name = "Alle corde",
    },
    [54249] = {
        name = "Giustizia Zandalari",
    },
    [54265] = {
        name = "Ordini da Azshara",
    },
    [54269] = {
        name = "Nessuno fuggirà",
    },
    [54270] = {
        name = "Distruggere le immagini speculari",
    },
    [54271] = {
        name = "L'epurazione di Telaamon",
    },
    [54275] = {
        name = "Diradare la nebbia",
    },
    [54280] = {
        name = "Affrontarli apertamente",
    },
    [54282] = {
        name = "Battaglia di Dazar'alor",
    },
    [54300] = {
        name = "Spezzare la fede",
    },
    [54301] = {
        name = "La pietà di Talanji",
    },
    [54302] = {
        name = "La caduta di Zuldazar",
    },
    [54303] = {
        name = "In marcia verso Nazmir",
    },
    [54310] = {
        name = "Riadattare il villaggio",
    },
    [54312] = {
        name = "Nebbia di guerra",
    },
    [54402] = {
        name = "Cambiare marcia",
    },
    [54404] = {
        name = "Macchinazioni dei Ferroscuro",
    },
    [54407] = {
        name = "Intrufolarsi nella palude",
    },
    [54412] = {
        name = "Diluvio a Zul'jan",
    },
    [54416] = {
        name = "Preparativi per il Fronte di Guerra",
    },
    [54417] = {
        name = "Mostrare la nostra potenza",
    },
    [54418] = {
        name = "Il robot della morte",
    },
    [54419] = {
        name = "Placare le masse",
    },
    [54421] = {
        name = "Addomesticare le loro bestie",
    },
    [54433] = {
        name = "Ordini da Azshara",
    },
    [54438] = {
        name = "Crogiolo delle Tempeste: Reliquie della Tempesta",
    },
    [54439] = {
        name = "Crogiolo delle Tempeste: Reliquie della Tempesta",
    },
    [54441] = {
        name = "Conquistare la Porta Insanguinata",
    },
    [54459] = {
        name = "Colui che cammina nella Luce",
    },
    [54485] = {
        name = "Battaglia di Dazar'alor",
    },
    [54510] = {
        name = "Sciagura scongiurata",
    },
    [54518] = {
        name = "Zero Zeppelin",
    },
    [54519] = {
        name = "Obiettivi di squadra",
    },
    [54559] = {
        name = "Liberare Piumeria",
    },
    [54576] = {
        name = "I migliori di Gnomeregan",
    },
    [54577] = {
        name = "Sale oscure e ingranaggi impolverati",
    },
    [54580] = {
        name = "Un enigma boreale",
    },
    [54581] = {
        name = "Da oggi con ancora più polli meccanici",
    },
    [54582] = {
        name = "Più furbo di un Trogg medio.",
    },
    [54639] = {
        name = "Un segnale dalle Cime Tempestose",
    },
    [54640] = {
        name = "Violenza gnomesca",
    },
    [54641] = {
        name = "Per Gnomeregan!",
    },
    [54642] = {
        name = "G.U.A.I. in vista",
    },
    [54703] = {
        name = "Posta prioritaria",
    },
    [54706] = {
        name = "Il Carpentiere di Kul Tiras",
    },
    [54708] = {
        name = "Richiamo al dovere",
    },
    [54721] = {
        name = "Troppo vecchia per questa nave",
    },
    [54723] = {
        name = "Nascondere la nave",
    },
    [54725] = {
        name = "Esseri dalle profondità",
    },
    [54726] = {
        name = "Legna per la nave",
    },
    [54727] = {
        name = "Trasporto di squadra",
    },
    [54728] = {
        name = "Legna infestata",
    },
    [54729] = {
        name = "Colli Tetri",
    },
    [54730] = {
        name = "L'influenza di Gorak Tul",
    },
    [54731] = {
        name = "Equilibrio in tutte le cose",
    },
    [54732] = {
        name = "Molla l'osso!",
    },
    [54733] = {
        name = "Recuperare il carico",
    },
    [54734] = {
        name = "La chiamata di Dorian",
    },
    [54735] = {
        name = "Una ciurma degna",
    },
    [54754] = {
        name = "Per la Regina",
    },
    [54759] = {
        name = "Sussurri degli spiriti",
    },
    [54760] = {
        name = "Gli Spiritisti",
    },
    [54761] = {
        name = "Guida spirituale",
    },
    [54762] = {
        name = "Un piccolo rifugio",
    },
    [54763] = {
        name = "Trapasso",
    },
    [54764] = {
        name = "Tempesta a Zoccolo Sanguinario",
    },
    [54765] = {
        name = "Ringraziare la guida",
    },
    [54766] = {
        name = "Rispondere alla chiamata",
    },
    [54787] = {
        name = "Ballo in maschera",
    },
    [54850] = {
        name = "Operazione: Troggageddon",
    },
    [54851] = {
        name = "La benedizione delle maree",
    },
    [54871] = {
        name = "In arrivo",
    },
    [54913] = {
        name = "Lampo di genio",
    },
    [54915] = {
        name = "Attivare la telemetria",
    },
    [54916] = {
        name = "Il credo del predatore",
    },
    [54917] = {
        name = "Pagare col sangue",
    },
    [54918] = {
        name = "La Scintilla dell'Immaginazione",
    },
    [54919] = {
        name = "Legami del Tuono",
    },
    [54920] = {
        name = "Nostalgia di casa",
    },
    [54922] = {
        name = "I suoi dadi e bulloni",
    },
    [54925] = {
        name = "Eresia!",
    },
    [54929] = {
        name = "Pronti a partire",
    },
    [54930] = {
        name = "Liberare i robot",
    },
    [54938] = {
        name = "L'aiuto di un fratello",
    },
    [54939] = {
        name = "Testardo come un Barbabronzea",
    },
    [54940] = {
        name = "Incontro con la M.A.D.R.E.",
    },
    [54945] = {
        name = "Cominciamo",
    },
    [54946] = {
        name = "Rapporto da Gila",
    },
    [54947] = {
        name = "Una piccola squadra",
    },
    [54958] = {
        name = "Navi nella notte",
    },
    [54959] = {
        name = "Sotto chiavi",
    },
    [54960] = {
        name = "Un ritrovo difficile",
    },
    [54961] = {
        name = "Ciò che è giusto è giusto",
    },
    [54964] = {
        name = "Un viaggio di sola andata per il Cuore",
    },
    [54965] = {
        name = "Robot affettati",
    },
    [54969] = {
        name = "Discesa",
    },
    [54972] = {
        name = "La strada di casa",
    },
    [54975] = {
        name = "Una breve tregua",
    },
    [54976] = {
        name = "L'ombra di Gilneas",
    },
    [54977] = {
        name = "Verso Boscovespro",
    },
    [54980] = {
        name = "La rovina dei Cuparovina",
    },
    [54981] = {
        name = "Un ululato alla luna",
    },
    [54982] = {
        name = "Lo spirito del cacciatore",
    },
    [54983] = {
        name = "Risvegliare un sognatore",
    },
    [54984] = {
        name = "Non svegliare il lupo che dorme",
    },
    [54990] = {
        name = "La nuova guardia",
    },
    [54992] = {
        name = "L'inizio di qualcosa di grande",
    },
    [54997] = {
        name = "Vittime del mare",
    },
    [54999] = {
        name = "Sotto falsa bandiera",
    },
    [55028] = {
        name = "Recuperare i frammenti",
    },
    [55031] = {
        name = "Seguire la corrente",
    },
    [55033] = {
        name = "Morte ai Bracescura",
    },
    [55034] = {
        name = "Sotto falsa bandiera",
    },
    [55039] = {
        name = "In cerca Dell'Acqua",
    },
    [55040] = {
        name = "Guardando dentro",
    },
    [55043] = {
        name = "Storie di mare",
    },
    [55044] = {
        name = "Ambasciator Non Porta Pena",
    },
    [55045] = {
        name = "Il custode di mio fratello",
    },
    [55047] = {
        name = "Mettere al sicuro il Forte di Zannaguerra",
    },
    [55048] = {
        name = "Giochi da spie",
    },
    [55049] = {
        name = "Interrompere le comunicazioni",
    },
    [55050] = {
        name = "Biglietti, prego.",
    },
    [55051] = {
        name = "Dimostrazione di potere",
    },
    [55052] = {
        name = "Mettere al sicuro il Forte di Zannaguerra",
    },
    [55053] = {
        name = "La strada di casa",
    },
    [55054] = {
        name = "Sollevazione",
    },
    [55055] = {
        name = "Costruire una trappola per pesci più grande",
    },
    [55087] = {
        name = "Tempesta Incombente",
    },
    [55088] = {
        name = "Le spie scomparse",
    },
    [55089] = {
        name = "Trovare Shaw",
    },
    [55090] = {
        name = "L'adunata dei nemici",
    },
    [55092] = {
        name = "Distruzione del potere",
    },
    [55094] = {
        name = "Stai giù e corri!",
    },
    [55095] = {
        name = "Sollevazione",
    },
    [55096] = {
        name = "Un messaggio per mio padre",
    },
    [55101] = {
        name = "Come diventare un Meccanista di Discarica",
    },
    [55103] = {
        name = "Tutto può essere fonte di idee",
    },
    [55116] = {
        name = "Recuperare un indizio",
    },
    [55117] = {
        name = "Corrispondenza non corrisposta",
    },
    [55118] = {
        name = "Questioni in sospeso",
    },
    [55119] = {
        name = "A rapporto!",
    },
    [55121] = {
        name = "Il Laboratorio di Mardivas",
    },
    [55124] = {
        name = "Ciò che è giusto è giusto",
    },
    [55136] = {
        name = "La Bestia di Vimini",
    },
    [55153] = {
        name = "Costruzione collaborativa",
    },
    [55171] = {
        name = "Spia contro spia",
    },
    [55175] = {
        name = "Dove porta la strada",
    },
    [55177] = {
        name = "Strappi nel tempo",
    },
    [55179] = {
        name = "Rappresaglia coordinata",
    },
    [55182] = {
        name = "Riassemblaggio necessario.",
    },
    [55183] = {
        name = "Cercare un punto strategico",
    },
    [55185] = {
        name = "Ascoltare con attenzione",
    },
    [55188] = {
        name = "Strappi nel tempo",
    },
    [55195] = {
        name = "Riverbero",
    },
    [55210] = {
        name = "Batterie non incluse",
    },
    [55211] = {
        name = "Ricaricare Bullonaccio",
    },
    [55214] = {
        name = "Cucitura allentata",
    },
    [55216] = {
        name = "La prova",
    },
    [55217] = {
        name = "Ripagare il debito",
    },
    [55218] = {
        name = "Il cuoio pregiato di Sheza",
    },
    [55219] = {
        name = "Passare dalla base",
    },
    [55220] = {
        name = "Caccia al pesce",
    },
    [55221] = {
        name = "Raccolta delle Ossa",
    },
    [55222] = {
        name = "Fare rumore",
    },
    [55223] = {
        name = "Strumenti di distruzione",
    },
    [55227] = {
        name = "La conciatrice millenaria",
    },
    [55228] = {
        name = "La prova",
    },
    [55229] = {
        name = "Ripagare il debito",
    },
    [55230] = {
        name = "Il cuoio pregiato di Telonis",
    },
    [55231] = {
        name = "L'altro Danzaspettri",
    },
    [55232] = {
        name = "La minaccia di Mevris",
    },
    [55233] = {
        name = "Raccolta delle Ossa",
    },
    [55234] = {
        name = "Fare rumore",
    },
    [55235] = {
        name = "Strumenti di distruzione",
    },
    [55247] = {
        name = "Fiducia ottenuta",
    },
    [55252] = {
        name = "Loa senza tempio",
    },
    [55253] = {
        name = "Una dimostrazione di fede",
    },
    [55254] = {
        name = "Un riposo infinito",
    },
    [55258] = {
        name = "Mangiare e dormire",
    },
    [55298] = {
        name = "Pescare per qualcosa di superiore",
    },
    [55339] = {
        name = "Pulizie in corso",
    },
    [55361] = {
        name = "Lo Sciamano perduto.",
    },
    [55362] = {
        name = "Furia elementale",
    },
    [55363] = {
        name = "Salva il Chiaroveggente",
    },
    [55373] = {
        name = "Fuori dalle scatole",
    },
    [55374] = {
        name = "Una perturbazione dal sottosuolo",
    },
    [55384] = {
        name = "Sistemarsi",
    },
    [55385] = {
        name = "Perlustrare i recinti",
    },
    [55390] = {
        name = "Nell'oscurità, io sogno",
    },
    [55392] = {
        name = "Entrare nel Metasogno",
    },
    [55393] = {
        name = "Annullare il Vuoto",
    },
    [55394] = {
        name = "Schegge di smeraldo",
    },
    [55395] = {
        name = "Non chiudere gli occhi",
    },
    [55396] = {
        name = "La sostanza di cui sono fatti i sogni",
    },
    [55397] = {
        name = "Prima del risveglio",
    },
    [55398] = {
        name = "La lunga veglia",
    },
    [55400] = {
        name = "Prendi questa mano",
    },
    [55407] = {
        name = "Placare le ossa",
    },
    [55425] = {
        name = "Dominare l'indomabile",
    },
    [55462] = {
        name = "Richiamo della Viandante",
    },
    [55465] = {
        name = "Andare più a fondo",
    },
    [55469] = {
        name = "Verso Zin-Azshari",
    },
    [55481] = {
        name = "Perlustrare il palazzo",
    },
    [55482] = {
        name = "Connessione stabilita",
    },
    [55485] = {
        name = "Terrori nell'abisso",
    },
    [55486] = {
        name = "Segreti della telemanzia",
    },
    [55488] = {
        name = "Parlare coi morti",
    },
    [55489] = {
        name = "Il racconto dell'ancella",
    },
    [55490] = {
        name = "Cavare gli occhi",
    },
    [55497] = {
        name = "Un volto amico",
    },
    [55500] = {
        name = "Un'amica da salvare",
    },
    [55503] = {
        name = "Il cornofurente e il sauride",
    },
    [55504] = {
        name = "Santuari di Zuldazar",
    },
    [55505] = {
        name = "In memoria di Roo'li",
    },
    [55506] = {
        name = "La fine della strada",
    },
    [55507] = {
        name = "La benedizione di Torcali",
    },
    [55519] = {
        name = "Una ferita recente",
    },
    [55520] = {
        name = "Curare Nordrassil",
    },
    [55521] = {
        name = "Alla maniera dell'Azerite",
    },
    [55529] = {
        name = "Restituzioni non accettate",
    },
    [55530] = {
        name = "Un luogo più sicuro",
    },
    [55533] = {
        name = "La M.A.D.R.E. sa sempre cos'è meglio",
    },
    [55558] = {
        name = "Nascondiglio",
    },
    [55560] = {
        name = "La vendetta di Utama",
    },
    [55561] = {
        name = "I resti di Zin-Azshari",
    },
    [55565] = {
        name = "Consolidare le riserve di Mana",
    },
    [55569] = {
        name = "Echi di dolore",
    },
    [55570] = {
        name = "Segreti nelle rovine",
    },
    [55571] = {
        name = "Svelare la verità",
    },
    [55573] = {
        name = "Eliminare i profanatori",
    },
    [55574] = {
        name = "I Giavellotti di Azshara",
    },
    [55585] = {
        name = "Un inizio promettente",
    },
    [55586] = {
        name = "Un lavoro pulito",
    },
    [55590] = {
        name = "Mettere le cose a posto",
    },
    [55592] = {
        name = "Un inizio promettente",
    },
    [55593] = {
        name = "Informazioni sui nemici",
    },
    [55594] = {
        name = "Un lavoro pulito",
    },
    [55595] = {
        name = "Conoscenze dimenticate",
    },
    [55596] = {
        name = "Mettere le cose a posto",
    },
    [55597] = {
        name = "Legati dall'onore",
    },
    [55598] = {
        name = "Cosa sappiamo sui Naga",
    },
    [55599] = {
        name = "Esplorazione in incognito",
    },
    [55600] = {
        name = "Saziare i Draghi Carnivori",
    },
    [55601] = {
        name = "Incetta di cristalli",
    },
    [55608] = {
        name = "Negozio di progetti",
    },
    [55618] = {
        name = "La Forgia del Cuore",
    },
    [55622] = {
        name = "Pronto per la consegna",
    },
    [55630] = {
        name = "Cominciamo",
    },
    [55632] = {
        name = "Limiti di altezza",
    },
    [55635] = {
        name = "Una voce nel vento",
    },
    [55645] = {
        name = "Visita principesca",
    },
    [55646] = {
        name = "La leggenda di Meccagon",
    },
    [55647] = {
        name = "Orecchio per la truffa",
    },
    [55648] = {
        name = "Questa è la nostra cripta",
    },
    [55649] = {
        name = "Macchinazioni per Meccagon",
    },
    [55650] = {
        name = "Solo con i migliori",
    },
    [55651] = {
        name = "Verso Meccagon!",
    },
    [55652] = {
        name = "Baia del Prospetto",
    },
    [55657] = {
        name = "All'ombra delle ali cremisi",
    },
    [55685] = {
        name = "Veniamo in pace... e con intenti lucrosi",
    },
    [55694] = {
        name = "Qualcosa nell'acqua",
    },
    [55696] = {
        name = "Giro di prova",
    },
    [55697] = {
        name = "Lavoro di gambe",
    },
    [55707] = {
        name = "La prima è in omaggio",
    },
    [55708] = {
        name = "Potenziamento",
    },
    [55729] = {
        name = "La Resistenza ha bisogno di te!",
    },
    [55730] = {
        name = "Salvare la Resistenza",
    },
    [55731] = {
        name = "Le armate di mio padre",
    },
    [55732] = {
        name = "Una vecchia cicatrice",
    },
    [55734] = {
        name = "Costruire la trivella",
    },
    [55735] = {
        name = "Difendere il Maelstrom",
    },
    [55736] = {
        name = "Benvenuti nella Resistenza",
    },
    [55737] = {
        name = "Al tempo dell'Azerite",
    },
    [55752] = {
        name = "Combattiamo uniti",
    },
    [55753] = {
        name = "Abbattere il suo robot",
    },
    [55778] = {
        name = "Visioni di pericolo",
    },
    [55779] = {
        name = "Sospensione della condanna",
    },
    [55780] = {
        name = "Vecchi alleati",
    },
    [55781] = {
        name = "Vecchi alleati",
    },
    [55782] = {
        name = "Rinvio dell'esecuzione",
    },
    [55783] = {
        name = "Rinvio dell'esecuzione",
    },
    [55784] = {
        name = "Ripagare il favore",
    },
    [55795] = {
        name = "Montagne in movimento",
    },
    [55796] = {
        name = "Eresia al crocevia",
    },
    [55797] = {
        name = "Furia della madre dei cornofurente",
    },
    [55798] = {
        name = "Mai vagare da soli",
    },
    [55799] = {
        name = "Cambio di marea",
    },
    [55860] = {
        name = "Lumache di mare ovunque",
    },
    [55861] = {
        name = "Seguire i residui",
    },
    [55862] = {
        name = "Informazioni sui nemici",
    },
    [55863] = {
        name = "Conoscenze dimenticate",
    },
    [55864] = {
        name = "Il prezzo è la morte",
    },
    [55865] = {
        name = "Cosa sappiamo sui Naga",
    },
    [55866] = {
        name = "Esplorazione in incognito",
    },
    [55867] = {
        name = "Incetta di cristalli",
    },
    [55868] = {
        name = "Seguire i residui",
    },
    [55869] = {
        name = "Ripulire i fondali",
    },
    [55870] = {
        name = "Lumache di mare ovunque",
    },
    [55937] = {
        name = "Ripulire i fondali",
    },
    [55967] = {
        name = "Saziare i Draghi Carnivori",
    },
    [55983] = {
        name = "Un luogo più sicuro",
    },
    [55995] = {
        name = "Riparazione straordinaria",
    },
    [56030] = {
        name = "L'ordine della Capoguerra",
    },
    [56031] = {
        name = "L'offensiva del lupo",
    },
    [56037] = {
        name = "Rubare i segreti dei Naga",
    },
    [56038] = {
        name = "Lavorare per uno scopo",
    },
    [56039] = {
        name = "Evoluzione bellica",
    },
    [56043] = {
        name = "Inviare la flotta",
    },
    [56044] = {
        name = "Inviare la flotta",
    },
    [56045] = {
        name = "Rubare i segreti dei Naga",
    },
    [56046] = {
        name = "Lavorare per uno scopo",
    },
    [56047] = {
        name = "Evoluzione bellica",
    },
    [56063] = {
        name = "Maree oscure",
    },
    [56095] = {
        name = "Retaggio di Nar'anan",
    },
    [56118] = {
        name = "Cambio di dieta",
    },
    [56143] = {
        name = "Il destino della Professoressa Elryna",
    },
    [56156] = {
        name = "Una lama temprata",
    },
    [56167] = {
        name = "Investigando le Alture",
    },
    [56168] = {
        name = "Fabbrica ristrutturata",
    },
    [56175] = {
        name = "Privo di emissioni",
    },
    [56181] = {
        name = "Questa la offro io",
    },
    [56209] = {
        name = "Le Sale della Creazione",
    },
    [56210] = {
        name = "Pietre Rivelatrici",
    },
    [56211] = {
        name = "Pietre Rivelatrici",
    },
    [56234] = {
        name = "Amici bisognosi di aiuto",
    },
    [56235] = {
        name = "Nel cuore di Nazjatar",
    },
    [56236] = {
        name = "Non è ancora finita",
    },
    [56239] = {
        name = "Strano Coltello d'Argento",
    },
    [56240] = {
        name = "Strano Coltello d'Argento",
    },
    [56241] = {
        name = "Indizi conservati",
    },
    [56242] = {
        name = "Indizi conservati",
    },
    [56243] = {
        name = "Diari dei morti",
    },
    [56244] = {
        name = "Diari dei morti",
    },
    [56245] = {
        name = "Lucchetto Incantato",
    },
    [56246] = {
        name = "Lucchetto Incantato",
    },
    [56247] = {
        name = "Storia di un tesoro",
    },
    [56248] = {
        name = "Storia di un tesoro",
    },
    [56304] = {
        name = "Miseria e nobiltà",
    },
    [56305] = {
        name = "Peschiamo!",
    },
    [56309] = {
        name = "La città degli amici annegati",
    },
    [56310] = {
        name = "La città degli amici annegati",
    },
    [56311] = {
        name = "Annegamento permanente",
    },
    [56312] = {
        name = "Annegamento permanente",
    },
    [56313] = {
        name = "L'Araldo della Guerra",
    },
    [56314] = {
        name = "L'Araldo della Guerra",
    },
    [56315] = {
        name = "La loro scelta",
    },
    [56316] = {
        name = "La loro scelta",
    },
    [56319] = {
        name = "Il Contratto di Caricalesta",
    },
    [56320] = {
        name = "La prima ricarica è gratuita!",
    },
    [56321] = {
        name = "Salvare Corin",
    },
    [56325] = {
        name = "Respingere le onde",
    },
    [56346] = {
        name = "Antica tecnologia",
    },
    [56347] = {
        name = "Un'opportunità abissale",
    },
    [56348] = {
        name = "Palazzo Eterno: possiamo renderlo più forte...",
    },
    [56349] = {
        name = "Palazzo Eterno: Spingersi al limite",
    },
    [56350] = {
        name = "Perlustrare il palazzo",
    },
    [56351] = {
        name = "Palazzo Eterno: Spingersi al limite",
    },
    [56352] = {
        name = "Palazzo Eterno: possiamo renderlo più forte...",
    },
    [56353] = {
        name = "Un'opportunità abissale",
    },
    [56354] = {
        name = "Antica tecnologia",
    },
    [56356] = {
        name = "Palazzo Eterno: La scommessa della Regina",
    },
    [56358] = {
        name = "Palazzo Eterno: La scommessa della Regina",
    },
    [56374] = {
        name = "Un problema titanico",
    },
    [56375] = {
        name = "Verso Ramkahen",
    },
    [56376] = {
        name = "Minacce incombenti",
    },
    [56377] = {
        name = "Forgiature avanzate",
    },
    [56378] = {
        name = "L'equipaggio scomparso",
    },
    [56379] = {
        name = "L'equipaggio scomparso",
    },
    [56401] = {
        name = "Un lampo nel blu",
    },
    [56422] = {
        name = "Su ali spettrali",
    },
    [56429] = {
        name = "Contrarietà",
    },
    [56472] = {
        name = "La Società di Uldum",
    },
    [56494] = {
        name = "La vigilia della battaglia",
    },
    [56495] = {
        name = "Contro di noi",
    },
    [56496] = {
        name = "La vigilia della battaglia",
    },
    [56536] = {
        name = "Non è mai facile",
    },
    [56537] = {
        name = "Il sigillo misterioso",
    },
    [56538] = {
        name = "I clan dei Mogu",
    },
    [56539] = {
        name = "Alla ricerca dei Rajani",
    },
    [56540] = {
        name = "Una prova di tenacia",
    },
    [56541] = {
        name = "Il Generatore di Nalak'sha",
    },
    [56542] = {
        name = "Una speranza ritrovata",
    },
    [56560] = {
        name = "Una scoperta bizzarra",
    },
    [56561] = {
        name = "Una scoperta bizzarra",
    },
    [56574] = {
        name = "Riflessi nell'ambra",
    },
    [56575] = {
        name = "Di nuovo a Kor'vess",
    },
    [56576] = {
        name = "Disinfestazione di Aqir",
    },
    [56577] = {
        name = "Decimare lo sciame",
    },
    [56578] = {
        name = "Radici marce e corrotte",
    },
    [56580] = {
        name = "I segreti dell'ambra",
    },
    [56616] = {
        name = "Vecchie facce, nuovi problemi",
    },
    [56617] = {
        name = "Uno sciame unito",
    },
    [56640] = {
        name = "Anime salve",
    },
    [56641] = {
        name = "Distruzione del potere",
    },
    [56642] = {
        name = "Maree oscure",
    },
    [56643] = {
        name = "Nel profondo",
    },
    [56644] = {
        name = "Contrarietà",
    },
    [56645] = {
        name = "Il cuore dello sciame",
    },
    [56647] = {
        name = "La minaccia dei Mantid",
    },
    [56719] = {
        name = "Via libera",
    },
    [56739] = {
        name = "Il potere della devozione",
    },
    [56741] = {
        name = "La Lancia del Destino",
    },
    [56771] = {
        name = "Guerrieri perduti nel tempo",
    },
    [56833] = {
        name = "Capi dell'Orda",
    },
    [56979] = {
        name = "Assicurare l'assedio",
    },
    [56980] = {
        name = "Tra di noi",
    },
    [56981] = {
        name = "Dispiegamento strategico",
    },
    [56982] = {
        name = "Davanti ai cancelli di Orgrimmar",
    },
    [56993] = {
        name = "Il prezzo della vittoria",
    },
    [57002] = {
        name = "Vecchio soldato",
    },
    [57005] = {
        name = "Nuove amicizie",
    },
    [57006] = {
        name = "Un degno alleato",
    },
    [57010] = {
        name = "Ottenere il potere",
    },
    [57043] = {
        name = "Vecchi amici, nuove opportunità",
    },
    [57045] = {
        name = "Una consegna speciale",
    },
    [57047] = {
        name = "Un semplice esperimento",
    },
    [57048] = {
        name = "Acquisti tecnologici",
    },
    [57051] = {
        name = "Recupero crediti!",
    },
    [57052] = {
        name = "Ho quello che ti serve",
    },
    [57053] = {
        name = "Test della forza contundente",
    },
    [57058] = {
        name = "Divertirsi con le mine",
    },
    [57059] = {
        name = "Diamoci dentro!",
    },
    [57067] = {
        name = "Mogu alle porte",
    },
    [57068] = {
        name = "Ricognizione in aquilone",
    },
    [57069] = {
        name = "Meglio iniziare dai capi",
    },
    [57070] = {
        name = "Mogussacro",
    },
    [57071] = {
        name = "Nessun barile resterà indietro",
    },
    [57072] = {
        name = "Uno yak per ogni occasione",
    },
    [57074] = {
        name = "Spalle alla porta",
    },
    [57075] = {
        name = "Coraggio liquido",
    },
    [57076] = {
        name = "Ritorno a Calanebbia",
    },
    [57077] = {
        name = "Cercasi acquirenti!",
    },
    [57078] = {
        name = "La lista dei VIP",
    },
    [57079] = {
        name = "Pattumiatelo via!",
    },
    [57080] = {
        name = "Una ricompensa adatta",
    },
    [57088] = {
        name = "Via libera",
    },
    [57090] = {
        name = "Assicurare l'assedio",
    },
    [57091] = {
        name = "Tra di noi",
    },
    [57092] = {
        name = "Dispiegamento strategico",
    },
    [57093] = {
        name = "Davanti ai cancelli di Orgrimmar",
    },
    [57094] = {
        name = "Il prezzo della vittoria",
    },
    [57095] = {
        name = "Vecchio soldato",
    },
    [57126] = {
        name = "Mari propizi",
    },
    [57130] = {
        name = "Traditori tra noi",
    },
    [57147] = {
        name = "Non è la mia Capoguerra",
    },
    [57148] = {
        name = "Spezzare l'assedio",
    },
    [57149] = {
        name = "Eliminazione della propaganda",
    },
    [57150] = {
        name = "Milizia",
    },
    [57151] = {
        name = "Linea di confine",
    },
    [57152] = {
        name = "La vera lealtà",
    },
    [57198] = {
        name = "Senso del dovere",
    },
    [57220] = {
        name = "Inizializzazione del protocollo d'accensione",
    },
    [57221] = {
        name = "Rioriginazione",
    },
    [57222] = {
        name = "Investigare nelle Sale",
    },
    [57290] = {
        name = "A capofitto nei Sotterranei",
    },
    [57324] = {
        name = "Col vento in poppa",
    },
    [57362] = {
        name = "Nel cuore dell'oscurità",
    },
    [57373] = {
        name = "Discesa nella Follia",
    },
    [57374] = {
        name = "Nelle profondità più oscure",
    },
    [57376] = {
        name = "Il bisogno nascosto",
    },
    [57378] = {
        name = "Resti di un Mondo Infranto",
    },
    [57448] = {
        name = "Nuovi alleati tra noi",
    },
    [57486] = {
        name = "Energia in calo",
    },
    [57487] = {
        name = "Un po' d'aiuto",
    },
    [57488] = {
        name = "Il progetto attuale",
    },
    [57490] = {
        name = "In tutta sicurezza",
    },
    [57491] = {
        name = "La soluzione migliore per tutti",
    },
    [57492] = {
        name = "Lui?",
    },
    [57493] = {
        name = "Sintonia mentale",
    },
    [57494] = {
        name = "Un cuore forte",
    },
    [57495] = {
        name = "Il futuro di Meccagon",
    },
    [57496] = {
        name = "Ascensione",
    },
    [57497] = {
        name = "Diffondere le notizie",
    },
    [57524] = {
        name = "Accedere agli Archivi",
    },
    [57873] = {
        name = "Notizie da Orsis",
    },
    [57915] = {
        name = "Alla ricerca dei sopravvissuti",
    },
    [57954] = {
        name = "Bruciare i corpi",
    },
    [57955] = {
        name = "Al Porto di Ankhaten",
    },
    [57956] = {
        name = "Gli Ospiti Nomadi",
    },
    [57969] = {
        name = "Dei feriti da curare",
    },
    [57970] = {
        name = "Il Rovinatore Xok'nixx",
    },
    [57971] = {
        name = "Le Rovine di Ammon",
    },
    [57990] = {
        name = "L'Obelisco del Sole",
    },
    [58008] = {
        name = "Sfiniti di tutto punto",
    },
    [58009] = {
        name = "Dritto verso la Luna",
    },
    [58087] = {
        name = "Abbattere le batterie",
    },
    [58214] = {
        name = "Questioni urgenti",
    },
    [58496] = {
        name = "Un consigliere indesiderato",
    },
    [58498] = {
        name = "Il ritorno del Re Guerriero",
    },
    [58502] = {
        name = "Dove si trova il Cuore",
    },
    [58506] = {
        name = "Diagnostica di rete",
    },
    [58582] = {
        name = "Il ritorno del Principe Nero",
    },
    [58583] = {
        name = "Dove si trova il Cuore",
    },
    [58606] = {
        name = "Approfondimenti pezzo per pezzo",
    },
    [58615] = {
        name = "Sussurri nell'Oscurità",
    },
    [58631] = {
        name = "Nei sogni",
    },
    [58632] = {
        name = "Ny'alotha, la Città Risvegliata: la fine del Corruttore",
    },
    [58634] = {
        name = "Aprire il varco",
    },
    [58636] = {
        name = "Oggetto di studio: gli Amathet",
    },
    [58638] = {
        name = "Uno studio più approfondito",
    },
    [58639] = {
        name = "Una storia sepolta sotto la sabbia",
    },
    [58640] = {
        name = "Lo studio continua...",
    },
    [58641] = {
        name = "I cercatori della Corruzione",
    },
    [58642] = {
        name = "Obiettivi condivisi",
    },
    [58643] = {
        name = "Distruzione reciproca garantita",
    },
    [58645] = {
        name = "Un mondo che vale la pena salvare",
    },
    [58646] = {
        name = "Mordete questo!",
    },
    [58737] = {
        name = "Le scoperte di Magni",
    },
})
]])()
