----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "ptBR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateNPCsTable({
    [3037] = {
        name = "Sheza Juba Agreste",
    },
    [5164] = {
        name = "Grumnus Mold'aço",
    },
    [14720] = {
        name = "Lorde Supremo Saurfang",
    },
    [15192] = {
        name = "Anacronos",
    },
    [36648] = {
        name = "Baine Casco Sangrento",
    },
    [108017] = {
        name = "Torv Passão",
    },
    [120168] = {
        name = "Cronista To'kini",
    },
    [120170] = {
        name = "Nathanos Arauto da Praga",
    },
    [120551] = {
        name = "Krag'wa, o Imenso",
    },
    [120740] = {
        name = "Rei Rastakhan",
    },
    [120904] = {
        name = "Princesa Talanji",
    },
    [120922] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [121144] = {
        name = "Katherine Proudmore",
    },
    [121239] = {
        name = "Filinto Belvento",
    },
    [121241] = {
        name = "Princesa Talanji",
    },
    [121288] = {
        name = "Princesa Talanji",
    },
    [121599] = {
        name = "Rei Rastakhan",
    },
    [121603] = {
        name = "Abigail Lerner",
    },
    [121706] = {
        name = "Senhora das Feras L'kala",
    },
    [122009] = {
        name = "Mestre de Kraal B'khor",
    },
    [122129] = {
        name = "Comerciante Alexxi Cruzencredo",
    },
    [122169] = {
        name = "Abigail Lerner",
    },
    [122289] = {
        name = "Guarda-lâmina Jaka",
    },
    [122320] = {
        name = "Guarda-lâmina Jaka",
    },
    [122370] = {
        name = "Ciro Desalento",
    },
    [122493] = {
        name = "Annie Baracho",
    },
    [122671] = {
        name = "Custódio",
    },
    [122672] = {
        name = "Olívia",
    },
    [122702] = {
        name = "Encantadora Quinni",
    },
    [122703] = {
        name = "Kumali, a Esperta",
    },
    [122706] = {
        name = "Teurga Salazae",
    },
    [122760] = {
        name = "Druidesa-de-guerra Loti",
    },
    [122795] = {
        name = "Mandingueiro Kejabu",
    },
    [122817] = {
        name = "Guarda-lâmina Jaka",
    },
    [122939] = {
        name = "Filhote de Escornante",
    },
    [122991] = {
        name = "Caçadora Sombria Mutumba",
    },
    [123000] = {
        name = "Capitão Rez'okum",
    },
    [123005] = {
        name = "Rosarães Guima",
    },
    [123019] = {
        name = "Mestre da Caça Vol'ka",
    },
    [123022] = {
        name = "Rastreador Burke",
    },
    [123026] = {
        name = "Erak, o Indiferente",
    },
    [123063] = {
        name = "Koppaka Ancião",
    },
    [123118] = {
        name = "Coureador Zeca",
    },
    [123178] = {
        name = "Mathiaz",
    },
    [123335] = {
        name = "Druidesa-de-guerra Loti",
    },
    [123415] = {
        name = "Henrique Hardwick",
    },
    [123526] = {
        name = "Tique",
    },
    [123544] = {
        name = "Mathiaz",
    },
    [123545] = {
        name = "Samalandra",
    },
    [123548] = {
        name = "Tique",
    },
    [123878] = {
        name = "Mathiaz",
    },
    [124062] = {
        name = "Rei Rastakhan",
    },
    [124063] = {
        name = "Jol, o Ancião",
    },
    [124289] = {
        name = "Liza Seminário, a Arriscada",
    },
    [124376] = {
        name = "Mandingueiro Zentimo",
    },
    [124417] = {
        name = "Altino Branco",
    },
    [124468] = {
        name = "Ramiro Rubrens",
    },
    [124629] = {
        name = "Kaza'jin, o Teceondas",
    },
    [124641] = {
        name = "Caçadora Sombria Mutumba",
    },
    [124655] = {
        name = "Rei Rastakhan",
    },
    [124786] = {
        name = "Tomás Vina",
    },
    [124802] = {
        name = "Lorde Aldrius Lancastre",
    },
    [124915] = {
        name = "Rei Rastakhan",
    },
    [124922] = {
        name = "Helena Gentil",
    },
    [125039] = {
        name = "Comerciante Kro",
    },
    [125041] = {
        name = "Sábio dos Pergaminhos Goji",
    },
    [125093] = {
        name = "Morador de Refúgio Outonal",
    },
    [125309] = {
        name = "Abigail Vilas",
    },
    [125312] = {
        name = "Sábia dos Pergaminhos Rooka",
    },
    [125317] = {
        name = "Caçadora Sombria Narez",
    },
    [125342] = {
        name = "Capitã Kilsan",
    },
    [125380] = {
        name = "Lucília Capelo",
    },
    [125385] = {
        name = "Marechal Everardo Ribas",
    },
    [125394] = {
        name = "Oficial Henrique Fraga",
    },
    [125398] = {
        name = "Haroldo Bergamota",
    },
    [125457] = {
        name = "Rebeca Baratuxa",
    },
    [125486] = {
        name = "Montasa Nivek",
    },
    [125922] = {
        name = "Irmão Teroldo",
    },
    [125962] = {
        name = "Gerente Geraldo",
    },
    [126039] = {
        name = "Mag'ash, o Venenoso",
    },
    [126079] = {
        name = "Mortívago Kol'jun",
    },
    [126080] = {
        name = "Mortívaga Shinga",
    },
    [126148] = {
        name = "Mandingueira Jala",
    },
    [126158] = {
        name = "Filinto Belvento",
    },
    [126210] = {
        name = "Zelador Allen",
    },
    [126213] = {
        name = "Princesa Talanji",
    },
    [126225] = {
        name = "Aarão Crespo",
    },
    [126240] = {
        name = "Brigite Fragoso",
    },
    [126289] = {
        name = "Patrício Chagas",
    },
    [126298] = {
        name = "Brício Trovamare",
    },
    [126308] = {
        name = "Quincas Albe",
    },
    [126310] = {
        name = "Evelyn Pires",
    },
    [126346] = {
        name = "Patrício Chagas",
    },
    [126377] = {
        name = "Ingrid Beliza",
    },
    [126511] = {
        name = "Esfolador Macário",
    },
    [126560] = {
        name = "Druidesa-de-guerra Loti",
    },
    [126564] = {
        name = "Senhor da Bagata Raal",
    },
    [126620] = {
        name = "Filinto Belvento",
    },
    [126804] = {
        name = "Saurolisco Preso",
    },
    [127006] = {
        name = "Melissa Queiroga",
    },
    [127015] = {
        name = "Tadeu Contefenda, o Vovô",
    },
    [127080] = {
        name = "Lorde Vale Outonal",
    },
    [127112] = {
        name = "Mestre Forjador Zak'aal",
    },
    [127144] = {
        name = "Melissa Queiroga",
    },
    [127157] = {
        name = "Marcus Convales",
    },
    [127161] = {
        name = "Alanna Rolim",
    },
    [127215] = {
        name = "Caçador Sombrio Da'jul",
    },
    [127216] = {
        name = "Zardrax, o Fortalecente",
    },
    [127296] = {
        name = "Davi Maldus",
    },
    [127377] = {
        name = "Pa'kul",
    },
    [127391] = {
        name = "Sanguinário Jo'chunga",
    },
    [127396] = {
        name = "Iniciada Peônia",
    },
    [127418] = {
        name = "Edu Maldus",
    },
    [127481] = {
        name = "Lorde Kennings",
    },
    [127489] = {
        name = "Senhor da Bagata Raal",
    },
    [127537] = {
        name = "Geraldina",
    },
    [127558] = {
        name = "Artur Horta",
    },
    [127559] = {
        name = "Lorde Aldrius Lancastre",
    },
    [127570] = {
        name = "Guarda-lâmina Jaka",
    },
    [127646] = {
        name = "Lorde Kennings",
    },
    [127715] = {
        name = "Lucília Capelo",
    },
    [127743] = {
        name = "Tia Amanda Baratuxa",
    },
    [127803] = {
        name = "Caleb Batarem",
    },
    [127837] = {
        name = "Kaza'jin, o Teceondas",
    },
    [127961] = {
        name = "Princesa Talanji",
    },
    [127980] = {
        name = "Akunda, o Sensível",
    },
    [127992] = {
        name = "Akunda, o Exaltado",
    },
    [128228] = {
        name = "Sam Faminto",
    },
    [128229] = {
        name = "Jane Punhalada",
    },
    [128261] = {
        name = "Imediato Jamboya",
    },
    [128349] = {
        name = "Hilda Quebrafogo",
    },
    [128353] = {
        name = "Tandi Carburada",
    },
    [128377] = {
        name = "Rato de Praia Bob",
    },
    [128381] = {
        name = "Drogrin Tragabirita",
    },
    [128457] = {
        name = "Mafalda Contefenda",
    },
    [128467] = {
        name = "Elias Eugênio",
    },
    [128494] = {
        name = "Adela Hortêncio",
    },
    [128618] = {
        name = "Mestre de Doca Heritão",
    },
    [128679] = {
        name = "Rosaline Madeira",
    },
    [128680] = {
        name = "Okri Carrapeta",
    },
    [129164] = {
        name = "Cronista Jabari",
    },
    [129165] = {
        name = "Guarda Satao",
    },
    [129170] = {
        name = "Rufino",
    },
    [129291] = {
        name = "Chefe Tak",
    },
    [129392] = {
        name = "Henrique, o Indefeso",
    },
    [129491] = {
        name = "Rei Rastakhan",
    },
    [129561] = {
        name = "Druidesa-de-guerra Loti",
    },
    [129578] = {
        name = "Sálvio Martini",
    },
    [129613] = {
        name = "Magno Algerson",
    },
    [129642] = {
        name = "Lucília Capelo",
    },
    [129643] = {
        name = "Marechal Everardo Ribas",
    },
    [129670] = {
        name = "Lissa Guardárvore",
    },
    [129703] = {
        name = "Senhor da Bagata Raal",
    },
    [129757] = {
        name = "Rei Rastakhan",
    },
    [129808] = {
        name = "Fazendeiro Campodouro",
    },
    [129858] = {
        name = "Gisberto Chispabroca",
    },
    [129907] = {
        name = "Zul, o Profeta",
    },
    [129956] = {
        name = "Mestre de Doca Dindo",
    },
    [129983] = {
        name = "Inquisidora Claralvor",
    },
    [130101] = {
        name = "Recruta Brutus",
    },
    [130190] = {
        name = "Sargento Calvino",
    },
    [130216] = {
        name = "Magni Barbabronze",
    },
    [130341] = {
        name = "Guarda-lâmina Jaka",
    },
    [130368] = {
        name = "Sterno Vivaro III",
    },
    [130375] = {
        name = "Tales Celescárdio",
    },
    [130377] = {
        name = "Mensageiro Geraldo",
    },
    [130399] = {
        name = "Zoé Parafusoca",
    },
    [130424] = {
        name = "Henrique, o Indefeso",
    },
    [130450] = {
        name = "Guarda-lâmina Sonji",
    },
    [130468] = {
        name = "Tikinha",
    },
    [130478] = {
        name = "Gridão",
    },
    [130481] = {
        name = "Mortívaga Shinga",
    },
    [130576] = {
        name = "Irmão Pique",
    },
    [130603] = {
        name = "Quebra-fera Hakid",
    },
    [130660] = {
        name = "Guarda Bélica Rakera",
    },
    [130667] = {
        name = "Guarda Bélica Rakera",
    },
    [130694] = {
        name = "Prefeita Roz",
    },
    [130697] = {
        name = "Marechal da Brigada de Incêndio Gil",
    },
    [130706] = {
        name = "Espírito de Izita",
    },
    [130714] = {
        name = "Irmão Pique",
    },
    [130750] = {
        name = "Capitão Grezz'ko",
    },
    [130785] = {
        name = "Mestre da Caça Kil'ja",
    },
    [130786] = {
        name = "Hobert",
    },
    [130821] = {
        name = "Mestre das Ondas Lanfa",
    },
    [130833] = {
        name = "Capitão Grezz'ko",
    },
    [130844] = {
        name = "Princesa Talanji",
    },
    [130901] = {
        name = "Cronista Grazzul",
    },
    [130904] = {
        name = "Samuel Guilhem",
    },
    [130905] = {
        name = "Cala Cruzencredo",
    },
    [130929] = {
        name = "Mandingueira Jangalar",
    },
    [131000] = {
        name = "Comandante Kellam",
    },
    [131001] = {
        name = "Tenente Espargosa",
    },
    [131002] = {
        name = "Tenente Hauer",
    },
    [131003] = {
        name = "Especialista Wenderson",
    },
    [131004] = {
        name = "Escudeiro Augusto Neto",
    },
    [131048] = {
        name = "Tenente Torquato",
    },
    [131248] = {
        name = "Samuel Guilhem",
    },
    [131253] = {
        name = "Guardião Titânico Hezrel",
    },
    [131290] = {
        name = "Filinto Belvento",
    },
    [131354] = {
        name = "Mãe das Feras Jabati",
    },
    [131442] = {
        name = "Leandro Reimão",
    },
    [131443] = {
        name = "Chefe Telemante Oculeth",
    },
    [131448] = {
        name = "Ubaldo Azinhal",
    },
    [131469] = {
        name = "Martino Uchoa",
    },
    [131579] = {
        name = "Aldeão Cativo",
    },
    [131580] = {
        name = "Aprendiz Telemante Astrandis",
    },
    [131582] = {
        name = "Avaliadora Tae'shara Vigiassangre",
    },
    [131627] = {
        name = "Tomás Rosáceo",
    },
    [131636] = {
        name = "Marechal Everardo Ribas",
    },
    [131638] = {
        name = "Lucília Capelo",
    },
    [131639] = {
        name = "Inquisidora Maça",
    },
    [131640] = {
        name = "Inquisidor Novaes",
    },
    [131641] = {
        name = "Inquisidor Iorrico",
    },
    [131642] = {
        name = "Inquisidor Maré-severa",
    },
    [131654] = {
        name = "Meredite",
    },
    [131656] = {
        name = "Mestre de Matilha Arquibaldo",
    },
    [131657] = {
        name = "Compêndio do Sangue Derramado",
    },
    [131684] = {
        name = "Pâmela Hardwick, a Preciosa",
    },
    [131763] = {
        name = "Escavador Morgrum Pedernal",
    },
    [131775] = {
        name = "Zé Sem-orelha",
    },
    [131777] = {
        name = "Acádia Xistorijo",
    },
    [131793] = {
        name = "Anderson Mildião",
    },
    [131840] = {
        name = "Shuga Rancatopo",
    },
    [131879] = {
        name = "Inquisidora Claralvor",
    },
    [132118] = {
        name = "Fazendeiro Burto",
    },
    [132193] = {
        name = "Angus Baláster",
    },
    [132228] = {
        name = "Elric Valgrine",
    },
    [132292] = {
        name = "Raimundo Mildião",
    },
    [132332] = {
        name = "Princesa Talanji",
    },
    [132333] = {
        name = "Princesa Talanji",
    },
    [132347] = {
        name = "Quintino Valgrine",
    },
    [132374] = {
        name = "Elza Wright",
    },
    [132617] = {
        name = "Wolks Graxorteiro",
    },
    [132647] = {
        name = "Anderson Mildião",
    },
    [132720] = {
        name = "Mestre Falcoeiro Olio",
    },
    [132966] = {
        name = "Lina Nectáreo",
    },
    [132988] = {
        name = "Mathiaz",
    },
    [132994] = {
        name = "Lorde Artur Capelo",
    },
    [133035] = {
        name = "Oficial Jovan",
    },
    [133050] = {
        name = "Princesa Talanji",
    },
    [133098] = {
        name = "Inquisidora Claralvor",
    },
    [133101] = {
        name = "Samanta Nectáreo",
    },
    [133105] = {
        name = "Ubaldo Azinhal",
    },
    [133125] = {
        name = "Princesa Talanji",
    },
    [133126] = {
        name = "Martino Uchoa",
    },
    [133324] = {
        name = "Senhor da Bagata Raal",
    },
    [133476] = {
        name = "Princesa Talanji",
    },
    [133489] = {
        name = "Ormhun Rochamalho",
    },
    [133523] = {
        name = "Ji Pata de Fogo",
    },
    [133536] = {
        name = "Grix Badaró, o Mão de Ferro",
    },
    [133550] = {
        name = "Aprendiz de Minerador Zé",
    },
    [133551] = {
        name = "Minerador-chefe Theock",
    },
    [133552] = {
        name = "Químico-chefe Walters",
    },
    [133576] = {
        name = "Timoneira Gancho",
    },
    [133577] = {
        name = "Mestre Artilheiro Lino",
    },
    [133578] = {
        name = "\"Chumbada\"",
    },
    [133640] = {
        name = "Caminha, o Ancestral",
    },
    [133653] = {
        name = "Senhor da Bagata Raal",
    },
    [133839] = {
        name = "Homero Espargosa",
    },
    [133953] = {
        name = "Sargento Calvino",
    },
    [134009] = {
        name = "Cidadã de Corlain",
    },
    [134166] = {
        name = "Filinto Belvento",
    },
    [134325] = {
        name = "Terêncio Florestan",
    },
    [134345] = {
        name = "Coletor Kojo",
    },
    [134408] = {
        name = "Encarregado Jethek",
    },
    [134509] = {
        name = "Guia-chefe Allentorx",
    },
    [134628] = {
        name = "Técnica Civil Alena",
    },
    [134639] = {
        name = "Irmão Pique",
    },
    [134702] = {
        name = "Netinho Sorriso",
    },
    [134720] = {
        name = "Leo Matoso",
    },
    [134752] = {
        name = "Prefeita Roz",
    },
    [134776] = {
        name = "Davi Barnabé",
    },
    [134953] = {
        name = "Alexandre Bompasso",
    },
    [135021] = {
        name = "Inquisidora Claralvor",
    },
    [135067] = {
        name = "Moxie Travigira",
    },
    [135085] = {
        name = "Capitã Lilian Novaes",
    },
    [135133] = {
        name = "Guarda Bélica Rakera",
    },
    [135179] = {
        name = "Maurílio Sarrafada",
    },
    [135200] = {
        name = "Alexandre Bompasso",
    },
    [135205] = {
        name = "Nathanos Arauto da Praga",
    },
    [135308] = {
        name = "Asista Goja",
    },
    [135330] = {
        name = "Netinho Sorriso",
    },
    [135367] = {
        name = "Valentina Rariboi",
    },
    [135517] = {
        name = "Guarda-maré Victoria",
    },
    [135534] = {
        name = "Irmão Pique",
    },
    [135541] = {
        name = "Incinerador de Borraquilha",
    },
    [135595] = {
        name = "Pa'kul",
    },
    [135612] = {
        name = "Haraldo Serpecida",
    },
    [135614] = {
        name = "Mestre Mathias Shaw",
    },
    [135618] = {
        name = "Falstad Martelo Feroz",
    },
    [135620] = {
        name = "Kelsey Fagulhaço",
    },
    [135673] = {
        name = "Batedor Kellisson",
    },
    [135681] = {
        name = "Grã-almirante Jes-Tereth",
    },
    [135682] = {
        name = "Patrício Coelho",
    },
    [135690] = {
        name = "Capitã do Medo Velarrota",
    },
    [135691] = {
        name = "Nathanos Arauto da Praga",
    },
    [135784] = {
        name = "Guarda Imperial",
    },
    [135793] = {
        name = "Coletor Kojo",
    },
    [135794] = {
        name = "Sábia dos Pergaminhos Nola",
    },
    [135801] = {
        name = "Senhor da Bagata Raal",
    },
    [135855] = {
        name = "Teka Bobinarame",
    },
    [135861] = {
        name = "Adalina Miramata",
    },
    [135874] = {
        name = "Lea Martinez",
    },
    [135890] = {
        name = "Rei Rastakhan",
    },
    [135901] = {
        name = "Fungoriano Ramossangue",
    },
    [135976] = {
        name = "Morwin Claricórdia",
    },
    [136041] = {
        name = "Emília Bontempo",
    },
    [136053] = {
        name = "Samuel Guilhem",
    },
    [136059] = {
        name = "Layla Quilharreta",
    },
    [136140] = {
        name = "Clâncio Engraxadinho",
    },
    [136184] = {
        name = "Ambrósio Cartola",
    },
    [136195] = {
        name = "Socorrista Feorea",
    },
    [136197] = {
        name = "Brigadeiro Thônio",
    },
    [136227] = {
        name = "Fixi Navalha",
    },
    [136233] = {
        name = "Claus Belvento",
    },
    [136234] = {
        name = "Mari Mettebronka",
    },
    [136309] = {
        name = "Imediato Jamboya",
    },
    [136310] = {
        name = "Imediato Jamboya",
    },
    [136414] = {
        name = "Pastora Ribeiro d'Azenha",
    },
    [136432] = {
        name = "Brann Barbabronze",
    },
    [136458] = {
        name = "Mari Mettebronka",
    },
    [136497] = {
        name = "Guarda-maré Victoria",
    },
    [136562] = {
        name = "Intendente Alfino",
    },
    [136568] = {
        name = "Capitã Conrado",
    },
    [136574] = {
        name = "Charles Dalmora",
    },
    [136576] = {
        name = "Mestra de Doca Leitão",
    },
    [136641] = {
        name = "Brann Barbabronze",
    },
    [136645] = {
        name = "Brann Barbabronze",
    },
    [136658] = {
        name = "Maria Dalmora",
    },
    [136675] = {
        name = "Brann Barbabronze",
    },
    [136683] = {
        name = "Príncipe Mercador Gallywix",
    },
    [136779] = {
        name = "Imediato Jamboya",
    },
    [136907] = {
        name = "Magni Barbabronze",
    },
    [136933] = {
        name = "Irmão Pique",
    },
    [137008] = {
        name = "Sargento Tareia",
    },
    [137075] = {
        name = "Tenente Dênis Metuendo",
    },
    [137094] = {
        name = "Fazendeiro Max",
    },
    [137112] = {
        name = "Guardião Titânico Hezrel",
    },
    [137213] = {
        name = "Haraldo Serpecida",
    },
    [137337] = {
        name = "Sargento Tareia",
    },
    [137401] = {
        name = "Thane de Bigorna Thurgaden",
    },
    [137506] = {
        name = "Irmão Pique",
    },
    [137543] = {
        name = "Sargento Tareia",
    },
    [137613] = {
        name = "Roberto Agarramalho",
    },
    [137675] = {
        name = "Caçador Sombrio Ty'jin",
    },
    [137691] = {
        name = "Irmão Pique",
    },
    [137694] = {
        name = "Parin Medalengenho",
    },
    [137727] = {
        name = "Imediata Frizotti",
    },
    [137742] = {
        name = "Caçador Sombrio Ty'jin",
    },
    [137818] = {
        name = "Mixtudo Chavetino, o \"Rato Marinho\"",
    },
    [137837] = {
        name = "Lady Suprema Geya'rah",
    },
    [137867] = {
        name = "Haraldo Serpecida",
    },
    [137878] = {
        name = "Mestre Gadrin",
    },
    [138138] = {
        name = "Princesa Talanji",
    },
    [138285] = {
        name = "Nathanos Arauto da Praga",
    },
    [138352] = {
        name = "Sumo Senhor da Guerra Cromush",
    },
    [138365] = {
        name = "Sumo Senhor da Guerra Cromush",
    },
    [138520] = {
        name = "Aldeã de Zeb'ahari",
    },
    [138521] = {
        name = "Técnico de Minas",
    },
    [138669] = {
        name = "Rosarães Guima",
    },
    [138688] = {
        name = "Centuriã Kaja Pedra Morna",
    },
    [138708] = {
        name = "Garona Meiorken",
    },
    [138735] = {
        name = "Felícia Graciliana",
    },
    [139061] = {
        name = "Nathanos Arauto da Praga",
    },
    [139069] = {
        name = "Imediato Rubrens",
    },
    [139070] = {
        name = "Capitão Rubrens",
    },
    [139089] = {
        name = "Guarda de Tenervau",
    },
    [139098] = {
        name = "Tomás Zelão",
    },
    [139568] = {
        name = "Magíster Umbric",
    },
    [139705] = {
        name = "Haraldo Serpecida",
    },
    [139719] = {
        name = "Shandris Plumaluna",
    },
    [139722] = {
        name = "Explosineiro Fusivoide",
    },
    [139912] = {
        name = "Patrulheira Wons",
    },
    [139926] = {
        name = "Voz-dos-espinhos Betulosque",
    },
    [139928] = {
        name = "Mestre Gadrin",
    },
    [140046] = {
        name = "Rosi",
    },
    [140048] = {
        name = "Artur Alísio",
    },
    [140105] = {
        name = "Nathanos Arauto da Praga",
    },
    [140176] = {
        name = "Nathanos Arauto da Praga",
    },
    [140258] = {
        name = "Shandris Plumaluna",
    },
    [140484] = {
        name = "Capitã Amália Rocha",
    },
    [140485] = {
        name = "Nathanos Arauto da Praga",
    },
    [140487] = {
        name = "Tomás Zelão",
    },
    [140495] = {
        name = "Katherine Proudmore",
    },
    [140590] = {
        name = "Capitão Grezz'ko",
    },
    [140724] = {
        name = "Princesa Talanji",
    },
    [140725] = {
        name = "Espírito de Vol'jin",
    },
    [140752] = {
        name = "Geni Celeráguas",
    },
    [141078] = {
        name = "Refugiado da Colina da Vigília",
    },
    [141555] = {
        name = "Baine Casco Sangrento",
    },
    [141602] = {
        name = "Tomás Zelão",
    },
    [141603] = {
        name = "Mallory Capucho",
    },
    [141643] = {
        name = "Patiscante do Leito Marinho",
    },
    [141644] = {
        name = "Nathanos Arauto da Praga",
    },
    [141672] = {
        name = "Marinheiro Afogado",
    },
    [141769] = {
        name = "Marília Capucho",
    },
    [141815] = {
        name = "Marinheiro Afogado",
    },
    [141952] = {
        name = "Escornante Jovem",
    },
    [142275] = {
        name = "Grommash Grito Infernal",
    },
    [142651] = {
        name = "Lucília Capelo",
    },
    [142721] = {
        name = "Dalton Karn",
    },
    [142930] = {
        name = "Haraldo Serpecida",
    },
    [143536] = {
        name = "Sumo Senhor da Guerra Volrath",
    },
    [143559] = {
        name = "Grã-marechal Tremulâmina",
    },
    [143565] = {
        name = "Caminha, o Ancestral",
    },
    [143692] = {
        name = "Anacronos",
    },
    [143777] = {
        name = "Hasani Alto",
    },
    [143787] = {
        name = "Avoa-voa",
    },
    [143845] = {
        name = "Lady Suprema Geya'rah",
    },
    [143846] = {
        name = "Alleria Correventos",
    },
    [143851] = {
        name = "Kelsey Fagulhaço",
    },
    [143871] = {
        name = "Encarregada Engrebotão",
    },
    [143878] = {
        name = "Riz Sujismundo",
    },
    [143908] = {
        name = "Corpo Mutilado",
    },
    [144095] = {
        name = "Mestre Mathias Shaw",
    },
    [145005] = {
        name = "Elite dos Andarilhos",
    },
    [145022] = {
        name = "Tecelã do Tempo Delormi",
    },
    [145131] = {
        name = "Infoguru Gryzix",
    },
    [145190] = {
        name = "Princesa Talanji",
    },
    [145225] = {
        name = "Espírito de Vol'jin",
    },
    [145359] = {
        name = "Princesa Talanji",
    },
    [145411] = {
        name = "Grande Dama Sylvana Correventos",
    },
    [145423] = {
        name = "Tomás Zelão",
    },
    [145424] = {
        name = "Baine Casco Sangrento",
    },
    [145462] = {
        name = "Brann Barbabronze",
    },
    [145464] = {
        name = "Conselheiro Belgrum",
    },
    [145580] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [145593] = {
        name = "Rosaline Madeira",
    },
    [145632] = {
        name = "Okri Carrapeta",
    },
    [145751] = {
        name = "Príncipe Mercador Gallywix",
    },
    [145965] = {
        name = "Espírito de Vol'jin",
    },
    [145981] = {
        name = "Espírito de Vol'jin",
    },
    [146010] = {
        name = "Patrulheira Sombria Lyana",
    },
    [146013] = {
        name = "Patrulheira Sombria Alina",
    },
    [146050] = {
        name = "Maiev Cantonegro",
    },
    [146073] = {
        name = "Príncipe Mercador Gallywix",
    },
    [146208] = {
        name = "Krag'wa, o Imenso",
    },
    [146209] = {
        name = "Pa'kul",
    },
    [146290] = {
        name = "Espírito de Vol'jin",
    },
    [146323] = {
        name = "Nathanos Arauto da Praga",
    },
    [146325] = {
        name = "Retalhador Blix",
    },
    [146335] = {
        name = "Rainha Talanji",
    },
    [146373] = {
        name = "Maiev Cantonegro",
    },
    [146374] = {
        name = "Shandris Plumaluna",
    },
    [146375] = {
        name = "Sira Velaluna",
    },
    [146536] = {
        name = "Fogo-fátuo Perdido",
    },
    [146601] = {
        name = "Sira Velaluna",
    },
    [146630] = {
        name = "Espírito de Vol'jin",
    },
    [146654] = {
        name = "Grande Dama Sylvana Correventos",
    },
    [146791] = {
        name = "Patrulheira Sombria Lyana",
    },
    [146806] = {
        name = "Patrulheira Sombria Lyana",
    },
    [146824] = {
        name = "Princesa Talanji",
    },
    [146877] = {
        name = "Princesa Talanji",
    },
    [146902] = {
        name = "Irmão Pique",
    },
    [146921] = {
        name = "Princesa Talanji",
    },
    [146937] = {
        name = "Patrulheira Sombria Lyana",
    },
    [146939] = {
        name = "Embaixatriz Fiaurora",
    },
    [146982] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [146988] = {
        name = "Cavador Golad",
    },
    [147088] = {
        name = "Arcanista Valtrois",
    },
    [147135] = {
        name = "Nathanos Arauto da Praga",
    },
    [147145] = {
        name = "Nathanos Arauto da Praga",
    },
    [147148] = {
        name = "Carlota",
    },
    [147149] = {
        name = "Morton Engrenaldo",
    },
    [147151] = {
        name = "Kelsey Fagulhaço",
    },
    [147155] = {
        name = "Mathiaz",
    },
    [147210] = {
        name = "Patrulheira Sombria Lyana",
    },
    [147311] = {
        name = "Morton Engrenaldo",
    },
    [147519] = {
        name = "Kelsey Fagulhaço",
    },
    [147819] = {
        name = "Mestre de Espadas Telaamon",
    },
    [147842] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [147843] = {
        name = "Mestre Mathias Shaw",
    },
    [147844] = {
        name = "Mestre de Espadas Telaamon",
    },
    [147939] = {
        name = "Ás dos Ares Tempestrava",
    },
    [147943] = {
        name = "Capitão Pierre Bicochispa",
    },
    [147950] = {
        name = "Capitão Engrenagem Piscavera",
    },
    [147952] = {
        name = "Filó Espocabucho",
    },
    [148096] = {
        name = "Alta-prelada Ranata",
    },
    [148339] = {
        name = "Mathiaz",
    },
    [148798] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [148870] = {
        name = "Dorian Marinho",
    },
    [149084] = {
        name = "Andarilho Espiritual Ussoh",
    },
    [149088] = {
        name = "Andarilha Espiritual Isahi",
    },
    [149143] = {
        name = "Nathanos Arauto da Praga",
    },
    [149252] = {
        name = "Céu Atado",
    },
    [149471] = {
        name = "Patrulheira Sombria Velonara",
    },
    [149503] = {
        name = "Capitão Engrenagem Piscavera",
    },
    [149528] = {
        name = "Baine Casco Sangrento",
    },
    [149529] = {
        name = "Andarilho Espiritual Ussoh",
    },
    [149612] = {
        name = "Shandris Plumaluna",
    },
    [149736] = {
        name = "Imagem de Mimiron",
    },
    [149809] = {
        name = "Gasganete",
    },
    [149815] = {
        name = "Grizzek Chave-frouxa",
    },
    [149823] = {
        name = "Magni Barbabronze",
    },
    [149842] = {
        name = "Baine Casco Sangrento",
    },
    [149864] = {
        name = "Mestre-faz-tudo Superchispa",
    },
    [149867] = {
        name = "Magni Barbabronze",
    },
    [149870] = {
        name = "Grif Selvacuore",
    },
    [149877] = {
        name = "Mestre-faz-tudo Superchispa",
    },
    [149904] = {
        name = "Neri Pinafiada",
    },
    [150086] = {
        name = "Fúsio Molachispa",
    },
    [150101] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [150115] = {
        name = "Princesa Tess Greymane",
    },
    [150145] = {
        name = "Gila Cruzalinha",
    },
    [150187] = {
        name = "Nathanos Arauto da Praga",
    },
    [150196] = {
        name = "Primeira Arcanista Thalyssra",
    },
    [150200] = {
        name = "Mensageira Claridge",
    },
    [150206] = {
        name = "Chefe Telemante Oculeth",
    },
    [150208] = {
        name = "Mestre-faz-tudo Superchispa",
    },
    [150209] = {
        name = "Neri Pinafiada",
    },
    [150309] = {
        name = "Baine Casco Sangrento",
    },
    [150311] = {
        name = "Tomás Zelão",
    },
    [150391] = {
        name = "Imagem de Mimiron",
    },
    [150433] = {
        name = "Vigia do Penhasco Cicatriz Orgulhosa",
    },
    [150515] = {
        name = "Ciro Desalento",
    },
    [150555] = {
        name = "Aren Engrenália",
    },
    [150573] = {
        name = "Reciclador Cataplau",
    },
    [150574] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [150630] = {
        name = "Flipo Carga-rápida",
    },
    [150631] = {
        name = "Prisca Carga-rápida",
    },
    [150633] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [150637] = {
        name = "Kelsey Fagulhaço",
    },
    [150640] = {
        name = "Mestre Mathias Shaw",
    },
    [150690] = {
        name = "Chefe Mida",
    },
    [150796] = {
        name = "Kelsey Fagulhaço",
    },
    [150884] = {
        name = "Tchella Wright",
    },
    [150885] = {
        name = "Fera de Vime",
    },
    [150893] = {
        name = "Altar do Mar",
    },
    [150894] = {
        name = "Altar da Natureza",
    },
    [150895] = {
        name = "Altar das Areias",
    },
    [150896] = {
        name = "Altar do Anoitecer",
    },
    [150897] = {
        name = "Altar do Alvorecer",
    },
    [150898] = {
        name = "Altar das Tormentas",
    },
    [150956] = {
        name = "Perfuratriz Quebrada",
    },
    [151000] = {
        name = "Mestre de Espadas Okani",
    },
    [151100] = {
        name = "Gila Cruzalinha",
    },
    [151129] = {
        name = "Safroneta Flaivvers",
    },
    [151130] = {
        name = "Grizzek Chave-frouxa",
    },
    [151132] = {
        name = "Peninha",
    },
    [151134] = {
        name = "Tecelã do Tempo Delormi",
    },
    [151137] = {
        name = "Alfaiate Sincrônica",
    },
    [151162] = {
        name = "Atikka Busca Lua, o Ás",
    },
    [151173] = {
        name = "Daniss Bailalma",
    },
    [151283] = {
        name = "Filhote de Escornante",
    },
    [151285] = {
        name = "Mevris Bailalma",
    },
    [151286] = {
        name = "Filha de Torcali",
    },
    [151462] = {
        name = "Daniella Barbela",
    },
    [151626] = {
        name = "Caçador Akana",
    },
    [151641] = {
        name = "Andarilho Espiritual Chifre de Ébano",
    },
    [151682] = {
        name = "Merithra do Sonho",
    },
    [151693] = {
        name = "Merithra do Sonho",
    },
    [151695] = {
        name = "Andarilho Espiritual Chifre de Ébano",
    },
    [151704] = {
        name = "Valithria Andassonho",
    },
    [151741] = {
        name = "Aprendiz Odari",
    },
    [151761] = {
        name = "Vassandra Garrevolta",
    },
    [151825] = {
        name = "Merithra do Sonho",
    },
    [151851] = {
        name = "Chefe Telemante Oculeth",
    },
    [151887] = {
        name = "Merithra do Sonho",
    },
    [151947] = {
        name = "Príncipe Erazmin",
    },
    [151999] = {
        name = "Jo'nok, Baluarte de Torcali",
    },
    [152002] = {
        name = "Imagem de Mimiron",
    },
    [152047] = {
        name = "Xablau Guelbraque",
    },
    [152066] = {
        name = "Primeira Arcanista Thalyssra",
    },
    [152095] = {
        name = "Magni Barbabronze",
    },
    [152108] = {
        name = "Neri Pinafiada",
    },
    [152194] = {
        name = "M.A.D.R.E.",
    },
    [152206] = {
        name = "Magni Barbabronze",
    },
    [152238] = {
        name = "Riathia Estelaprata",
    },
    [152316] = {
        name = "Imagem de Thalyssra",
    },
    [152385] = {
        name = "Andarilho Espiritual Chifre de Ébano",
    },
    [152484] = {
        name = "Mestre-faz-tudo Superchispa",
    },
    [152489] = {
        name = "Altar das Tormentas",
    },
    [152490] = {
        name = "Altar do Alvorecer",
    },
    [152493] = {
        name = "Altar das Areias",
    },
    [152495] = {
        name = "Altar do Mar",
    },
    [152496] = {
        name = "Altar da Natureza",
    },
    [152497] = {
        name = "Altar do Anoitecer",
    },
    [152504] = {
        name = "Gasganete",
    },
    [152522] = {
        name = "Gasganete",
    },
    [152578] = {
        name = "Gasganete",
    },
    [152652] = {
        name = "Gasganete",
    },
    [152747] = {
        name = "Christy Socapeça",
    },
    [152783] = {
        name = "Gasganete",
    },
    [152815] = {
        name = "Magni Barbabronze",
    },
    [152820] = {
        name = "Príncipe Erazmin",
    },
    [152845] = {
        name = "Gasganete",
    },
    [152851] = {
        name = "Príncipe Erazmin",
    },
    [152864] = {
        name = "Mestre-faz-tudo Superchispa",
    },
    [153253] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [153365] = {
        name = "Matriarca-da-colmeia Meleira",
    },
    [153385] = {
        name = "Mestre de Espadas Okani",
    },
    [153393] = {
        name = "Abelardo",
    },
    [153422] = {
        name = "Chefe Telemante Oculeth",
    },
    [153509] = {
        name = "Artífice Okata",
    },
    [153510] = {
        name = "Artífice Itanu",
    },
    [153512] = {
        name = "Rastreador Pruque",
    },
    [153514] = {
        name = "Rastreadora Palta",
    },
    [153617] = {
        name = "Shandris Plumaluna",
    },
    [153670] = {
        name = "Príncipe Erazmin",
    },
    [153936] = {
        name = "Feitor Hajeer",
    },
    [154002] = {
        name = "Atólia Perolágua",
    },
    [154023] = {
        name = "Coletora Nascente",
    },
    [154143] = {
        name = "Coletor Kojo",
    },
    [154248] = {
        name = "Espadachim Inowari",
    },
    [154257] = {
        name = "Instrutor Ulooaka",
    },
    [154408] = {
        name = "Rolam",
    },
    [154444] = {
        name = "Voz da Tempestade Qian",
    },
    [154514] = {
        name = "Kelya Lunapoente",
    },
    [154520] = {
        name = "Primeira Arcanista Thalyssra",
    },
    [154522] = {
        name = "Shandris Plumaluna",
    },
    [154532] = {
        name = "Magni Barbabronze",
    },
    [154533] = {
        name = "Magni Barbabronze",
    },
    [154574] = {
        name = "Kelya Lunapoente",
    },
    [154601] = {
        name = "Kelya Lunapoente",
    },
    [154607] = {
        name = "Imagem de Torcali",
    },
    [154640] = {
        name = "Grã-marechal Tremulâmina",
    },
    [154660] = {
        name = "Shandris Plumaluna",
    },
    [154661] = {
        name = "Primeira Arcanista Thalyssra",
    },
    [154958] = {
        name = "Operário Mitélio",
    },
    [155071] = {
        name = "Shandris Plumaluna",
    },
    [155095] = {
        name = "Rei Phaoris",
    },
    [155102] = {
        name = "Alta-exploradora Dellorah",
    },
    [155325] = {
        name = "Primeira Arcanista Thalyssra",
    },
    [155336] = {
        name = "Guerreiro Mogu",
    },
    [155482] = {
        name = "Shandris Plumaluna",
    },
    [155562] = {
        name = "Mestre Shado-Pan",
    },
    [155785] = {
        name = "Grã-senhora Jaina Proudmore",
    },
    [156003] = {
        name = "Andarilho das Lendas Cho",
    },
    [156297] = {
        name = "Chen Malte do Trovão",
    },
    [156358] = {
        name = "Azeitona",
    },
    [156390] = {
        name = "Chen Malte do Trovão",
    },
    [156391] = {
        name = "Li Li Malte do Trovão",
    },
    [156396] = {
        name = "Espoleta Chaveforte",
    },
    [156423] = {
        name = "Grande Dama Sylvana Correventos",
    },
    [156425] = {
        name = "Patrulheira Sombria Lenara",
    },
    [156440] = {
        name = "Nathanos Arauto da Praga",
    },
    [156520] = {
        name = "Roberto Agarramalho",
    },
    [156542] = {
        name = "Cronk Graxafuso",
    },
    [156937] = {
        name = "Chen Malte do Trovão",
    },
    [156938] = {
        name = "Li Li Malte do Trovão",
    },
    [157180] = {
        name = "Barriletes de Malte do Trovão Abandonados",
    },
    [157491] = {
        name = "Roberto Agarramalho",
    },
    [157997] = {
        name = "Kelsey Fagulhaço",
    },
    [158145] = {
        name = "Príncipe Erazmin",
    },
    [159544] = {
        name = "Arik Escorpicada",
    },
    [159560] = {
        name = "Pioneiro Lashan",
    },
    [159682] = {
        name = "Rastreadora Samara",
    },
    [159820] = {
        name = "Reparador Dyrin",
    },
    [159920] = {
        name = "Zahra Espreitareia",
    },
    [160101] = {
        name = "Kelsey Fagulhaço",
    },
    [160232] = {
        name = "Christy Socapeça",
    },
    [161031] = {
        name = "Capitão Hadan",
    },
    [161458] = {
        name = "Valira Sanguinar",
    },
    [161805] = {
        name = "Magni Barbabronze",
    },
})
]])()
