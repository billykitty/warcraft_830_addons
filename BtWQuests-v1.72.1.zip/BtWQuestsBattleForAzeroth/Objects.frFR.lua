----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "frFR" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateObjectsTable({
    [244983] = {
        name = "Montre de gousset sale",
    },
    [270917] = {
        name = "Registre de Ruisseval",
    },
    [271706] = {
        name = "Tableau des chasseurs",
    },
    [272179] = {
        name = "Bulletin du maire",
    },
    [272422] = {
        name = "Grimoire d’Héléna",
    },
    [273814] = {
        name = "Charme-lame",
    },
    [273854] = {
        name = "Sac à dos",
    },
    [276251] = {
        name = "Inventaire de l’excavation",
    },
    [276488] = {
        name = "Boulet de canon en azérite",
    },
    [276513] = {
        name = "Éperlan intact",
    },
    [276515] = {
        name = "Canne à pêche",
    },
    [276837] = {
        name = "Caillou à recettes",
    },
    [277199] = {
        name = "Liste de tâches abîmée",
    },
    [277373] = {
        name = "Algue scintillante",
    },
    [277459] = {
        name = "Effigie de cochon",
    },
    [278197] = {
        name = "Fiole d’antidote",
    },
    [278252] = {
        name = "Offre d’emploi",
    },
    [278313] = {
        name = "Lettre gratinée",
    },
    [278368] = {
        name = "Note en lambeaux",
    },
    [278447] = {
        name = "Lance de trappeur infidèle",
    },
    [278570] = {
        name = "Journal antique",
    },
    [278577] = {
        name = "Missive de la Horde déchirée",
    },
    [278669] = {
        name = "Grand livre de Havrebrune",
    },
    [278675] = {
        name = "Effigie maudite",
    },
    [279337] = {
        name = "Grimoire malecarde",
    },
    [279646] = {
        name = "Chroniques de la garde de sang",
    },
    [279647] = {
        name = "Tome du Sacrifice",
    },
    [280576] = {
        name = "Parchemin dans son étui",
    },
    [280727] = {
        name = "Note calcinée",
    },
    [281230] = {
        name = "Invitation officielle",
    },
    [281348] = {
        name = "Lettre désagrégée",
    },
    [281551] = {
        name = "Avis d’offre d’emploi",
    },
    [281583] = {
        name = "Reliquaire ancien",
    },
    [281639] = {
        name = "Statue croulante",
    },
    [281647] = {
        name = "Avis posté",
    },
    [281673] = {
        name = "Journal de villageois de Corlain",
    },
    [281718] = {
        name = "ON EMBAUCHE",
    },
    [282457] = {
        name = "Totem roncegarde",
    },
    [282478] = {
        name = "Caisse vide",
    },
    [282498] = {
        name = "Flûte du désert",
    },
    [284426] = {
        name = "Engin d’extraction enfoui",
    },
    [286016] = {
        name = "Journal de bord",
    },
    [287081] = {
        name = "Tablette antique",
    },
    [287185] = {
        name = "Avis de recherche : sombre orateur Jo’la",
    },
    [287189] = {
        name = "Avis de recherche : bêtes dangereuses",
    },
    [287228] = {
        name = "Avis de recherche : chroniqueur sombre",
    },
    [287229] = {
        name = "Avis de recherche : chroniqueur sombre",
    },
    [287232] = {
        name = "Rapport de reconnaissance",
    },
    [287327] = {
        name = "Rapport de reconnaissance",
    },
    [287398] = {
        name = "Avis de recherche : Za’roco",
    },
    [287440] = {
        name = "Avis de recherche : Taz’raka",
    },
    [287441] = {
        name = "Avis de recherche : éclaireur des sables Vesarik",
    },
    [287442] = {
        name = "Avis de recherche : participants à l’excursion Cobra",
    },
    [287958] = {
        name = "Panneau d’affichage",
    },
    [288157] = {
        name = "Avis de recherche : Yarsel’ghun",
    },
    [288167] = {
        name = "Paquet de Marie",
    },
    [288214] = {
        name = "Avis de recherche",
    },
    [288622] = {
        name = "Avis de recherche",
    },
    [288641] = {
        name = "Avis de recherche : kidnappeurs de griffons",
    },
    [289310] = {
        name = "AVIS DE RECHERCHE : garde-terre déchaîné",
    },
    [289313] = {
        name = "Avis de recherche : le Frelon",
    },
    [289361] = {
        name = "Avis de recherche : intendant Ssylis",
    },
    [289365] = {
        name = "Avis de recherche",
    },
    [289728] = {
        name = "Carte au trésor du capitaine Gulnaku",
    },
    [290138] = {
        name = "Bombe anti-robot",
    },
    [290419] = {
        name = "Avis de recherche",
    },
    [290537] = {
        name = "Offre d’emploi",
    },
    [290750] = {
        name = "Réserve jambani",
    },
    [290765] = {
        name = "Grand tas de pièces d’or",
    },
    [290993] = {
        name = "Butin des Lamineurs",
    },
    [291143] = {
        name = "La clé de Ranah",
    },
    [291291] = {
        name = "Avis de recherche : braconnier",
    },
    [292523] = {
        name = "Avis de recherche",
    },
    [293567] = {
        name = "Avis de recherche",
    },
    [293568] = {
        name = "Avis de recherche",
    },
    [293985] = {
        name = "On recherche : Étripeur de guerre",
    },
    [297492] = {
        name = "Panneau d’affichage",
    },
    [298778] = {
        name = "Avis de recherche",
    },
    [298849] = {
        name = "Avis de recherche",
    },
    [298858] = {
        name = "Avis de recherche",
    },
    [307748] = {
        name = "Lettre de la KapitalRisk",
    },
    [309498] = {
        name = "Présentoir à armure",
    },
    [311155] = {
        name = "Tablette antique",
    },
    [311218] = {
        name = "Xal’atath, lame de l’Empire noir",
    },
    [311885] = {
        name = "Xal’atath, lame de l’Empire noir",
    },
    [322533] = {
        name = "Grimoire des éléments de Mardivas",
    },
    [326393] = {
        name = "Cache d’armes azéritiques",
    },
    [326418] = {
        name = "Coffre arcanique",
    },
    [326588] = {
        name = "Cache d’armes azéritiques",
    },
    [327170] = {
        name = "Râtelier d’armes",
    },
    [327591] = {
        name = "Journal en bon état",
    },
    [327592] = {
        name = "Verrou enchanté",
    },
    [327596] = {
        name = "Focalisateur abyssal endommagé",
    },
    [329805] = {
        name = "Cristal étrange",
    },
})
]])()
