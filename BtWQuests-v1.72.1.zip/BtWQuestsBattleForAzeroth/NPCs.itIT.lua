----- AUTO GENERATED - DO NOT EDIT

if GetLocale() ~= "itIT" then
    return
end

loadstring([[
BtWQuestsDatabase:UpdateNPCsTable({
    [3037] = {
        name = "Sheza Manto Selvaggio",
    },
    [5164] = {
        name = "Grumnus Plasmacciaio",
    },
    [14720] = {
        name = "Gran Supremo Faucisaure",
    },
    [15192] = {
        name = "Anacronos",
    },
    [36648] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [108017] = {
        name = "Torv Doppio Colpo",
    },
    [120168] = {
        name = "Storiografo To'kini",
    },
    [120170] = {
        name = "Nathanos Selvamorta",
    },
    [120551] = {
        name = "Krag'wa l'Enorme",
    },
    [120740] = {
        name = "Re Rastakhan",
    },
    [120788] = {
        name = "Genn Mantogrigio",
    },
    [120904] = {
        name = "Principessa Talanji",
    },
    [120922] = {
        name = "Dama Jaina Marefiero",
    },
    [121144] = {
        name = "Katherine Marefiero",
    },
    [121239] = {
        name = "Flynn Ventofermo",
    },
    [121241] = {
        name = "Principessa Talanji",
    },
    [121288] = {
        name = "Principessa Talanji",
    },
    [121599] = {
        name = "Re Rastakhan",
    },
    [121706] = {
        name = "Signora delle Bestie L'kala",
    },
    [122009] = {
        name = "Maestro del Kraal B'khor",
    },
    [122129] = {
        name = "Commerciante Alexxi Cruzpot",
    },
    [122289] = {
        name = "Guardia di Spade Kaja",
    },
    [122320] = {
        name = "Guardia di Spade Kaja",
    },
    [122370] = {
        name = "Cyrus Granscogliera",
    },
    [122661] = {
        name = "Generale Jakra'zet",
    },
    [122672] = {
        name = "Olivia",
    },
    [122702] = {
        name = "Incantatrice Quinni",
    },
    [122703] = {
        name = "Kumali l'Astuta",
    },
    [122706] = {
        name = "Teurga Salazae",
    },
    [122760] = {
        name = "Druida da Guerra Loti",
    },
    [122795] = {
        name = "Taumaturgo Kejabu",
    },
    [122817] = {
        name = "Guardia di Spade Kaja",
    },
    [122939] = {
        name = "Cucciolo di Cornofurente",
    },
    [122991] = {
        name = "Cacciatrice dell'Ombra Mutumba",
    },
    [123000] = {
        name = "Capitano Rez'okun",
    },
    [123019] = {
        name = "Maestra Cacciatrice Vol'ka",
    },
    [123022] = {
        name = "Braccatore Burke",
    },
    [123026] = {
        name = "Erak il Distaccato",
    },
    [123063] = {
        name = "Anziano Kuppaka",
    },
    [123118] = {
        name = "Mastro Bracconiere Custer",
    },
    [123178] = {
        name = "Asdrubal",
    },
    [123335] = {
        name = "Druida da Guerra Loti",
    },
    [123415] = {
        name = "Henry Mantoduro",
    },
    [123526] = {
        name = "Schiaffo",
    },
    [123544] = {
        name = "Asdrubal",
    },
    [123545] = {
        name = "Tripla G",
    },
    [123548] = {
        name = "Schiaffo",
    },
    [123878] = {
        name = "Asdrubal",
    },
    [124062] = {
        name = "Re Rastakhan",
    },
    [124063] = {
        name = "Jol l'Antico",
    },
    [124289] = {
        name = "Liz \"La Rischiosa\" Seminario",
    },
    [124376] = {
        name = "Taumaturgo Zentimo",
    },
    [124629] = {
        name = "Kaza'jin il Serraonda",
    },
    [124641] = {
        name = "Cacciatrice dell'Ombra Mutumba",
    },
    [124655] = {
        name = "Re Rastakhan",
    },
    [124802] = {
        name = "Ser Aldrius Norwington",
    },
    [124915] = {
        name = "Re Rastakhan",
    },
    [124922] = {
        name = "Helena la Gentile",
    },
    [125039] = {
        name = "Commerciante Kro",
    },
    [125041] = {
        name = "Pergamologo Goji",
    },
    [125093] = {
        name = "Abitante di Malautunno",
    },
    [125312] = {
        name = "Pergamologo Rooka",
    },
    [125317] = {
        name = "Cacciatrice dell'Ombra Narez",
    },
    [125342] = {
        name = "Capitano Keelson",
    },
    [125380] = {
        name = "Lucille Crestabianca",
    },
    [125385] = {
        name = "Maresciallo Everit Reade",
    },
    [125394] = {
        name = "Conestabile Henry Framer",
    },
    [125486] = {
        name = "Cavaliere Alato Nivek",
    },
    [125922] = {
        name = "Fratello Therold",
    },
    [125962] = {
        name = "Gestore Yerold",
    },
    [126039] = {
        name = "Mag'ash il Velenoso",
    },
    [126079] = {
        name = "Kol'jun Calcamorte",
    },
    [126080] = {
        name = "Shinga Calcamorte",
    },
    [126148] = {
        name = "Taumaturga Jala",
    },
    [126158] = {
        name = "Flynn Ventofermo",
    },
    [126210] = {
        name = "Curatore Allen",
    },
    [126213] = {
        name = "Principessa Talanji",
    },
    [126240] = {
        name = "Bridget Acquasana",
    },
    [126298] = {
        name = "Brannon Sacraonda",
    },
    [126511] = {
        name = "Scuoiatore MacGuff",
    },
    [126560] = {
        name = "Druida da Guerra Loti",
    },
    [126564] = {
        name = "Signore del Maleficio Raal",
    },
    [126620] = {
        name = "Flynn Ventofermo",
    },
    [126804] = {
        name = "Saurolisco Intrappolato",
    },
    [127015] = {
        name = "Thaddeus \"Nonno\" Guardavarchi",
    },
    [127080] = {
        name = "Ser Vallecupa",
    },
    [127112] = {
        name = "Mastro Forgiatore Zak'aal",
    },
    [127157] = {
        name = "Marcus Urlavalle",
    },
    [127215] = {
        name = "Cacciatore dell'Ombra Da'jul",
    },
    [127216] = {
        name = "Zardrax il Potenziatore",
    },
    [127391] = {
        name = "Bramasangue Jo'chunga",
    },
    [127396] = {
        name = "Iniziata Peony",
    },
    [127481] = {
        name = "Ser Kennings",
    },
    [127489] = {
        name = "Signore del Maleficio Raal",
    },
    [127559] = {
        name = "Ser Aldrius Norwington",
    },
    [127570] = {
        name = "Guardia di Spade Kaja",
    },
    [127646] = {
        name = "Ser Kennings",
    },
    [127715] = {
        name = "Lucille Crestabianca",
    },
    [127743] = {
        name = "Zia Amanda Hale",
    },
    [127837] = {
        name = "Kaza'jin il Serraonda",
    },
    [127961] = {
        name = "Principessa Talanji",
    },
    [127980] = {
        name = "Akunda il Sensibile",
    },
    [127992] = {
        name = "Akunda l'Osannato",
    },
    [128228] = {
        name = "Sam l'Affamato",
    },
    [128229] = {
        name = "Jane l'Afflitta",
    },
    [128261] = {
        name = "Primo Ufficiale Jamboya",
    },
    [128349] = {
        name = "Hilde Spezzafiamme",
    },
    [128353] = {
        name = "Pendi Sfornamicce",
    },
    [128377] = {
        name = "Bob il Cercatore di Tesori",
    },
    [128381] = {
        name = "Drogrin Baffosbronzo",
    },
    [128457] = {
        name = "Maude Guardavarchi",
    },
    [128494] = {
        name = "Adela Biancospino",
    },
    [128618] = {
        name = "Ormeggiatore Herrington",
    },
    [128680] = {
        name = "Okri Cianciachiavi",
    },
    [129164] = {
        name = "Storiografo Jabari",
    },
    [129165] = {
        name = "Guardia Satao",
    },
    [129392] = {
        name = "Henry \"il Senza Speranza\"",
    },
    [129491] = {
        name = "Re Rastakhan",
    },
    [129561] = {
        name = "Druida da Guerra Loti",
    },
    [129642] = {
        name = "Lucille Crestabianca",
    },
    [129643] = {
        name = "Maresciallo Everit Reade",
    },
    [129670] = {
        name = "Lyssa Guardalberi",
    },
    [129703] = {
        name = "Signore del Maleficio Raal",
    },
    [129757] = {
        name = "Re Rastakhan",
    },
    [129808] = {
        name = "Contadino Terraricca",
    },
    [129858] = {
        name = "Wulferd Frizzaforche",
    },
    [129907] = {
        name = "Profeta Zul",
    },
    [129956] = {
        name = "Ormeggiatore Tyndall",
    },
    [129983] = {
        name = "Inquisitrice Albachiara",
    },
    [130101] = {
        name = "Recluta Brutis",
    },
    [130190] = {
        name = "Sergente Calvin",
    },
    [130216] = {
        name = "Magni Barbabronzea",
    },
    [130341] = {
        name = "Guardia di Spade Kaja",
    },
    [130375] = {
        name = "Tallis Cuorceleste",
    },
    [130377] = {
        name = "Corriere Gerald",
    },
    [130399] = {
        name = "Zooey Sporcaruote",
    },
    [130424] = {
        name = "Henry \"il Senza Speranza\"",
    },
    [130450] = {
        name = "Guardia di Spade Sonji",
    },
    [130468] = {
        name = "Piccola Tika",
    },
    [130481] = {
        name = "Shinga Calcamorte",
    },
    [130576] = {
        name = "Fratello Pike",
    },
    [130603] = {
        name = "Hakid lo Spezzabestie",
    },
    [130660] = {
        name = "Guardia da Guerra Rakera",
    },
    [130667] = {
        name = "Guardia da Guerra Rakera",
    },
    [130694] = {
        name = "Sindaca Roz",
    },
    [130697] = {
        name = "Jill la Pompiera",
    },
    [130706] = {
        name = "Spirito di Izita",
    },
    [130714] = {
        name = "Fratello Pike",
    },
    [130750] = {
        name = "Capitano Grez'ko",
    },
    [130785] = {
        name = "Maestra Cacciatrice Kil'ja",
    },
    [130821] = {
        name = "Maestra delle Onde Lanfa",
    },
    [130833] = {
        name = "Capitano Grez'ko",
    },
    [130844] = {
        name = "Principessa Talanji",
    },
    [130901] = {
        name = "Storiografo Grazzul",
    },
    [130929] = {
        name = "Taumaturga Jangalar",
    },
    [131000] = {
        name = "Comandante Kellam",
    },
    [131001] = {
        name = "Tenente Harris",
    },
    [131002] = {
        name = "Tenente Bauer",
    },
    [131003] = {
        name = "Specialista Wembley",
    },
    [131004] = {
        name = "Scudiero Augustus III",
    },
    [131048] = {
        name = "Tenente Tarenfold",
    },
    [131231] = {
        name = "Jin'tiki",
    },
    [131253] = {
        name = "Guardiano dei Titani Hezrel",
    },
    [131290] = {
        name = "Flynn Ventofermo",
    },
    [131354] = {
        name = "Madre delle Bestie Jabati",
    },
    [131443] = {
        name = "Capo Telemante Oculeth",
    },
    [131579] = {
        name = "Abitante Catturato",
    },
    [131580] = {
        name = "Apprendista Telemante Astrandis",
    },
    [131582] = {
        name = "Esaminatrice Tae'shara Mirasangue",
    },
    [131636] = {
        name = "Maresciallo Everit Reade",
    },
    [131638] = {
        name = "Lucille Crestabianca",
    },
    [131639] = {
        name = "Inquisitrice Mace",
    },
    [131640] = {
        name = "Inquisitore Notley",
    },
    [131641] = {
        name = "Inquisitore Yorrick",
    },
    [131642] = {
        name = "Inquisitore Ondafiera",
    },
    [131656] = {
        name = "Maestro dei Segugi Archibald",
    },
    [131657] = {
        name = "Compendio della Carneficina",
    },
    [131684] = {
        name = "Penny \"la Preziosa\" Mantoduro",
    },
    [131763] = {
        name = "Scavatore Morgrum Ardibraci",
    },
    [131775] = {
        name = "Joe il Senza Orecchie",
    },
    [131777] = {
        name = "Acadia Limapietre",
    },
    [131840] = {
        name = "Shuga Scoppiatappi",
    },
    [131879] = {
        name = "Inquisitrice Albachiara",
    },
    [132118] = {
        name = "Contadino Burton",
    },
    [132332] = {
        name = "Principessa Talanji",
    },
    [132333] = {
        name = "Principessa Talanji",
    },
    [132617] = {
        name = "Bently Sfiammagrasso",
    },
    [132720] = {
        name = "Mastro Falconiere Lloyd",
    },
    [132988] = {
        name = "Asdrubal",
    },
    [132994] = {
        name = "Ser Arthur Crestabianca",
    },
    [133035] = {
        name = "Ufficiale Jovan",
    },
    [133050] = {
        name = "Principessa Talanji",
    },
    [133098] = {
        name = "Inquisitrice Albachiara",
    },
    [133125] = {
        name = "Principessa Talanji",
    },
    [133324] = {
        name = "Signore del Maleficio Raal",
    },
    [133476] = {
        name = "Principessa Talanji",
    },
    [133489] = {
        name = "Ormhun Durmartello",
    },
    [133523] = {
        name = "Ji Palmo Infuocato",
    },
    [133536] = {
        name = "Grix \"Pugniferrei\" Barlow",
    },
    [133550] = {
        name = "Apprendista Minatore Joe",
    },
    [133551] = {
        name = "Capo Minatore Theock",
    },
    [133552] = {
        name = "Capo Alchimista Walters",
    },
    [133576] = {
        name = "Timoniera Uncino",
    },
    [133577] = {
        name = "Mastro Artigliere Line",
    },
    [133578] = {
        name = "\"Piombo\"",
    },
    [133640] = {
        name = "Wayne l'Ancestrale",
    },
    [133653] = {
        name = "Signore del Maleficio Raal",
    },
    [133953] = {
        name = "Sergente Calvin",
    },
    [134009] = {
        name = "Abitante di Corlain",
    },
    [134166] = {
        name = "Flynn Ventofermo",
    },
    [134345] = {
        name = "Kojo il Collezionista",
    },
    [134408] = {
        name = "Caposquadra Jethek",
    },
    [134509] = {
        name = "Capo Guida Trinciachiavi",
    },
    [134628] = {
        name = "Tecnica Civile Alena",
    },
    [134639] = {
        name = "Fratello Pike",
    },
    [134752] = {
        name = "Sindaca Roz",
    },
    [134953] = {
        name = "Alexander Calcarotta",
    },
    [135021] = {
        name = "Inquisitrice Albachiara",
    },
    [135067] = {
        name = "Moxie Torcitoppe",
    },
    [135085] = {
        name = "Capitano Lilian Nottley",
    },
    [135133] = {
        name = "Guardia da Guerra Rakera",
    },
    [135179] = {
        name = "Mener Archfeld",
    },
    [135200] = {
        name = "Alexander Calcarotta",
    },
    [135205] = {
        name = "Nathanos Selvamorta",
    },
    [135308] = {
        name = "Pterrorbalia Goja",
    },
    [135517] = {
        name = "Guardia delle Maree Victoria",
    },
    [135534] = {
        name = "Fratello Pike",
    },
    [135541] = {
        name = "Inceneritore degli Aqualorda",
    },
    [135612] = {
        name = "Halford Sventradraghi",
    },
    [135614] = {
        name = "Maestro Mathias Shaw",
    },
    [135618] = {
        name = "Falstad Granmartello",
    },
    [135620] = {
        name = "Kelsey Ferfavilla",
    },
    [135673] = {
        name = "Esploratore McKellis",
    },
    [135681] = {
        name = "Gran Ammiraglio Jes-Tereth",
    },
    [135690] = {
        name = "Ammiraglio del Terrore Velamesta",
    },
    [135691] = {
        name = "Nathanos Selvamorta",
    },
    [135784] = {
        name = "Guardia Imperiale",
    },
    [135793] = {
        name = "Kojo il Collezionista",
    },
    [135794] = {
        name = "Pergamologa Nola",
    },
    [135801] = {
        name = "Signore del Maleficio Raal",
    },
    [135855] = {
        name = "Teekay Ronzapedali",
    },
    [135861] = {
        name = "Adalyn Scrutaboschi",
    },
    [135890] = {
        name = "Re Rastakhan",
    },
    [135901] = {
        name = "Fungariano Ramorosso",
    },
    [135976] = {
        name = "Morwin Cuorbosco",
    },
    [136041] = {
        name = "Emily Chiarosole",
    },
    [136059] = {
        name = "Layla Chigliapiatta",
    },
    [136140] = {
        name = "Clonk Ungipezzi",
    },
    [136195] = {
        name = "Medico Feorea",
    },
    [136197] = {
        name = "Brigadiere Thom",
    },
    [136227] = {
        name = "Fixi Lamascaltra",
    },
    [136233] = {
        name = "Klause Ventofermo",
    },
    [136234] = {
        name = "Cesi Bombapazza",
    },
    [136309] = {
        name = "Primo Ufficiale Jamboya",
    },
    [136310] = {
        name = "Primo Ufficiale Jamboya",
    },
    [136414] = {
        name = "Pastora Milbrooke",
    },
    [136432] = {
        name = "Brann Barbabronzea",
    },
    [136458] = {
        name = "Cesi Bombapazza",
    },
    [136497] = {
        name = "Guardia delle Maree Victoria",
    },
    [136562] = {
        name = "Quartiermastro Alfin",
    },
    [136568] = {
        name = "Capitano Conrad",
    },
    [136576] = {
        name = "Ormeggiatrice Leighton",
    },
    [136641] = {
        name = "Brann Barbabronzea",
    },
    [136645] = {
        name = "Brann Barbabronzea",
    },
    [136675] = {
        name = "Brann Barbabronzea",
    },
    [136683] = {
        name = "Principe del Commercio Gallywix",
    },
    [136779] = {
        name = "Primo Ufficiale Jamboya",
    },
    [136907] = {
        name = "Magni Barbabronzea",
    },
    [136933] = {
        name = "Fratello Pike",
    },
    [137008] = {
        name = "Sergente Ermey",
    },
    [137075] = {
        name = "Tenente Dennis Storiacupa",
    },
    [137094] = {
        name = "Contadino Max",
    },
    [137112] = {
        name = "Guardiano dei Titani Hezrel",
    },
    [137213] = {
        name = "Halford Sventradraghi",
    },
    [137337] = {
        name = "Sergente Ermey",
    },
    [137401] = {
        name = "Thane della Forgia Thurgaden",
    },
    [137506] = {
        name = "Fratello Pike",
    },
    [137543] = {
        name = "Sergente Ermey",
    },
    [137613] = {
        name = "Hobart Multivite",
    },
    [137675] = {
        name = "Cacciatore dell'Ombra Ty'jin",
    },
    [137691] = {
        name = "Fratello Pike",
    },
    [137694] = {
        name = "Parin Trescatoppe",
    },
    [137727] = {
        name = "Primo Ufficiale Owings",
    },
    [137742] = {
        name = "Cacciatore dell'Ombra Ty'jin",
    },
    [137818] = {
        name = "Myxle \"Il Topo di Mare\" Storcibudella",
    },
    [137837] = {
        name = "Suprema Geya'rah",
    },
    [137867] = {
        name = "Halford Sventradraghi",
    },
    [137878] = {
        name = "Maestro Gadrin",
    },
    [138138] = {
        name = "Principessa Talanji",
    },
    [138285] = {
        name = "Nathanos Selvamorta",
    },
    [138352] = {
        name = "Gran Signore della Guerra Cromush",
    },
    [138365] = {
        name = "Gran Signore della Guerra Cromush",
    },
    [138520] = {
        name = "Abitante di Zeb'ahari",
    },
    [138521] = {
        name = "Tecnico della Miniera",
    },
    [138688] = {
        name = "Centuriona Kaya Pietra Calda",
    },
    [138708] = {
        name = "Garona Mezzorco",
    },
    [138735] = {
        name = "Felecia Roccialieta",
    },
    [139061] = {
        name = "Nathanos Selvamorta",
    },
    [139069] = {
        name = "Primo Ufficiale Redmond",
    },
    [139070] = {
        name = "Capitano Redmond",
    },
    [139089] = {
        name = "Guardia di Guadobasso",
    },
    [139568] = {
        name = "Magistro Umbric",
    },
    [139705] = {
        name = "Halford Sventradraghi",
    },
    [139719] = {
        name = "Shandris Piumaluna",
    },
    [139722] = {
        name = "Dinamitardo Micciapazza",
    },
    [139912] = {
        name = "Guardaboschi Wons",
    },
    [139926] = {
        name = "Granbetulla Cantaspine",
    },
    [139928] = {
        name = "Maestro Gadrin",
    },
    [140048] = {
        name = "Arthur Ventosaldo",
    },
    [140105] = {
        name = "Nathanos Selvamorta",
    },
    [140176] = {
        name = "Nathanos Selvamorta",
    },
    [140258] = {
        name = "Shandris Piumaluna",
    },
    [140484] = {
        name = "Capitano Amalia Stone",
    },
    [140485] = {
        name = "Nathanos Selvamorta",
    },
    [140495] = {
        name = "Katherine Marefiero",
    },
    [140590] = {
        name = "Capitano Grez'ko",
    },
    [140724] = {
        name = "Principessa Talanji",
    },
    [140725] = {
        name = "Spirito di Vol'jin",
    },
    [140752] = {
        name = "Jenny Rivolesto",
    },
    [141078] = {
        name = "Rifugiato di Colle Vigile",
    },
    [141555] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [141643] = {
        name = "Macellachele del Fondale",
    },
    [141644] = {
        name = "Nathanos Selvamorta",
    },
    [141672] = {
        name = "Marinaio Annegato",
    },
    [141815] = {
        name = "Marinaio Annegato",
    },
    [141952] = {
        name = "Cornofurente Giovane",
    },
    [142275] = {
        name = "Grommash Malogrido",
    },
    [142651] = {
        name = "Lucille Crestabianca",
    },
    [142930] = {
        name = "Halford Sventradraghi",
    },
    [143536] = {
        name = "Gran Signore della Guerra Volrath",
    },
    [143559] = {
        name = "Gran Maresciallo Fremilama",
    },
    [143565] = {
        name = "Wayne l'Ancestrale",
    },
    [143692] = {
        name = "Anacronos",
    },
    [143777] = {
        name = "Hasani lo Slanciato",
    },
    [143845] = {
        name = "Suprema Geya'rah",
    },
    [143846] = {
        name = "Alleria Ventolesto",
    },
    [143851] = {
        name = "Kelsey Ferfavilla",
    },
    [143871] = {
        name = "Caposquadra Vitearmata",
    },
    [143878] = {
        name = "Reez Tetrok",
    },
    [143908] = {
        name = "Corpo Mutilato",
    },
    [144095] = {
        name = "Maestro Mathias Shaw",
    },
    [145005] = {
        name = "Lungopasso Élite",
    },
    [145022] = {
        name = "Tessitempo Delormi",
    },
    [145131] = {
        name = "Esperto di Dati Gryzix",
    },
    [145190] = {
        name = "Principessa Talanji",
    },
    [145225] = {
        name = "Spirito di Vol'jin",
    },
    [145359] = {
        name = "Principessa Talanji",
    },
    [145411] = {
        name = "Dama Sylvanas Ventolesto",
    },
    [145424] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [145462] = {
        name = "Brann Barbabronzea",
    },
    [145464] = {
        name = "Consigliere Belgrum",
    },
    [145580] = {
        name = "Dama Jaina Marefiero",
    },
    [145632] = {
        name = "Okri Cianciachiavi",
    },
    [145751] = {
        name = "Principe del Commercio Gallywix",
    },
    [145793] = {
        name = "Dama Liadrin",
    },
    [145816] = {
        name = "M.IM.MO.G.",
    },
    [145965] = {
        name = "Spirito di Vol'jin",
    },
    [145981] = {
        name = "Spirito di Vol'jin",
    },
    [146010] = {
        name = "Guardaboschi Oscura Lyana",
    },
    [146011] = {
        name = "Varok Faucisaure",
    },
    [146013] = {
        name = "Guardaboschi Oscura Alina",
    },
    [146050] = {
        name = "Maiev Cantombroso",
    },
    [146073] = {
        name = "Principe del Commercio Gallywix",
    },
    [146208] = {
        name = "Krag'wa l'Enorme",
    },
    [146290] = {
        name = "Spirito di Vol'jin",
    },
    [146323] = {
        name = "Nathanos Selvamorta",
    },
    [146325] = {
        name = "Trituratore Blix",
    },
    [146335] = {
        name = "Regina Talanji",
    },
    [146373] = {
        name = "Maiev Cantombroso",
    },
    [146374] = {
        name = "Shandris Piumaluna",
    },
    [146375] = {
        name = "Sira Guardialuna",
    },
    [146536] = {
        name = "Fuoco Fatuo Perduto",
    },
    [146601] = {
        name = "Sira Guardialuna",
    },
    [146623] = {
        name = "M.IM.MO.G.",
    },
    [146630] = {
        name = "Spirito di Vol'jin",
    },
    [146654] = {
        name = "Dama Sylvanas Ventolesto",
    },
    [146791] = {
        name = "Guardaboschi Oscura Lyana",
    },
    [146806] = {
        name = "Guardaboschi Oscura Lyana",
    },
    [146824] = {
        name = "Principessa Talanji",
    },
    [146877] = {
        name = "Principessa Talanji",
    },
    [146902] = {
        name = "Fratello Pike",
    },
    [146921] = {
        name = "Principessa Talanji",
    },
    [146937] = {
        name = "Guardaboschi Oscura Lyana",
    },
    [146939] = {
        name = "Ambasciatrice Giuralba",
    },
    [146982] = {
        name = "Dama Jaina Marefiero",
    },
    [146988] = {
        name = "Scavatore Golad",
    },
    [147075] = {
        name = "Generale Rakera",
    },
    [147088] = {
        name = "Arcanista Valtrois",
    },
    [147135] = {
        name = "Nathanos Selvamorta",
    },
    [147145] = {
        name = "Nathanos Selvamorta",
    },
    [147151] = {
        name = "Kelsey Ferfavilla",
    },
    [147155] = {
        name = "Asdrubal",
    },
    [147210] = {
        name = "Guardaboschi Oscura Lyana",
    },
    [147519] = {
        name = "Kelsey Ferfavilla",
    },
    [147819] = {
        name = "Maestro di Spade Telaamon",
    },
    [147842] = {
        name = "Dama Jaina Marefiero",
    },
    [147843] = {
        name = "Maestro Mathias Shaw",
    },
    [147844] = {
        name = "Maestro di Spade Telaamon",
    },
    [147939] = {
        name = "Asso Sgranatempeste",
    },
    [147943] = {
        name = "Capitano Tread Tappovite",
    },
    [147950] = {
        name = "Capitan Meccanico Minimolla",
    },
    [147952] = {
        name = "Fizzi Meccanarco",
    },
    [148015] = {
        name = "Taelia Domadraghi",
    },
    [148096] = {
        name = "Somma Prelata Rata",
    },
    [148339] = {
        name = "Asdrubal",
    },
    [148798] = {
        name = "Dama Jaina Marefiero",
    },
    [148870] = {
        name = "Dorian Dell'Acqua",
    },
    [149084] = {
        name = "Spiritista Ussoh",
    },
    [149088] = {
        name = "Spiritista Isahi",
    },
    [149143] = {
        name = "Nathanos Selvamorta",
    },
    [149252] = {
        name = "Cielo Vincolato",
    },
    [149471] = {
        name = "Guardaboschi Oscura Velonara",
    },
    [149503] = {
        name = "Capitan Meccanico Minimolla",
    },
    [149528] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [149529] = {
        name = "Spiritista Ussoh",
    },
    [149612] = {
        name = "Shandris Piumaluna",
    },
    [149736] = {
        name = "Immagine di Mimiron",
    },
    [149809] = {
        name = "Sparachiodi",
    },
    [149815] = {
        name = "Grizzek Frizzachiavi",
    },
    [149823] = {
        name = "Magni Barbabronzea",
    },
    [149842] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [149864] = {
        name = "Mastro Meccanista Granfavilla",
    },
    [149867] = {
        name = "Magni Barbabronzea",
    },
    [149870] = {
        name = "Grif Cuorselvaggio",
    },
    [149877] = {
        name = "Mastro Meccanista Granfavilla",
    },
    [149904] = {
        name = "Neri Pinnafine",
    },
    [150086] = {
        name = "Bullon Balzascintille",
    },
    [150087] = {
        name = "Genn Mantogrigio",
    },
    [150101] = {
        name = "Dama Jaina Marefiero",
    },
    [150115] = {
        name = "Principessa Tess Mantogrigio",
    },
    [150145] = {
        name = "Gila Intrecciacavi",
    },
    [150187] = {
        name = "Nathanos Selvamorta",
    },
    [150196] = {
        name = "Prima Arcanista Thalyssra",
    },
    [150200] = {
        name = "Corriere Claridge",
    },
    [150206] = {
        name = "Capo Telemante Oculeth",
    },
    [150208] = {
        name = "Mastro Meccanista Granfavilla",
    },
    [150209] = {
        name = "Neri Pinnafine",
    },
    [150309] = {
        name = "Baine Zoccolo Sanguinario",
    },
    [150391] = {
        name = "Immagine di Mimiron",
    },
    [150433] = {
        name = "Guardiana del Picco Sfregio Fiero",
    },
    [150515] = {
        name = "Cyrus Granscogliera",
    },
    [150555] = {
        name = "Waren Cuordentato",
    },
    [150573] = {
        name = "Kerpezz il Riciclatore",
    },
    [150574] = {
        name = "Dama Jaina Marefiero",
    },
    [150630] = {
        name = "Flip Caricalesta",
    },
    [150631] = {
        name = "Pristy Caricalesta",
    },
    [150633] = {
        name = "Dama Jaina Marefiero",
    },
    [150637] = {
        name = "Kelsey Ferfavilla",
    },
    [150640] = {
        name = "Maestro Mathias Shaw",
    },
    [150796] = {
        name = "Kelsey Ferfavilla",
    },
    [150885] = {
        name = "Bestia di Vimini",
    },
    [150893] = {
        name = "Santuario del Mare",
    },
    [150894] = {
        name = "Santuario della Natura",
    },
    [150895] = {
        name = "Santuario delle Sabbie",
    },
    [150896] = {
        name = "Santuario del Vespro",
    },
    [150897] = {
        name = "Santuario dell'Alba",
    },
    [150898] = {
        name = "Santuario delle Tempeste",
    },
    [150956] = {
        name = "Trivella Guasta",
    },
    [151000] = {
        name = "Maestro di Spade Okani",
    },
    [151100] = {
        name = "Gila Intrecciacavi",
    },
    [151129] = {
        name = "Saffronetta Flivvers",
    },
    [151130] = {
        name = "Grizzek Frizzachiavi",
    },
    [151132] = {
        name = "Piumotto",
    },
    [151134] = {
        name = "Tessitempo Delormi",
    },
    [151137] = {
        name = "Sarta Sincronica",
    },
    [151162] = {
        name = "Atikka \"Asso\" Rincorri Lune",
    },
    [151173] = {
        name = "Daniss Danzaspettri",
    },
    [151283] = {
        name = "Cucciolo di Cornofurente",
    },
    [151285] = {
        name = "Mevris Danzaspettri",
    },
    [151286] = {
        name = "Figlia di Torcali",
    },
    [151462] = {
        name = "Danielle Lancialenza",
    },
    [151626] = {
        name = "Cacciatore Akana",
    },
    [151641] = {
        name = "Spiritista Corna Nere",
    },
    [151682] = {
        name = "Merithra del Sogno",
    },
    [151693] = {
        name = "Merithra del Sogno",
    },
    [151695] = {
        name = "Spiritista Corna Nere",
    },
    [151704] = {
        name = "Valithria Vagasogni",
    },
    [151741] = {
        name = "Apprendista Odari",
    },
    [151761] = {
        name = "Vassandra Asproverde",
    },
    [151784] = {
        name = "Mia Mantogrigio",
    },
    [151825] = {
        name = "Merithra del Sogno",
    },
    [151851] = {
        name = "Capo Telemante Oculeth",
    },
    [151887] = {
        name = "Merithra del Sogno",
    },
    [151947] = {
        name = "Principe Erazmin",
    },
    [151999] = {
        name = "Jo'nok, Baluardo di Torcali",
    },
    [152002] = {
        name = "Immagine di Mimiron",
    },
    [152047] = {
        name = "Poen Branchiak",
    },
    [152066] = {
        name = "Prima Arcanista Thalyssra",
    },
    [152095] = {
        name = "Magni Barbabronzea",
    },
    [152108] = {
        name = "Neri Pinnafine",
    },
    [152194] = {
        name = "M.A.D.R.E.",
    },
    [152206] = {
        name = "Magni Barbabronzea",
    },
    [152238] = {
        name = "Riathia Stellargentea",
    },
    [152316] = {
        name = "Immagine di Thalyssra",
    },
    [152385] = {
        name = "Spiritista Corna Nere",
    },
    [152484] = {
        name = "Mastro Meccanista Granfavilla",
    },
    [152489] = {
        name = "Santuario delle Tempeste",
    },
    [152490] = {
        name = "Santuario dell'Alba",
    },
    [152493] = {
        name = "Santuario delle Sabbie",
    },
    [152495] = {
        name = "Santuario del Mare",
    },
    [152496] = {
        name = "Santuario della Natura",
    },
    [152497] = {
        name = "Santuario del Vespro",
    },
    [152504] = {
        name = "Sparachiodi",
    },
    [152522] = {
        name = "Sparachiodi",
    },
    [152578] = {
        name = "Sparachiodi",
    },
    [152652] = {
        name = "Sparachiodi",
    },
    [152747] = {
        name = "Christy Pestaviti",
    },
    [152783] = {
        name = "Sparachiodi",
    },
    [152815] = {
        name = "Magni Barbabronzea",
    },
    [152820] = {
        name = "Principe Erazmin",
    },
    [152845] = {
        name = "Sparachiodi",
    },
    [152851] = {
        name = "Principe Erazmin",
    },
    [152864] = {
        name = "Mastro Meccanista Granfavilla",
    },
    [153253] = {
        name = "Dama Jaina Marefiero",
    },
    [153365] = {
        name = "Madre dell'Alveare Dolcedorso",
    },
    [153385] = {
        name = "Maestro di Spade Okani",
    },
    [153422] = {
        name = "Capo Telemante Oculeth",
    },
    [153509] = {
        name = "Artigiano Okata",
    },
    [153510] = {
        name = "Artigiano Itanu",
    },
    [153512] = {
        name = "Cercatore Pruc",
    },
    [153514] = {
        name = "Cercatrice Paltha",
    },
    [153617] = {
        name = "Shandris Piumaluna",
    },
    [153670] = {
        name = "Principe Erazmin",
    },
    [153932] = {
        name = "Genn Mantogrigio",
    },
    [153936] = {
        name = "Sovrintendente Hajeer",
    },
    [154002] = {
        name = "Atolia Perlamarina",
    },
    [154023] = {
        name = "Raccoglitore Immaturo",
    },
    [154143] = {
        name = "Kojo il Collezionista",
    },
    [154248] = {
        name = "Spadaccino Inowari",
    },
    [154257] = {
        name = "Istruttore Ulooaka",
    },
    [154418] = {
        name = "Ra-Den",
    },
    [154444] = {
        name = "Oratore delle Tempeste Qian",
    },
    [154514] = {
        name = "Kelya Ombraluna",
    },
    [154520] = {
        name = "Prima Arcanista Thalyssra",
    },
    [154522] = {
        name = "Shandris Piumaluna",
    },
    [154532] = {
        name = "Magni Barbabronzea",
    },
    [154533] = {
        name = "Magni Barbabronzea",
    },
    [154574] = {
        name = "Kelya Ombraluna",
    },
    [154601] = {
        name = "Kelya Ombraluna",
    },
    [154607] = {
        name = "Immagine di Torcali",
    },
    [154640] = {
        name = "Gran Maresciallo Fremilama",
    },
    [154660] = {
        name = "Shandris Piumaluna",
    },
    [154661] = {
        name = "Prima Arcanista Thalyssra",
    },
    [154958] = {
        name = "Bracciante Mitchell",
    },
    [155071] = {
        name = "Shandris Piumaluna",
    },
    [155095] = {
        name = "Re Phaoris",
    },
    [155102] = {
        name = "Gran Esploratrice Dellorah",
    },
    [155325] = {
        name = "Prima Arcanista Thalyssra",
    },
    [155336] = {
        name = "Guerriera Mogu",
    },
    [155482] = {
        name = "Shandris Piumaluna",
    },
    [155496] = {
        name = "Irathion",
    },
    [155562] = {
        name = "Maestra Shandaren",
    },
    [155785] = {
        name = "Dama Jaina Marefiero",
    },
    [155786] = {
        name = "Varok Faucisaure",
    },
    [156003] = {
        name = "Ramingo della Sapienza Cho",
    },
    [156297] = {
        name = "Chen Triplo Malto",
    },
    [156390] = {
        name = "Chen Triplo Malto",
    },
    [156391] = {
        name = "Li Li Triplo Malto",
    },
    [156396] = {
        name = "Sassy Serrabullona",
    },
    [156423] = {
        name = "Dama Sylvanas Ventolesto",
    },
    [156425] = {
        name = "Guardaboschi Oscura Lenara",
    },
    [156440] = {
        name = "Nathanos Selvamorta",
    },
    [156520] = {
        name = "Hobart Multivite",
    },
    [156542] = {
        name = "Bronto Ingrassamicce",
    },
    [156937] = {
        name = "Chen Triplo Malto",
    },
    [156938] = {
        name = "Li Li Triplo Malto",
    },
    [157180] = {
        name = "Barili di Triplo Malto Abbandonati",
    },
    [157491] = {
        name = "Hobart Multivite",
    },
    [157997] = {
        name = "Kelsey Ferfavilla",
    },
    [158145] = {
        name = "Principe Erazmin",
    },
    [159544] = {
        name = "Arik Scorpiaculeo",
    },
    [159560] = {
        name = "Predone Lashan",
    },
    [159587] = {
        name = "Gelbin Meccatork",
    },
    [159682] = {
        name = "Braccatrice Samara",
    },
    [159820] = {
        name = "Curatore Dyrin",
    },
    [159920] = {
        name = "Inseguitrice delle Sabbie Zahra",
    },
    [160101] = {
        name = "Kelsey Ferfavilla",
    },
    [160232] = {
        name = "Christy Pestaviti",
    },
    [161031] = {
        name = "Capitano Hadan",
    },
    [161805] = {
        name = "Magni Barbabronzea",
    },
})
]])()
