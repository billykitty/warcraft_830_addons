DAMAGE_TEXT_FONT = "Interface\\AddOns\\AnyFont\\font.ttf"
