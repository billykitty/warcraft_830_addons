# Chinchilla Minimap

## [v2.10.1](https://github.com/Ravendwyr/Chinchilla/tree/v2.10.1) (2020-01-20)
[Full Changelog](https://github.com/Ravendwyr/Chinchilla/compare/v2.10.0...v2.10.1)

- TrackingDots: More fixes for the blip maps.  
- Core: Bump Interface number to 80300.  
- TrackingDots: Updated for Patch 8.3.  
