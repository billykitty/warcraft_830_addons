# [2.18.4-14-gf3253736](https://github.com/WeakAuras/WeakAuras2/tree/f3253736d8b8bdeee4e4981dd070d2d8953a6d6e) (2020-09-15)

[Full Changelog](https://github.com/WeakAuras/WeakAuras2/compare/2.18.4...f3253736d8b8bdeee4e4981dd070d2d8953a6d6e)

InfusOnWoW (5):

- Fix anchoring to unit frames on group join
- Use the right anchorPoint
- Fix getting the width and height of text regions for Group layouts
- Fix MoverSizer trying to attach to restricted regions
- Sanitize additional progress values somewhat

Stanzilla (9):

- Update issue rules
- Try yet another action
- Use my fork of the GitHub Action
- Switch to different action
- Update issues.yml
- Create issues.yml
- Update issuecomplete.yml
- Create issuecomplete.yml
- Add support for Custom Class Colors

