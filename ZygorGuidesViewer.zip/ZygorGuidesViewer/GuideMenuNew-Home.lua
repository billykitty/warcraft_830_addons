local ZGV = ZygorGuidesViewer
if not ZGV then return end

-- #GLOBALS ZygorGuidesViewer

local GuideMenu = ZGV.GuideMenu

GuideMenu.HomeVersion = 1
GuideMenu.Home={
	{"banner", image=ZGV.DIR.."\\Skins\\banner"},

	{"section", text=[[New Release |cffffcc00October 10th, 2019 | Release 7.0.21120]]},

	{"section", text=[[|cffffcc00Questing|r.]]},
	{"item", text=[[Added |cffffcc00Nazjatar Storyline Quests|r.]], guide="LEVELING\\Battle for Azeroth (110-120)\\Kul Tiras\\Nazjatar\\Nazjatar"},
	{"item", text=[[Added |cffffcc00Mechagon Storyline Quests|r.]], guide="LEVELING\\Battle for Azeroth (110-120)\\Kul Tiras\\Mechagon Island\\Mechagon Island"},
	{"item", text=[[Added |cffffcc008.2 War Campaign|r.]], guide="LEVELING\\Battle for Azeroth (110-120)\\War Campaign"},

	{"section", text=[[|cffffcc00Dailies & World Quests|r.]]},
	{"item", text=[[Added |cffffcc00Nazjatar World Quests|r.]], guide="DAILIES\\Battle for Azeroth\\Nazjatar World Quests"},
	{"item", text=[[Added |cffffcc00Nazjatar Dailies|r.]], guide="DAILIES\\Battle for Azeroth\\Nazjatar\\Nazjatar Dailies"},
	{"item", text=[[Added |cffffcc00Mechagon World Quests|r.]], guide="DAILIES\\Battle for Azeroth\\Mechagon Island World Quests"},
	{"item", text=[[Added |cffffcc00Mechagon Dailies|r.]], guide="DAILIES\\Battle for Azeroth\\Mechagon Island\\Mechagon Dailies"},
	{"item", text=[[Added |cffffcc00Mechagon Fishing Dailies|r.]], guide="DAILIES\\Battle for Azeroth\\Mechagon Island\\Mechagon Fishing Dailies"},

}


-- faction="Alliance" {"separator"},