local ZygorGuidesViewer=ZygorGuidesViewer
if not ZygorGuidesViewer then return end
if UnitFactionGroup("player")~="Alliance" then return end
if ZGV:DoMutex("ReputationsABFA") then return end
ZygorGuidesViewer.GuideMenuTier = "BFA"
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\7th Legion",{
author="support@zygorguides.com",
keywords={"7th","Legion"},
description="This guide will walk you through becoming exalted with the \"7th Legion\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('7th Legion') < Exalted end,
achieveid={12954},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the 7th Legion |condition rep('7th Legion')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "7th Legion" world quests.
|tip Complete the weekly Island Expeditions quest "Azerite for the Alliance".
|tip Complete Missions at your mission table that reward reputation with the 7th Legion.
step
_Congratulations!_
You reached Exalted reputation with the "7th Legion" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Champions of Azeroth",{
author="support@zygorguides.com",
keywords={"Champions","of","Azeroth"},
description="This guide will walk you through becoming exalted with the \"Champions of Azeroth\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('Champions of Azeroth') < Exalted end,
achieveid={12955},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the Champions of Azeroth |condition rep('Champions of Azeroth')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "Champions of Azeroth" world quests.
|tip Complete Missions at your mission table that reward reputation with the Champions of Azeroth.
step
_Congratulations!_
You reached Exalted reputation with the "Champions of Azeroth" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Order of Embers",{
author="support@zygorguides.com",
keywords={"Order","of","Embers"},
description="This guide will walk you through becoming exalted with the \"Order of Embers\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('Order of Embers') < Exalted end,
achieveid={12952},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the Order of Embers |condition rep('Order of Embers')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "Order of Embers" world quests.
|tip Complete Missions at your mission table that reward reputation with the Order of Embers.
step
_Congratulations!_
You reached Exalted reputation with the "Order of Embers" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Proudmoore Admiralty",{
author="support@zygorguides.com",
keywords={"Proudmoore","Admiralty"},
description="This guide will walk you through becoming exalted with the \"Proudmoore Admiralty\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('Proudmoore Admiralty') < Exalted end,
achieveid={12951},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the Proudmoore Admiralty |condition rep('Proudmoore Admiralty')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "Proudmoore Admiralty" world quests.
|tip Complete Missions at your mission table that reward reputation with the Proudmoore Admiralty.
step
_Congratulations!_
You reached Exalted reputation with the "Proudmoore Admiralty" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Rustbolt Resistance",{
author="support@zygorguides.com",
keywords={"Rustbolt","Resistance","Mechagon"},
description="This guide will walk you through becoming exalted with the \"Rustbolt Resistance\" faction.",
condition_suggested=function() return level == 120 and rep('Rustbolt Resistance') < Exalted end,
achieveid={13557},
},[[
step
Complete the "A Tempered Blade" Quest |condition completedq(56156)
|tip Use the "Nazjatar" leveling guide to accomplish this.
step
Reach Exalted Reputation with the Rustbolt Resistance |condition rep('Rustbolt Resistance') == Exalted
|tip Use the Battle for Azeroth "Mechagon Island World Quests" guides to complete "Rustbolt Resistance" world quests.
|tip Complete Missions at your mission table that reward reputation with the Rustbolt Resistance.
|tip Additionally, complete the "Mechagon Island" leveling guide.
|tip Rare spawns also award small amounts of reputation.
|tip Contract: Rustbolt Resistance from Inscription allows you to gain rep from all Kul Tiras and Zandalar world quests.
step
_Congratulations!_
You reached Exalted reputation with the "Rustbolt Resistance" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Storm's Wake",{
author="support@zygorguides.com",
keywords={"Storm's","Wake"},
description="This guide will walk you through becoming exalted with the \"Storm's Wake\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('Storm\'s Wake') < Exalted end,
achieveid={12953},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the Storm's Wake |condition rep('Storm\'s Wake')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "Storm's Wake" world quests.
|tip Complete Missions at your mission table that reward reputation with the Storm's Wake.
step
_Congratulations!_
You reached Exalted reputation with the "Storm's Wake" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Tortollan Seekers",{
author="support@zygorguides.com",
keywords={"Tortollan","Seekers"},
description="This guide will walk you through becoming exalted with the \"Tortollan Seekers\" faction.",
condition_suggested=function() return level >= 110 and level <= 120 and rep('Tortollan Seekers') < Exalted end,
achieveid={12956},
},[[
step
Unlock World Quests |condition completedq(52450) or completedq(51918)
|tip Use the following guides to accomplish this:
|tip Intro and Quest Zone Choice guide.
|tip Battle for Azeroth Leveling guides.
|tip War Campaign guide.
step
Reach Exalted Reputation with the Tortollan Seekers |condition rep('Tortollan Seekers')==Exalted
|tip Use the Battle for Azeroth "World Quests" guides to complete "Tortollan Seekers" world quests.
|tip Complete Missions at your mission table that reward reputation with the Tortollan Seekers.
step
_Congratulations!_
You reached Exalted reputation with the "Tortollan Seekers" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Waveblade Ankoan",{
author="support@zygorguides.com",
keywords={"Waveblade","Ankoan","Nazjatar"},
description="This guide will walk you through becoming exalted with the \"Waveblade Ankoan\" faction.",
condition_suggested=function() return level == 120 and rep('Waveblade Ankoan') < Exalted end,
achieveid={13557},
},[[
step
Unlock World Quests |condition completedq(56156)
|tip Use the "Nazjatar" leveling guide to accomplish this.
step
Reach Exalted Reputation with the Waveblade Ankoan |condition rep('Waveblade Ankoan') == Exalted
|tip Use the Battle for Azeroth "Nazjatar World Quests" guides to complete "Waveblade Ankoan" world quests.
|tip Complete Missions at your mission table that reward reputation with the Waveblade Ankoan.
|tip Additionally, complete the "Nazjatar" leveling guide.
|tip Contract: Ankoan from Inscription allows you to gain rep from all Kul Tiras and Zandalar world quests.
step
_Congratulations!_
You reached Exalted reputation with the "Waveblade Ankoan" faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Honeyback Hive",{
author="support@zygorguides.com",
keywords={"Bee"},
description="\nThis guide will unlock the \"Honeyback Hive\" faction and assist you with reaching Exalted.",
condition_suggested=function() return level >= 120 and rep('Honeyback Hive') < Exalted end,
condition_valid=function() return achieved(13062) end,
condition_valid_msg="You must first earn the \"Let's Bee Friends\" achievement!",
condition_end=function() return rep("Honeyback Hive") == Exalted and completedq(56108) end,
},[[
step
Earn the "Let's Bee Friends" Achievement |achieve 13062
|tip Use the "Let's Bee Friends" achievement guide to accomplish this.
|tip You must complete this to collect the "Bumbles" battle pet.
step
Summon the "Bumbles" or "Seabreeze Bumblebee" Battle Pet |condition activepet(143730) or activepet(143176) |goto Stormsong Valley/0 69.24,64.20 |q 56104 |future
|tip Use their respective battle pet guides to collect one.
step
Watch the dialogue
|tip Summon the "Bumbles" battle pet.
Summon the "Bumbles" Battle Pet Near Barry |q 55906 |goto 69.24,64.20 |future
step
Watch the dialogue
Wait for Barry to Confront the Honeyback Hivemother |q 55904 |goto 62.94,26.57 |future
|tip Do not go into the cave.
step
click Jelly Deposit##327516
collect 1 Thin Jelly##169106 |goto 63.20,28.47 |q 56104 |future
step
talk Honeyback Hivemother##153365
Choose _<Offer [Thin Jelly]>_
Make an Offering to the Honeyback Hivemother |q 56104 |goto 62.90,26.53 |future
step
talk Barry##153393
Ask him _"Uh, sure?"_
Watch the dialogue
Speak with Barry |q 56105 |goto 63.00,26.61 |future
step
Watch the dialogue
Follow Barry Into the Cave |q 57704 |goto 62.56,26.37 |future
step
talk Barry##153393
Ask him _"What was that all about?"_
Speak with Barry |q 56735 |goto 62.56,26.38 |future
step
talk Nascent Harvester##154023
Choose _<Offer [Thin Jelly]>_
Feed the Larva |q 57528 |goto 62.53,26.43 |future
step
label "Kill_Honey_Smasher_Revered"
kill Honey Smasher##154154
|tip It walks up and down the coast around this area.
|tip Loot the corpse before you leave.
Defeat the Honey Smasher |q 57726 |goto 61.41,16.20 |future |or
'|condition rep("Honeyback Hive") >= Revered |or
step
label "Reach_Revered_Reputation"
map Stormsong Valley/0
path follow smart; loop on; ants curved; dist 30
path	63.60,25.67	64.12,30.21	61.81,31.00	64.01,37.28	62.08,46.11
path	61.47,51.92	63.13,51.40	64.24,52.43	72.31,52.16	68.25,55.41
path	66.00,58.21	66.93,63.51	71.32,67.24	69.71,75.98	66.43,70.37
path	61.45,55.92	56.21,58.78	58.30,54.29	54.72,48.45	53.34,43.12
path	52.53,39.13	55.23,41.02	55.24,38.46	56.06,37.13	55.10,31.26
path	51.36,31.93	47.47,32.20	44.51,36.66	49.85,36.74	46.55,41.98
path	44.63,49.27	47.97,62.33	40.89,62.15	35.11,64.45	33.24,67.87
path	33.39,71.99	29.82,76.19	25.88,74.30	25.51,67.16	31.46,60.14
path	35.55,52.37	36.77,47.69	40.39,47.35	37.33,37.29	33.15,32.86
path	47.39,25.42	52.37,27.08	53.91,27.73	55.78,27.94	57.58,30.01
path	58.85,30.83	61.37,28.86	58.58,28.41	56.23,22.87	56.40,18.77
path	58.27,21.38	61.40,22.33	63.27,22.24
click Jelly Deposit##327516+
click Large Jelly Deposit##328429+
|tip They look like clusters of honeycomb on the ground all over Stormsong Valley.
|tip Exchange Jellies at the Honeyback Hivemother in the Honeyback Hatchery.
talk Honeyback Harvester##155069
|tip They will occasionally appear on your minimap as gold-colored stars.
|tip You will also see a patch of flowers illuminated by sunlight.
|tip This will spawn waves of enemies and sometimes a rare or elite.
|tip You will have 5 minutes to clear 15 waves.
|tip A large group with party buffs is beneficial.
Choose _<Makes some strange gestures.>_
Reach Revered Reputation with the Honeyback Hive |condition rep("Honeyback Hive") >= Revered |or
|tip Feed the Jellies you collect to your Honeyback Harvester in the Honeyback Hatchery.
'|condition not completedq(57726) and rep("Honeyback Hive") < Revered |or |next "Kill_Honey_Smasher_Revered"
'|goto 62.87,26.53 < 300 |c |noway |only if haveanyquest(56473,56474,56092,56144,56475,56091) |or |next "Turnin_Honeyback_Harvester_Quests_Revered"
step
label "Turnin_Honeyback_Harvester_Quests_Revered"
talk Honeyback Hivemother##153365
|tip Inside the cave.
turnin Envenomed Spider Fang##56473 |goto 62.45,26.05 |only if havequest(56473)
turnin Hivekiller Stinger##56474 |goto 62.45,26.05 |only if havequest(56474)
turnin Hivethief's Jelly Stash##56092 |goto 62.45,26.05 |only if havequest(56092)
turnin Old Nasha's Paw##56144 |goto 62.45,26.05 |only if havequest(56144)
turnin Spiral Yeti Horn##56475 |goto 62.45,26.05 |only if havequest(56475)
turnin Usurper's Scent Gland##56091 |goto 62.45,26.05 |only if havequest(56091)
No Quest to Turn In |condition not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Hive") < Exalted |only if not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Hive") < Revered |next "Reach_Revered_Reputation" |or
'|condition rep("Honeyback Hive") >= Revered |or
step
map Stormsong Valley/0
path follow smart; loop on; ants curved; dist 30
path	63.60,25.67	64.12,30.21	61.81,31.00	64.01,37.28	62.08,46.11
path	61.47,51.92	63.13,51.40	64.24,52.43	72.31,52.16	68.25,55.41
path	66.00,58.21	66.93,63.51	71.32,67.24	69.71,75.98	66.43,70.37
path	61.45,55.92	56.21,58.78	58.30,54.29	54.72,48.45	53.34,43.12
path	52.53,39.13	55.23,41.02	55.24,38.46	56.06,37.13	55.10,31.26
path	51.36,31.93	47.47,32.20	44.51,36.66	49.85,36.74	46.55,41.98
path	44.63,49.27	47.97,62.33	40.89,62.15	35.11,64.45	33.24,67.87
path	33.39,71.99	29.82,76.19	25.88,74.30	25.51,67.16	31.46,60.14
path	35.55,52.37	36.77,47.69	40.39,47.35	37.33,37.29	33.15,32.86
path	47.39,25.42	52.37,27.08	53.91,27.73	55.78,27.94	57.58,30.01
path	58.85,30.83	61.37,28.86	58.58,28.41	56.23,22.87	56.40,18.77
path	58.27,21.38	61.40,22.33	63.27,22.24
click Jelly Deposit##327516+
click Large Jelly Deposit##328429+
|tip They look like clusters of honeycomb on the ground all over Stormsong Valley.
|tip Exchange Jellies at the Honeyback Hivemother in the Honeyback Hatchery.
talk Honeyback Harvester##155069
|tip They will occasionally appear on your minimap as gold-colored stars.
|tip You will also see a patch of flowers illuminated by sunlight.
|tip This will spawn waves of enemies and sometimes a rare or elite.
|tip You will have 5 minutes to clear 15 waves.
|tip A large group with party buffs is beneficial.
Choose _<Makes some strange gestures.>_
collect 20 Rich Jelly##168825 |or
|tip You need 20 Rich Jelly to purchase Beeholder's Goggles.
|tip These will allow you to see jelly deposits on the minimap.
'|condition rep("Honeyback Hive") == Exalted or itemcount(169109) >= 1 |or
step
talk Barry##153393
buy 1 Beeholder's Goggles##169109 |goto 62.77,26.87 |or
'|condition rep("Honeyback Hive") == Exalted or itemcount(169109) >= 1 |or
step
label "Gain_Beeholder's_Buff"
use the Beeholder's Goggles##169109
Gain the "Beeholder's Goggles" Buff |havebuff spell:299445 |or
'|condition rep("Honeyback Hive") == Exalted |or
step
label "Kill_Honey_Smasher_Exalted"
kill Honey Smasher##154154
|tip It walks up and down the coast around this area.
|tip Loot the corpse before you leave.
Defeat the Honey Smasher |q 57726 |goto 61.41,16.20 |future |or
'|condition rep("Honeyback Hive") == Exalted |or
step
label "Reach_Exalted_Reputation"
map Stormsong Valley/0
path follow smart; loop on; ants curved; dist 30
path	63.60,25.67	64.12,30.21	61.81,31.00	64.01,37.28	62.08,46.11
path	61.47,51.92	63.13,51.40	64.24,52.43	72.31,52.16	68.25,55.41
path	66.00,58.21	66.93,63.51	71.32,67.24	69.71,75.98	66.43,70.37
path	61.45,55.92	56.21,58.78	58.30,54.29	54.72,48.45	53.34,43.12
path	52.53,39.13	55.23,41.02	55.24,38.46	56.06,37.13	55.10,31.26
path	51.36,31.93	47.47,32.20	44.51,36.66	49.85,36.74	46.55,41.98
path	44.63,49.27	47.97,62.33	40.89,62.15	35.11,64.45	33.24,67.87
path	33.39,71.99	29.82,76.19	25.88,74.30	25.51,67.16	31.46,60.14
path	35.55,52.37	36.77,47.69	40.39,47.35	37.33,37.29	33.15,32.86
path	47.39,25.42	52.37,27.08	53.91,27.73	55.78,27.94	57.58,30.01
path	58.85,30.83	61.37,28.86	58.58,28.41	56.23,22.87	56.40,18.77
path	58.27,21.38	61.40,22.33	63.27,22.24
click Jelly Deposit##327516+
click Large Jelly Deposit##328429+
|tip They look like clusters of honeycomb on the ground all over Stormsong Valley.
|tip Exchange Jellies at the Honeyback Hivemother in the Honeyback Hatchery.
talk Honeyback Harvester##155069
|tip They will occasionally appear on your minimap as gold-colored stars.
|tip You will also see a patch of flowers illuminated by sunlight.
|tip This will spawn waves of enemies and sometimes a rare or elite.
|tip You will have 5 minutes to clear 15 waves.
|tip A large group with party buffs is beneficial.
Choose _<Makes some strange gestures.>_
Reach Exalted Reputation with the Honeyback Hive |condition rep("Honeyback Hive") == Exalted |or
|tip Feed the Jellies you collect to your Honeyback Harvester in the Honeyback Hatchery.
'|condition not completedq(57726) and rep("Honeyback Hive") < Exalted |or |next "Kill_Honey_Smasher_Exalted"
'|condition not hasbuff("spell:299445") and rep("Honeyback Hive") < Exalted |or |next "Gain_Beeholder's_Buff"
'|goto 62.87,26.53 < 300 |c |noway |only if haveanyquest(56473,56474,56092,56144,56475,56091) |or |next "Turnin_Honeyback_Harvester_Quests_Exalted"
step
label "Turnin_Honeyback_Harvester_Quests_Exalted"
talk Honeyback Hivemother##153365
|tip Inside the cave.
turnin Envenomed Spider Fang##56473 |goto 62.45,26.05 |only if havequest(56473)
turnin Hivekiller Stinger##56474 |goto 62.45,26.05 |only if havequest(56474)
turnin Hivethief's Jelly Stash##56092 |goto 62.45,26.05 |only if havequest(56092)
turnin Old Nasha's Paw##56144 |goto 62.45,26.05 |only if havequest(56144)
turnin Spiral Yeti Horn##56475 |goto 62.45,26.05 |only if havequest(56475)
turnin Usurper's Scent Gland##56091 |goto 62.45,26.05 |only if havequest(56091)
No Quest to Turn In |condition not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Hive") < Exalted |only if not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Hive") < Exalted |next "Reach_Exalted_Reputation" |or
'|condition rep("Honeyback Hive") == Exalted |or
step
_Congratulations!_
You are Exalted with the Honeyback Hive Faction.
]])
ZygorGuidesViewer:RegisterGuide("Reputations Guides\\Battle for Azeroth\\Honeyback Harvester",{
author="support@zygorguides.com",
keywords={"Bee"},
description="\nTo complete this guide, you will need to reach Exalted with the \"Honeyback Hive\" faction "..
"and farm Jelly to feed your Honeyback Harvester.",
condition_suggested=function() return level >= 120 and rep('Honeyback Harvester') == Mature end,
condition_valid=function() return achieved(13062) end,
condition_valid_msg="You must first earn the \"Let's Bee Friends\" achievement!",
condition_end=function() return rep("Honeyback Harvester") == Mature end,
},[[
leechsteps "Reputations Guides\\Battle for Azeroth\\Honeyback Hive" 1-19
step
label "Gain_Beeholder's_Buff"
use the Beeholder's Goggles##169109
Gain the "Beeholder's Goggles" Buff |havebuff spell:299445 |or
'|condition rep("Honeyback Harvester") == Mature |or
step
label "Kill_Honey_Smasher"
kill Honey Smasher##154154
|tip It walks up and down the coast around this area.
|tip Loot the corpse before you leave.
Defeat the Honey Smasher |q 57726 |goto Stormsong Valley/0 61.41,16.20 |future |or
'|condition rep("Honeyback Harvester") == Mature |or
step
label "Reach_Mature_Reputation"
map Stormsong Valley/0
path follow smart; loop on; ants curved; dist 30
path	63.60,25.67	64.12,30.21	61.81,31.00	64.01,37.28	62.08,46.11
path	61.47,51.92	63.13,51.40	64.24,52.43	72.31,52.16	68.25,55.41
path	66.00,58.21	66.93,63.51	71.32,67.24	69.71,75.98	66.43,70.37
path	61.45,55.92	56.21,58.78	58.30,54.29	54.72,48.45	53.34,43.12
path	52.53,39.13	55.23,41.02	55.24,38.46	56.06,37.13	55.10,31.26
path	51.36,31.93	47.47,32.20	44.51,36.66	49.85,36.74	46.55,41.98
path	44.63,49.27	47.97,62.33	40.89,62.15	35.11,64.45	33.24,67.87
path	33.39,71.99	29.82,76.19	25.88,74.30	25.51,67.16	31.46,60.14
path	35.55,52.37	36.77,47.69	40.39,47.35	37.33,37.29	33.15,32.86
path	47.39,25.42	52.37,27.08	53.91,27.73	55.78,27.94	57.58,30.01
path	58.85,30.83	61.37,28.86	58.58,28.41	56.23,22.87	56.40,18.77
path	58.27,21.38	61.40,22.33	63.27,22.24
click Jelly Deposit##327516+
click Large Jelly Deposit##328429+
|tip They look like clusters of honeycomb on the ground all over Stormsong Valley.
|tip Exchange Jellies at the Honeyback Hivemother in the Honeyback Hatchery.
talk Honeyback Harvester##155069
|tip They will occasionally appear on your minimap as gold-colored stars.
|tip You will also see a patch of flowers illuminated by sunlight.
|tip This will spawn waves of enemies and sometimes a rare or elite.
|tip You will have 5 minutes to clear 15 waves.
|tip A large group with party buffs is beneficial.
Choose _<Makes some strange gestures.>_
Reach Mature Reputation with the Honeyback Harvester |condition rep("Honeyback Harvester") == Mature |or
|tip Feed the Jellies you collect to your Honeyback Harvester in the Honeyback Hatchery.
'|condition not completedq(57726) and rep("Honeyback Harvester") < Mature |or |next "Kill_Honey_Smasher"
'|condition not hasbuff("spell:299445") and rep("Honeyback Harvester") < Mature |or |next "Gain_Beeholder's_Buff"
'|goto 62.87,26.53 < 300 |c |noway |only if haveanyquest(56473,56474,56092,56144,56475,56091) |or |next "Turnin_Honeyback_Harvester_Quests"
step
label "Turnin_Honeyback_Harvester_Quests"
talk Honeyback Hivemother##153365
|tip Inside the cave.
turnin Envenomed Spider Fang##56473 |goto 62.45,26.05 |only if havequest(56473)
turnin Hivekiller Stinger##56474 |goto 62.45,26.05 |only if havequest(56474)
turnin Hivethief's Jelly Stash##56092 |goto 62.45,26.05 |only if havequest(56092)
turnin Old Nasha's Paw##56144 |goto 62.45,26.05 |only if havequest(56144)
turnin Spiral Yeti Horn##56475 |goto 62.45,26.05 |only if havequest(56475)
turnin Usurper's Scent Gland##56091 |goto 62.45,26.05 |only if havequest(56091)
No Quest to Turn In |condition not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Hive") < Exalted |only if not haveanyquest(56473,56474,56092,56144,56475,56091) and rep("Honeyback Harvester") < Mature |next "Reach_Mature_Reputation" |or
'|condition rep("Honeyback Harvester") == Mature |or
step
Reach Exalted Reputation with the Honeyback Hive |condition rep("Honeyback Hive") == Exalted
|tip Use the "Honeyback Hive" reputation guide to accomplish this.
step
talk Honeyback Harvester##155745
|tip Inside the cave.
accept Leaving the Hive##56108 |goto 62.56,26.39
step
talk Barry##153393
Tell him _"One of the bees is acting strangely."_
Speak to Barry |q 56108/1 |goto 62.77,26.87 |future
step
talk Honeyback Harvester##155742
turnin Leaving the Hive##56108 |goto 62.85,26.49
]])
