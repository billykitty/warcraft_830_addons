Boomkinator = LibStub("AceAddon-3.0"):NewAddon("Boomkinator", "AceConsole-3.0", "AceEvent-3.0", "AceTimer-3.0")

local L = LibStub("AceLocale-3.0"):GetLocale("Boomkinator")
local LBG = LibStub("LibButtonGlow-1.0", true)

-- localize functions
local UnitGUID = _G.UnitGUID
local UnitExists = _G.UnitExists
local UnitBuff = _G.UnitBuff
local UnitDebuff = _G.UnitDebuff
local UnitClass = _G.UnitClass
local UnitPower = _G.UnitPower
local GetSpellInfo = _G.GetSpellInfo
local GetSpellCooldown = _G.GetSpellCooldown
local UnitHealth = _G.UnitHealth
local UnitHealthMax = _G.UnitHealthMax
local GetSpecialization = _G.GetSpecialization
local GetTalentInfo = _G.GetTalentInfo
local sformat = string.format
--
local settings
-- supported classes and specs
local talents = {
	["WARRIOR"] = {
--		[1] = "Arms",
	},
	["PALADIN"] = {
--		[3] = "Retribution",
	},
	["HUNTER"] = {
		[1] = "BeastMastery",
--		[2] = "Marksmanship",
	},
	["ROGUE"] = {
		[1] = "Assassination",
		[2] = "Outlaw",
		[3] = "Subtlety",
	},
	["PRIEST"] = {
		[3] = "Shadow",
	},
	["DEATHKNIGHT"] = {
	},
	["SHAMAN"] = {
		[2]	= "Enhancement",
	},
	["MAGE"] = {
		[1] = "Arcane",
	},
	["WARLOCK"] = {
		[1] = "Affliction",
		[2] = "Demonology",
		[3] = "Destruction",
	},
	["MONK"] = {
		[3] = "Windwalker",
	},
	["DRUID"] = {
		[1] = "Balance",
--		[2] = "Feral",
--		[4] = "Restoration",
	},
	["DEMONHUNTER"] = {
--		[1] = "Havoc",
--		[2] = "Vengeance"
	},
}

local updater = ""
local spells = {}
local icons = {}

local dicebox = {}
local classFlags = {}
local imps = {} -- imp timers
local impd = {} -- oldest imps

Boomkinator.Credits1 = "Boomkinator - by Aznamir (Lightbringer US)";

local bf = CreateFrame("Frame", "BoomkinatorFrame", UIParent);
bf:SetSize(150, 150)
bf:SetPoint("CENTER")
bf:SetFrameStrata("BACKGROUND")
--bf.texture = bf:CreateTexture("$parent_Texture")
--bf.texture:SetAllPoints()
--bf.texture:SetTexture(132303)
bf:SetMovable(true)
bf:RegisterForDrag("RightButton");
bf:SetScript("OnDragStart", function(self) self:StartMoving() end)
bf:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)

local sf = CreateFrame("Frame", "ShardFrame", UIParent);
sf:SetSize(150, 50)
sf:SetPoint("BOTTOMLEFT", bf, "TOPLEFT", 0, -39)
sf:SetFrameStrata("BACKGROUND")
local sh = {}
for i = 1, 5 do
sh[i] = CreateFrame("Frame", "$parent_"..i, sf)
sh[i]:SetSize(16, 16)
sh[i]:SetPoint("TOPLEFT", sf, "TOPLEFT", (i-1) * 22, 20)
sh[i].t=sh[i]:CreateTexture("$parent_Texture")
sh[i].t:SetAllPoints()
sh[i].t:SetTexture(134075)
end
local sh_frames = {0, 5, 8, 10, 8, 5, 0, -5, -8, -10, -8, -5}
local sh_pos ={1, 2, 3, 4, 5}

local btn = {}
local buttons = {}
local timers = {}
local stacks = {}

local btnpos = {[1] = {	[1] = {x = 0, y =  0}, [2] = {x = 1, y =  0}, [3] = {x = 2, y =  0}, [4] = {x = 3, y =  0}, [5] = {x = 4, y =  0}, 
                        [6] = {x = 5, y =  0}, [7] = {x = 6, y =  0}, [8] = {x = 7, y =  0}, [9] = {x = 8, y =  0}, [10]= {x = 9, y =  0},
					  },
				[2] = {	[1] = {x = 0, y =  0}, [2] = {x = 1, y =  0}, [3] = {x = 2, y =  0}, [4] = {x = 3, y =  0}, [5] = {x = 4, y =  0}, 
						[6] = {x = 0, y = -1}, [7] = {x = 1, y = -1}, [8] = {x = 2, y = -2}, [9] = {x = 3, y = -1}, [10]= {x = 4, y = -1},
					  },
				[3] = {	[1] = {x = 0, y =  0}, [2] = {x = 1, y =  0}, [3] = {x = 2, y =  0},
						[4] = {x = 0, y = -1}, [5] = {x = 1, y = -1}, [6] = {x = 2, y = -1},
						[7] = {x = 0, y = -2}, [8] = {x = 1, y = -2}, [9] = {x = 2, y = -2}, [10]= {x = 3, y = -2},
					  },
}
local colors = {["red"] 	= {1.0, 0.0, 0.0},
				["green"] 	= {0.0, 1.0, 0.0},
				["blue"] 	= {0.5, 1.0, 0.5},
				["white"]	= {1.0, 1.0, 1.0},
				}
local i
for i = 1, 10 do
	btn[i] = CreateFrame("Frame", "$parent_Button"..i, bf, "ActionBarButtonSpellActivationAlert")
	btn[i]:SetSize(32,32)
	btn[i]:SetPoint("TOPLEFT", bf, "TOPLEFT", btnpos[3][i].x * 32, btnpos[3][i].y * 32)
	buttons[i] = btn[i]:CreateTexture("$parent_Texture")
	buttons[i]:SetAllPoints()
	--buttons[i]:SetTexture(132303 + i)
	buttons[i]:SetVertexColor(1, 1, 1, 0.5)
	timers[i] = btn[i]:CreateFontString("$parent_Time" , "OVERLAY", "GameFontHighlightSmall")
	timers[i]:SetSize(32,16)
	timers[i]:SetPoint("BOTTOMLEFT", btn[i], "BOTTOMLEFT", 0, -1)
	timers[i]:SetJustifyH("RIGHT")
	timers[i]:SetText(i)
	stacks[i] = btn[i]:CreateFontString("$parent_Stack" , "OVERLAY", "GameFontHighlightSmall")
	stacks[i]:SetSize(32,16)
	stacks[i]:SetPoint("TOPLEFT", btn[i], "TOPLEFT", 0, -1)
	stacks[i]:SetJustifyH("RIGHT")
	stacks[i]:SetText("x"..i)
end
--LBG.ShowOverlayGlow(btn[1]) 
--bf:Hide()
-------------------------------------------------------------------
-- Interface settings
-------------------------------------------------------------------
Boomkinator.options =
{
	type = "group",
	name = "Boomkinator",
	args = {
		desc = {
			type = "description",
			order = 0,
			name = L["MOVE_DESC"],
		},
		reset = {
			type = "execute",
			order = 1,
			name = L["RESET"],
			desc = L["RESET_DESC"],
			func = function() Boomkinator:Reset() end,
		},
		show = {
			type = "execute",
			order = 2,
			name = L["SHOW"],
			desc = L["SHOW_DESC"],
			func = function() Boomkinator:ShowLayout() end,
		},
		hide = {
			type = "execute",
			order = 3,
			name = L["HIDE"],
			desc = L["HIDE_DESC"],
			func = function() Boomkinator:HideLayout() end,
		},
		lock = {
			type = "execute",
			order = 4,
			name = L["LOCK"],
			desc = L["LOCK_DESC"],
			func = function() 
					settings.locked = true
					Boomkinator:LockLayout() 
				end,
		},
		unlock = {
			type = "execute",
			order = 5,
			name = L["UNLOCK"],
			desc = L["UNLOCK_DESC"],
			func = function()
					settings.locked = false
					Boomkinator:UnlockLayout()
				end,
		},
		scale = {
			type = "range",
			order = 6,
			name = L["BSC"],
			desc = L["BSC_DESC"],
			min = 0.4,
			max = 1.5,
			step = 0.05,
			get = function(info) return settings.buffscale end,
			set = function(info, val)
					settings.buffscale = val
					Boomkinator:UpdateLayout()
				end,
		},
		fontscale = {
			type = "range",
			order = 7,
			name = "Font Scale",
			desc = "Scale of timer fonts", 
			min = 8,
			max = 14,
			step = 1,
			get = function(info) return settings.fontscale end,
			set = function(info, val)
					settings.fontscale = val
					Boomkinator:UpdateLayout()
				end,
		},
		rows = {
			type = "range",
			order = 8,
			name = "Display Rows",
			desc = "Number of button rows", 
			min = 1,
			max = 3,
			step = 1,
			get = function(info) return settings.rows end,
			set = function(info, val)
					settings.rows = val
					Boomkinator:UpdateLayout()
				end,
		},
		power = {
			type = "execute",
			order = 9,
			name = L["ANIMATE"],
			desc = L["ANIMATE_DESC"],
			func = function()
					settings.animate = not settings.animate
				end,
		},
		spellcheck = {
			type = "execute",
			order = 10,
			name = "spellcheck",
			desc = "spellcheck",
			func = function() Boomkinator:CheckSpells() end,
		},
	},
}
-------------------------------------------------------------------
-- Default Settings
-------------------------------------------------------------------
Boomkinator.defaults = {
	profile = {
		buffscale = 0.9,
		fontscale = 10,
		locked = false,
		disabled = false,
		rows = 3,
		animate = false,
	}
}
-------------------------------------------------------------------
-- Ace Framework Events
-------------------------------------------------------------------
function Boomkinator:OnInitialize()
	--self:Print("OnInitialize")
	DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99"..Boomkinator.Credits1.."|r")
	self.db = LibStub("AceDB-3.0"):New("BoomkinatorDB", Boomkinator.defaults, "Default")
	self.db.RegisterCallback(self, "OnProfileChanged", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileCopied", "OnProfileChanged")
	self.db.RegisterCallback(self, "OnProfileReset", "OnProfileChanged")
	settings = self.db.profile
	Boomkinator.options.args.profiles = LibStub("AceDBOptions-3.0"):GetOptionsTable(self.db)

	LibStub("AceConfig-3.0"):RegisterOptionsTable("Boomkinator", Boomkinator.options, "boom")
	self.optionsFrame = LibStub("AceConfigDialog-3.0"):AddToBlizOptions("Boomkinator", "Boomkinator")

	self:UpdateLayout()
end

function Boomkinator:OnProfileChanged()
	--self:Print("OnProfileChanged")
	settings = self.db.profile
	self:UpdateLayout()
end

function Boomkinator:OnEnable()
	--self:Print("OnEnable")
	settings.disabled = false
	self:RegisterEvent("PLAYER_REGEN_ENABLED")
	self:RegisterEvent("PLAYER_REGEN_DISABLED")
	--self:RegisterEvent("ACTIVE_TALENT_GROUP_CHANGED")
	self:RegisterEvent("PLAYER_TALENT_UPDATE")
	--self:RegisterEvent("ENCOUNTER_START")
	--self:RegisterEvent("ENCOUNTER_END")
	self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
	self:UpdateLayout()
end

function Boomkinator:OnDisable()
	--self:Print("OnDisable")
	-- events
	settings.disabled = true
	self:UpdateLayout()
end

function Boomkinator:MediaUpdate()

end
-------------------------------------------------------------------
-- Service Functions
-------------------------------------------------------------------
function Boomkinator:FormatTime(time)
	if not time or time < 0 or time == 9999 then
		return ""
	end
	local mins = floor(time / 60)
	local secs = time - (mins * 60)
	return sformat("%d:%02d", mins, secs)
end

function Boomkinator:FormatShort(time)
	if not time or time < 0 or time == 9999 then
		return ""
	end
	return sformat("%0.1f", time)
end

function Boomkinator:ReadableNumber(num, places)
    local ret
    local placeValue = ("%%.%df"):format(places or 0)
    if not num then
        return 0
    elseif num >= 1000000000000 then
        ret = placeValue:format(num / 1000000000000) .. " T" -- trillion
    elseif num >= 1000000000 then
        ret = placeValue:format(num / 1000000000) .. " B" -- billion
    elseif num >= 1000000 then
        ret = placeValue:format(num / 1000000) .. " M" -- million
    elseif num >= 1000 then
        ret = placeValue:format(num / 1000) .. "K" -- thousand
    else
        ret = num -- hundreds
    end
    return ret
end
-------------------------------------------------------------------
-- Command Prompt Response
-------------------------------------------------------------------
function Boomkinator:Reset()
	bf:ClearAllPoints()
	bf:SetPoint("CENTER")
end

function Boomkinator:Debug()
	self:Print("Spells:")
	for i = 1, 20 do
		self:Print("  " .. i .. " = " .. (spells[i] or ""))
	end
	self:Print("Icons:")
	for i = 1, 10 do
		self:Print("  " .. i .. " = " .. (icons[i] or ""))
	end
end
-------------------------------------------------------------------
-- Internal Functions
-------------------------------------------------------------------

-------------------------------------------------------------------
-- External Event Handling
------------------------------------------------------------------
function Boomkinator:PLAYER_REGEN_ENABLED()
	--self:Print("Regen Enabled")
	self:CancelTimer(self.UpdateTimer, true)
	self:HideLayout()
end

function Boomkinator:PLAYER_REGEN_DISABLED()
	--self:Print("Regen Disabled")

	if updater == "" then
		--self:Print("Entered combat without settings, trying to fix UI")
		self:UpdateLayout()
	end
	
	if updater ~= "" then
		--self:Print(updater)
		self.UpdateTimer = self:ScheduleRepeatingTimer(updater, 0.1)
		self:ShowLayout()
	end
end

function Boomkinator:ACTIVE_TALENT_GROUP_CHANGED()
	self:UpdateLayout()
end

function Boomkinator:PLAYER_TALENT_UPDATE()
	self:UpdateLayout()
end

function Boomkinator:COMBAT_LOG_EVENT_UNFILTERED(event, ...)
	local spellName
	local timestamp, subEvent, hideCaster, sourceGUID, sourceName, sourceFlags, sourceRaidFlags, destGUID, destName, destFlags, destRaidFlag, spellId = CombatLogGetCurrentEventInfo()
	if (sourceGUID == UnitGUID("player") and updater == "ButtonsDemonology") then
		if subEvent == "SPELL_SUMMON" then
			if spellId == 104317 or spellId == 279910 then -- summoned a wild imp
				imps[destGUID] = {[1] = GetTime() + 20, 	-- expiration timer
								  [2] = 100 				-- power
								 }
			elseif spellId == 265187 then -- summoned tyrant
				if select(4, GetTalentInfo(7, 2, 1)) then  -- demonic consumption kills imps
					imps = {} -- clean up imp list
					impd = {} -- clean up oldest imps
				else
					-- extend all imps by 15 sec
					for k, v in pairs(imps) do
						imps[k][1] = imps[k][1] + 15
					end
					if impd[1] then impd[1][1] = impd[1][1] + 15 end
					if impd[2] then impd[2][1] = impd[2][1] + 15 end
				end
			end
		elseif subEvent == "SPELL_CAST_SUCCESS" then
			if spellId == 264130 then -- power siphon kills 2 oldest imps
				--Boomkinator:Print("event: " .. subEvent .. " source: " .. sourceGUID .. " dest: " .. (destGUID or 0))
				if impd[1] then imps[impd[1][2]] = nil end
				if impd[2] then imps[impd[2][2]] = nil end
				impd = {}
			elseif spellId == 196277 then -- implosion, ripperoni
				imps = {}
				impd = {}
			end
		end
	elseif imps[sourceGUID] and subEvent == "SPELL_CAST_SUCCESS" then
		spellName = Boomkinator:BuffSearch("player", GetSpellInfo(265273), "PLAYER") -- Demonic Power buff
		if not spellName then -- casting firebolts w/o tyrant present
			imps[sourceGUID][2] = imps[sourceGUID][2] - 20	-- deplete enegry
			imps[sourceGUID][1] = imps[sourceGUID][1] - 2  	-- decrease time to live
			if imps[sourceGUID][2] == 0 then
				-- dead
				imps[sourceGUID] = nil
			end
		end
	--else
	--	Boomkinator:Print("event: " .. subEvent .. " source: " .. sourceGUID .. " dest: " .. (destGUID or 0))
	end
end

-------------------------------------------------------------------
-- Internal Functions
-------------------------------------------------------------------

function Boomkinator:CheckTalents()
	local _, class = UnitClass("player")
	local spec = GetSpecialization()
	local name, i
	if talents[class] then
		name = talents[class][spec]
	end

	if name then
		updater = "Buttons"..name
		for i = 1, 20, 1 do
			spells[i] = Boomkinator.Spells[name][i]
		end
	else
		updater = ""
	end
end

function Boomkinator:DebuffSearch(target, spellName, filter)
	for i = 1, 40 do
		local name, _, count, _, duration, expirationTime = UnitDebuff(target, i, filter);
		if name and name == spellName then
			return name, count, duration, expirationTime
		end
	end
	return nil, nil, nil, nil
end

function Boomkinator:BuffSearch(target, spellName, filter)
	for i = 1, 40 do
		local name, _, count, _, duration, expirationTime = UnitBuff(target, i, filter);
		if name and name == spellName then
			return name, count, duration, expirationTime
		end
	end
	return nil, nil, nil, nil
end

function Boomkinator:DoTheThing(thing, slot, ...)
-- thing, slot, parameters
-- 1, x, power
-- self buff
-- 2, x, target, spell, coloring_method(1, -1, 0), show_stacks(1, -1), stacks_max
-- debuff
-- 3, x, target, spell, coloring_method(1, -1, 0), recast time (seconds)
-- simple cooldown
-- 4, x, spell, shorttimer
-- conditional debuff on target
-- 5, x, target, spell, method, condition
-- conditional cooldown
-- 6, x, spell, condition, shorttimer
-- rechargeable spell
-- 7, x, spell, duration(1 for long), condition
	local target, spell, power, powerlimit, condition, method, show_stacks, shorttimer, stacks_max
	local start, duration, expire
	--local buffName, buffCount, buffDuration, buffExpire
	
	-- power check
	-- 1, x, power
	if thing == 1 then
		power = select(1, ...)
		stacks[slot]:SetText("x"..(power or "0"))
	-- self buff expiration
	-- 2, x, target, spell, method, shows tacks
	elseif thing == 2 then
		target = select (1, ...)
		spell = select(2, ...)
		method = select(3, ...)
		show_stacks = select(4, ...)
		stacks_max = select(5, ...)
		spellName = GetSpellInfo(spell)
		--buffName, _, _, buffCount, _, buffDuration, buffExpire = UnitBuff(target, spellName)
		local buffName, buffCount, buffDuration, buffExpire = Boomkinator:BuffSearch(target, spellName)
		if buffName and buffExpire then
			expire = buffExpire - GetTime()
			timers[slot]:SetText(Boomkinator:FormatShort(expire))
			-- stack counts
			if show_stacks == 1 then
				if buffCount then
					stacks[slot]:SetText("x" .. buffCount)
					if stacks_max and stacks_max > 0 then
					-- color stacks
						if buffCount == stacks_max then
							stacks[slot]:SetTextColor(1, 0, 0, 1)
						else
							stacks[slot]:SetTextColor(0, 1, 0, 1)
						end
					end
				else
					stacks[slot]:SetText("")
				end
			end
			-- highlight method
			if method == 1 then
				buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
			elseif method == -1 then
				buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
			end
		else
			if show_stacks == 1 then
				stacks[slot]:SetText("")
			end
			if method == 1 then 
				buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
			elseif method == -1 then
				buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
			end
			timers[slot]:SetText("")
		end
		return buffCount
	 -- debuff on target
	 -- 3, x, target, spell, method, refresh_timer
	elseif thing == 3 then
		target = select (1, ...)
		spell = select(2, ...)
		method = select(3, ...)
		shorttimer = select(4, ...) 
		if UnitExists(target) and spell then
			spellName = GetSpellInfo(spell)
			local _, _, buffDuration, buffExpire = Boomkinator:DebuffSearch(target, spellName, "PLAYER")
			if buffExpire then
				expire = buffExpire - GetTime()
				timers[slot]:SetText(Boomkinator:FormatShort(expire))
				if shorttimer and shorttimer > expire then -- need to refresh
					timers[slot]:SetTextColor(1, 0, 0, 1)
				else
					timers[slot]:SetTextColor(0.5, 1, 0.5, 1)
				end
				if method == 1 then
					if LBG then
						LBG.HideOverlayGlow(btn[slot]) 
					else
						buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
					end
				elseif method == -1 then
					if LBG then
						LBG.ShowOverlayGlow(btn[slot])
					else
						buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
					end
				end
			else
				timers[slot]:SetText("")
				if method == 1 then
					if LBG then
						LBG.ShowOverlayGlow(btn[slot])
					else
						buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
					end 
				elseif method == -1 then
					if LBG then
						LBG.HideOverlayGlow(btn[slot]) 
					else
						buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
					end 
				end
			end
		else
			timers[slot]:SetText("")
			if method == 1 then
				if LBG then
					LBG.HideOverlayGlow(btn[slot]) 
				else
					buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
				end 
			elseif method == -1 then
				if LBG then
					LBG.ShowOverlayGlow(btn[slot])
				else
					buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
				end 
			end
		end
	-- simple cooldown
	-- 4, x, spell, shorttimer
	elseif thing == 4 then
		spell = select(1, ...)
		shorttimer = select(2, ...)
		spellName = GetSpellInfo(spell)
		if spellName then
			start, duration = GetSpellCooldown(spellName)
			if start then
				if start == 0 or (start > 0 and duration < 1.5 ) then
					timers[slot]:SetText("")
					--LBG.ShowOverlayGlow(btn[slot])
					buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
				else
					-- on cooldown
					expire = start + duration - GetTime()
					if shorttimer == 1 then
						timers[slot]:SetText(Boomkinator:FormatShort(expire))
					else
						timers[slot]:SetText(Boomkinator:FormatTime(expire))
					end
					--LBG.HideOverlayGlow(btn[slot])
					buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
				end
			else
				timers[slot]:SetText("NA")
				--LBG.HideOverlayGlow(btn[slot])
				buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
			end
		end
	-- conditional debuff on target
	-- 5, x, target, spell, method, condition
	elseif thing == 5 then
		target = select (1, ...)
		spell = select(2, ...)
		method = select(3, ...)
		condition = select(4, ...)
		if UnitExists(target) and spell then
			spellName = GetSpellInfo(spell)
			local _, _, buffDuration, buffExpire = Boomkinator:DebuffSearch(target, spellName, "PLAYER")
			if buffExpire then
				expire = buffExpire - GetTime()
				timers[slot]:SetText(Boomkinator:FormatShort(expire))
				if method == 1 then
					buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
				elseif method == -1 then
					buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
				end
			else
				timers[slot]:SetText("")
				if condition then
					if method == 1 then
						buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
					elseif method == -1 then
						buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
					end
				else
					if method == 1 then
						buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
					elseif method == -1 then
						buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
					end
				end
			end
		else
			timers[slot]:SetText("")
			if method == 1 then
				buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
			elseif method == -1 then
				buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
			end
		end
	-- conditional cooldown
	-- 6, x, spell, condition, shorttimer
	elseif thing == 6 then 
		spell = select(1, ...)
		condition = select(2, ...)
		shorttimer = select(3, ...)
		if spell then
			start, duration = GetSpellCooldown(GetSpellInfo(spell))
			if start then
				if (start == 0 or (start > 0 and duration < 1.5 )) then
					timers[slot]:SetText("")
					if condition then
						buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
					else
						buttons[slot]:SetVertexColor(1, 1, 1, 0.5)
					end
				else
					-- on cooldown
					expire = start + duration - GetTime()
					if shorttimer == 1 then 
						timers[slot]:SetText(Boomkinator:FormatShort(expire))
					else
						timers[slot]:SetText(Boomkinator:FormatTime(expire))
					end
					buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
				end
			else
				timers[slot]:SetText("NA")
				buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
			end
		end
	-- rechargeable spell
	-- 7, x, spell, duration(1 for short)		
	elseif thing == 7 then
		spell = select(1, ...)
		shorttimer = select(2, ...)
		condition = select(3, ...)
		spellName = GetSpellInfo(spell)
		local buffCount, _, _, _ = GetSpellCharges(spellName)
		if buffCount then
			if  (buffCount > 0 and condition) then
				stacks[slot]:SetText("x" .. buffCount)
				timers[slot]:SetText("")
				if buffCount > 2 then
					buttons[slot]:SetVertexColor(1, 1, 1, 1)
				elseif buffCount == 2 then
					buttons[slot]:SetVertexColor(1, 1, 1, 0.75)			
				elseif buffCount == 1 then			
					buttons[slot]:SetVertexColor(1, 1, 1, 0.50)
				end
			else
				stacks[slot]:SetText("")
				buttons[slot]:SetVertexColor(1, 1, 1, 0.3)
				--check cooldown for next
				start, duration = GetSpellCooldown(spellName)
				if start then
					if start == 0 or (start > 0 and duration < 1.5 ) then
						timers[slot]:SetText("")
					else
						expire = start + duration - GetTime()
						if shorttimer == 0 then
							timers[slot]:SetText("")
						elseif shorttimer == 1 then
							timers[slot]:SetText(Boomkinator:FormatShort(expire))
						else
							timers[slot]:SetText(Boomkinator:FormatTime(expire))
						end
					end
				end
			end -- buff count
		end	-- buff exists
	end -- if thing
end -- do the thing

-- new version
function Boomkinator:Decorator(arr)
--[=====[
{	
	["slot"] = 1,
	["decor"] = 2,
	["target"] = "target",
	["spell"] = 12345,
	--["decor_method"] = "normal" -- normal - highlight when missing, reverse - highlight when active, none - do nothing
	["glow"] = true,
	["condition"] = true
	["timer"] = "short" -- or "long"
	["refresh_timer"]= 5.2
	["show_stacks"] = true
	["stacks_max"] = 3
	["power"] = 100
}
--]=====]
	--Boomkinator:Print(arr)
	local slot = arr["slot"]
	local decor = arr["decor"]
	local target = arr["target"]
	local spell = arr["spell"]
	--local decor_method = arr["decor_method"]
	local glow = arr["glow"]
	local condition = arr["condition"]
	local timer = arr["timer"]
	local refresh_timer = arr["refresh_timer"]
	local show_stacks = arr["show_stacks"]
	local stacks_max = arr["stacks_max"]
	local power = arr["power"]
	
	local buffName, buffCount, buffDuration, buffExpire
	local spellName, start, duration, expire, timefn, unit_exists
	-- decorator settings
	local stack_text, stack_color, timer_text, timer_color, highlight
	
	if spell then spellName = GetSpellInfo(spell) end
	if target then unit_exists = UnitExists(target) end

	if decor == "power_display" then
		stack_text = "x" .. (power or "0")
	elseif decor == "simple_buff" then
		buffName, buffCount, buffDuration, buffExpire = Boomkinator:BuffSearch(target, spellName)
		if buffName and buffExpire then
			highlight = false
			expire = buffExpire - GetTime()
			timer_text = Boomkinator:FormatShort(expire)
			timer_color = colors["white"]
			if show_stacks and buffCount then
				stack_text = "x" .. buffCount
				if (stacks_max or 0) > 0 then
					if buffCount == stacks_max then
						stack_color = colors["red"]
					else
						stack_color = colors["green"]
					end
				else
					stack_color = colors["white"]
				end
			else
				stack_text = ""
				stack_color = colors["white"]
			end
		else
			highlight = true
			timer_text = ""
			timer_color = colors["white"]
			stack_text = ""
			stack_color = colors["white"]
		end		
	elseif decor == "simple_debuff" then
		if unit_exists and spellName then
			local _, _, buffDuration, buffExpire = Boomkinator:DebuffSearch(target, spellName, "PLAYER")
			if buffExpire then
				highlight = false
				expire = buffExpire - GetTime()
				timer_text = Boomkinator:FormatShort(expire)
				if refresh_timer and refresh_timer > expire then
					timer_color = colors["red"]
				else
					timer_color = colors["blue"]
				end
			else
				highlight = true
				timer_text = ""
			end
		else
			highlight = false
			timer_text = ""
		end
	end
	Boomkinator:DecorateButton( slot, highlight, glow, 
								timer_text, timer_color, 
								stack_text, stack_color)
end

function Boomkinator:DecorateButton(slot, highlight, glow, 
								timer_text, timer_color, 
								stack_text, stack_color)
	if timer_text then
		timers[slot]:SetText(timer_text)
		if timer_color then
			timers[slot]:SetTextColor(timer_color[1], timer_color[2], timer_color[3], timer_color[4])
		end
	else
		timers[slot]:SetText("")
	end
	
	if stack_text then
		stacks[slot]:SetText(stack_text)
		if stack_color then
			stacks[slot]:SetTextColor(stack_color[1], stack_color[2], stack_color[3], stack_color[4])
		end
	else
		stacks[slot]:SetText("")
	end
	
	if glow and highlight then
		LBG.ShowOverlayGlow(btn[slot])
	elseif glow and not highlight then
		LBG.HideOverlayGlow(btn[slot])
	elseif not glow and highlight then
		buttons[slot]:SetVertexColor(1, 1, 1, 0.75)
	elseif not glow and not highlight then
		buttons[slot]:SetVertexColor(1, 1, 1, 0.25)
	end
end

function Boomkinator:TalentSelector(row1, col1, id1, -- primary choice for the icon
									row2, col2, id2, -- secondary choice for the icon
									id3				 -- default fall-back
									)
	if not select(4, GetTalentInfo(row1, col1, 1)) then
		if id2 and select(4, GetTalentInfo(row2, col2, 1)) then
			-- secondari preference
			return id2, select(3, GetSpellInfo(id2)), 2
		else 
			-- default option
			return id3, select(3, GetSpellInfo(id3)), 3
		end
	else
		-- main preference
		return id1, select(3, GetSpellInfo(id1)), 1
	end
	return nil, nil, nil
end
-------------------------------------------------------------------
-- Buff UI Setup
-------------------------------------------------------------------
function Boomkinator:UpdateLayout()
	--self:Print("Update Layout")
	local spellName, spellIcon, spellSelected, spellID, i, choice
	self:CheckTalents()
	--self:Print(updater)
	icons = {}
	-- set default icons for 10 buttons
	if updater then
		for i = 1, 10, 1 do
			icons[i] = select(3, GetSpellInfo(spells[i]))
		end
	end
	for i = 1, 5 do
		sh[i]:Hide()
	end
	-- talent customizations
	if updater == "ButtonsAssassination" then
		-- exsang vs toxic blade vs nothing
		spells[7], icons[7] = Boomkinator:TalentSelector(6, 3, spells[7], 6, 2, spells[17])
	elseif updater == "ButtonsOutlaw" then
		-- ghostly strike
		spells[10],icons[10]= Boomkinator:TalentSelector(1, 3, spells[10])
		-- slice and dice
		spells[7], icons[7] = Boomkinator:TalentSelector(6, 3, spells[17])
		--loading the dice box
		for i = 1, 6, 1 do
			dicebox[spells[10+i]] = select(3, GetSpellInfo(spells[10+i]))
		end
	elseif updater == "ButtonsSubtlety" then
		-- secret technique
		spells[6], icons[6] = Boomkinator:TalentSelector(7, 2, spells[6])
	elseif updater == "ButtonsBalance" then
		-- spell flare
		spells[2], icons[2] = Boomkinator:TalentSelector(6, 3, spells[2])
		-- incarnation
		spells[8], icons[8] = Boomkinator:TalentSelector(5, 3, spells[8], 5, 2, spells[11])
	elseif updater == "ButtonsAffliction" then
		-- deathbolt
		spells[7], icons[7] = Boomkinator:TalentSelector(1, 3, spells[7])
		-- siphon
		spells[3], icons[3] = Boomkinator:TalentSelector(2, 3, spells[3])
		-- ps / taint
		spells[8], icons[8] = Boomkinator:TalentSelector(4, 2, spells[8], 4, 3, spells[11])
		-- haunt
		spells[4], icons[4] = Boomkinator:TalentSelector(6, 2, spells[4])
		-- dsm
		spells[9], icons[9] = Boomkinator:TalentSelector(7, 3, spells[9])
	elseif updater == "ButtonsDemonology" then
		-- bombers
		spells[1], icons[1] = Boomkinator:TalentSelector(1, 3, spells[1], 1, 2, spells[11])
		-- doom, power siphon, demonic calling
		spells[3], icons[3] = Boomkinator:TalentSelector(2, 3, spells[3], 2, 2, spells[13])
		-- nether portal
		--spells[6], icons[6] = Boomkinator:TalentSelector(7, 3, spells[6])
		-- vilefiend
		spells[7], icons[7] = Boomkinator:TalentSelector(4, 3, spells[7], 4, 2, spells[17])
		-- grimoire
		spells[8], icons[8] = Boomkinator:TalentSelector(6, 3, spells[8])
	elseif updater == "ButtonsDestruction" then
		-- shadow burn
		spells[2], icons[2] = Boomkinator:TalentSelector(2, 3, spells[2])
		-- soul fire
		spells[3], icons[3] = Boomkinator:TalentSelector(1, 3, spells[3])
		-- channel demonfire
		spells[6], icons[6] = Boomkinator:TalentSelector(7, 2, spells[6])
		-- cataclysm
		spells[7], icons[7] = Boomkinator:TalentSelector(4, 3, spells[7])
		-- dark soul: instability
		spells[9], icons[9] = Boomkinator:TalentSelector(7, 3, spells[9])
	elseif updater == "ButtonsEnhancement" then
		-- earthen spike
		spells[9], icons[9] = Boomkinator:TalentSelector(7, 2, spells[9])
		-- sundering
		spells[10],icons[10]= Boomkinator:TalentSelector(6, 3, spells[10])
	elseif updater == "ButtonsShadow" then
		classFlags["PRIEST"] = {}
		-- dark void
		spells[4], icons[4] = Boomkinator:TalentSelector(3, 3, spells[4])
		-- sw:d vs shadow crash vs nothing
		spells[6], icons[6] = Boomkinator:TalentSelector(5, 2, spells[6], 5, 3, spells[16])
		-- mindbender
		spells[7], icons[7] = Boomkinator:TalentSelector(6, 2, spells[17], nil, nil, nil, spells[7]) 
		-- void torrent
		spells[8], icons[8] = Boomkinator:TalentSelector(6, 3, spells[8], nil, nil, nil, nil)
		-- ascension vs surrender
		spells[9], icons[9], choice = Boomkinator:TalentSelector(7, 3, spells[9], 7, 2, spells[19])
		if choice == 3 then
			classFlags["PRIEST"]["Legacy of the Void"] = true
		end
	elseif updater == "ButtonsArcane" then
		classFlags["MAGE"] = {}
		-- charged up vs supernova
		spells[5], icons[5] = Boomkinator:TalentSelector(4, 2, spells[5], 4, 3, spells[15])
		-- incanter's flow vs mirror image vs rune of power
		spells[6], icons[6], choice = Boomkinator:TalentSelector(3, 1, spells[3], 3, 2, spells[17], spells[18])
		if choice == 1 then
			classFlags["MAGE"]["Incanter's Flow"] = true
		elseif choice == 2 then
			classFlags["MAGE"]["Mirror Image"] = true
		else
			classFlags["MAGE"]["Rune of Power"] = true
		end
		-- arcane orb
		spells[9], icons[9] = Boomkinator:TalentSelector(7, 3, spells[9])
	elseif updater == "ButtonsWindwalker" then
		classFlags["MONK"] = {}
		-- chi burst vs chi wave vs nothing
		spells[2], icons[2] = Boomkinator:TalentSelector(1, 3, spells[2], 1, 2, spells[12])
		-- fists of wt vs energizing elixir vs nothing
		spells[6], icons[6] = Boomkinator:TalentSelector(3, 2, spells[6], 3, 3, spells[16])
		-- xuen vs rushing jade wind vs nothing
		spells[7], icons[7] = Boomkinator:TalentSelector(6, 3, spells[7], 6, 2, spells[17])
		-- serenity vs whirling punch vs nothing
		spells[8], icons[8] = Boomkinator:TalentSelector(7, 3, spells[8], 7, 2, spells[18], spells[19])
		-- roll vs chi torpedo
		spells[10],icons[10]= Boomkinator:TalentSelector(2, 2, spells[20], nil, nil, nil, spells[10])
	elseif updater == "ButtonsBeastMastery" then	
		spells[3], icons[3] = Boomkinator:TalentSelector(4, 3, spells[13], nil, nil, nil)
		spells[9], icons[9] = Boomkinator:TalentSelector(2, 3, spells[19], nil, nil, nil)
	end
	--[=====[
	elseif updater == "ButtonsFeral" then
		spellSelected = select(4, GetTalentInfo(1, 3, 1))
		if not spellSelected then
			spells[5] = nil
			icons[5] = nil
		end
		spellSelected = select(4, GetTalentInfo(5, 2, 1))
		if spellSelected then
			spells[7] = spells[17]
			icons[7] = select(3, GetSpellInfo(spells[7]))
		end
	elseif updater == "ButtonsHavoc" then
		spellSelected = select(4, GetTalentInfo(7, 3, 1))
		if spellSelected then -- track nemesis instead
			spells[10] = spells[12]
			icons[10] = select(3, GetSpellInfo(spells[10]))
			slice = true
		else
			slice = select(4, GetTalentInfo(7, 1, 1))
			if slice then
				spells[10] = spells[11]
				icons[10] = select(3, GetSpellInfo(spells[10]))
			end
		end
	elseif updater == "ButtonsBeastMastery" then
		--90 talent
		spellSelected = select(4, GetTalentInfo(6, 2, 1))
		if spellSelected then --barrage
			spells[3] = spells[11] 
			icons[3] = select(3, GetSpellInfo(spells[3]))
		end
		spellSelected = select(4, GetTalentInfo(6, 3, 1))
		if spellSelected then -- volley, not tracking
			spells[3] = nil
			icons[3] = nil
		end
		--100 talent
		spellSelected = select(4, GetTalentInfo(7, 1, 1))
		if not spellSelected then -- nothing to track
			spells[9] = nil
			icons[9] = nil
		end
	elseif updater == "ButtonsMarksmanship" then
		--90 talent
		spellSelected = select(4, GetTalentInfo(6, 2, 1))
		if spellSelected then --barrage
			spells[3] = spells[11] 
			icons[3] = select(3, GetSpellInfo(spells[3]))
		end
		spellSelected = select(4, GetTalentInfo(6, 3, 1))
		if spellSelected then -- volley, not tracking
			spells[3] = nil
			icons[3] = nil
		end
	elseif updater == "ButtonsRetribution" then
		spellSelected = select(4, GetTalentInfo(4, 3, 1))
		if spellSelected then
			spells[5] = spells[15]
			icons[5] = select(3, GetSpellInfo(spells[5]))
		end
	end
	--]=====]
	
	if updater then
		for i = 1, 10 do
			btn[i]:SetPoint("TOPLEFT", bf, "TOPLEFT", btnpos[settings.rows][i].x * 32, btnpos[settings.rows][i].y * 32)	
			buttons[i]:SetTexture(icons[i])
			timers[i]:SetText("")
			timers[i]:SetTextColor(1, 1, 1, 1)
			timers[i]:SetFont("Fonts\\FRIZQT__.TTF", settings.fontscale, "OUTLINE")
			stacks[i]:SetText("")
			stacks[i]:SetTextColor(1, 1, 1, 1)
			stacks[i]:SetFont("Fonts\\FRIZQT__.TTF", settings.fontscale, "OUTLINE")
		end
	end
	
	bf:SetScale(settings.buffscale)
	self:HideLayout()

	if settings.locked then
		Boomkinator:LockLayout()
	else
		Boomkinator:UnlockLayout()
	end
end

function Boomkinator:ShowLayout()
	bf:Show()
	sf:Show()
end

function Boomkinator:HideLayout()
	bf:Hide()
	sf:Hide()
end

function Boomkinator:LockLayout()
	bf:EnableMouse(false)
end

function Boomkinator:UnlockLayout()
	bf:EnableMouse(true)
end

function Boomkinator:GetSeverityColor(percent)
	if (percent >= 0.5) then
		return (1.0-percent)*2, 1.0, 0.0
	else
		return 1.0, percent*2, 0.0
	end
end

function Boomkinator:AnimateShards()
	-- custom shite
	local power = UnitPower("player", 7)
	for i = 1, 5 do
		if i <= power then
			sh[i]:Show()
		else
			sh[i]:Hide()
		end
		if power == 5 then
			sh[i]:SetPoint("TOPLEFT", sf, "TOPLEFT", (i-1) * 22, 20 + sh_frames[sh_pos[i]])
			sh_pos[i] = sh_pos[i]+1
			if sh_pos[i] > 12 then sh_pos[i]=1 end
		else
			sh[i]:SetPoint("TOPLEFT", sf, "TOPLEFT", (i-1) * 22, 20)
		end
	end
end
-------------------------------------------------------------------
-- Class Functionality: Warlock Affliction
-------------------------------------------------------------------
function Boomkinator:ButtonsAffliction()
	local i, expire, minUA, cntUA
	-- soul shards
	--Boomkinator:DoTheThing(1, 4, UnitPower("player", 7))
	--stacks[4]:SetTextColor(0, 1, 1, 1)
	--buttons[4]:SetVertexColor(1, 1, 1, 0.5)

	--check agony
	Boomkinator:DoTheThing(3, 1, "target", spells[1], 1, 5.4)
	--check corruption
	Boomkinator:DoTheThing(3, 2, "target", spells[2], 1, 4.2)
	-- siphon
	Boomkinator:DoTheThing(3, 3, "target", spells[3], 1, 4.5)
	--check haunt (cooldown)
	Boomkinator:DoTheThing(4, 4, spells[4], 1)
	-- check unstable affliction
	if UnitExists("target") then
		UA = GetSpellInfo(spells[5])
		minUA = 9999
		cntUA = 0
		for i = 1, 40 do
			local name, _, _, _, _, expirationTime = UnitDebuff("target", i, "PLAYER")
			if name and name == UA and expirationTime then
				cntUA = cntUA + 1
				expire = expirationTime - GetTime()
				if expire < minUA then
					minUA = expire
				end
			end
		end
		if cntUA > 0 then
			stacks[5]:SetText("x" .. cntUA)
			stacks[5]:SetTextColor(0, 1, 1, 1)
			timers[5]:SetText(Boomkinator:FormatShort(minUA))
			if LBG then
				LBG.HideOverlayGlow(btn[5])
			else
				buttons[5]:SetVertexColor(1, 1, 1, 0.5)
			end
		else
			stacks[5]:SetText("")
			timers[5]:SetText("")
			if LBG then 
				LBG.ShowOverlayGlow(btn[5])
			else
				buttons[5]:SetVertexColor(1, 1, 1, 0.75)
			end
		end
	end
	-- Darkglare
	Boomkinator:DoTheThing(4, 6, spells[6], -1)
	-- deathbolt
	Boomkinator:DoTheThing(4, 7, spells[7], -1)	
	-- ps or vile taint
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	-- ps
	Boomkinator:DoTheThing(4, 9, spells[9], -1)

	if settings.animate then Boomkinator:AnimateShards() end
end
-------------------------------------------------------------------
-- Class Functionality: Warlock Demonology
-------------------------------------------------------------------
function Boomkinator:ButtonsDemonology()
    local power = UnitPower("player" , 7)  -- SPELL_POWER_SOUL_SHARDS
	local spellName, spellIcon, buffName, buffCount, buffDuration, buffExpire
	local impcount = 0
	local expire
	local time = GetTime()
	if not (impd[1] and imps[impd[1][2]]) then
		impd[1] = { [1] = time + 100,
		            [2] = "Z",
		}
	end
	if not (impd[2] and imps[impd[2][2]]) then
		impd[2] = { [1] = time + 100,
		            [2] = "Z",
		}
	end
	-- bombers or demonic strength
	Boomkinator:DoTheThing(6, 1, spells[1], (power >=2), 1)
	-- dreadstalkers
	-- check demonic calling
	spellName = GetSpellInfo(spells[12])
	buffName = Boomkinator:BuffSearch("player", spellName)
	Boomkinator:DoTheThing(6, 2, spells[2], (power >= 2 or (power >=1 and buffName)), 1)
	
	-- doom/siphon
	--if spells[3] == spells[13] then -- siphon
	--	Boomkinator:DoTheThing(4, 3, spells[3])
	--else
	--	Boomkinator:DoTheThing(3, 3, "target", spells[3], 1)
	--end
	-- shadow bolt / demon bolt
	spellName = GetSpellInfo(spells[20])
	buffName, buffCount = Boomkinator:BuffSearch("player", spellName)
	if buffName then -- has a core
		-- do not use shadow bolt
		buttons[4]:SetVertexColor(1, 1, 1, 0.25)
		if power < 4 then -- won't overcap shards
			buttons[5]:SetVertexColor(1, 1, 1, 1)
		else -- use HoG first, dummy
			buttons[5]:SetVertexColor(1, 1, 1, 0.25)
		end
		stacks[5]:SetText("x"..buffCount)
	else
		buttons[4]:SetVertexColor(1, 1, 1, 1)
		buttons[5]:SetVertexColor(1, 1, 1, 0.25)
		stacks[5]:SetText("")
	end
	-- hog and soul shards
	Boomkinator:DoTheThing(1, 6, power)
	if power >= 3 then
		buttons[6]:SetVertexColor(1, 1, 1, 1)
	else
		buttons[6]:SetVertexColor(1, 1, 1, 0.25)	
	end
	--nether portal
	-- doom/siphon
	--Boomkinator:DoTheThing(4, 6, spells[6])
	
	-- summon vilefiend
	Boomkinator:DoTheThing(4, 7, spells[7])
	-- summon felguard
	Boomkinator:DoTheThing(4, 8, spells[8])
	-- summon tyrant
	Boomkinator:DoTheThing(4, 9, spells[9])
	--Imp counts
	for k, v in pairs(imps) do
		if imps[k][1] < time then -- expired
			imps[k] = nil
		else 
			impcount = impcount + 1
			if imps[k][1] < impd[1][1] then
				impd[1][1] = imps[k][1]
				impd[1][2] = k
			elseif imps[k][1] < impd[2][1] then
				impd[2][1] = imps[k][1]
				impd[2][2] = k
			end
		end
	end
	
	-- implosion buff tracking
	
	spellName = GetSpellInfo(spells[18])
	buffName, buffCount, buffDuration, buffExpire = Boomkinator:BuffSearch("player", spellName)
	
	if buffName and buffExpire then
		stacks[10]:SetText("x" .. impcount)
		expire = buffExpire - GetTime()
		timers[10]:SetText(Boomkinator:FormatShort(expire))
		if LBG then
			LBG.HideOverlayGlow(btn[10])
		end
	else
		timers[10]:SetText("")
		stacks[10]:SetText("x" .. impcount)
		if impcount >= 3 then
			expire = impd[1][1] - time
			timers[10]:SetText(Boomkinator:FormatShort(expire))
			if LBG then
				LBG.ShowOverlayGlow(btn[10])
			end
		else
			if LBG then
				LBG.HideOverlayGlow(btn[10])
			end
		end
	end
--	buttons[10]:SetVertexColor(1, 1, 1, 0.25)
	
-- custom pet actions
--	spellName = GetSpellInfo(spells[3])
--	spellIcon = select(3, GetSpellInfo(spells[3]))
--	buttons[3]:SetTexture(spellIcon)
--	-- pet cooldown
--	Boomkinator:DoTheThing(4, 3, spells[3])

	if settings.animate then Boomkinator:AnimateShards() end

end
-------------------------------------------------------------------
-- Class Functionality: Warlock Destruction
-------------------------------------------------------------------
function Boomkinator:ButtonsDestruction()
    local power
	-- soul shards
	power = UnitPower("player" , 7)  -- SPELL_POWER_SOUL_SHARDS 
	Boomkinator:DoTheThing(1, 4, power)
	-- chaos bolt
	if power >= 2 then
		buttons[6]:SetVertexColor(1, 1, 1, 1)
	else
		buttons[6]:SetVertexColor(1, 1, 1, 0.3)
	end
	--immolate
	Boomkinator:DoTheThing(3, 1, "target", spells[1], 1, 6)
	-- shadow burn
	Boomkinator:DoTheThing(7, 2, spells[2], 1, true)
	-- soul fire
	Boomkinator:DoTheThing(4, 3, spells[3], true)
	-- conflag
	Boomkinator:DoTheThing(7, 5, spells[5], 1, true)
	-- demonfire
	Boomkinator:DoTheThing(4, 6, spells[6], true)
	-- cataclysm
	Boomkinator:DoTheThing(4, 7, spells[7], true)
	-- doomguard
	Boomkinator:DoTheThing(4, 8, spells[8])	
	-- grimoire
	Boomkinator:DoTheThing(4, 9, spells[9])	
	
	if settings.animate then Boomkinator:AnimateShards() end
	
end
-------------------------------------------------------------------
-- Class Functionality: Rogue Assassination
-------------------------------------------------------------------
function Boomkinator:ButtonsAssassination()
	local power = UnitPower("player", 4) -- combo points
	local energy = UnitPower("player", SPELL_POWER_ENERGY) -- energy
	-- kick
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- rupture
	Boomkinator:DoTheThing(3, 2, "target", spells[2], 1, 7)
	if energy < 25 then
		buttons[2]:SetVertexColor(1, 1, 1, 0.25)
	else
		buttons[2]:SetVertexColor(1, 1, 1, 0.75)
	end
	-- garrote
	Boomkinator:DoTheThing(3, 3, "target", spells[3], 1, 4)
	if energy < 45 then
		buttons[3]:SetVertexColor(1, 1, 1, 0.25)
	else
		buttons[3]:SetVertexColor(1, 1, 1, 0.75)
	end
	-- envenom
	Boomkinator:DoTheThing(6, 4, spells[4], (energy >= 35), 1)
	-- combos for envenom
	Boomkinator:DoTheThing(1, 4, power)
	-- crimson vial
	Boomkinator:DoTheThing(6, 5, spells[5], (energy >=30), 1)
	-- kidney shot
	Boomkinator:DoTheThing(4, 6, spells[6],  1)
	-- exsang
	Boomkinator:DoTheThing(4, 7, spells[7],  1)
	-- vendeta
	Boomkinator:DoTheThing(4, 8, spells[8],  -1)
	-- vanish
	Boomkinator:DoTheThing(4, 9, spells[9],  -1)
end
-------------------------------------------------------------------
-- Class Functionality: Rogue Combat
-------------------------------------------------------------------
function Boomkinator:ButtonsOutlaw()
	local power = UnitPower("player", 4) -- combo points
	local energy = UnitPower("player", SPELL_POWER_ENERGY) -- energy
	local dice = 0
	local keep = 0

	Boomkinator:DoTheThing(1, 4, power)
	-- kick
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- blade flurry
	Boomkinator:DoTheThing(7, 2, spells[2], 1, true)
	-- adrenaline rush
	Boomkinator:DoTheThing(4, 3, spells[3], -1)
	-- opportiunity
	Boomkinator:DoTheThing(2, 4, "player", spells[4], 1, -1)
	-- crimson vial
	Boomkinator:DoTheThing(6, 5, spells[5], (energy >=30), 1)
	-- shot
	Boomkinator:DoTheThing(4, 6, spells[6], 1)
	-- slice and dice	
	Boomkinator:DoTheThing(2, 7, "player", spells[7], -1, -1)
	-- bone analysis
	for i = 1, 40 do
		local buffID = select(10,  UnitBuff("player", i))
		local buffExpire = select(6, UnitBuff("player", i))
		if buffID then
			if dicebox[buffID] then
				expire = buffExpire - GetTime()
				dice = dice + 1
				if (buffID == 193358 or buffID == 193357) then
					keep = 1
				end
				if dice == 1 then
					buttons[8]:SetTexture(dicebox[buffID])
					buttons[8]:SetVertexColor(1, 1, 1, 0.5)
					timers[8]:SetText(Boomkinator:FormatShort(expire))
				end
			end
		else
			break
		end
	end
	
	if dice == 0 then
		buttons[8]:SetTexture(nil)
		timers[8]:SetText("")
		stacks[8]:SetText("")
		
		if LBG then 
			LBG.ShowOverlayGlow(btn[8])
		end
		
	else
		if dice > 1 then
			stacks[8]:SetText("+" .. ( dice - 1) )
			stacks[8]:SetTextColor(0, 1, 1, 1)
		elseif keep == 1 then
			stacks[8]:SetText("++")
			stacks[8]:SetTextColor(0, 1, 1, 1)
		else
			stacks[8]:SetText("")
		end
		
		if LBG then 
			LBG.HideOverlayGlow(btn[8])
		end
		
	end
	-- blade rush
	Boomkinator:DoTheThing(4, 9, spells[9])
	-- ghostly strike
	Boomkinator:DoTheThing(5, 10, "target", spells[10], 1, (energy >=35))
end
-------------------------------------------------------------------
-- Class Functionality: Rogue Subtlety
-------------------------------------------------------------------
function Boomkinator:ButtonsSubtlety()
	local power = UnitPower("player", 4) -- combo points
	local energy = UnitPower("player", SPELL_POWER_ENERGY) -- energy
	-- combos
	Boomkinator:DoTheThing(1, 8, power)
	-- energy
	Boomkinator:DoTheThing(1, 4, energy)
	-- kick
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- shadow dance
	Boomkinator:DoTheThing(7, 2, spells[2], 1, 1)
	-- symbols of death
	Boomkinator:DoTheThing(7, 3, spells[3], 1, 1)
	-- nothing for 4
	
	-- crimson vial
	Boomkinator:DoTheThing(6, 5, spells[5], (energy >=30), 1)
	-- goremaw's bite
	Boomkinator:DoTheThing(4, 6, spells[6])
	-- nightblade
	Boomkinator:DoTheThing(3, 7, "target", spells[7], 1, 4.8)
	-- eviscerate
	Boomkinator:DoTheThing(6, 8, spells[8], (energy >=35 and power >= 5), 1)
	-- shadow blades
	Boomkinator:DoTheThing(4, 9, spells[9])
end
-------------------------------------------------------------------
-- Class Functionality: Druid Moonkin
-------------------------------------------------------------------
function Boomkinator:ButtonsBalance()
	local power = UnitPower("player", SPELL_POWER_ECLIPSE)
	-- moonfire
	Boomkinator:DoTheThing(3, 1, "target", spells[1], 1, 7.3)
	-- stellar flare
	Boomkinator:DoTheThing(3, 2, "target", spells[2], 1, 8)
	-- sun fire
	Boomkinator:DoTheThing(3, 3, "target", spells[3], 1, 6)
	-- lunar strike
	Boomkinator:DoTheThing(2, 4, "player", spells[12], 0, 1, 3)
	buttons[4]:SetVertexColor(1, 1, 1, 0.3)
	-- starsurge
	Boomkinator:DoTheThing(1, 5, power)	
	if power >= 40 then
		buttons[5]:SetVertexColor(1, 1, 1, 0.75)
	else
		buttons[5]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- solar wrath
	Boomkinator:DoTheThing(2, 6, "player", spells[13], 0, 1, 3)
	buttons[6]:SetVertexColor(1, 1, 1, 0.3)
	-- starfall
	if power >= 50 then
		buttons[7]:SetVertexColor(1, 1, 1, 0.75)
	else
		buttons[7]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- alignment
	Boomkinator:DoTheThing(4, 8, spells[8])
	-- new moon dynamic icon
	buttons[9]:SetTexture(select(3, GetSpellInfo(spells[9])))
	Boomkinator:DoTheThing(7, 9, spells[9], 1, true)
end

function Boomkinator:ButtonsBalance_new()
	local power = UnitPower("player", SPELL_POWER_ECLIPSE)
	Boomkinator:Decorator({ ["slot"] = 1,
							["decor"] = "simple_debuff",
							["target"] = "target",
							["spell"] = spells[1],
							["glow"] = true,
							["refresh_timer"] = 7.3})
	Boomkinator:Decorator({ ["slot"] = 2,
							["decor"] = "simple_debuff",
							["target"] = "target",
							["spell"] = spells[2],
							["glow"] = true,
							["refresh_timer"] = 8})
	Boomkinator:Decorator({ ["slot"] = 3,
							["decor"] = "simple_debuff",
							["target"] = "target",
							["spell"] = spells[3],
							["glow"] = true,
							["refresh_timer"] = 6})	
	Boomkinator:Decorator({	["slot"] = 5,
							["decor"] = "power_display",
							["power"] = power})
end
-------------------------------------------------------------------
-- Class Functionality: Druid Restoration
-------------------------------------------------------------------
function Boomkinator:ButtonsRestoration()
	Boomkinator:DoTheThing(2, 1, "target", spells[1], -1)
	Boomkinator:DoTheThing(2, 2, "target", spells[2], -1)
	Boomkinator:DoTheThing(2, 3, "target", spells[3], -1)
	Boomkinator:DoTheThing(7, 5, spells[5], 1, true)
	Boomkinator:DoTheThing(4, 6, spells[6], 1)
	Boomkinator:DoTheThing(4, 7, spells[7], -1)
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	Boomkinator:DoTheThing(4, 9, spells[9], -1)
end
-------------------------------------------------------------------
-- Class Functionality: Druid Feral
-------------------------------------------------------------------
function Boomkinator:ButtonsFeral()
	local power1 = UnitPower("player", SPELL_POWER_ENERGY) -- energy
	local power2 = UnitPower("player", 4) -- combo points
	-- rip
	Boomkinator:DoTheThing(3, 1, "target", spells[1], 1)
	-- rake
	Boomkinator:DoTheThing(3, 2, "target", spells[2], 1)
	-- talons
	-- 2, x, target, spell, coloring_method(1, -1, 0), show_stacks(1, -1), stacks_max
	Boomkinator:DoTheThing(2, 3, "player", spells[3], 0, 1, 2)
	
	-- tiger's
	Boomkinator:DoTheThing(4, 8, spells[8], 1)
	-- berserk
	Boomkinator:DoTheThing(4, 9, spells[9], -1)
end
-------------------------------------------------------------------
-- Class Functionality: Demon Hunter Havoc
-------------------------------------------------------------------
function Boomkinator:ButtonsHavoc()
	-- fury
	local power = UnitPower("player", SPELL_POWER_DEMONIC_FURY)
	Boomkinator:DoTheThing(1, 4, power)
	-- consume magic
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- fel rush
	Boomkinator:DoTheThing(7, 2, spells[2], 1, true)
	-- eye beam
	Boomkinator:DoTheThing(6, 3, spells[3], (power >= 50))
	-- chaos strike
	Boomkinator:DoTheThing(6, 4, spells[4], (power >= 40), 1)
	-- throw glaive
	Boomkinator:DoTheThing(4, 5, spells[5], 1)
	-- blade dance
	Boomkinator:DoTheThing(6, 6, spells[6], (power >= 35), 1)
	-- meta
	Boomkinator:DoTheThing(4, 7, spells[7])
	-- artifact
	Boomkinator:DoTheThing(4, 8, spells[8])
	-- retreat
	Boomkinator:DoTheThing(4, 9, spells[9])
	-- chaos blades / fel barrage
	if slice then
		Boomkinator:DoTheThing(4, 10, spells[10], -1)
	else
		Boomkinator:DoTheThing(7, 10, spells[10], -1, true)
	end
end
-------------------------------------------------------------------
-- Class Functionality: Demon Hunter Vengeance
-------------------------------------------------------------------
function Boomkinator:ButtonsVengeance()
	local power = UnitPower("player", SPELL_POWER_PAIN)
	Boomkinator:DoTheThing(1, 4, power)
	buttons[4]:SetVertexColor(1, 1, 1, 0.25)
	-- consume magic
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- infernal strike
	Boomkinator:DoTheThing(7, 2, spells[2], 1, true)
	-- sigil of flame
	Boomkinator:DoTheThing(4, 3, spells[3], 1)
	-- soul cleave
	Boomkinator:DoTheThing(2, 5, "player", spells[11], 0, 1)
	if power >= 60 then
		buttons[5]:SetVertexColor(1, 1, 1, 0.75)
	elseif power >= 30 then
		buttons[5]:SetVertexColor(1, 1, 1, 0.50)
	else
		buttons[5]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- immolation aura
	Boomkinator:DoTheThing(4, 6, spells[6], 1)
	-- meta
	Boomkinator:DoTheThing(4, 7, spells[7])
	-- demon spikes
	Boomkinator:DoTheThing(7, 8, spells[8], 1, true)
	-- empower wards
	Boomkinator:DoTheThing(4, 9, spells[9], 1)
	-- artifact
	Boomkinator:DoTheThing(4, 10, spells[10])
end
-------------------------------------------------------------------
-- Class Functionality: Hunter Beast Mastery
-------------------------------------------------------------------
function Boomkinator:ButtonsBeastMastery()
	local power = UnitPower("player", SPELL_POWER_FOCUS)
	-- counter shot
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- beast cleave
	Boomkinator:DoTheThing(2, 2, "pet", spells[2], -1, -1, 0)
	-- murder
	Boomkinator:DoTheThing(6, 3, spells[3], (power >= 30), -1)
	-- cobra shot
	Boomkinator:DoTheThing(1, 4, power)
	if power >= 90 then
		buttons[4]:SetVertexColor(1, 1, 1, 0.75)
	elseif power >= 35 then
		buttons[4]:SetVertexColor(1, 1, 1, 0.5)
	else
		buttons[4]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- kill command
	Boomkinator:DoTheThing(6, 5, spells[5], (power >= 30), 1)
	-- barbed shot
	Boomkinator:DoTheThing(7, 6, spells[6], 1, true)
	-- bestial wrath
	Boomkinator:DoTheThing(4, 7, spells[7], -1)
	-- aspect of the wild
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	-- chimaera shot
	Boomkinator:DoTheThing(4, 9, spells[9], 1)
end
-------------------------------------------------------------------
-- Class Functionality: Hunter Marksmanship
-------------------------------------------------------------------
function Boomkinator:ButtonsMarksmanship()
	local power = UnitPower("player", SPELL_POWER_FOCUS)
	Boomkinator:DoTheThing(1, 5, power)
	if power >= 50 then
		buttons[5]:SetVertexColor(1, 1, 1, 0.75)
	else
		buttons[5]:SetVertexColor(1, 1, 1, 0.25)
	end
	--counter shot
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- vulnerable
	Boomkinator:DoTheThing(3, 2, "target", spells[2], -1, 0)
	-- barrage/crows
 	Boomkinator:DoTheThing(6, 3, spells[3], (power >= 30), -1)
	
	-- sidewinders
	Boomkinator:DoTheThing(7, 6, spells[6], -1, true)
	-- artifact
	Boomkinator:DoTheThing(4, 9, spells[9], 1)
end
-------------------------------------------------------------------
-- Class Functionality: Paladin Retribution
-------------------------------------------------------------------
function Boomkinator:ButtonsRetribution()
	local power = UnitPower("player", SPELL_POWER_HOLY_POWER)
	Boomkinator:DoTheThing(1, 7, power)
	-- rebuke
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- exec sentence
	Boomkinator:DoTheThing(6, 2, spells[2], (power >= 3), 1)
	-- vengeance
	Boomkinator:DoTheThing(6, 3, spells[3], (power == 5), 1)
	-- crusader strike
	Boomkinator:DoTheThing(7, 4, spells[4], -1, true)
	-- blade of justice/divine hammer
	Boomkinator:DoTheThing(4, 5, spells[5], 1)
	-- judgement
	Boomkinator:DoTheThing(4, 6, spells[6], 1)
	-- verdict
	Boomkinator:DoTheThing(6, 7, spells[7], (power >= 3), 1)
	-- wrath
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	-- artifact
	Boomkinator:DoTheThing(4, 9, spells[9], 1)
end
-------------------------------------------------------------------
-- Class Functionality: Priest Shadow
-------------------------------------------------------------------
function Boomkinator:ButtonsShadow()
	local power = UnitPower("player", SPELL_POWER_INSANITY)
	local s, _, _, e = Boomkinator:BuffSearch("player", GetSpellInfo(spells[15]))	 -- voidform	
	
	Boomkinator:DoTheThing(1, 5, power)
	-- mind blast
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- shadow word:pain
	Boomkinator:DoTheThing(3, 2, "target", spells[2], 1, 5.3)
	-- vampiric touch
	Boomkinator:DoTheThing(3, 3, "target", spells[3], 1, 7)
	-- dark void
	Boomkinator:DoTheThing(4, 4, spells[4], 1)
	-- void eruption / void bolt
	buttons[5]:SetTexture(select(3, GetSpellInfo(spells[5])))
	Boomkinator:DoTheThing(6, 5, spells[5],    (power >= 90) 
											or (power >= 60 and classFlags["PRIEST"]["Legacy of the Void"])
	                                        or (s and e), 1)
	-- shadow word death
	Boomkinator:DoTheThing(7, 6, spells[6], 1, true)
	if UnitExists("target") and UnitHealth("target")/UnitHealthMax("target") >= 0.2 then
		buttons[6]:SetVertexColor(1, 1, 1, 0.25)	
	end
	-- shadow crash
	Boomkinator:DoTheThing(4, 6, spells[6], 1)
	-- shadow field
	Boomkinator:DoTheThing(4, 7, spells[7], -1)
	-- void torrent
	Boomkinator:DoTheThing(6, 8, spells[8], (s and e), -1)
	-- ascendion or surrender
	Boomkinator:DoTheThing(4, 9, spells[9], -1)
end
-------------------------------------------------------------------
-- Class Functionality: Mage Arcane
-------------------------------------------------------------------
function Boomkinator:ButtonsArcane()
	local power = UnitPower("player", 16) --SPELL_POWER_ARCANE_CHARGES)
	-- counterspell
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	-- arcane power
	Boomkinator:DoTheThing(4, 2, spells[2], -1)
	-- evocation
	Boomkinator:DoTheThing(4, 3, spells[3], -1)
	-- arcane charges
	Boomkinator:DoTheThing(1, 4, power)
	-- charged up/supernova
	Boomkinator:DoTheThing(4, 5, spells[5], 1)
	-- custom
	if classFlags["MAGE"]["Incanter's Flow"] then
		-- buff with stack count
		Boomkinator:DoTheThing(2, 6, "player", spells[6], 0, 1, 6)
	elseif classFlags["MAGE"]["Mirror Image"] then
		-- simple cooldown
		Boomkinator:DoTheThing(4, 6, spells[6], -1)
	elseif classFlags["MAGE"]["Rune of Power"] then
		-- spell charges
		Boomkinator:DoTheThing(7, 6, spells[6], 1, true)
	end
	-- clearcasting buff
	Boomkinator:DoTheThing(2, 7, "player", spells[7], 1, -1)
	-- pom
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	-- arcane orb
	Boomkinator:DoTheThing(4, 9, spells[9], 1)
end
-------------------------------------------------------------------
-- Class Functionality: Warrior Arms
-------------------------------------------------------------------
function Boomkinator:ButtonsArms()
	local power = UnitPower("player", SPELL_POWER_RAGE)
	-- colossus smash debuff
	Boomkinator:DoTheThing(3, 1, "target", spells[1], 1)
	-- mortal strike
	Boomkinator:DoTheThing(4, 2, spells[2], 1)
	-- battle cry
	Boomkinator:DoTheThing(4, 3, spells[3], 1)
	-- slam / rage
	Boomkinator:DoTheThing(1, 4, power)
	-- execute
	if UnitExists("target") and UnitHealth("target")/UnitHealthMax("target") >= 0.2 then
		buttons[5]:SetVertexColor(1, 1, 1, 0.25) -- inactive
	else
		buttons[5]:SetVertexColor(1, 1, 1, 0.75) -- execute away
	end
	-- blade storm
	Boomkinator:DoTheThing(4, 6, spells[6], -1)
	-- artifact
	Boomkinator:DoTheThing(4, 7, spells[7], -1)
end
-------------------------------------------------------------------
-- Class Functionality: Shaman Enhancement
-------------------------------------------------------------------
function Boomkinator:ButtonsEnhancement()
	local power = UnitPower("player", SPELL_POWER_MAELSTROM)
	-- row 1
	Boomkinator:DoTheThing(4, 1, spells[1], 1)
	Boomkinator:DoTheThing(2, 2, "player", spells[2], -1, -1)
	Boomkinator:DoTheThing(2, 3, "player", spells[3], -1, -1)
	if power < 20 then
		buttons[3]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- row 2
	Boomkinator:DoTheThing(1, 4, power)
	Boomkinator:DoTheThing(7, 5, spells[5], 1, true)
	icons[6] = select(3, GetSpellInfo(spells[6]))
	Boomkinator:DoTheThing(6, 6, spells[6], (power >= 30), 1)
	if power < 30 then
		buttons[6]:SetVertexColor(1, 1, 1, 0.25)
	end
	-- row 3
	Boomkinator:DoTheThing(6, 7, spells[7], (power>=20), 1)
	Boomkinator:DoTheThing(4, 8, spells[8], -1)
	Boomkinator:DoTheThing(6, 9, spells[9], (power>=20), 1)
	Boomkinator:DoTheThing(6, 10, spells[10], (power>=20), 1)
end
-------------------------------------------------------------------
-- Class Functionality: Monk Windwalker
-------------------------------------------------------------------
function Boomkinator:ButtonsWindwalker()
end

function Boomkinator:CheckSpells()
	for key, val in pairs(Boomkinator.Spells) do
	   print(key)
	      for key2, val2 in pairs(val) do	
	         if val2 then
		    local s = GetSpellInfo(val2)
		       if not s then
                          print("   " .. val2 .. " " .. "!!!!! nothing !!!!!")
      		       end
		 end
             end
	 end
end
