# OmniCC Changelog

## 8.3.6

* Deferred loading of OmniCC_Config until you either use /omnicc or click on it in interface options
* Updated Ace3 packages for compatibility with World of Warcraft Shadowlands