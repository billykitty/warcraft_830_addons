local AddonName = ...
local L = LibStub("AceLocale-3.0"):NewLocale(AddonName, "ruRU")
if not L then return end

-- effect names
L.Updated = "Обновлено до v%s"
L.Pulse = "Импульс"
L.Shine = "Блеск"