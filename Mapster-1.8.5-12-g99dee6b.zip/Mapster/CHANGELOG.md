# Mapster

## [1.8.5-12-g99dee6b](https://github.com/Nevcairiel/Mapster/tree/99dee6ba2354b253b9ee9d1281d454ebe81ea07a) (2020-08-30)
[Full Changelog](https://github.com/Nevcairiel/Mapster/compare/1.8.5...99dee6ba2354b253b9ee9d1281d454ebe81ea07a) [Previous Releases](https://github.com/Nevcairiel/Mapster/releases)

- Rename PR workflow  
- Add Shadowlands 9.0.1.35707 FogClear data  
- No classic pkgmeta here  
- Fix path to locale script  
- Fix luacheck  
- Increase the max drag size of the map  
    Fixes #24  
- Split FogClear data in two files for Retail and Classic  
- Update TOC  
- Migrate to GitHub Actions  
- Don't adjust the frame position when the window is maximized  
- Fix quest poi scaling on 9.0  
- Add a workaround for the map not opening in combat in some circumstances  
