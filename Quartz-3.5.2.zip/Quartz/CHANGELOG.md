# Quartz

## [3.5.2](https://github.com/Nevcairiel/Quartz/tree/3.5.2) (2019-09-25)
[Full Changelog](https://github.com/Nevcairiel/Quartz/compare/3.5.1...3.5.2)

- Update TOC for 8.2.5  
- Disable EnemyCasts module on Classic, due to zero spellID in CLEU  
